#!/bin/bash

#SBATCH --job-name="Test"
#SBATCH --output="test.%j.%N.out"
#SBATCH --partition=umd-cscdr-cpu
#SBATCH --nodes=1
#SBATCH --ntasks=45
#SBATCH --ntasks-per-core=1
#SBATCH --mem=50G
#SBATCH --time=1:00:00

mpiexec -np 45 ./p3pple_2P
