import sys
import os
import re

## Read INPUT file line by line
## and read in values for the following flags
## NPX
## NPY
## NPZ
## FLUID
## OBSTACLE
filename = "../input"
file = open(filename, 'r')

for line in file:
    if re.search('^\s*(\w+)\s*=\s*(\w+)', line):
        match = re.search('^\s*(\w+)\s*=\s*(\w+)', line)
#         print match.group(1) + ' ' + match.group(2)
        if match.group(1) ==  'FLUID':
            if match.group(2) == 'drop':
                print ('........fluid geometry set to DROP')
                os.system('cp ../misc/initf_drop.cpp ../initf.cpp')
            elif match.group(2) == 'jet':
                print ('........fluid geometry set to JET')
                os.system('cp ../misc/initf_jet.cpp ../initf.cpp')
            elif match.group(2) == 'ray3d':
                print ('........fluid geometry set to Rayleigh-Taylor 3D')
                os.system('cp ../misc/initf_RAY_3D.cpp ../initf.cpp')
            elif match.group(2) == 'rayaxi':
                print ('........fluid geometry set to Rayleigh-Taylor Axi')
                os.system('cp ../misc/initf_RAY_AXI.cpp ../initf.cpp')
            elif match.group(2) == 'dam' :
                print ('..........fluid geometry set to initial dam')
                os.system('cp ../misc/init_dam.cpp ../initf.cpp')
            elif match.group(2) == 'cyl' :
                print ('..........fluid geometry set to cylinder')
                os.system('cp ../misc/initf_cyl.cpp ../initf.cpp')
            elif match.group(2) == 'inc_plane' :
                print ('..........fluid geometry set to inclined plane')
                os.system('cp ../misc/initf_plane.cpp ../initf.cpp')
            elif match.group(2) == 'belfast' :
                print ('..........fluid geometry set to belfast')
                os.system('cp ../misc/initf_belfast.cpp ../initf.cpp')
            elif match.group(2) == 'plug' :
                print ('..........fluid geometry set to plug')
                os.system('cp ../misc/initf_plug.cpp ../initf.cpp')
            elif match.group(2) == 'bubble' :
                print ('..........fluid geometry set to bubble')
                os.system('cp ../misc/initf_bubble.cpp ../initf.cpp')
            else:
                print ('FLUID variable definition error')
        elif match.group(1) == 'OBSTACLE':
            if match.group(2) == 'none':
                print ('........obstacles set to NONE')
                os.system('cp ../misc/obstgen_none.cpp ../obstgen.cpp')
            elif match.group(2) == 'nozzle_01':
                print ('........obstacles set to NOZZLE_O1')
                os.system('cp ../misc/obstgen_nozzle_01.cpp ../obstgen.cpp')
            elif match.group(2) == 'pratt_nozzle':
                print ('........obstacles set to Pratt_Nozzle')
                os.system('cp ../misc/obstgen_Pratt_Nozzle.cpp ../obstgen.cpp')
            elif match.group(2) == 'dihen':
                print ('........obstacles set to DIHEN')
                os.system('cp ../misc/obstgen_DIHEN.cpp ../obstgen.cpp')
            elif match.group(2) == 'pipe':
                print ('........obstacles set to PIPE')
                os.system('cp ../misc/obstgen_pipe.cpp ../obstgen.cpp')
            elif match.group(2) == 'plane':
                print ('........obstacles set to PLANE')
                os.system('cp ../misc/obstgen_plane.cpp ../obstgen.cpp')
            elif match.group(2) == 'jet_pipe':
                print ('........obstacles set to JET_PIPE')
                os.system('cp ../misc/obstgen_jet_pipe.cpp ../obstgen.cpp')
            elif match.group(2) == 'dam_box':
                print ('........obstacles set to DAM_BOX')
                os.system('cp ../misc/obstgen_box.cpp ../obstgen.cpp')
            elif match.group(2) == 'belfast':
                print ('........obstacles set to belfast')
                os.system('cp ../misc/belfast_obst_water.cpp ../obstgen.cpp')
            else:
                print ('OBSTACLE variable definition error')
        elif match.group(1) == 'NPX':
            NPX = match.group(2)
        elif match.group(1) == 'NPY':
            NPY = match.group(2)
        elif match.group(1) == 'NPZ':
            NPZ = match.group(2)

file.close()

line1 = '#define NP_X ' + NPX + '\n'
line2 = '#define NP_Y ' + NPY + '\n'
line3 = '#define NP_Z ' + NPZ + '\n'

lines = [line1, line2, line3]

file1 = open("../headers/size_defs.h",'w')
file1.writelines(lines)
file1.close()

