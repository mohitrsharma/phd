//set the number of partition is each direciton here (NP_X stans for number of
//processors in the x direction, etc. Set all 3 to 0 for auto partition )
#define NP_X 1
#define NP_Y 1
#define NP_Z 1
//Communications routines.

//All interprocessor communications are done using calls to routines in this function.
//It should be possible to replace MPI with another message passing library by reimplementing
//comm.cpp, but it may
