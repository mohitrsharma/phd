#ifndef ripplec_H
#define ripplec_H

extern "C"
{

	// common block for MPI data.
	extern struct
	{
		int OProc[3];
		int MyRank;
		int iError;
		int NProc;
		int Neighbors[6];
		int COMM_CART;
	}mpi;

	extern struct
	{
		int fnx, fny, fnz;
		int fx, fy, fz;
	}dimension;
}

#endif	//ripplec_H