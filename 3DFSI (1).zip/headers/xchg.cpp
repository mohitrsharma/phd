#include "ripple.h"
#include "comm.h"
#include "vector.h"

/******************************************************************************


Subroutine XCHG is called by:	

Subroutine XCHG calls:			

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/


template <class T> void xchg (T* array)
{
	arecvplane<T> (array, 2);
	arecvplane<T> (array, 1);
	sendplane<T> (array, 1);
	sendplane<T> (array, 2);
	arecvspacewait();
	sendwait();
	
	arecvplane<T> (array, 4);
	arecvplane<T> (array, 3);
	sendplane<T> (array, 3);
	sendplane<T> (array, 4);
	arecvspacewait();
	sendwait();

	arecvplane<T> (array, 6);
	arecvplane<T> (array, 5);
	sendplane<T> (array, 5);
	sendplane<T> (array, 6);
	arecvspacewait();
	sendwait();
}
#ifdef rudman_fine
	template <class T> void xchg_f (T *array)
	{
		arecvplane_f<T> (array, 2);
		arecvplane_f<T> (array, 1);
		sendplane_f<T> (array, 1);
		sendplane_f<T> (array, 2);
		arecvspacewait();
		sendwait();
		
		arecvplane_f<T> (array, 4);
		arecvplane_f<T> (array, 3);
		sendplane_f<T> (array, 3);
		sendplane_f<T> (array, 4);
		arecvspacewait();
		sendwait();

		arecvplane_f<T> (array, 6);
		arecvplane_f<T> (array, 5);
		sendplane_f<T> (array, 5);
		sendplane_f<T> (array, 6);
		arecvspacewait();
		sendwait();		
	}
	
template <class T> void xchg2 (T *array, T *gArray, T *pArray)
{
	//see the next routine for comments
	arecvplane2<T> (gArray,2);
	arecvplane2<T> (gArray,1);
	sendplane2<T> (array,gArray,pArray,1);
	sendplane2<T> (array,gArray,pArray,2);
	arecvspacewait();
	sendwait();
	
	arecvplane2<T> (gArray,4);
	arecvplane2<T> (gArray,3);
	sendplane2<T> (array,gArray,pArray,3);
	sendplane2<T> (array,gArray,pArray,4);
	arecvspacewait();
	sendwait();
	
	arecvplane2<T> (gArray,6);
	arecvplane2<T> (gArray,5);
	sendplane2<T> (array,gArray,pArray,5);
	sendplane2<T> (array,gArray,pArray,6);
	arecvspacewait();
	sendwait();
} 

#ifdef __solid
template <class T> void xchg2_f (T *array, T* gArray, T *pArray)
{
	//*array: main array [with 3D cartesian mpi topology]
	//*gArray: stores 2nd layer of ghost cells on six faces [receives]
	//*pArray: is to be decorated with physical cells and ghost cell
	//   	     values before sending [sends]
	
	//xchange information in x-direction
	arecvplane2_f<T> (gArray,2);
	arecvplane2_f<T> (gArray,1);
	sendplane2_f<T> (array,gArray,pArray,1);
	sendplane2_f<T> (array,gArray,pArray,2);
	arecvspacewait();
	sendwait();
	
	//in y-direction
	arecvplane2_f<T> (gArray,4);
	arecvplane2_f<T> (gArray,3);
	sendplane2_f<T> (array,gArray,pArray,3);
	sendplane2_f<T> (array,gArray,pArray,4);
	arecvspacewait();
	sendwait();
	
	//lastly z-direction
	arecvplane2_f<T> (gArray,6);
	arecvplane2_f<T> (gArray,5);
	sendplane2_f<T> (array,gArray,pArray,5);
	sendplane2_f<T> (array,gArray,pArray,6);
	arecvspacewait();
	sendwait();	
}
#endif

#endif

#ifdef bl_mg
template <class T> void xchg_lev (const int &lev, T* array)
{
	arecvplane_lev <T> (lev,array, 2);
	arecvplane_lev <T> (lev,array, 1);
	sendplane_lev <T> (lev,array, 1);
	sendplane_lev <T> (lev,array, 2);
	arecvspacewait();
	sendwait();
	
	arecvplane_lev <T> (lev,array, 4);
	arecvplane_lev <T> (lev,array, 3);
	sendplane_lev <T> (lev,array, 3);
	sendplane_lev <T> (lev,array, 4);
	arecvspacewait();
	sendwait();

	arecvplane_lev <T> (lev,array, 6);
	arecvplane_lev <T> (lev,array, 5);
	sendplane_lev <T> (lev,array, 5);
	sendplane_lev <T> (lev,array, 6);
	arecvspacewait();
	sendwait();
}
#endif
