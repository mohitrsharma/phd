#ifndef SETUP_AIRWAY_TREE_H
#define SETUP_AIRWAY_TREE_H

void initialize_ytube();
void read_airway_tree_input();
template <class T> void rval(const char *value, T &data); 

#endif //SETUP_AIRWAY_TREE_H
