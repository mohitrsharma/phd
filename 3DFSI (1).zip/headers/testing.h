#ifndef TESTING_H
#define TESTING_H

/*****************************************************************
* This is a header file for all the functions used in testing and*
* debugging the code.  All the variables used for testing will be*
* declared first in testing.cpp.  Testing.cpp will be the same as*
* decl.cpp subroutine, except only with subroutines used for     *
* testing.                                                       *
*****************************************************************/


#include <stdio.h>
#include "vector.h"

//obstacle
	typedef struct obst_type
	{
		bool flag_l;
		bool flag_r;
		bool flag_b;
		bool flag_f;
		bool flag_u;
		bool flag_o;
	} _obst;

	typedef struct bubble_type
	{
        bool current;
        bool old;
    } _bubble;

extern "C"
{
	//VARIABLE DECLARATIONS

    //bubble
    extern _bubble *bubble;
    extern double c1,c2;
//	extern struct Profile energy[500];//assume at most 500 lines in "energy.txt" file
    extern double init_pressure, init_volume;
    extern bool BUBBLE;
    extern double BUBBLE_Z_LIM;
    extern double SLOPE;
    extern double ZSTR;
    extern double ZCONE;
    extern double ZOUT;
    extern double NOZZLE_RAD;
    extern double ENRG, Erate, Esum;
    extern double Cv;
    extern double T_INIT,P_INIT, T2;
    extern double GAMMA;
    extern double R_NUCL;
    extern double Pb;//bubble pressure
    extern double Vb;//bubble volume
    extern double Pb_max;
    extern double Td;//time of discharge
    extern double Eff;//efficiency of discharge
    extern int ICL, JCL, KCL;
    extern double jet_energy;
    extern double delta_jet_energy;
	//sphericity
	extern double *f1,*difference, spherity, x_cent, y_cent, z_cent;
	extern double umax, vmax, wmax, rhomax, xmumin;
	extern double umin, vmin, wmin;

	//obstacles
 	extern _obst *obst;


	/*INPUT FLAGS*/
	extern int CGITER;
    extern bool DELTADJ;
    extern bool ICEM;
	extern bool ENERGY;
	extern bool VARPROP;
}
//FUNCTION DECLERATIONS/PROTOTYPES

//for calculating sphericity
void sphericity(double x_cent, double y_cent, double z_cent);
void setf1(double x_cent, double y_cent, double z_cent);
void residual();

//for implementing obstacles
void bcfobs();
void bcobs();
void bdycellobs();
bool isobstsfc(int index);
void tecpo();
void velgradobs(double *util, double *vtil, double *wtil);
void flagproc(void);
void flagobs(void);
void viscousobs(double *, double *, double *);
void normalsobs(double * ftildeobs);
void mollifytobs(double *, double *, double *);
void obstgen(void);

//for overwritting V field
void overwrite_vfield();

//getting max and min of variables
double getmax (double * var, int *ii, int *jj, int *kk);
double getmin (double * var, int *ii, int *jj, int *kk);
void printmax (void);
void printmin (void);
void test_print(void);

/* printing subroutines*/
void saveinput(void);			/* write INPUT to SUMMARY file */
void PrintCycleInfo(void);

//for bubble simulations
void get_bubble_pressure(void);
void init_Pb(void);
void max_Pb(void);
void isentropic_Pb(void);
void bubble_volume(void);
double vel_centline(void);
void energy_balance(void);
double energy_leaving(void);
double energy_leftover(void);
void apply_bubble_pressure(void);
void update_bubble(void);


//dump files
void read_dump(void);

//symetry checking
void sym_check(void);
bool equal(double A, double B, double tol);
void print_27(double *var, int indx);
void make_pressure_symmetric(void);

//boudary conditions
void inflow_L_face(void);
void inflow_R_face(void);
void inflow_B_face(void);
void inflow_F_face(void);
void inflow_U_face(void);
void inflow_O_face(void);

void inflow_L_jet(void);
void inflow_R_jet(void);
void inflow_B_jet(void);
void inflow_F_jet(void);
void inflow_U_jet_Laminar(void);
void inflow_U_jet_Turbulent(void);
void inflow_O_jet(void);

void open_L(void);
void open_R(void);
void open_B(void);
void open_F(void);
void open_U(void);
void open_O(void);

/* other boundary conditions */
void lid_O(void);
void inflow_pratt_nozzle(void);
void outflow_pratt_nozzle(void);
void inflow_DIHEN(void);
void open_U_jet(void);

void NoGhostInfo(Vector *V);
/*working with ICEM*/
void ReadBC(void);
void ReadLIQUID(void);
void ReadSOLID(void);
void OpenFiles(void);
void CloseFiles(void);

/*contact angles*/
void CA_Under(void);
#endif //TESTING_H
