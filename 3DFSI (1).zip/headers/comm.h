#include <mpi.h>
#ifndef comm_H
#define comm_H
//Interface to the MPI library. 
//In the interests of keeping the code semi-portable to other 
//message-passing libraries, interface to message-passing library
//should be done only by calling functions listed here, not 
//directly to the library.

//OPs for reduce operations.
#define OP_SUM (1)
#define OP_MAX (2)
#define OP_MIN (3)

	void initmpi (int argc, char *argv[]);
	void cleanupmpi();
	void adjustdims ();
	void creatempitopology();

	void cartsize (int *x, int *y, int *z);
	int  rankat (const int &x, const int &y, const int &z);
	void coordat (const int &rank, int *x, int *y, int *z);

	void bcastdata (void *data, const int &size);
//	void sync ();
	void bar ();
	void dallreduce (double *sendbuf, double *recvbuf, const int &count, const int &op);
	void dreduce (double *sendbuf, double *recvbuf, const int &count, const int &op);
	void dallreduceloc (double *sendbuf, double *recvbuf, int &x, int &y, int &z, const int &op);
	void dreduceloc (double *sendbuf, double *recvbuf, int &x, int &y, int &z, const int &op);
	void mpigroup (MPI_Group group_name, MPI_Comm group_comm, int n_ranks, int *rank_list);

	void senddata (void *array, const unsigned long &size, const int &destrank, const int &tag);
	template <class T> void sendspace (T *array, const int &nx, const int &ny, const int &nz, const int &x1, const int &y1, const int &z1, const int &x2, const int &y2, const int &z2, const int &destrank, const int &tag);
	void sendwait ();
	void recvdata (void *array, const unsigned long &size, const int &srcrank, const int &tag);
	template <class T> void recvspace (T *array, const int &nx, const int &ny, const int &nz, const int &x1, const int &y1, const int &z1, const int &x2, const int &y2, const int &z2, const int &srcrank, const int &tag);
	template <class T> void sendplane (T *array, const int &direction);
	template <class T> void recvplane (T *array, const int &direction);
	template <class T> void sendplaneex (T *array, const int &direction, const int &rnx, const int &rny, const int &rnz);
	template <class T> void recvplaneex (T *array, const int &direction, const int &rnx, const int &rny, const int &rnz);
	template <class T> void sendplanen (T *array, const int &direction, int Neighbors[6], const int &rnx, const int &rny, const int &rnz);
	template <class T> void recvplanen (T *array, const int &direction, int Neighbors[6], const int &rnx, const int &rny, const int &rnz);
	
	unsigned int wtime ();

	struct doubleuint
	{
		double value;
		unsigned int loc;
	};

	//asynchronous receives

	//void arecvdata (void *array, const int &count, const MPI_Datatype &dt, const int &srcrank, const int &tag);
	template <class T> void arecvplane (T *array, const int &direction);
	template <class T> void arecvplanen (T *array, const int &direction, int Neighbors[6], const int &rnx, const int &rny, const int &rnz);
	template <class T> void arecvplaneex (T *array, const int &direction, const int &rnx, const int &rny, const int &rnz);
	template <class T> int arecvspace (T *array, const int &nx, const int &ny, const int &nz, const int &x1, const int &y1, const int &z1, const int &x2, const int &y2, const int &z2, const int &srcrank, const int &tag);
	template <class T> void tarecvspace2 (const int &Handle, T* dummy);
	void arecvspace2 (const int &Handle);
	void arecvwait();
	void arecvspacewait();

	//Modify tags to try to make every message have almost unique tags
	int SendTag(int Tag, int rank);
	int RecvTag(int Tag, int rank);
	
#ifdef rudman_fine
	template <class T> void sendplane_f(T *array, const int &direction);
	template <class T> void arecvplane_f(T *array, const int &direction);
	template <class T> void arecvplane2(T *array, const int &direction);
	template <class T> void sendplane2(T *array, T *gArray, T *pArray, const int &direction);
//#ifdef __solid
	template <class T> void arecvplanen2(T *array, const int &direction, int Neighbors[6], const int &rnx, const int &rny, const int &rnz);
	template <class T> void arecvplane2_f(T *array, const int &direction);
	template <class T> void sendplane2_f(T *array, T *gArray, T *pArray, const int &direction);
	template <class T> void sendplanen2(T *array, T *gArray, T *pArray, const int &direction, int Neighbors[6], const int &rnx, const int &rny, const int &rnz);
//#endif

#endif

#ifdef bl_mg
	template <class T> void sendplane_lev (const int &lev, T *array, const int &direction);
	template <class T> void arecvplane_lev(const int &lev, T *array, const int &direction);
#endif

#define ANY_SOURCE 	(-2)
#define ANY_TAG     (-1)
#endif //comm_H
