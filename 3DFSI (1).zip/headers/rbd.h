#ifndef rbd_H
#define rbd_H

//RBD format header.

/*
	RBD format:
	Bytes		Description
		8		double time (sec.) of current frame
		4		magic number 0x293D6948
		4		number of variables (#var)
		4		nproc
		4		MyRank
		4		count
		4		nx
		4		ny
		4		nz
		4		oproc[0]
		4		oproc[1]
		4		oproc[2]
	   12		padding
	#var*16		Null-terminated variable names.

	#var*nx
	*ny*nz
	*sizeof(double)
				variable data in double format.
				Data in fortran array format (first index 'moves' fastest)
*/

#define RBDMAGIC 0x293D6948

struct rbd
{
	double time;	//time (sec.) of current frame.
	int magic;		//magic number = 0x293D6948
	int nvar;		//number of variables stored.
	int nproc;		//number of processors for complete data.
	int rank;		//rank number for this processor.
	int count;		//1-based count of output files. 1st frame=1, 2nd frame=2, etc.
	int nx,ny,nz;	//size of field for local processor
	int origin[3];	//global coordinates of local origin (0,0,0).
	int pad[3];
};
struct vname
{
	char name[16];
};

static void initrbd (struct rbd* hdr)
{
	hdr->magic = RBDMAGIC;
	hdr->nvar=0;
	hdr->nproc=1;
	hdr->rank=0;
	hdr->count=1;
	hdr->nx=hdr->ny=hdr->nz=0;
	hdr->origin[0]=hdr->origin[1]=hdr->origin[2]=0;
}

static bool magicok (struct rbd* hdr)
{
	if (hdr->magic != RBDMAGIC) return false;
	return true;
}

#undef RBDMAGIC

#endif //rbd_H


