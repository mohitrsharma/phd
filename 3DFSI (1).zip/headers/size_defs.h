#define NP_X 1
#define NP_Y 1
#define NP_Z 1
