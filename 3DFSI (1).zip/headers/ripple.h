#ifndef ripple_H
#define ripple_H

#include <stdio.h>
#ifdef CUDA
#include "/usr/local/cuda/include/cuda.h"
#include "/usr/local/cuda/include/cuda_runtime.h"
#endif
/******************************************************************************
____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comment
at places in the code where changesa are made

DESCRIPTION											NAME		DATE

-New CUDA functions									S.Codyer	Dec. 19,2011
-New parameters added for variable properties       Babak       Sep. 13,2009
-Created this template for tracking changes			Amirreza	Dec. 2,2005
-Replacing "void setrho()"  with   "void			Amirreza	Dec. 2,2005
 setproperties()".	
-Deleting xmu from "//intvarr"						Amirreza	Dec. 2,2005
-Adding *xmu to "extern double"						Amirreza	Dec. 2,2005
-Adding *rho to "extern double"						Amirreza	Dec. 7,2005
-Adding rhof2,xmuf2 to "//intvarr"					Amirreza 	Dec. 8,2005
_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

//Multidimension arrays use fortran format: 'fastest-moving' dimension
//is the first one.
//a[k][j][i] = a(i+1,j+1,k+1) = a [i + j*nx + k*nx*ny]
#ifdef __cplusplus 
extern "C"
{
#endif
	extern struct _dim
	{
		int nx, ny, nz;
		int fx, fy, fz;
	} dim;

	// common block for MPI data.
	extern struct _mpi
	{
		int OProc[3];
		int MyRank;
		int iError;
		int NProc;
		int Neighbors[6];
		int COMM_CART;
		bool obst_flag;
	}mpi;

	//If any arrays need saving when adjusting processor boundaries (procadj)
	//make sure procadj is modified accordingly.
	//Arrays.

	//All extern variables must be instantiated in decl.cpp.
	//keep the number of arrays to a minimum for memory's sake
	
	//multigrid parameters
	extern int npre,npost,ntop,mgcycles;
	extern double omega,maxres;
	extern int minmgcycles;

	//fldvarr
	extern double *u,*v,*w,*p,*f,*h,*tmp;
	extern double *un,*vn,*wn,*pn,*fn,*hn,*tmpn,*FN;
	extern double *ar,*af,*ao,*ac;
#ifdef CUDA
	extern int *A_row, *A_col;
	extern double *A_val, *jacobi_a, *CUDA_RHS, *X;
#endif	
#ifndef rudman_fine
	extern double *utemp,*vtemp;
#endif
	extern double *xmu,*rho,*cp,*cond,*sigma,*ftemp;
	extern double *avnx,*avny,*avnz;
	extern double *rhorc,*rhofc,*rhooc;
	extern double *gradrox,*gradroy,*gradroz;
	//fine grid arrays
#ifdef rudman_fine
	extern double *f_f,*fn_f,*vol_f,*FN_f;
	//2nd layer of ghost in standard grid
	extern double *f2mx,*f2my,*f2mz,*splanDo2;
	extern int t_prob,t_prob2,p_flg; 
	extern double *temp_f[12];	
	
//*********************************** New Variables **************************//
	extern double *ytubef_field;
	extern double z_upper_bound;
	extern double *plug_f;
	extern double *plug_c;
	
	extern double x_carina;

	extern double z_bifurcation;
	
	extern double parent_radius;
	
	extern double film_thickness;
		
	extern double tube_angle;
	
	extern int plug_number; // these variables are for multiple plug instillation
	extern double plug_frequency;
	extern double plug_i_time; // plug initializing time
	
#ifdef impose_CA
	extern double *f2_arr;
#endif

	// passive scalar transport
	extern double *scal, *crse_scal, *scal_c, *flx;
//***************************************************************************//

#ifdef __solid
	#define NBODY 1 //number of rigid bodies
	extern double *psi,*psi_f,*psin_f,*PSIN_f;
	extern double psivol, pvchgt, rhof0;
	extern double *planDo2,*fvirt_f,*fvirt2_f,*avnx2_f,*avny2_f,*avnz2_f;
	extern int *planIn2, *triple_flg,*triple_flg2, *neigh_triple;
	extern double *psi2_f,*f2_f;
	extern double *psi2mx,*psi2my,*psi2mz;
	
//*********************************** New Variables **************************//
	extern double *alpha_f;
	extern double global_velocity;

	extern double *g_fvirt;
	
	extern double time_1, time_2;
	
#ifdef print_norm
	extern double *global_kappa;
	extern double *g_normx, *g_normy, *g_normz;
	
#endif print_norm
//****************************************************************************//

	//structure definitions
	typedef struct {
		double x;
		double y;
		double z;
	} st_point;
	
	typedef struct {
		int l[10]; //id of vertices (with intersections) to be stored
		int tot_l; //total number of intersections with face
		int n; // # of vertices in the face
	      st_point vert[10]; //maxm. of 5 possible [6 for two interface cuts]
					//last 2 entries points on the interface
		st_point nor; //normal this particular face
	} st_face;
	
	typedef struct {
		int n; // # of faces of a polyhedron
		st_face face[10]; //maxm. of 7 faces [8 in case of two interfaces]
					//last entry is actual interface
	} st_polyhedron;
	
	typedef struct {
	      double x,y,z,w; 
	} Quat;
	extern st_point t_cent, t_nor; // for special test-cases 
	extern st_point Theta[NBODY+1], Omega[NBODY+1], Omegan[NBODY+1], Cent[NBODY+1];
	extern st_point Mvert[NBODY+1],Pvert[NBODY+1];
	extern double rig_U[NBODY+1][4], rig_Un[NBODY+1][4];
	extern int i_max[NBODY+1],i_min[NBODY+1],j_min[NBODY+1],j_max[NBODY+1],k_min[NBODY+1],k_max[NBODY+1];
	extern int ZDOF[NBODY+1][7], IPRES[NBODY+1];
#endif
//------------------------alphabetic order---------------------------------
	void initf_f();
	void bcf_f();
	void bcfobs_f();
	void bcvel();
	//void calc_cross_visc(double *fvar);
	void fine2stnd();
	void *memalloc2(int nx, int ny, int nz, int elsz);
	void *memalloc3(int nx, int ny, int nz, int elsz);
	void normals_f();
	void normalsobs_f(double *ftildeobs_f);
	void normals_from_fine(double *cnx, double *cny, double *cnz,
					   double *fnx, double *fny, double *fnz);
	double recons_2P(double xn, double yn, double zn, double fijkd, double epsi, int ijkd, int ijka);
	void stag_den();
	void stag_vol();
	void tecpf_f();
	void velgrad_new();
	void vofdly_f();
	void voferr_f();
//------------------------alphabetic order ------------------------------
#ifdef __solid
	void init_ytube(st_point *dimen1, st_point *theta1, double *rad1_o, double *rad1_i, double height1, st_point *dimen2, st_point *theta2, double *rad2_o, double *rad2_i, double height2, st_point *dimen3, double *rad3_o, double *rad3_i, double height3);
	void area_2(double fijk, int i, int j, int k, int ijk, st_point *nor, st_point *cent, st_point *a);
	void bcfvirt_f();
	void bcpsi();
	void bcpsi_f();
	void bcpsiobs_f();
	void normalspsiobs_f(double *psiavnx_f, double *psiavny_f, double *psiavnz_f);
	double calc_poly_vol (st_polyhedron *ptr); 
	void calc_polyhedron_centroid (int i, int j, int k, st_polyhedron *ptr, st_point *cent, double *tot_vol);
	void calc_solid_mass();
	void calc_total_fluid(double *f_total);
	void clean_VOF();
	void const_com_polyhedron(st_polyhedron *sim_ptr, st_polyhedron *com_ptr, st_point *cent, st_point *nor, int srt);
	void const_sim_polyhedron(st_polyhedron *ptr);
	void corr_initf();
	void crossProduct(double *a, double *b, double *c);
	void cube_plane_int(double *f_p, st_point *nor, st_point *cent, int i, int j, int k, int sp);
	void density_correction(double velocity);
	double largest_solid_velocity();
	int detect_air_film(); 
	void epsi1_sol (int i, int j, int k, int loop, double vel, double *epsi1);
	void equate_pt(st_point *pt1, st_point *pt2);
	void init_inc_rect (st_point *pcent, st_point *dimen, double phi0);
	void init_sol_cyl (st_point *cent, double *rad);
	void init_sol_cube(st_point *cent, st_point *dimen);
	void initpsi_f(st_point *cent, double *rad);
	void initvoidpsi_f();
	void make_unity(st_point *nor);
	void mod_xmu();
	void modify_boundary(int nsubcyc, st_point *cent, st_point *nor);
	void modify_boundary2(int nsubcyc, st_point *cent, double *theta);
	void multi_solid_ancillary();
	void Ncalc_psi_centroid(st_point *cent, int bindx);
	void normals_alpha_f();
	void Nrigid_body_vel3(int bindx);
	void Nset_rigid_body_vel(int loop, int bindx);
	void Nsol_bounding_box(int bindx);
	void normals_fvirt();
	void normalspsi_f();
	void printError(int nsubcyc);
	void printPolyVertices(st_polyhedron *ptr);
	void psierr_f();
	void psifine2stnd();
	double psi_ucv(int i, int j, int k);
	double psi_vcv(int i, int j, int k);
	double psi_wcv(int i, int j, int k);
	void recons_contact_line();
	void scale_psi_cells(int bindx);
	void setup_rigid_body();
	void sol_centroid (int i, int j, int k, st_point *v0, double *voli);
#endif
//---------------------------------------------------------------------
#endif
	//fldvari
	extern int *nf, *kbot, *ktop;	//kbot[ny][nx], ktop[ny][nx]

	//meshr
	extern double *x,*y,*z;					//x[nx], y[ny], z[nz]
	extern double *xi,*yj,*zk;				//xi[nx], yj[ny], zk[nz]
	extern double *delx,*dely,*delz;		//delx[nx], dely[ny], delz[nz]
	extern double *rdx,*rdy,*rdz;			//rdx[nx], rdy[ny], rdz[nz]
	extern double *delxl,*delyb,*delzu;		//delxl[nx],delyb[ny],delzu[nz]
	extern double *rdelxl,*rdelyb,*rdelzu;	//rdelxl[nx],rdelyb[ny],rdelzu[nz]
	extern double *vol;						//vol[nz][ny][nx]
	extern double xe,ye,ze;
	extern double dxmn,dymn,dzmn,xmn,ymn,zmn;

	//meshi
	extern int nxmn,nymn,nzmn,inside[7];

	//intvarr
	extern double
		delt,t,prtdt,twprt,pltdt,twplt,twfin,xmuf1,
		dtend,dmpdt,twdmp,rhof1,vchgt,stf1,gx,gy,gz,uf1,
		vf1,wf1,uf2,vf2,wf2,flgc,xmin,xmax,ymin,ymax,zmin,
		zmax,tke,dudr,dudl,dudt,dudb,dudo,dudu,dvdr,
		dvdl,dvdt,dvdb,dvdo,dvdu,dwdr,dwdl,dwdt,dwdb,dwdo,
		dwdu,tquit,tbeg,dxmin,dymin,dzmin,psat,
		dtvis,dtvist,dtsft,dtsftt,dtdif,dtdift,
		deltold,con,fcvlim,cangler,canglel,
		canglet,cangleb,cangleo,cangleu,xmv,ymv,zmv,
		frctn,radius,xcent,ycent,zcent,fvol,spr,
		sprl,sprr,datadt,twdata,rhof2,xmuf2,
		condf1,condf2,cpf1,cpf2,h0f2,tif1,tif2,
		bcvl,bcvr,bcvb,bcvf,bcvu,bcvo;

	//varprop
	extern int nFLUID1, nFLUID2;
	extern double FLUID1_T[20], FLUID1_xmu[20], FLUID1_st[20], FLUID1_Cp[20], FLUID1_K[20];
	extern double FLUID2_T[20], FLUID2_xmu[20], FLUID2_st[20], FLUID2_Cp[20], FLUID2_K[20];
	
	//intvari
	extern int
		ncyc,kl,kr,kb,kf,ko,ku,iter,
		kel,ker,keb,kef,keu,keo,
		nocon,nflgc,liter,itc,jtc,ktc,ivis,jvis,
		kvis,isft,jsft,ksft,idif,jdif,kdif,ibcflg,
		ica,iplot,idump,islice,iar,istart;

	//constr
	#define em6 (1.0e-6)
	#define tiny (1.0e-25)
	extern double
		emf,emf1,em10,ep10,em6p1,em61,
		pi,rpd,pi2;

	//frsrfr
	extern double frsurf;

	//frsrfi
	extern int *ijkfr;		//ijkfr[nz][ny][nx]

	//labelc
	extern char idt[3];

	//arear
	extern double
		n1,n2,n3,pcorner[8],pp[6],qq[6],rr[6],
		xco[6],yco[6],zco[6];

	//temp
	extern double *temp[25];
	//bool sflag = true;

	//Function declarations:
	void arraysalloc(int sx, int sy, int sz);
	void arraysfree();
	void* memalloc (int nx, int ny, int nz, int elsz);
	void memfree (void *p);
	void procadj (int dir, int index, int amount);
	void rinput();

	void setup();
	bool newcyc();	//returns true if we want to quit.
	void convect();
	void tension();		//surface tension.
	void implctp();		//Implicitly solve for pressure
	void diffusion();	//Solves diffusion part of the energy equation
	void vofdly();		//VOF
	void viscous();

#ifdef bl_mg
	#define MGLEVS 5 //make sure each processor has # cells which is 
	                 //a factor of 32 (2^5) in each direction
	
	//first the variables
	extern double *mg_cc[MGLEVS+1], *mg_dd[MGLEVS+1], *mg_uu[MGLEVS];
	extern double *mg_ss[MGLEVS+1], *mg_ec[MGLEVS+1][4];
	extern int mg_bnd[MGLEVS+1][4];
	
	extern int mg_nu1,mg_nu2,mg_max_iter,mg_bottom_max_iter;
	extern double mg_eps,mg_abs_eps,mg_bottom_solve_eps,mg_dh[MGLEVS+1][4];
	
	//now the functions
	void mg_param_init();
	void bl_mg_memalloc();
	void bl_mg_main();
	void mg_boxlib();
#endif

	//cuda - S.Codyer
#ifdef CUDA
	void cgitj_gpu(double *A_val, int *A_row, int *A_col, double *a, int nm_gpu, int non_zeros, double *x, double *y, int *istop, double ercg);
	__global__ void GhostRMV(double *V, int a, int b, int c, int d, int e, int f);
	__global__ void JPrecon(double *J, double* V1, double* V2);
#endif

	void meshset();
	void aset();
	void initf();
	void initenrg();
//ben	void limit();
	void voferr();
	void dt();
	void bcf();
	void setproperties();
	void enthtmp();
	void fixtmp();
	void initreg();
	void normals();
	void setnf();
	void bc();
	void bce();
	void global();
	void prtplt (int n);
	void tecpf();
	//void tecpo();
	void dump();
	void deltadj();
	void area (int ijk, double *face, double *xd, double *yd, double *zd);
	void mollifyt();
	void velgrad();
	void bdycell();
	void accel();
	double cangle (int iside, int ii, int jj, int kk);
	double kface (int C1INDX, int C2INDX);
	double interp (double *array1, double *array2, double value1);

/*last 3 functions are for calculating sphericity:  BEN
	void sphericity(double x_cent, double y_cent, double z_cent);
	void setf1(double x_cent, double y_cent, double z_cent);
	double residual();
	//obstacles
	void bcfobs();
	void bcobs();
	void bdycellobs();
	bool isobstsfc(int index);
*/	//multigrid
	bool restrict(int level, double **anew, double *a, int *sizeofanew, int nx, int ny, int nz);
	bool restrictcoef(int level, int nx, int ny, int nz);
	bool interpolate(int level, double**anew, double *a, int *sizeofanew, int nx, int ny, int nz);
	void gs(double *p, double *rhs, double *a, double *bl, double *br, double *bb, double *bt, double *bu, double *bo, int nx, int ny, int nz, struct _ginfo &info);
	void residue (double**res, int *sizeofres, double *p, double *a, double *rhs, double *bl, double *br, double *bb, double *bt, double *bu, double *bo, int nx, int ny, int nz);
	void resize (double **a, int *asize, int size);
	void mg(double *p, double *rhs, double *a, double *bl, double *br, double *bb, double *bt, double *bu, double *bo );
	void mgv(double *p, double *rhs, double *a, double *bl, double *br, double *bb, double *bt, double *bu, double *bo );
	double normres (double *res, double *rhs, double *a, int nx, int ny, int nz);

	static inline double CUBE(double x)
	{
		return x*x*x;
	}
	static inline double SQUARE(double x)
	{
		return x*x;
	}

	double bcvof(int i, int j, int k, int iface);
	//Load Balancing:
	typedef unsigned int ltime_t;
	extern ltime_t LTime;	//Local time for one iteration.
	void LoadBalance();		//Perform load balancing.

	//File IO
	struct _files		//Must contain only FILE*s. Else, change file closing code.
	{
		FILE *input, *error, *out, *sphere, *summary;
	}extern files;			//Instantiated in decl.cpp



#ifdef __cplusplus 
}	//extern "C"
#endif

	template <class T> static void xchg(T *array);
#ifdef rudman_fine
	template <class T> static void xchg_f(T *array);
	template <class T> void xchg2 (T *array, T *gArray, T *pArray);
#ifdef __solid
	template <class T> void xchg2_f (T *array, T* gArray, T *pArray);
#endif

#endif

#ifdef bl_mg
	template <class T> static void xchg_lev(const int &lev, T *array);
#endif

	#include "xchg.cpp"

//Covenience:
#define IND(X,Y,Z) ((X)+((Y)+(Z)*dim.ny)*dim.nx)	//Index for accessing NX*NY*NZ arrays.
#define NX dim.nx
#define NY dim.ny
#define NZ dim.nz
#define imax dim.nx
#define jmax dim.ny
#define kmax dim.nz
#define ijmax dim.nx*dim.ny
#define im1 (NX-1)
#define jm1 (NY-1)
#define km1 (NZ-1)
#define im2 (NX-2)
#define jm2 (NY-2)
#define km2 (NZ-2)

//laziness...
#define IJK IND(i,j,k)

#define IJKM IND(i,j,k-1)
#define IPJK IND(i+1,j,k)
#define IJPK IND(i,j+1,k)
#define IMJK IND(i-1,j,k)
#define IJMK IND(i,j-1,k)
#define IJKP IND(i,j,k+1)

#define IMJKM IND(i-1,j,k-1)
#define IPJKM IND(i+1,j,k-1)
#define IJMKM IND(i,j-1,k-1)
#define IJPKM IND(i,j+1,k-1)
#define IPJPK IND(i+1,j+1,k)
#define IMJMK IND(i-1,j-1,k)
#define IMJPK IND(i-1,j+1,k)
#define IPJMK IND(i+1,j-1,k)
#define IMJKP IND(i-1,j,k+1)
#define IPJKP IND(i+1,j,k+1)
#define IJMKP IND(i,j-1,k+1)
#define IJPKP IND(i,j+1,k+1)

#define IMJMKM IND(i-1,j-1,k-1)
#define IPJMKM IND(i+1,j-1,k-1)
#define IMJPKM IND(i-1,j+1,k-1)
#define IPJPKM IND(i+1,j+1,k-1)
#define IMJMKP IND(i-1,j-1,k+1)
#define IPJMKP IND(i+1,j-1,k+1)
#define IMJPKP IND(i-1,j+1,k+1)
#define IPJPKP IND(i+1,j+1,k+1)

//rudman_fine

#ifdef rudman_fine
	
	#define IND_f(X,Y,Z) ((X)+((Y)+(Z)*(2*dim.ny-2))*(2*dim.nx-2)) 
	#define NX_f (2*dim.nx-2)
	#define NY_f (2*dim.ny-2)
	#define NZ_f (2*dim.nz-2)
	#define imax_f (2*dim.nx-2)
	#define jmax_f (2*dim.ny-2)
	#define kmax_f (2*dim.nz-2)
	#define ijmax_f ((2*dim.nx-2)*(2*dim.ny-2))
	#define im1_f (NX_f-1)
	#define jm1_f (NY_f-1)
	#define km1_f (NZ_f-1)
	#define im2_f (NX_f-2)
	#define jm2_f (NY_f-2)
	#define km2_f (NZ_f-2)
	
	#define IJK_f IND_f(i,j,k)
	
	#define IJKM_f IND_f(i,j,k-1)
	#define IPJK_f IND_f(i+1,j,k)
	#define IJPK_f IND_f(i,j+1,k)
	#define IMJK_f IND_f(i-1,j,k)
	#define IJMK_f IND_f(i,j-1,k)
	#define IJKP_f IND_f(i,j,k+1)

	#define IMJKM_f IND_f(i-1,j,k-1)
	#define IPJKM_f IND_f(i+1,j,k-1)
	#define IJMKM_f IND_f(i,j-1,k-1)
	#define IJPKM_f IND_f(i,j+1,k-1)
	#define IPJPK_f IND_f(i+1,j+1,k)
	#define IMJMK_f IND_f(i-1,j-1,k)
	#define IMJPK_f IND_f(i-1,j+1,k)
	#define IPJMK_f IND_f(i+1,j-1,k)
	#define IMJKP_f IND_f(i-1,j,k+1)
	#define IPJKP_f IND_f(i+1,j,k+1)
	#define IJMKP_f IND_f(i,j-1,k+1)
	#define IJPKP_f IND_f(i,j+1,k+1)

	#define IMJMKM_f IND_f(i-1,j-1,k-1)
	#define IPJMKM_f IND_f(i+1,j-1,k-1)
	#define IMJPKM_f IND_f(i-1,j+1,k-1)
	#define IPJPKM_f IND_f(i+1,j+1,k-1)
	#define IMJMKP_f IND_f(i-1,j-1,k+1)
	#define IPJMKP_f IND_f(i+1,j-1,k+1)
	#define IMJPKP_f IND_f(i-1,j+1,k+1)
	#define IPJPKP_f IND_f(i+1,j+1,k+1)
#endif

#define MAX(A,B) ((A>B)?(A):(B))
#define MIN(A,B) ((A<B)?(A):(B))

#define SIGN(A) (((A)<0)?(-1):(1))

#endif	//ripple_H
