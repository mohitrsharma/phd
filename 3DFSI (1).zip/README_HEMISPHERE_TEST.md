# Hemisphere-Planar Interface Test Case

## Problem Description

This test case simulates a static configuration of a hemisphere intersected by a planar interface. The setup consists of:

- A hemispherical solid with radius 5/32 (0.15625) centered at (0.3125, 0.3125, 0)
- A planar interface with normal vector (1/√2, 0, 1/√2), creating a 45-degree angle with the z-axis
- Computational domain size of 0.625 × 0.625 × 0.3125
- Grid resolution of 32 × 32 × 16 cells

The test case validates volume fraction calculations and interface reconstruction accuracy, focusing on the three-phase contact line where solid, liquid, and gas phases meet.

## Files Modified

1. **`input`** - Configuration file with domain and simulation parameters
   - Domain size: 0.625 × 0.625 × 0.3125
   - Grid resolution: 32 × 32 × 16
   - Fluid properties: density, viscosity, surface tension
   - Simulation parameters: time step, cycle count

2. **`src/initf.cpp`** - Custom initialization code for the hemisphere and planar interface
   - Uses `init_sol_weight_quater()` function to initialize the hemisphere
   - Creates planar interface with `cube_plane_int()` function
   - Handles three-phase intersections properly

## Setup Instructions for Cluster Environment

### Prerequisites
- MPI implementation (MPICH or OpenMPI)
- C/C++ compiler (gcc recommended)
- Slurm workload manager for job submission
- ParaView for visualization (optional)

### Steps to Run the Test

1. **Prepare the environment**:
   - Upload the modified files to your cluster
   - Ensure the appropriate modules are available (gcc, openmpi)

2. **Submit the job**:
   - Use the provided sbatch script
   ```
   sbatch run_hemisphere_test.sh
   ```

3. **Monitor the job**:
   ```
   squeue -u $USER
   ```

4. **Check output**:
   - Examine the log files: `hemisphere_test_*.out` and `hemisphere_test_*.err`
   - Check volume data: `fluid_volume.txt`
   - Visualize results: download `*.vtk` files and open in ParaView

## Implementation Details

### Solid Initialization (Hemisphere)
- The hemisphere is initialized using the `init_sol_weight_quater()` function
- This function calculates accurate volume fractions for the hemisphere with subcell resolution
- Only the lower half of the sphere (z ≤ 0) is considered to create the hemisphere

### Fluid Initialization (Planar Interface)
- The planar interface is initialized using the `cube_plane_int()` function
- This function calculates the exact volume fraction in each cell accounting for solid presence
- The function handles the three-phase intersection points properly

### Key Functions Used
- `init_sol_weight_quater()`: Creates a solid hemisphere with subcell resolution
- `cube_plane_int()`: Calculates plane-cell intersections accounting for solid presence
- `fine2stnd()`: Converts fine grid values to standard grid for visualization

## Expected Results

### Visual Features
- A hemispherical solid at the bottom of the domain
- A planar interface intersecting the hemisphere
- A circular contact line where all three phases meet

### Quantitative Validation
- The total fluid volume is reported in `fluid_volume.txt`
- The contact line should form a perfect circle in the x-y plane
- Interface normals should be accurate at the contact line

## Troubleshooting

- **Module loading issues**: Adjust module names in `run_hemisphere_test.sh` to match your cluster
- **Compilation errors**: Check compiler flags and ensure FINE_GRID flag is properly set
- **Runtime errors**: Verify input parameters are correct
- **Visualization issues**: Try different isosurface values (0.5 is standard)

## Notes

- This is a static test case - the interfaces do not move
- No fluid dynamics are simulated
- The test primarily validates the three-phase reconstruction algorithms
- This simplified approach leverages existing functions in the codebase rather than reimplementing the geometry 