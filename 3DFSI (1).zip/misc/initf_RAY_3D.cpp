#include "ripple.h"
#include <stdlib.h>
#include <time.h>
#include "testing.h"

/******************************************************************************
This subroutine INITF initializes vof field for Rayleigh-Taylor instability
problem

Subroutine INITF is called by:	SETUP

Subroutine INITF calls:	****

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

- Crated this subroutine for initializing			Babak		Oct 21 2009
  Rayleigh�Taylor instability problem		

- Created this template for tracking changes		Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

void initf()
{
	double tx, tz, txm, tzm, xfine, zfine; //temporary x,y,z of ijk
	double ftotal=0.0;
	double f_total = 0.0;
	int i,j,k;

	//loop that initialized the f field of a droplet
	for (i=1;i<=im1;i++)
		for (j=1;j<=jm1;j++)
			for (k=1;k<=km1;k++)
			{
				//cell is empty?
				tx = x[i];
				tz = z[k];
				txm = x[i-1];
				tzm = z[k-1];

				//goto cube;
				if (tz < (ze*(0.5-0.0125*cos(pi*xi[i]/xe))))
					f[IJK] = 0.0;
				//cell is full?
				else if (tzm > (ze*(0.5-0.0125*cos(pi*xi[i]/xe))))
					f[IJK] = 1.0;
	
				//cell neither empty nor full
				else
				{
					f[IJK] = 0.0;
					for (int l=0;l<25;l++)
						for (int m=0;m<25;m++)
							for (int n=0;n<25;n++)
							{
								xfine = txm+(l-0.5)/25.0*delx[i];
								zfine = tzm+n/25.0*delz[k];
								if (zfine > (ze*(0.5-0.0125*cos(pi*xfine/xe))))
								f[IJK]+= 6.4e-5;
							}
				}
				
				ftotal += f[IJK]*vol[IJK];
				f_total += f[IJK];
			}

	//fprintf (files.out, "initial f vs exact: %12.5f\n", ftotal/(4.0/3.0*pi*CUBE(radius)));
	fprintf (files.sphere, "f_volume = %12.4e, and ftotal = %12.4e\n", ftotal, f_total);
	
}
