#include "ripple.h"
#include "TECIO.h"
#include <stdio.h>

extern void pfvar(double *a, int nx, int ny, int nz)
{
	static int pfvc=0;
	char fname[256];
	pfvc++;
	sprintf (fname, "v%02d%05d.plt",mpi.MyRank,pfvc);

	int Debug=0;
	int VIsDouble=1;

	TECINI ("fname", "X Y Z A", fname, ".", &Debug, &VIsDouble);
	TECZNE ("1", &nx, &ny, &nz, "POINT", "");
	
	int i,j,k,n=1;
	int c=0;
	for (k=0;k<nz;k++)
		for (j=0;j<ny;j++)
			for (i=0;i<nx;i++)
			{
				double di = i, dj=j, dk=k;
				TECDAT (&n, &di, &VIsDouble);
				TECDAT (&n, &dj, &VIsDouble);
				TECDAT (&n, &dk, &VIsDouble);
				TECDAT (&n, &a[c++], &VIsDouble);
			}
	TECEND();
}
