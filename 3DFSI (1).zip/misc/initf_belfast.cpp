#include "ripple.h"
#include <stdlib.h>
#include <time.h>
#include "testing.h"
/************************************************************************
*This subroutine initializes the f-field for dam-break problem
* 
*************************************************************************/

void initf()
{
	//stub function... doesn't do anything
}

#ifdef rudman_fine

void initf_f() {
	int i,j,k,ti,tj,tk;
	
	double tx,ty,tz,txm,tym,tzm;
	double xl,xr,yb,yf,zu,zo,p_vol;
	
	double ftotal=0.0;
	double f_total=0.0;
	
	//limits of the cube
	xl=0.0; xr=xe;
	yb=0.0; yf=ye;
	zu=0.0; zo=2.5e-3;
	
	for(i=1;i<im1_f;i++)
	 for(j=1;j<jm1_f;j++)
	  for(k=1;k<km1_f;k++) {
		  tx = (i+2*mpi.OProc[0])*0.5e0*delx[1];
		  ty = (j+2*mpi.OProc[1])*0.5e0*dely[1];
		  tz = (k+2*mpi.OProc[2])*0.5e0*delz[1];
		  
		  ti=(i+1)/2; tj=(j+1)/2; tk=(k+1)/2;
 		  
		  txm = tx - 0.5e0*delx[1];
		  tym = ty - 0.5e0*dely[1];
		  tzm = tz - 0.5e0*delz[1];
		  
		  p_vol = 0.e0;
		  if(txm>=xl && tx<=xr) p_vol = 1.e0;
		  else if(txm<xl && tx>xl) p_vol = (tx-xl)/(0.5e0*delx[1]);
		  else if(txm<xr && tx>xr) p_vol = (xr-txm)/(0.5e0*delx[1]);
				
		  //y-direction
		  if(tym>=yb && ty<=yf) p_vol *=1.e0;
		  else if(tym<yb && ty>yb) p_vol *= (ty-yb)/(0.5e0*dely[1]);
		  else if(tym<yf && ty>yf) p_vol *= (yf-tym)/(0.5e0*dely[1]);
		  else p_vol *= 0.e0;
				
		  //z-direction
		  if(tzm>=zu && tz<=zo) p_vol *=1.e0;
		  else if(tzm<zu && tz>zu) p_vol *= (tz-zu)/(0.5e0*delz[1]);
		  else if(tzm<zo && tz>zo) p_vol *= (zo-tzm)/(0.5e0*delz[1]);
		  else p_vol *= 0.e0;
				
		  ftotal += p_vol*vol_f[IJK_f];
		  f_total += p_vol;
		  		
		  if(ac[IND(ti,tj,tk)]<em6) continue;
		  f_f[IJK_f] += p_vol; //for multiple solid bodies
	  }
	  fprintf(files.sphere, "f_volume=%12.8e, and ftotal=%12.8e\n",ftotal,f_total);
}

#endif
