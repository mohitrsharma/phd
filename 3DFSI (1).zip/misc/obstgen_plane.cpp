#include "ripple.h"
#include "testing.h"
/*============================================================================*/
#define PLANE_ZTOP 1.0e-3
#define STEP 1

/******************************************************************************
this subroutine generates an obstacles plane on the bottom face.

This subroutine is copied into OBSTGEN.CPP when OBSTACLE flag in "input" 
file is set to "plane"


Subroutine OBSTGEN is called by:	SETUP

Subroutine OBSTGEN calls:

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE

-implement obstacles								Ben			April 21 2005

*******************************************************************************/

void obstgen()
{
	int i,j,k;
	for (k = 0; k < kmax; k++)
		for (j = 0; j < jmax; j++)
			for (i = 0; i < imax; i++)
			{
				if ( z[k] <= PLANE_ZTOP && STEP)
				{
					ac[IJK] = 0.0;//cell is obst.
					ar[IJK] = 0.0;
					af[IJK] = 0.0;
					ao[IJK] = 0.0;
				}
				else
				{
					ac[IJK] = 1.0;//cell is not obst.
					ar[IJK] = 1.0;
					af[IJK] = 1.0;
					ao[IJK] = 1.0;
				}
			}
			/* Print obstacle file and flag processors having obstacle cells */
			if (mpi.NProc < 2) tecpo();		/* print obstacle.rbd file */

			flagproc();         			/* flag processors which have obstacle surface cells in
											* their local domain */
			if (mpi.obst_flag)
				flagobs();	    			/* flag obtacle surface cells according
											* to their orientation to the fluid cells */

}
