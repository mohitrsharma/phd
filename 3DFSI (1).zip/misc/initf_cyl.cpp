#include "ripple.h"
#include <stdlib.h>
#include <time.h>
#include "testing.h"
/************************************************************************
*This subroutine initializes the f-field for a cylinder; the center of 
* cylinder is xcent ycent from input file
*************************************************************************/
void initf()
{
	double tx, ty, txm, tym, tzm;
	double r2=radius*radius;
	double ftotal=0.0;
	double f_total=0.0;
	
	int i,j,k;
	//loop thta initialized f-field for a cylinder
	for(i=1;i<im1;i++)
		for(j=1;j<jm1;j++)
			for(k=1;k<km1;k++) {
				//cell is empty?
				tx = (i+mpi.OProc[0])*delx[1]; //global coordinates in fine-grid
				ty = (j+mpi.OProc[1])*dely[1];
				
				txm = tx-delx[1];
				tym = ty-dely[1];
				
				//goto cube;
				if ( MIN(SQUARE(txm-xcent), SQUARE(tx-xcent))
					+MIN(SQUARE(tym-ycent), SQUARE(ty-ycent))
					>= r2)
					f[IJK]=0;
				//cell is full?
				else if ( MAX(SQUARE(txm-xcent), SQUARE(tx-xcent))
					+MAX(SQUARE(tym-ycent), SQUARE(ty-ycent))
					<= r2)
					f[IJK]=1.0;
					
				//cell neither empty nor full
				else
				{
					f[IJK]=0.0;
					for (int l=0;l<25;l++)
						for (int m=0;m<25;m++)
							for (int n=0;n<25;n++)
							{	
								
								if (SQUARE(txm+(l+0.5)/25.0*delx[1]*0.5e0-xcent)+
									SQUARE(tym+(m+0.5)/25.0*dely[1]*0.5e0-ycent)
									< r2)
									f[IJK]+= 6.4e-5;
							}
				}
				
				ftotal += f[IJK]*vol[IJK];
				f_total += f[IJK];
			}
			
	fprintf (files.sphere, "f_volume = %12.8e, and ftotal = %12.8e\n", ftotal, f_total);
}

#ifdef rudman_fine
void initf_f() 
{
	double tx, ty, txm, tym, tzm;
	double r2=radius*radius;
	double ftotal=0.0;
	double f_total=0.0;
	
	int i,j,k;
	
	//loop thta initialized f-field for a cylinder
	for(i=1;i<im1_f;i++)
		for(j=1;j<jm1_f;j++)
			for(k=1;k<km1_f;k++) {
				//cell is empty?
				tx = (i+2*mpi.OProc[0])*0.5e0*delx[1]; //global coordinates in fine-grid
				ty = (j+2*mpi.OProc[1])*0.5e0*dely[1];
				
				txm = tx-0.5e0*delx[1];
				tym = ty-0.5e0*dely[1];
				
				//goto cube;
				if ( MIN(SQUARE(txm-xcent), SQUARE(tx-xcent))
					+MIN(SQUARE(tym-ycent), SQUARE(ty-ycent))
					>= r2)
					f_f[IJK_f]=0;
				//cell is full?
				else if ( MAX(SQUARE(txm-xcent), SQUARE(tx-xcent))
					+MAX(SQUARE(tym-ycent), SQUARE(ty-ycent))
					<= r2)
					f_f[IJK_f]=1.0;
					
				//cell neither empty nor full
				else
				{
					f_f[IJK_f]=0.0;
					for (int l=0;l<25;l++)
						for (int m=0;m<25;m++)
							for (int n=0;n<25;n++)
							{	
								
								if (SQUARE(txm+(l+0.5)/25.0*delx[1]*0.5e0-xcent)+
									SQUARE(tym+(m+0.5)/25.0*dely[1]*0.5e0-ycent)
									< r2)
									f_f[IJK_f]+= 6.4e-5;
							}
				}
				
				ftotal += f_f[IJK_f]*vol_f[IJK_f];
				f_total += f_f[IJK_f];
			}
			
	fprintf (files.sphere, "f_volume = %12.8e, and ftotal = %12.8e\n", ftotal, f_total);
}
/*
void fine2stnd()
{	
	int i,j,k;
	//on the standard grid
	for(i=1;i<im1;i++) //REAL cells
		for(j=1;j<jm1;j++)
			for(k=1;k<km1;k++)
				f[IJK]=0.125e0*(f_f[IND_f(2*i,2*j,2*k)]+f_f[IND_f(2*i-1,2*j,2*k)]+f_f[IND_f(2*i-1,2*j-1,2*k)]+f_f[IND_f(2*i,2*j-1,2*k)]
				+f_f[IND_f(2*i,2*j,2*k-1)]+f_f[IND_f(2*i-1,2*j,2*k-1)]+f_f[IND_f(2*i-1,2*j-1,2*k-1)]+f_f[IND_f(2*i,2*j-1,2*k-1)]);
}*/
#endif
