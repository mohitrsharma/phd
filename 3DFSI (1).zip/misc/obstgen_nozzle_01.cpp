#include "ripple.h"
#include "testing.h"
#include <math.h>//fabs
#include <stdio.h>//printf


/*============================================================================*/
#define PLANE_ZBOT 15.0e-3
#define PLANE_THICK 3.0e-3
#define NOZZLE_RAD 1*radius
#define K_PLANE z[k] > PLANE_ZBOT && z[k] <= (PLANE_ZBOT+PLANE_THICK)
#define METHOD 3
/******************************************************************************
This subroutine generates a simple nozzle to be used with bubble geometry. it
simply creates a plane in the Z direction of some specified thickness which has
an spherical opening in the center of the XY-plane of the domain.

This subroutine will be called when OBSTACLE flag in "input" file is
set to nozle_01

           PLANE              NOZZLE                     PLANE
xxxxxxxxxxxxxxxxxxxxxxxxxxxx           xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

Subroutine OBSTGEN is called by:	ASET

Subroutine OBSTGEN calls: none

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Changed the header to reflect current changes in	Ben			Dec 13 2007
 how the code works with "make setup"
-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE

*******************************************************************************/

void obstgen()
{
    float tx, ty, tz, txm, tym, tzm; //temporary x,y,z of ijk
	float R2=NOZZLE_RAD*NOZZLE_RAD;
	int i,j,k;
	for (k = 0; k < kmax; k++)
		for (j = 0; j < jmax; j++)
			for (i = 0; i < imax; i++)
			{
                //if current k is within the obstacle plane
                if ( K_PLANE  )
				{
					ac[IJK] = 0.0;//cell is obst.
					ar[IJK] = 0.0;
					af[IJK] = 0.0;
					ao[IJK] = 0.0;
				}
				else
				{
					ac[IJK] = 1.0;//cell is not obst.
					ar[IJK] = 1.0;
					af[IJK] = 1.0;
					ao[IJK] = 1.0;
				}
			}
	//now add the openning
	switch (METHOD)
	{
        case 1:
            {
                 printf("In Method 1\n");
                int i_cent, j_cent;

            	if (mpi.NProc > 2)
                {
                    i_cent = 0;
                    j_cent = 0;
                }
                else
                {
                    for (i = 1; i < im1; i++)
            		for(j = 1; j < jm1; j++)
            		{
            		 		if(x[i] == xcent) i_cent = i;
            		 		if(y[j] == ycent) j_cent = j;
            		}
                }
            	int INT_NOZZLE_RAD = (int) NOZZLE_RAD / delx[1];
            	int ti, tj;
            	int INT_R2 = INT_NOZZLE_RAD*INT_NOZZLE_RAD;

                for(k = 1; k < km1; k++)
                    for(j = 1; j < jm1; j++)
                        for(i = 1; i < im1; i++)
                        {
                            //if current k is within the obstacle plane
                            if( K_PLANE )
                            {
                              //get center of the nozzle
                               ti = (i-i_cent)*(i-i_cent);
                               tj = (j-j_cent)*(j-j_cent);

                               if ( ti + tj < INT_R2 )//less than square or radius
                               {
                                    ac[IJK] = 1;//this cell is fluid
                                    ac[IPJK] = 1;
                                    ac[IJPK] = 1;
                                    ac[IPJPK] = 1;
                                    ar[IJK] = 1;//this cell is fluid
                                    ar[IPJK] = 1;
                                    ar[IJPK] = 1;
                                    ar[IPJPK] = 1;
                                    af[IJK] = 1;//this cell is fluid
                                    af[IPJK] = 1;
                                    af[IJPK] = 1;
                                    af[IPJPK] = 1;
                                    ao[IJK] = 1;//this cell is fluid
                                    ao[IPJK] = 1;
                                    ao[IJPK] = 1;
                                    ao[IPJPK] = 1;
                                }
                            }
                        }
                break;
            }
        case 2:
            {
                 printf("In Method 2\n");
                double tMAX;
                bool tEQUAL;

                for (k=1;k<km1;k++)
                    for (j=1;j<jm1;j++)
                        for (i=1;i<im1;i++)
                        {
                            //only if cell IJK is an obstacle cell
                        	if (K_PLANE)
                        	{
                        		tx = x[i];
                        		ty = y[j];
                        		tz = z[k];
                        		txm = x[i-1];
                        		tym = y[j-1];
                        		tzm = z[k-1];
                        		tEQUAL = false;

                        	    tMAX = MAX(SQUARE(txm-xcent), SQUARE(tx-xcent))
                        			+MAX(SQUARE(tym-ycent), SQUARE(ty-ycent));

                                if ( fabs( (tMAX - R2) / R2) < em6 )
                                    tEQUAL = true;

                        		//cell should become nozzle openning if less than r2
                        		else if ( tMAX < R2 || tEQUAL )
                        			{
                                           ac[IJK]=1.0;
                                           ar[IJK]=1.0;
                                           af[IJK]=1.0;
                                           ao[IJK]=1.0;
                        			}

                        	}

                        }
                break;
            }
        case 3:
            {
                //this method works better than methods 1 or 2.
                printf("In Method 3\n");
                double i_cent, j_cent;

            	if (mpi.NProc > 2)
                {
                    i_cent = 0.5;
                    j_cent = 0.5;
                }
                else
                {
                    for (i = 1; i < im1; i++)
                		for (j = 1; j < jm1; j++)
                		{
            		 		if(x[i] == xcent) i_cent = i + 0.5;
            		 		if(y[j] == ycent) j_cent = j + 0.5;
                		}
                }

            	int INT_NOZZLE_RAD = (int) NOZZLE_RAD / delx[1];
            	double ti, tj, ;
            	double R2 = INT_NOZZLE_RAD*INT_NOZZLE_RAD;
            	bool tEQUAL;

            	for(k = 1; k < km1; k++)
                    for(j = 1; j < jm1; j++)
                        for(i = 1; i < im1; i++)
                        {
                            //if current k is within the obstacle plane
                            if( K_PLANE )
                            {
                                //get center of the nozzle
                                ti = (i-i_cent)*(i-i_cent);
                                tj = (j-j_cent)*(j-j_cent);
                                tEQUAL = false;

                                if ( fabs(  ( (ti+tj) - R2 ) / R2 ) < em6 )
                                    tEQUAL = true;

                               //less than or equal to square or radius
                               if ( ti + tj < R2 || tEQUAL )
                               {
                                    ac[IJK] = 1;//this cell is fluid
                                    ar[IJK] = 1;//open to flow from right
                                    af[IJK] = 1;//open to flow from front
                                    ao[IJK] = 1;//open to flow form over

                                }
                            }
                        }
                break;
            }
    }

	/* Print obstacle file and flag processors having obstacle cells */
	if (mpi.NProc < 2) tecpo();		/* print obstacle.rbd file */

	flagproc();         			/* flag processors which have obstacle surface cells in
									* their local domain */
	if (mpi.obst_flag)
		flagobs();	    			/* flag obtacle surface cells according
	   								* to their orientation to the fluid cells */

}
