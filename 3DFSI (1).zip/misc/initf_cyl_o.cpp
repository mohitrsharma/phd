#include "ripple.h"
#include <stdlib.h>
#include <time.h>
#include "testing.h"

#define CYL_BOTTOM 14.78e-2   //location of bottom of cylinder i.e. under face
#define CYL_TOP 18.78e-2     //location of the top of the cylinder.
/*============================================================================*/ 

/******************************************************************************
This subroutine INITF sets the initial f field to a CYLINDER(mostly used 
for testing).

Subroutine INITF is called by:  SETUP

Subroutine INITF calls: ****
                                           ___CYL_TOP
                            XXXXXXXXXXXXXXX
                            XXXXXXXXXXXXXXX
                            XXXXXXXXXXXXXXX___CYL_BOTTOM
                            
____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION     
                                                        NAME        DATE
-Created this file for initializeing f field for        Ben         Sept 12 2005
 a cylinder on the UNDER side of the domain
-Created this template for tracking changes             Ben         Apr 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION                                         NAME        DATE


*******************************************************************************/

void initf()
{
    double tx, ty, tz, txm, tym, tzm; //temporary x,y,z of ijk
    double r2=radius*radius;
    double ftotal=0.0;
    double f_total = 0.0;
    int i,j,k;

    //loop that initialized the f fielf of the cylinder
    for (k=1;k<km1;k++)
        for (j=1;j<jm1;j++)
            for (i=1;i<im1;i++)
            {
                if (z[k] > CYL_BOTTOM && z[k] <= CYL_TOP)
                {
                    
                    tx = x[i];
                    ty = y[j];
                    tz = z[k];
                    txm = x[i-1];
                    tym = y[j-1];
                    tzm = z[k-1];
                    //cell is empty
                    if ( (MIN(SQUARE(txm-xcent), SQUARE(tx-xcent))
                        +MIN(SQUARE(tym-ycent), SQUARE(ty-ycent))
                        >= r2) ) 
                        f[IJK]=0;
    
                    //cell is full
                    else if ( (MAX(SQUARE(txm-xcent), SQUARE(tx-xcent))
                        +MAX(SQUARE(tym-ycent), SQUARE(ty-ycent))
                        <= r2) )
                        f[IJK]=1.0;
    
                    //cell neither empty nor full
                    else
                    {
                        f[IJK]=0.0;
                        for (int l=0;l<25;l++)
                            for (int m=0;m<25;m++)
                                {
                                    if ((SQUARE(x[i-1]+(l+0.5)/25.0*delx[i]-xcent)+
                                        SQUARE(y[j-1]+(m+0.5)/25.0*dely[j]-ycent) < r2))
                                        f[IJK]+= 1.6e-3;
                                }
                    }
                }
                ftotal += f[IJK]*vol[IJK];
            }
}
