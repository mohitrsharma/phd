#include "ripple.h"
#include <stdlib.h>
#include <time.h>
#include "testing.h"
/************************************************************************
*This subroutine initializes the f-field for dam-break problem
* 
*************************************************************************/
void initf() 
{
	int i,j,k;
	double wid=0.05715;
	double hei=15.26e-2;
	
	double ftotal=0.0;
	double f_total = 0.0;
	
	double rw, rh; int qw, qh, ig, jg, kg;
	qw=wid/delx[1]; rw=wid-qw*delx[1];
	qh=hei/delx[1]; rh=hei-qh*delx[1];
	
	for(i=1;i<im1;i++)
		for(j=1;j<jm1;j++)
			for(k=1;k<km1;k++) 
			{	
				f[IJK]=0.e0; //initialize with zero volume fraction
				ig=i+mpi.OProc[0]; //global coordinates
				jg=j+mpi.OProc[1];
				kg=k+mpi.OProc[2];
				
				if(ig<=qw && kg<=qh) f[IJK]=1.e0;
				if(ig==qw+1 && kg<=qh) f[IJK]=rw/delx[1];
				if(ig<=qw && kg==qh+1) f[IJK]=rh/delx[1];
				if(ig==qw+1 && kg==qh+1) f[IJK]=rw*rh/(delx[1]*delx[1]);
				
				ftotal += f[IJK]*vol[IJK];
				f_total += f[IJK];
			}
			fprintf (files.sphere, "f_volume = %12.4e, and ftotal = %12.4e\n", ftotal, f_total);
}

#ifdef rudman_fine

void initf_f() {
	int i,j,k;
	double wid=xe;
	double hei= 10.0e-3;
	//double hei = 0.3125e0;
	
	double ftotal=0.0;
	double f_total = 0.0;
	
	double rw, rh; int qw, qh, ig, jg, kg;
	qw=(wid+tiny)/(0.5e0*delx[1]); rw=wid-qw*0.5e0*delx[1];
	qh=(hei+tiny)/(0.5e0*delx[1]); rh=hei-qh*0.5e0*delx[1];
	
	for(i=1;i<im1_f;i++)
		for(j=1;j<jm1_f;j++)
			for(k=1;k<km1_f;k++) {
				f_f[IJK_f]=0.e0;
				ig=i+2*mpi.OProc[0];
				jg=j+2*mpi.OProc[1];
				kg=k+2*mpi.OProc[2];
				
				if(ig<=qw && kg<=qh) f_f[IJK_f]=1.e0;
				if(ig==qw+1 && kg<=qh) f_f[IJK_f]=rw/(0.5e0*delx[1]);
				if(ig<=qw && kg==qh+1) f_f[IJK_f]=rh/(0.5e0*delx[1]);
				if(ig==qw+1 && kg==qh+1) f_f[IJK_f]=rw*rh/(0.25e0*delx[1]*delx[1]);
				
				ftotal+=f_f[IJK_f]*vol_f[IJK_f];
				f_total+=f_f[IJK_f];
			}
			fprintf (files.sphere, "f_volume = %12.4e, and ftotal = %12.4e\n", ftotal, f_total);
}

//define another function that calculates f on the standard grid from fine grid f values
/*void fine2stnd()
{	
	int i,j,k;
	//on the standard grid
	for(i=1;i<im1;i++) //REAL cells
		for(j=1;j<jm1;j++)
			for(k=1;k<km1;k++)
				f[IJK]=0.125e0*(f_f[IND_f(2*i,2*j,2*k)]+f_f[IND_f(2*i-1,2*j,2*k)]+f_f[IND_f(2*i-1,2*j-1,2*k)]+f_f[IND_f(2*i,2*j-1,2*k)]
				+f_f[IND_f(2*i,2*j,2*k-1)]+f_f[IND_f(2*i-1,2*j,2*k-1)]+f_f[IND_f(2*i-1,2*j-1,2*k-1)]+f_f[IND_f(2*i,2*j-1,2*k-1)]);
}*/
#endif
