#include "ripple.h"
#include "testing.h"
#include <math.h>//fabs
#include <stdio.h>//printf

#define CH1		y[j] <= ye+1
#define CH2		x[i] <= 250.0e-6
#define XCENT	250.0e-6
#define YCENT	250.0e-6
#define ZCENT	15.0e-6
#define MF	1.0
/******************************************************************************
This subroutine generates a CONICAL NOZZLE to be used in bubble simulations.
The shape of the nozzle is defined by setting parameters ZSTR, ZCONE and ZOUT
in the input file.  ZSTR defines height of the cylindrical chamber. ZCONE is the
height of the connical section ans ZOUT is the height of the cylindrical outlet
of the nozzle.
Before every execution which includes obstacles it is necessary to copy the
appropriate aset_xxx.cpp into obstgen and compile it.  This way, a user can
create custom obstacles and save them uncer aset_xxx.cpp name.  Obstgen
subroutine will be compiled every time

           OBSTACLE              PIPE               OBSTACLE

Subroutine OBSTGEN is called by:	SETUP

Subroutine OBSTGEN calls:

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION                                         NAME        DATE

-Implemented the ability to have conical obstacles  Ben         Feb 01 2006
 defined, even when simulating half or a quarter
 of the bubble
-Removed parameter PLANE_THICK and created new      Ben         Jan 24 2006
 parameters in order to create conical nozzle
-moved parameters NOZZLE_RAD and PLANE_THICK to     Ben         Nov 22 2005
 the input file
-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION                                         NAME        DATE

*******************************************************************************/

void obstgen()
{
    double tx, ty, tz, txm, tym, tzm; //temporary x,y,z of ijk
    bool set_tk = false;
    int tk;
    int i, j, k;
    double tMAX, step = 0;
    bool tEQUAL;
	double SR2 = (radius * MF) * (radius * MF);

    for (k = 0; k < kmax; k++)
        for (j = 0; j < jmax; j++)
            for (i = 0; i < imax; i++)
            {
				tx = x[i];
				ty = y[j];
				tz = z[k];
				txm = (i > 0)? x[i-1]: x[0];
				tym = (j > 0)? y[j-1]: y[0];
				tzm = (k > 0)? z[k-1]: z[0];

				/* first initialize all cells as fluid */
				ac[IJK] = 0.0;//set to fluid
				ar[IJK] = 0.0;
				af[IJK] = 0.0;
				ao[IJK] = 0.0;

                if(CH1)
                {
					tEQUAL = false;
                    tMAX = MAX(SQUARE(txm - XCENT), SQUARE(tx - XCENT))
                            + MAX(SQUARE(tzm - ZCENT), SQUARE(tz - ZCENT));

                    if(fabs((tMAX - SR2) / SR2) < em6)
                        tEQUAL = true;

					if(tMAX < SR2)
                    {
                        ac[IJK]=1.0;
                        ar[IJK]=1.0;
                        af[IJK]=1.0;
                        ao[IJK]=1.0;
                    }
                }//if(CH1)
				if (CH2)
				{
					tEQUAL = false;
					tMAX = MAX(SQUARE(tym - YCENT), SQUARE(ty - YCENT))
							+ MAX(SQUARE(tzm - ZCENT), SQUARE(tz - ZCENT));

					if(fabs((tMAX - SR2) / SR2) < em6)
						tEQUAL = true;

					if(tMAX < SR2)
					{
						ac[IJK]=1.0;
						ar[IJK]=1.0;
						af[IJK]=1.0;
						ao[IJK]=1.0;
					}
				}
            }//for i, j, k loop
			/* Print obstacle file and flag processors having obstacle cells */
			if (mpi.NProc < 2) tecpo();		/* print obstacle.rbd file */

			flagproc();         			/* flag processors which have obstacle surface cells in
											* their local domain */
			if (mpi.obst_flag)
				flagobs();	    			/* flag obtacle surface cells according
											* to their orientation to the fluid cells */

}
