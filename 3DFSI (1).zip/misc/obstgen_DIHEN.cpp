#include "ripple.h"
#include <stdlib.h>
#include <time.h>
#include "testing.h"

#define ZERO    0.0
#define ONE     1.0
#define HALF    0.5
#define TWO     2.0
#define PI      3.141593

#define TCAP	35.e-6
#define TAIR	18.485e-6
#define TGLASS	100.0e-6
#define ROUT 	194.485e-6
#define R3		94.485e-6
#define R2		76.0e-6
#define R1		41.0e-6
/******************************************************************************
This subroutine generates nozzle for DIHEN simulations.

This subroutine is copied into OBSTGEN.CPP when OBSTACLE flag in "input" 
file is set to "dihen"

Subroutine OBSTGEN is called by: ASET

Subroutine OBSTGEN calls: none

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION
														NAME		DATE
-Created this file for initializeing f field for		Ben			Sept 12 2005
 a cylinder on the UNDER side of the domain
-Created this template for tracking changes				Ben			Apr 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

void obstgen()
{
    double tx, ty, tz, txm, tym, tzm; //temporary x,y,z of ijk
    double ftotal=0.0;
    double f_total = 0.0;
    double fac[NX*NY*NZ];
	double Z1;
    int i,j,k;
    for (i=0; i < NX*NY*NZ; i++){
        ac[i] = ONE;
        ar[i] = ONE;
        af[i] = ONE;
        ao[i] = ONE;
        fac[i] = ZERO;
    }

    Z1 = ze - 2 * delz[1];

    for (k=1;k<km1;k++){
        if (z[k] <= Z1)
            continue;

		tz = z[k];
		tzm = z[k-1];
        /* ROUT */
        for (j=1;j<jm1;j++)
            for (i=1;i<im1;i++){

                tx = x[i];
                ty = y[j];
                txm = x[i-1];
                tym = y[j-1];

                if ((MIN(SQUARE(txm-xcent), SQUARE(tx-xcent))
                      +MIN(SQUARE(tym-ycent), SQUARE(ty-ycent))
                      >= ROUT*ROUT) )
                    continue;

                if ((MAX(SQUARE(txm-xcent), SQUARE(tx-xcent))
                           +MAX(SQUARE(tym-ycent), SQUARE(ty-ycent))
                           > ROUT*ROUT)){
                    fac[IJK]= ZERO;
                    for (int l=0;l<25;l++)
                        for (int m=0;m<25;m++){
                            if ((SQUARE(x[i-1]+(l+0.5)/25.0*delx[i]-xcent)+
                                SQUARE(y[j-1]+(m+0.5)/25.0*dely[j]-ycent) < ROUT*ROUT))
                                fac[IJK]+= 1.6e-3;
                        }
                    ac[IJK] = ONE - fac[IJK];
                    continue;
                }
                ac[IJK] = ZERO;
            }

        /* R3 */
        for (j=1;j<jm1;j++)
            for (i=1;i<im1;i++){

                tx = x[i];
                ty = y[j];
                txm = x[i-1];
                tym = y[j-1];

                if ((MIN(SQUARE(txm-xcent), SQUARE(tx-xcent))
                    +MIN(SQUARE(tym-ycent), SQUARE(ty-ycent))
                    >= R3*R3) )
                    continue;

                if ((MAX(SQUARE(txm-xcent), SQUARE(tx-xcent))
                    +MAX(SQUARE(tym-ycent), SQUARE(ty-ycent))
                    > R3*R3)){
                    fac[IJK]= ZERO;
                    for (int l=0;l<25;l++)
                        for (int m=0;m<25;m++){
                            if ((SQUARE(x[i-1]+(l+0.5)/25.0*delx[i]-xcent)+
                                SQUARE(y[j-1]+(m+0.5)/25.0*dely[j]-ycent) < R3*R3))
                                fac[IJK]+= 1.6e-3;
                        }
                    ac[IJK] = fac[IJK];
                    continue;
                }
                ac[IJK] = ONE;
            }

            /* R2 */
            for (j=1;j<jm1;j++)
                for (i=1;i<im1;i++){

                    tx = x[i];
                    ty = y[j];
                    txm = x[i-1];
                    tym = y[j-1];

                    if ((MIN(SQUARE(txm-xcent), SQUARE(tx-xcent))
                        +MIN(SQUARE(tym-ycent), SQUARE(ty-ycent))
                        >= R2*R2) )
                        continue;

                    if ((MAX(SQUARE(txm-xcent), SQUARE(tx-xcent))
                        +MAX(SQUARE(tym-ycent), SQUARE(ty-ycent))
                        > R2*R2)){
                        fac[IJK]= ZERO;
                        for (int l=0;l<25;l++)
                            for (int m=0;m<25;m++){
                                if ((SQUARE(x[i-1]+(l+0.5)/25.0*delx[i]-xcent)+
                                    SQUARE(y[j-1]+(m+0.5)/25.0*dely[j]-ycent) < R2*R2))
                                    fac[IJK]+= 1.6e-3;
                            }
                        ac[IJK] = ONE - fac[IJK];
                        continue;
                    }
                    ac[IJK] = ZERO;
                }
            label59:
                /* R1 */
                for (j=1;j<jm1;j++)
                    for (i=1;i<im1;i++){

                    tx = x[i];
                    ty = y[j];
                    txm = x[i-1];
                    tym = y[j-1];

                    if ((MIN(SQUARE(txm-xcent), SQUARE(tx-xcent))
                         +MIN(SQUARE(tym-ycent), SQUARE(ty-ycent))
                         >= R1*R1) )
                        continue;

                    if ((MAX(SQUARE(txm-xcent), SQUARE(tx-xcent))
                         +MAX(SQUARE(tym-ycent), SQUARE(ty-ycent))
                         > R1*R1)){
                        fac[IJK]= ZERO;
                        for (int l=0;l<25;l++)
                            for (int m=0;m<25;m++){
                                if ((SQUARE(x[i-1]+(l+0.5)/25.0*delx[i]-xcent)+
                                    SQUARE(y[j-1]+(m+0.5)/25.0*dely[j]-ycent) < R1*R1))
                                    fac[IJK]+= 1.6e-3;
                            }
                        ac[IJK] = fac[IJK];
                        continue;
                    }
                    ac[IJK] = ONE;
                }
    }

    for (i = 1; i < im1; i++)
        for (j = 1; j < jm1; j++)
            for (k = 1; k < km1; k++){

                if (ac[IJK] > HALF)
                    ac[IJK] = ONE;
				else{
                    ac[IJK] = ZERO;
					ar[IJK] = ZERO;
					af[IJK] = ZERO;
					ao[IJK] = ZERO;
				}
            }
			/* Print obstacle file and flag processors having obstacle cells */
			if (mpi.NProc < 2) tecpo();		/* print obstacle.rbd file */

			flagproc();         			/* flag processors which have obstacle surface cells in
											* their local domain */
			if (mpi.obst_flag)
				flagobs();	    			/* flag obtacle surface cells according
											* to their orientation to the fluid cells */

}
