#include "ripple.h"
#include "testing.h"


void obstgen()
{
	int i,j,k;
	double bxl, bxr, byb, byt, bzu, bzo;
	
	bxl = 2.42e0; bxr = 2.62e0;
	byb = 0.25e0; byt = 0.75e0;
	bzu = 0.e0; bzo = 0.2e0;
	
	for(i=0;i<imax;i++)
		for(j=0;j<jmax;j++)
			for(k=0;k<kmax;k++)
			{
				if(xi[i]>=bxl && xi[i]<=bxr && yj[j]>=byb && yj[j]<=byt && zk[k]>=bzu && zk[k]<=bzo)
				{
					ac[IJK] = 0.e0; // is an obst.
					ar[IJK] = 0.e0;
					af[IJK] = 0.e0;
					ao[IJK] = 0.e0;
				}
				else
				{
					ac[IJK] = 1.e0; // is not an obst.
					ar[IJK] = 1.e0;
					af[IJK] = 1.e0;
					ao[IJK] = 1.e0;
				}	
			}
			
#ifdef obs_export
	tecpo();
	//ZIP rbd files after calling tecpo()
	if(mpi.MyRank==0) 
	{
		printf("compressing obst RBD files...\n");
		char command[50];
		sprintf(command,"gzip o%03d-*.rbd &", mpi.NProc);
		system(command);
	}
#endif
	flagproc();         			/* flag processors which have obstacle surface cells in
											* their local domain */
	if (mpi.obst_flag)
		flagobs();	    			/* flag obtacle surface cells according
							 * to their orientation to the fluid cells */
	

}
