#include "ripple.h"
#include "testing.h"
#include <math.h>//fabs
#include <stdio.h>//printf

#define STR		z[k] < 10.78e-2
#define MF	1.25
/******************************************************************************
This subroutine generates a CONICAL NOZZLE to be used in bubble simulations.
The shape of the nozzle is defined by setting parameters ZSTR, ZCONE and ZOUT
in the input file.  ZSTR defines height of the cylindrical chamber. ZCONE is the
height of the connical section ans ZOUT is the height of the cylindrical outlet
of the nozzle.

This subroutine is copied into OBSTGEN.CPP when OBSTACLE flag in "input"
file is set to "pipe"

           OBSTACLE              PIPE               OBSTACLE
ooooooooooooooooooooooooooooooooxxxxxxooooooooooooooooooooooooooooo
ooooooooooooooooooooooooooooooooxxxxxxooooooooooooooooooooooooooooo
ooooooooooooooooooooooooooooooooxxxxxxooooooooooooooooooooooooooooo
oooooooooooooooooooooooooooooooo      ooooooooooooooooooooooooooooo
oooooooooooooooooooooooooooooooo      ooooooooooooooooooooooooooooo
oooooooooooooooooooooooooooooooo      ooooooooooooooooooooooooooooo
oooooooooooooooooooooooooooooooo      ooooooooooooooooooooooooooooo
oooooooooooooooooooooooooooooooo      ooooooooooooooooooooooooooooo
oooooooooooooooooooooooooooooooo      ooooooooooooooooooooooooooooo
oooooooooooooooooooooooooooooooo      ooooooooooooooooooooooooooooo
oooooooooooooooooooooooooooooooo      ooooooooooooooooooooooooooooo
oooooooooooooooooooooooooooooooo      ooooooooooooooooooooooooooooo
oooooooooooooooooooooooooooooooo      ooooooooooooooooooooooooooooo
oooooooooooooooooooooooooooooooo      ooooooooooooooooooooooooooooo
oooooooooooooooooooooooooooooooo      ooooooooooooooooooooooooooooo
oooooooooooooooooooooooooooooooo      ooooooooooooooooooooooooooooo
				INLET
Subroutine OBSTGEN is called by:	ASET

Subroutine OBSTGEN calls: none

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION                                         NAME        DATE

-Implemented the ability to have conical obstacles  Ben         Feb 01 2006
 defined, even when simulating half or a quarter
 of the bubble
-Removed parameter PLANE_THICK and created new      Ben         Jan 24 2006
 parameters in order to create conical nozzle
-moved parameters NOZZLE_RAD and PLANE_THICK to     Ben         Nov 22 2005
 the input file
-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION                                         NAME        DATE

*******************************************************************************/

void obstgen()
{
    double tx, ty, tz, txm, tym, tzm; //temporary x,y,z of ijk
    bool set_tk = false;
    int tk;
    int i, j, k;
    double tMAX, step = 0;
    bool tEQUAL;
	double SR2 = (radius * MF) * (radius * MF);

    for(k = 0; k < kmax; k++)
        for(j = 0; j < jmax; j++)
            for(i = 0; i < imax; i++)
            {
                if(STR)
                {
                    tx = x[i];
                    ty = y[j];
                    tz = z[k];
                    txm = (i > 0)? x[i-1]: x[0];
                    tym = (j > 0)? y[j-1]: y[0];
                    tzm = (k > 0)? z[k-1]: z[0];
                    tEQUAL = false;

                    tMAX = MAX(SQUARE(txm - xcent), SQUARE(tx - xcent))
                            + MAX(SQUARE(tym - ycent), SQUARE(ty - ycent));

                    if(fabs((tMAX - SR2) / SR2) < em6)
                        tEQUAL = true;

                    /*cell should become obstacle if following is true*/
					if(tMAX > SR2 /*|| tEQUAL*/)
                    {
                        ac[IJK]=0.0;//set to obstacle
                        ar[IJK]=0.0;
                        af[IJK]=0.0;
                        ao[IJK]=0.0;
                    }
                    else
                    {
                        ac[IJK] = 1.0;//set to fluid
                        ar[IJK] = 1.0;
                        af[IJK] = 1.0;
                        ao[IJK] = 1.0;
                    }
                }//if(STR)
                else//cells above the nozzle re set to be fluid cells
                {
                    ac[IJK]=1.0;//set to fluid
                    ar[IJK]=1.0;
                    af[IJK]=1.0;
                    ao[IJK]=1.0;
                }
            }//for i, j, k loop
			/* Print obstacle file and flag processors having obstacle cells */
			if (mpi.NProc < 2) tecpo();		/* print obstacle.rbd file */

			flagproc();         			/* flag processors which have obstacle surface cells in
											* their local domain */
			if (mpi.obst_flag)
				flagobs();	    			/* flag obtacle surface cells according
											* to their orientation to the fluid cells */

}
