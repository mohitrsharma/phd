#include "ripple.h"
#include "testing.h"
/******************************************************************************
This subroutine generates NO obstacles. Its sets all the a_ arrays to 1.  It is
called when OBSTACELE flag in "input-flow" file is set to "none".

Subroutine OBSTGEN_NONE is called by:	ASET

Subroutine OBSTGEN_NONE calls:	****

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION												NAME		DATE
-Created this subroutine so that "make setup" comamnd	Ben			Dec 13 2007
 generates appropriate obstacles.
-Created this template for tracking changes				Ben			Apr 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/
void obstgen(){
    /*
     * This was coppied from misc/obstgen_none.cpp
	 * Does not generate obstacles. Sets all a_ arrays to 1, meaning fluid.
	*/
    int n;
	for (int n=0;n<NX*NY*NZ;n++){
		ac[n]=1.0;//if no obstacles, set all a_ arrays to 1
		ar[n]=1.0;
		af[n]=1.0;
		ao[n]=1.0;
	}
}
