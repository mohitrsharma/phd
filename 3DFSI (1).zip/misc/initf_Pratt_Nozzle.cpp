#include "ripple.h"
#include <stdlib.h>
#include <time.h>
#include "testing.h"

#define ZERO    0.0
#define ONE     1.0
#define HALF    0.5
#define TWO     2.0
#define PI      3.141593

#define RCJET   2.05e-3
#define NJET    3
#define VJET    5.0e0
#define RJET    0.25e-3
#define ANGJET  25.0 * PI / 180.0

#define DFACTV 	1.0
/******************************************************************************
This subroutine INITF sets the initial f field to a CYLINDER(mostly used
for testing).

Subroutine INITF is called by:	SETUP

Subroutine INITF calls:	****

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION
														NAME		DATE
-Created this file for initializeing f field for		Ben			Sept 12 2005
 a cylinder on the UNDER side of the domain
-Created this template for tracking changes				Ben			Apr 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

void initf()
{
	double tx, ty, tz, txm, tym, tzm; //temporary x,y,z of ijk
	double r2=radius*radius;
	double ftotal=0.0;
	double f_total = 0.0;
	int i,j,k;

    double TBASE,R2,AOVAL,BOVAL;
    double YCENTD,XCENTD,ANGZD,ANGD,ZDOM1,ZDOM2,TBIC;

    TBASE = delz[1];
    AOVAL = RJET;
    BOVAL = RJET / sin(ANGJET);
    R2 = AOVAL * BOVAL;
    ZDOM1 = ze - TBASE;
    for (int ND = 1; ND < NJET+1; ND++){

        ANGD = TWO * PI * (ND - 1) / NJET;
        XCENTD = xcent + RCJET * sin(ANGD);
        YCENTD = ycent + RCJET * cos(ANGD);
        for (i = 1; i < im1; i++)
            for (j = 1; j < jm1; j++)
                for (k = 1; k < km1; k++){
                    if (z[k] < ZDOM1)
                        continue;
                    tx = x[i];
                    ty = y[j];
                    txm = x[i-1];
                    tym = y[j-1];

                    if ((MIN(SQUARE(txm-XCENTD), SQUARE(tx-XCENTD))
                        +MIN(SQUARE(tym-YCENTD), SQUARE(ty-YCENTD))
                        < R2) ){
                        if ((MAX(SQUARE(txm-XCENTD), SQUARE(tx-XCENTD))
                            +MAX(SQUARE(tym-YCENTD), SQUARE(ty-YCENTD))
                            > R2)){
                            f[IJK]= ZERO;

                            for (int l=0;l<25;l++)
                                for (int m=0;m<25;m++){
                                if ((SQUARE(x[i-1]+(l+0.5)/25.0*delx[i]-XCENTD)+
                                    SQUARE(y[j-1]+(m+0.5)/25.0*dely[j]-YCENTD) < R2))
                                    f[IJK]+= 1.6e-3;
                                }
                            }
                        f[IJK] = ONE;
                    }
					else
                    	continue;
					
					/* set velocity in inflow boundary cells */
					if (f[IJK] > em6){
						u[IJK] = ZERO;
						v[IJK] = ZERO;
						w[IJK] = -VJET * sin(ANGJET);
						if (z[k] > ZDOM1 - HALF * delz[k] &&
							z[k] < ZDOM1 + HALF * delz[k]){
							u[IJK] = VJET * cos(ANGJET) * cos(ANGD);
							v[IJK] = -VJET * cos(ANGJET) * sin(ANGD);
						}
						u[IJK] = u[IJK] * DFACTV;
						v[IJK] = v[IJK] * DFACTV;
						w[IJK] = w[IJK] * DFACTV;
						u[IJKM] = u[IJK];
						v[IJKM] = v[IJK];
						w[IJKM] = w[IJK];
					}
					
				}/* for IJK*/
	}/* for ND*/
}
