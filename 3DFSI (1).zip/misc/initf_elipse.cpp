#include "ripple.h"
#include <stdlib.h>
#include <time.h>
#include "testing.h"

#define A 1.2e-3
#define B 1.0e-3
#define C 1.0e-3
/******************************************************************************
This subroutine INITF sets the initial f field for an ELIPSE. 

Subroutine INITF is called by:	SETUP

Subroutine INITF calls:	****

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Crated this subroutine for initializing drops		Ben			Sept 12 2005
-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

void initf()
{
	double tx, ty, tz, txm, tym, tzm; //temporary x,y,z of ijk
	double r2=radius*radius;
	double ftotal=0.0;
	double f_total = 0.0;
	int i,j,k;

	//loop that initialized the f field of a elipse
	for (i=1;i<im1;i++)
		for (j=1;j<jm1;j++)
			for (k=1;k<km1;k++)
	{
		tx = x[i];
		ty = y[j];
		tz = z[k];
		txm = x[i-1];
		tym = y[j-1];					
		tzm = z[k-1];
		/*cell is empty*/
		if (MIN(SQUARE(txm-xcent) / SQUARE(A), SQUARE(tx-xcent) / SQUARE(A))
				  +MIN(SQUARE(tym-ycent) / SQUARE(B), SQUARE(ty-ycent) / SQUARE(B))
				  +MIN(SQUARE(tzm-zcent) / SQUARE(C), SQUARE(tz-zcent) / SQUARE(C))
				  >= 1.0)
			f[IJK]=0;		
		/*cell is full*/
		else if (MAX(SQUARE(txm-xcent) / SQUARE(A), SQUARE(tx-xcent) / SQUARE(A))
					   +MAX(SQUARE(tym-ycent) / SQUARE(B), SQUARE(ty-ycent) / SQUARE(B))
					   +MAX(SQUARE(tzm-zcent) / SQUARE(C), SQUARE(tz-zcent) / SQUARE(C))
					   <= 1.0)
			f[IJK]=1.0;
		/*cell is partially filled*/
		else
		{
			f[IJK]=0.0;
			for (int l=0;l<25;l++)
				for (int m=0;m<25;m++)
					for (int n=0;n<25;n++)
			{
				if (SQUARE(x[i-1]+(l+0.5)/25.0*delx[i]-xcent) / SQUARE(A)+
					SQUARE(y[j-1]+(m+0.5)/25.0*dely[j]-ycent) / SQUARE(B)+
					SQUARE(z[k-1]+(n+0.5)/25.0*delz[k]-zcent) / SQUARE(C)
					< 1.0)
					f[IJK]+= 6.4e-5;
			}
		}
						
		ftotal += f[IJK]*vol[IJK];
		f_total += f[IJK];
	}
	
}
