#include "ripple.h"
#include <stdlib.h>
#include <time.h>
#include "testing.h"

#define ZERO    0.0
#define ONE     1.0
#define HALF    0.5
#define TWO     2.0
#define PI      3.141593

#define RBAIR   1.15e-3
#define RBIC    1.850e-3
#define RBOC    2.250e-3
#define RTAIR   1.2e-3
#define RTIC    1.35e-3
#define REXIT   1.5e-3

#define H1CONE  1.0e-3
#define H2CONE  2.0e-3
#define HEXIT   2.6e-3
#define RCJET   2.05e-3

#define NJET    3
#define VJET    5.0e0
#define RJET    0.25e-3
#define ANGJET  25.0 * PI / 180.0
/******************************************************************************
This subroutine generates Pratt & Whittney Fuel Injector.

This subroutine is copied into OBSTGEN.CPP when OBSTACLE flag in "input" 
file is set to "pratt_nozzle"

Subroutine OBSTGEN is called by:	ASET

Subroutine OBSTGEN calls: none

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION
														NAME		DATE
-Created this file for initializeing f field for		Ben			Sept 12 2005
 a cylinder on the UNDER side of the domain
-Created this template for tracking changes				Ben			Apr 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

void obstgen()
{
    double tx, ty, tz, txm, tym, tzm; //temporary x,y,z of ijk
    double ftotal=0.0;
    double f_total = 0.0;
    double fac[NX*NY*NZ];
    double TBASE,TBODY,R1,R2,R3,Z1,Z2,Z3,Z4,ROUT,AOVAL,BOVAL;
    double YCENTD,XCENTD,ANGZD,ANGD,ZDOM1,ZDOM2,TBIC;
    int i,j,k;
    for (i=0; i < NX*NY*NZ; i++){
        ac[i] = ONE;
        ar[i] = ONE;
        af[i] = ONE;
        ao[i] = ONE;
        fac[i] = ZERO;
    }
    TBASE = delz[1];
    TBODY = 5.0 * delx[1];
    Z1 = ze - (TBASE + HEXIT);
    Z2 = ze - (TBASE + H2CONE);
    Z3 = ze - (TBASE + H1CONE);
    Z4 = ze - TBASE;
    for (k=1;k<km1;k++){
        tz = z[k];
        tzm = z[k-1];
        R1 = ZERO;
        R2 = ZERO;
        R3 = ZERO;
        if (z[k] <= Z1)
            continue;
        if (z[k] > Z1 && z[k] <= Z2)
            R3 = REXIT;
        else if (z[k] > Z2 && z[k] < Z3)
            R3 = RBOC + (REXIT - RBOC) * (ze - TBASE - z[k]) / H2CONE;
        else if (z[k] > Z3 && z[k] <= Z4){
            R1 = RBAIR + (RTAIR - RBAIR) * (ze - TBASE - z[k]) / H1CONE;
            R2 = RBIC + (RTIC - RBIC) * (ze - TBASE - z[k]) / H1CONE;
            R3 = RBOC + (REXIT - RBOC) * (ze - TBASE - z[k]) / H2CONE;
        }
        else if (z[k] > Z4 && z[k] <= ze){
            R1 = RBAIR + (RTAIR - RBAIR) * (ze - TBASE - z[k]) / H1CONE;
            R3 = RBOC;
        }
        ROUT = R3 + TBODY;
        /* ROUT */
        for (j=1;j<jm1;j++)
            for (i=1;i<im1;i++){

                tx = x[i];
                ty = y[j];
                txm = x[i-1];
                tym = y[j-1];

                if ((MIN(SQUARE(txm-xcent), SQUARE(tx-xcent))
                      +MIN(SQUARE(tym-ycent), SQUARE(ty-ycent))
                      >= ROUT*ROUT) )
                    continue;

                if ((MAX(SQUARE(txm-xcent), SQUARE(tx-xcent))
                           +MAX(SQUARE(tym-ycent), SQUARE(ty-ycent))
                           > ROUT*ROUT)){
                    fac[IJK]= ZERO;
                    for (int l=0;l<25;l++)
                        for (int m=0;m<25;m++){
                            if ((SQUARE(x[i-1]+(l+0.5)/25.0*delx[i]-xcent)+
                                SQUARE(y[j-1]+(m+0.5)/25.0*dely[j]-ycent) < ROUT*ROUT))
                                fac[IJK]+= 1.6e-3;
                        }
                    ac[IJK] = ONE - fac[IJK];
                    continue;
                }
                ac[IJK] = ZERO;
            }

        if (R1 > tiny && R2 < tiny) goto label59; /* as in Mohhamand's FORTRAN code */

        /* R3 */
        for (j=1;j<jm1;j++)
            for (i=1;i<im1;i++){

                tx = x[i];
                ty = y[j];
                txm = x[i-1];
                tym = y[j-1];

                if ((MIN(SQUARE(txm-xcent), SQUARE(tx-xcent))
                    +MIN(SQUARE(tym-ycent), SQUARE(ty-ycent))
                    >= R3*R3) )
                    continue;

                if ((MAX(SQUARE(txm-xcent), SQUARE(tx-xcent))
                    +MAX(SQUARE(tym-ycent), SQUARE(ty-ycent))
                    > R3*R3)){
                    fac[IJK]= ZERO;
                    for (int l=0;l<25;l++)
                        for (int m=0;m<25;m++){
                            if ((SQUARE(x[i-1]+(l+0.5)/25.0*delx[i]-xcent)+
                                SQUARE(y[j-1]+(m+0.5)/25.0*dely[j]-ycent) < R3*R3))
                                fac[IJK]+= 1.6e-3;
                        }
                    ac[IJK] = fac[IJK];
                    continue;
                }
                ac[IJK] = ONE;
            }

            if (R1 < tiny && R2 < tiny) continue;

            /* R2 */
            for (j=1;j<jm1;j++)
                for (i=1;i<im1;i++){

                    tx = x[i];
                    ty = y[j];
                    txm = x[i-1];
                    tym = y[j-1];

                    if ((MIN(SQUARE(txm-xcent), SQUARE(tx-xcent))
                        +MIN(SQUARE(tym-ycent), SQUARE(ty-ycent))
                        >= R2*R2) )
                        continue;

                    if ((MAX(SQUARE(txm-xcent), SQUARE(tx-xcent))
                        +MAX(SQUARE(tym-ycent), SQUARE(ty-ycent))
                        > R2*R2)){
                        fac[IJK]= ZERO;
                        for (int l=0;l<25;l++)
                            for (int m=0;m<25;m++){
                                if ((SQUARE(x[i-1]+(l+0.5)/25.0*delx[i]-xcent)+
                                    SQUARE(y[j-1]+(m+0.5)/25.0*dely[j]-ycent) < R2*R2))
                                    fac[IJK]+= 1.6e-3;
                            }
                        ac[IJK] = ONE - fac[IJK];
                        continue;
                    }
                    ac[IJK] = ZERO;
                }
            label59:
                /* R1 */
                for (j=1;j<jm1;j++)
                    for (i=1;i<im1;i++){

                    tx = x[i];
                    ty = y[j];
                    txm = x[i-1];
                    tym = y[j-1];

                    if ((MIN(SQUARE(txm-xcent), SQUARE(tx-xcent))
                         +MIN(SQUARE(tym-ycent), SQUARE(ty-ycent))
                         >= R1*R1) )
                        continue;

                    if ((MAX(SQUARE(txm-xcent), SQUARE(tx-xcent))
                         +MAX(SQUARE(tym-ycent), SQUARE(ty-ycent))
                         > R1*R1)){
                        fac[IJK]= ZERO;
                        for (int l=0;l<25;l++)
                            for (int m=0;m<25;m++){
                                if ((SQUARE(x[i-1]+(l+0.5)/25.0*delx[i]-xcent)+
                                    SQUARE(y[j-1]+(m+0.5)/25.0*dely[j]-ycent) < R1*R1))
                                    fac[IJK]+= 1.6e-3;
                            }
                        ac[IJK] = fac[IJK];
                        continue;
                    }
                    ac[IJK] = ONE;
                }
    }
    AOVAL = RJET;
    BOVAL = RJET / sin(ANGJET);
    R2 = AOVAL * BOVAL;
    ZDOM1 = ze - TBASE;
    ZDOM2 = ZDOM1 - (HEXIT - H2CONE) / TWO;
    for (int ND = 1; ND < NJET+1; ND++){

        ANGD = TWO * PI * (ND - 1) / NJET;
        for (i = 1; i < im1; i++)
            for (j = 1; j < jm1; j++)
                for (k = 1; k < km1; k++){
                    if (z[k] < ZDOM2)
                        continue;
                    ANGZD = ZERO;
                    if (z[k] >= ZDOM2 && z[k] < ZDOM1)
                        ANGZD = (ZDOM1 - z[k]) / (tan(ANGJET) * RCJET);
                    if (z[k] > ZDOM1 - HALF * delz[k] &&
                        z[k] < ZDOM1 + HALF * delz[k])
                        ANGZD = ZERO;
                    XCENTD = xcent + RCJET * sin(ANGD + ANGZD);
                    YCENTD = ycent + RCJET * cos(ANGD + ANGZD);

                    tx = x[i];
                    ty = y[j];
                    txm = x[i-1];
                    tym = y[j-1];

                    if ((MIN(SQUARE(txm-XCENTD), SQUARE(tx-XCENTD))
                        +MIN(SQUARE(tym-YCENTD), SQUARE(ty-YCENTD))
                            >= R2) )
                        continue;

                    if ((MAX(SQUARE(txm-XCENTD), SQUARE(tx-XCENTD))
                        +MAX(SQUARE(tym-YCENTD), SQUARE(ty-YCENTD))
                            > R2)){
                        fac[IJK]= ZERO;

                        for (int l=0;l<25;l++)
                            for (int m=0;m<25;m++){
                                if ((SQUARE(x[i-1]+(l+0.5)/25.0*delx[i]-XCENTD)+
                                    SQUARE(y[j-1]+(m+0.5)/25.0*dely[j]-YCENTD) < R2))
                                        fac[IJK]+= 1.6e-3;
                                }
                        if (ac[IJK] < fac[IJK]){
                            ac[IJK] = fac[IJK];
                            continue;
                        }
                    }
                    ac[IJK] = ONE;
                }/* for IJK */
    }/* for ND */

    for (i = 1; i < im1; i++)
        for (j = 1; j < jm1; j++)
            for (k = 1; k < km1; k++){

                if (ac[IJK] > HALF)
                    ac[IJK] = ONE;
				else{
                    ac[IJK] = ZERO;
					ar[IJK] = ZERO;
					af[IJK] = ZERO;
					ao[IJK] = ZERO;
				}
            }
			/* Print obstacle file and flag processors having obstacle cells */
			if (mpi.NProc < 2) tecpo();		/* print obstacle.rbd file */

			flagproc();         			/* flag processors which have obstacle surface cells in
											* their local domain */
			if (mpi.obst_flag)
				flagobs();	    			/* flag obtacle surface cells according
											* to their orientation to the fluid cells */

}
