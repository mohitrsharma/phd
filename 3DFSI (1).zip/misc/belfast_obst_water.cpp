#include "ripple.h"
#include <stdlib.h>
#include <time.h>
#include "testing.h"
/************************************************************************
*This subroutine the obstacles and the f- for the Belfast simulation
* the setup is same as the experiment's at scale 1:25. This is not full
* scale
*************************************************************************/
void obstgen()
{
	int i,j,k;
	double tx,ty,tz,tar;
	for(k=0;k<kmax;k++)
	 for(j=0;j<jmax;j++)
	  for(i=0;i<imax;i++) {
		  
		  ac[IJK] = 1.0;
		  ar[IJK] = 1.0;
		  af[IJK] = 1.0;
		  ao[IJK] = 1.0;
		  
		  tx=xi[i]; ty=yj[j]; tz=zk[k];
		  if(tx>5.13 && tx<6.43) {
			  tar=0.11615*tx-0.59587;
			  if(tz<tar) {
				  ac[IJK] = 0.0;
				  ar[IJK] = 0.0;
				  af[IJK] = 0.0;
				  ao[IJK] = 0.0;
			  }
		  }
		  else if(tx>6.43 && tx<8.83) {
			  tar=0.151;
			  if(tz<tar) {
				  ac[IJK] = 0.0;
				  ar[IJK] = 0.0;
				  af[IJK] = 0.0;
				  ao[IJK] = 0.0;
			  }
		  }
		  else if(tx>8.83 && tx<12.53) {
			  tar=0.053784*tx-0.32391;
			  if(tz<tar) {
				  ac[IJK] = 0.0;
				  ar[IJK] = 0.0;
				  af[IJK] = 0.0;
				  ao[IJK] = 0.0;
			  }
		  }
		  else if(tx>12.53) {
			  tar=0.35;
			  if(tz<tar) {
				  ac[IJK] = 0.0;
				  ar[IJK] = 0.0;
				  af[IJK] = 0.0;
				  ao[IJK] = 0.0;
			  }
		  }
	  }
	
	//extra obstacles just below the WEC  
	for(k=0;k<kmax;k++)
	 for(j=0;j<jmax;j++)
	  for(i=0;i<imax;i++) {
		  tx=xi[i]; ty=yj[j]; tz=zk[k];
		  if(tx>8.16 && tx<8.304 && ty<0.540 && tz>0.151 && tz<0.312) {
			  ac[IJK] = 0.0;
			  ar[IJK] = 0.0;
			  af[IJK] = 0.0;
			  ao[IJK] = 0.0;
		  }
	  }
	  
	  tecpo();
	  flagproc();
	  if (mpi.obst_flag)
		flagobs();
}
