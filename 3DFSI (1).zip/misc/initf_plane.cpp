#include "ripple.h"
#include <stdlib.h>
#include <time.h>
#include "testing.h"

void initf() {
	// this is a stub function
	// empty
}

#ifdef rudman_fine
#ifdef __solid

void initf_f() {
	//initializes a plane on the fine grid with prescribed normals and 
	//location [nor,cent]
	int i,j,k;
	st_point nor;
	double f_p, f_total, ftotal;
	f_p = f_total = ftotal = 0.0;
	
	/*double t1, t2;
	t1 = 30.0*M_PI / 180.0; t2 = -60.0*M_PI / 180.0;	
	nor.x = cos(t1)*cos(t2);  nor.y = sin(t1); nor.z = cos(t1)*sin(t2);
	t_nor.x = nor.x, t_nor.y = nor.y, t_nor.z = nor.z;
	
	t_cent.x = 0.75; t_cent.y = 0.25;
	t_cent.z = 0.5;*/
	nor.x = sin(M_PI_4), nor.y = 0.0, nor.z = cos(M_PI_4);
	t_nor.x = nor.x, t_nor.y = nor.y, t_nor.z = nor.z;
	t_cent.x = 20.5*(0.5*delx[1]), t_cent.y = 0.0, t_cent.z = 20.5*(0.5*delx[1]);
	
	t_cent.x = t_cent.x / (0.5*delx[1]); 
	t_cent.y = t_cent.y / (0.5*dely[1]);
	t_cent.z = t_cent.z / (0.5*delz[1]);  

	for(i=1;i<im1_f;i++)
	 for(j=1;j<jm1_f;j++)
	  for(k=1;k<km1_f;k++) {
		  cube_plane_int(&f_p,&nor,&t_cent,i,j,k,0);
		  f_f[IJK_f] = f_p;
		  ftotal += f_f[IJK_f]*vol_f[IJK_f];
		  f_total += f_f[IJK_f];
	  }
}
/*
void fine2stnd()
{	
	int i,j,k;
	//on the standard grid
	for(i=1;i<im1;i++) //REAL cells
		for(j=1;j<jm1;j++)
			for(k=1;k<km1;k++)
				f[IJK]=0.125e0*(f_f[IND_f(2*i,2*j,2*k)]+f_f[IND_f(2*i-1,2*j,2*k)]+f_f[IND_f(2*i-1,2*j-1,2*k)]+f_f[IND_f(2*i,2*j-1,2*k)]
				+f_f[IND_f(2*i,2*j,2*k-1)]+f_f[IND_f(2*i-1,2*j,2*k-1)]+f_f[IND_f(2*i-1,2*j-1,2*k-1)]+f_f[IND_f(2*i,2*j-1,2*k-1)]);
}
*/
#endif
#endif
