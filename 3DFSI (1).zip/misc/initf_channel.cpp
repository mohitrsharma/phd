#include "ripple.h"
#include <stdlib.h>
#include <time.h>
#include "testing.h"
#include <string.h>/*memcpy*/

/******************************************************************************
This subroutine INITF sets the initial f field for a jet with a spherical tip. 

Subroutine INITF is called by:  SETUP

Subroutine INITF calls: ****

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION                                         NAME        DATE

-Crated this subroutine for initializing a jet      Ben         Sept 12 2005
-Created this template for tracking changes         Ben         April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION                                         NAME        DATE


*******************************************************************************/

void initf()
{
	int i, j, k;
	
	for (k = 0; k < kmax; k++)
		for (j = 0; j < jmax; j++)
			for (i = 0; i < imax; i++)
			{
				if (ac[IJK] == 1.0)
				{
					f[IJK] = 1.0;
					if (x[i] < 2 * delx[i])
					{
						u[IJK] = uf1;
						v[IJK] = vf1;
						w[IJK] = wf1;
						un[IJK]=u[IJK];
						vn[IJK]=v[IJK];
						wn[IJK]=w[IJK];
					}
				}
				else
				{
					f[IJK] = 0.0;
				}
			}
}

