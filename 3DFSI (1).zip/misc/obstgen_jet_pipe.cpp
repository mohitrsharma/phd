#include "ripple.h"
#include "testing.h"
#include <math.h>//fabs
#include <stdio.h>//printf

/******************************************************************************
Subroutine OBSTGEN is called by:	ASET

Subroutine OBSTGEN calls: none

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION                                         NAME        DATE

_________________________________TO DO LIST____________________________________

DESCRIPTION                                         NAME        DATE

*******************************************************************************/

void obstgen()
{
    double tx, ty, tz, txm, tym, tzm; //temporary x,y,z of ijk
    int i, j, k;
	double R2 = radius*radius;

    for(k = 0; k < kmax; k++)
        for(j = 0; j < jmax; j++)
            for(i = 0; i < imax; i++)
            {
				ac[IJK] = 1.0;//set to fluid
				ar[IJK] = 1.0;
				af[IJK] = 1.0;
				ao[IJK] = 1.0;
				if (mpi.Neighbors[4] == -1) {
					tx = x[i];
					ty = y[j];
					if ( k < 4 && ((SQUARE(tx - xcent) + SQUARE(ty - ycent)) > R2) )
					{
						ac[IJK]=0.0;//set to obstacle
		                		ar[IJK]=0.0;
				                af[IJK]=0.0;
				                ao[IJK]=0.0;
					}
				}
            }//for i, j, k loop

			/* Print obstacle file and flag processors having obstacle cells */
			if (mpi.NProc < 2) tecpo();		/* print obstacle.rbd file */

			flagproc();         			/* flag processors which have obstacle surface cells in
											* their local domain */
			if (mpi.obst_flag)
				flagobs();	    			/* flag obtacle surface cells according
											* to their orientation to the fluid cells */

}
