#include "ripple.h"
#include <stdlib.h>
#include <time.h>
#include "testing.h"
#include <string.h>/*memcpy*/

/******************************************************************************
This subroutine INITF sets the initial f field for a jet with a spherical tip. 

Subroutine INITF is called by:  SETUP

Subroutine INITF calls: ****

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION                                         NAME        DATE

-Crated this subroutine for initializing a jet      Ben         Sept 12 2005
-Created this template for tracking changes         Ben         April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION                                         NAME        DATE


*******************************************************************************/

void initf()
{
	double tx, ty, tz, txm, tym, tzm; //temporary x,y,z of ijk
	double r2=radius*radius;
	double ftotal=0.0;
	double f_total = 0.0;
	int i,j,k;
/*=============================================================================
	Jets are created in two parts. first part is to create the spherial tip of a
	a jet.  The spherical tip of the jet will extend below zcent variable.
	the second part is to create a cylindrical neck of the jet. the neck will 
	extend above the zcent variable.  i.e.)
	*       *   cylindrical neck
	*       *
	*_______*_____zcent
	*     *
	*   *     spherical tip
	***
                               
	==============================================================================*/
    //loop that initializes spherical tip of the jet
	for (i=0;i<=im1;i++)
		for (j=0;j<=jm1;j++)
			for (k=0;k<=km1;k++)
	{
		if ( z[k] > zcent )
		{
                    //cell is empty?
			tx = x[i];
			ty = y[j];
			tz = z[k];
			txm = x[i-1];
			tym = y[j-1];                   
			tzm = z[k-1];
                    //goto cube;
			if ( MIN(SQUARE(txm-xcent), SQUARE(tx-xcent))
						  +MIN(SQUARE(tym-ycent), SQUARE(ty-ycent))
						  +MIN(SQUARE(tzm-zcent), SQUARE(tz-zcent))
						  >= r2)
				f[IJK]=0;
                    //cell is full?
			else if ( MAX(SQUARE(txm-xcent), SQUARE(tx-xcent))
							   +MAX(SQUARE(tym-ycent), SQUARE(ty-ycent))
							   +MAX(SQUARE(tzm-zcent), SQUARE(tz-zcent))                       <= r2)
				f[IJK]=1.0;
    
                    //cell neither empty nor full
			else
			{
				f[IJK]=0.0;
				for (int l=0;l<25;l++)
					for (int m=0;m<25;m++)
						for (int n=0;n<25;n++)
				{
					if (SQUARE(x[i-1]+(l+0.5)/25.0*delx[i]-xcent)+
									   SQUARE(y[j-1]+(m+0.5)/25.0*dely[j]-ycent)+
									   SQUARE(z[k-1]+(n+0.5)/25.0*delz[k]-zcent)
									   < r2)
						f[IJK]+= 6.4e-5;
				}
			}
		}
		else //initialize cylindrical neck
		{
                    //cell is empty?
			tx = x[i];
			ty = y[j];
			tz = z[k];
			txm = x[i-1];
			tym = y[j-1];
			tzm = z[k-1];
                    //goto cube;
			if ( MIN(SQUARE(txm-xcent), SQUARE(tx-xcent))
						  +MIN(SQUARE(tym-ycent), SQUARE(ty-ycent)) > r2)
				f[IJK]=0;
                    //cell is full?
			else if ( MAX(SQUARE(txm-xcent), SQUARE(tx-xcent))
							   +MAX(SQUARE(tym-ycent), SQUARE(ty-ycent)) <= r2)
				f[IJK]=1.0;
                        //cell neither empty nor full
			else
			{
				f[IJK]=0.0;
				for (int l=0;l<25;l++)
					for (int m=0;m<25;m++)
				{
					if (SQUARE(x[i-1]+(l+0.5)/25.0*delx[i]-xcent)+
									   SQUARE(y[j-1]+(m+0.5)/25.0*dely[j]-ycent) < r2)
						f[IJK]+= 1.6e-3;
				}
			}
                    
                    
		}
		ftotal += f[IJK]*vol[IJK];
		f_total += f[IJK];
	}/*for IJK*/
	/*preseve plane shape near inflow boundary*/
	if (kl == 3)
	{
		printf("INITF ERROR: Jet not implemented on left face correctly!\n");
		exit(1);
	}
	else if (kr == 3)
	{
		printf("INITF ERROR: Jet not implemented on right face correctly!\n");
		exit(1);
	}
	else if (kb == 3)
	{
		printf("INITF ERROR: Jet not implemented on back face correctly!\n");
		exit(1);
	}
	else if (kf == 3)
	{
		printf("INITF ERROR: Jet not implemented on front face correctly!\n");
		exit(1);
	}
	else if (ku == 3)
	{
		printf("INITF ERROR: Jet not implemented on under face correctly!\n");
		exit(1);
	}
	else if (ko == 3)
	{
      /*if OVER face on this processor is real, preserve the original circular
		profile of the jet by copying f from level km2 into ftemp.  This is 
		needed later when applying bc's
	  */
		if (mpi.Neighbors[5] == -1)
		{
			memcpy (&ftemp[IND(0,0,km2)], &f[IND(0,0,km2)], NX*NY*sizeof(double));
		}
	}
}

