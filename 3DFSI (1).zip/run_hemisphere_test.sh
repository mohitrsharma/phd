#!/bin/bash
#SBATCH --job-name=hemisphere_test
#SBATCH --output=hemisphere_test_%j.out
#SBATCH --error=hemisphere_test_%j.err
#SBATCH --ntasks=4
#SBATCH --nodes=1
#SBATCH --time=01:00:00
#SBATCH --mem=4G

# Load necessary modules (adjust based on your cluster)
module load gcc
module load openmpi

# Change to the correct directory if needed
cd $SLURM_SUBMIT_DIR

echo "Starting hemisphere test case run..."
echo "=================================="

# Compile the code with FINE_GRID flag
echo "Compiling code..."
make clean
make COMPILE_FLAGS="-DFINE_GRID"

# Check if compilation was successful
if [ $? -ne 0 ]; then
    echo "Compilation failed!"
    exit 1
fi

# Run the simulation
echo "Running simulation..."
mpirun -n 4 ./ripple

# Check if run was successful
if [ $? -ne 0 ]; then
    echo "Run failed!"
    exit 1
fi

echo "=================================="
echo "Simulation completed successfully!"
echo "Output files have been generated in the current directory."
echo "Use ParaView to visualize the results with the VTK files."
echo "Check fluid_volume.txt for volume information."

# Optional: List output files
echo "Output files:"
ls -l *.vtk
cat fluid_volume.txt

exit 0 