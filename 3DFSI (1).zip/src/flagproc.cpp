#include <stdlib.h>
#include "ripple.h"
#include "testing.h"

void flagproc()
{
	/*
	 * This subroutine sets mpi.obstflag on every processor.
	 * Flag is set to FALSE by default.
	 * If 1 or more obstacle cells exists in the local domain,
	 * the flag is set to TRUE.  This flag is then used throughout
	 * the code so that processors who don't have obstacles in
	 * their local domain, have to worry about applying obstacle
	 * boundary conditions.
	 */
	int i,j,k;

	//initialize obst_flag variable of struct mpi to false
	for (i = 0; i < mpi.NProc; i++)
		mpi.obst_flag = false;

	//set obst_flag to true for those processors which have
	//at least 1 obstacle cell in their local domain
	for (k = 1; k < km1;k++)
		for (j = 1; j < jm1; j++)
			for (i = 1; i < im1; i++)
				if (isobstsfc(IJK))
				{
					mpi.obst_flag = true;
					goto done;
				}
			
	//look for obstacle cells in ghost cells on the right
	for(j=1;j<jm1;j++)
		for(k=1;k<km1;k++)
		{
			int ijkr = IND(im1,j,k);
			if(ac[ijkr]==0 && ac[ijkr-1]==1) // if(obst[ijkr].flag_r)
			{
				mpi.obst_flag = true;
				goto done;
			}
			
			ijkr = IND(0,j,k); //for viscousobs ... added by ashish
			if(ac[ijkr]==0 && ac[ijkr+1]==1) 
			{
				mpi.obst_flag = true;
				goto done;
			}
		}
		
	//look for obstacle cells in ghost cells in front
	for(i=1;i<im1;i++)
		for(k=1;k<km1;k++)
		{
			int ijkf = IND(i,jm1,k);
			if(ac[ijkf]==0 && ac[ijkf-imax]==1) //if(obst[ijkf].flag_f)
			{
				mpi.obst_flag = true;
				goto done;
			}
			
			ijkf = IND(i,0,k);
			if(ac[ijkf]==0 && ac[ijkf+imax]==1) 
			{
				mpi.obst_flag = true;
				goto done;
			}
		}
		
	//obstacle cells on top
	for(i=1;i<im1;i++)
		for(j=1;j<jm1;j++)
		{
			int ijko = IND(i,j,km1); 
			if(ac[ijko]==0 && ac[ijko-ijmax]==1)//if(obst[ijko].flag_o)
			{
				mpi.obst_flag = true;
				goto done;
			}
			
			ijko = IND(i,j,0); 
			if(ac[ijko]==0 && ac[ijko+ijmax]==1)
			{
				mpi.obst_flag = true;
				goto done;
			}
		}
			
	done:
		return;
}
