#include "ripple.h"
#include <stdlib.h>
#include <time.h>
#include "testing.h"

/******************************************************************************
This subroutine sets the f1 array used by RESIDUAL in order to measure by how
much is spherical droplet deformed during a translation

Subroutine SETF1 is called by:	SPHERICITY

Subroutine SETF1 calls:			

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

//set f1 array for comparing with f in order to calculate the sphericity
//of the droplet after translation

void setf1(double x_cent, double y_cent, double z_cent)
{
	double tx, ty, tz, txm, tym, tzm; //temporary x,y,z of ijk
	double r2=radius*radius;
	double f1total=0.0;
	int i,j,k;

	for (i=1;i<=im1;i++)
		for (j=1;j<=jm1;j++)
			for (k=1;k<=km1;k++)
			{
				//cell is empty?
				tx = x[i];
				ty = y[j];
				tz = z[k];
				txm = x[i-1];
				tym = y[j-1];
				tzm = z[k-1];
				//goto cube;
				if ( MIN(SQUARE(txm-x_cent), SQUARE(tx-x_cent))
					+MIN(SQUARE(tym-y_cent), SQUARE(ty-y_cent))
					+MIN(SQUARE(tzm-z_cent), SQUARE(tz-z_cent))
					>= r2)
					f1[IJK]=0;
	
				//cell is full?
				else if ( MAX(SQUARE(txm-x_cent), SQUARE(tx-x_cent))
					+MAX(SQUARE(tym-y_cent), SQUARE(ty-y_cent))
					+MAX(SQUARE(tzm-z_cent), SQUARE(tz-z_cent))
					<= r2)
					f1[IJK]=1.0;
	
				//cell neither empty nor full
				else
				{
					f1[IJK]=0.0;
					for (int l=0;l<25;l++)
						for (int m=0;m<25;m++)
							for (int n=0;n<25;n++)
							{
								if (SQUARE(x[i-1]+(l+0.5)/25.0*delx[i]-x_cent)+
									SQUARE(y[j-1]+(m+0.5)/25.0*dely[j]-y_cent)+
									SQUARE(z[k-1]+(n+0.5)/25.0*delz[k]-z_cent)
									< r2)
									f1[IJK]+= 6.4e-5;
							}
				}
		
		    }

	//fprintf (files.out, "initial f vs exact: %12.5f\n", ftotal/(4.0/3.0*pi*CUBE(radius)));
}
