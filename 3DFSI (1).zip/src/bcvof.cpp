#include "ripple.h"
#include <stdlib.h> //exit
#include "testing.h"

/******************************************************************************
This subroutine is called at the end of vofdly and it applies free surface
bc's to a single cell, including the face shared with another newly filled cell


Subroutine BCVOF is called by:	VOFDLY	

Subroutine BCVOF calls:		

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/


double bcvof (int i, int j, int k, int iface)
{
	int numneigh=0;
	const int ii=IND(i,j,k);
	const int ipjk=ii+1;
	const int imjk=ii-1;
	const int ijpk=ii+imax;
	const int ijmk=ii-imax;
	const int ijkp=ii+ijmax;
	const int ijkm=ii-ijmax;
	if ((f[imjk]<em6 && ar[imjk]>em6) || iface==1)
	{
		u[imjk]=u[imjk+inside[nf[ii]]];
		numneigh++;
	}
	if ((f[ipjk]<em6 && ar[ii]>em6) || iface==2)
	{
		int temp = inside[nf[ii]];
		u[ii]=u[ii+inside[nf[ii]]];
		numneigh++;
	}
	if ((f[ijmk]<em6 && af[ijmk]>em6) || iface==3)
	{
		v[ijmk]=v[ijmk+inside[nf[ii]]];
		numneigh++;
	}
	if ((f[ijpk]<em6 && af[ii]>em6) || iface==4)
	{
		v[ii]=v[ii+inside[nf[ii]]];
		numneigh++;
	}
	if ((f[ijkm]<em6 && ao[ijkm]>em6) || iface==5)
	{
		w[ijkm]=w[ijkm+inside[nf[ii]]];
		numneigh++;
	}
	if ((f[ijkp]<em6 && ao[ii]>em6) || iface==6)
	{
		w[ii]=w[ii+inside[nf[ii]]];
		numneigh++;
	}

	//now apply a divergence correction to any of the six
	//velocities bordering on void cells

	double dijk=rdx[i]*(ar[ii]*u[ii]-ar[imjk]*u[imjk])
		       +rdy[j]*(af[ii]*v[ii]-af[ijmk]*v[ijmk])
			   +rdz[k]*(ao[ii]*w[ii]-ao[ijkm]*w[ijkm]);

	switch (iface)
	{
		case 1: return u[imjk]+delx[i]*dijk/(ar[imjk]*(double)numneigh);
		case 2: return u[ii]-delx[i]*dijk/(ar[ii]*(double)numneigh);
		case 3: return v[ijmk]+dely[j]*dijk/(af[ijmk]*(double)numneigh);
		case 4: return v[ii]-dely[j]*dijk/(af[ii]*(double)numneigh);
		case 5: return w[ijkm]+delz[k]*dijk/(ao[ijkm]*(double)numneigh);
		case 6: return w[ii]-delz[k]*dijk/(ao[ii]*(double)numneigh);
		default:
			printf ("Error in bcvof, iface=%d\n",iface);
			exit (1);
	}
}
