#include "ripple.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef bl_mg
//---------------alphabetic order----------------------------//
void array_copy(const int lev, double *mf1, double *mf2);
double array_sum(const int lev, double *mf);
void bl_mg_prolongation(const int lev, double *cc, double *ff);
void bl_mg_restriction(const int lev, double *cc, double *ff);
void bl_mg_smoother(const int lev, double &omega, double *const ptr, double *uu, double *rh);
void bl_mg_v_cycle(const int lev, double *uu, double *rh, const int nu1, const int nu2);
void build_edge_coeffs();
void compute_defect(const int lev, double *const ptr, double *dd, double *ff, double *uu);
void debug_tool ();
void diag_initialize(const int lev, double *const ptr, double *rh);
double dot(const int lev, double *mf1, double *mf2, const bool local);
void itsol_bicgstab_solve(const int lev, double *uu, double *rh, const double &rel_eps, const int max_iter);
void itsol_bicgstabL_solve(const int lev, double *uu, double *rh, const double &rel_eps, const int max_iter);
void itsol_cg_solve(const int lev, double *uu, double *rh, const double &rel_eps, const int max_iter);
bool itsol_converged(const int lev, double *rr, double &rrnorm, const double &bnorm, const double &eps);
bool itsol2_converged(const int lev, double *rr, double &rrnorm, const double &bnorm, const double &eps);
void itsol_precon(const int lev, double *const ptr, double *uu, double *rh);
double max_of_stencil_sum(const int lev, double *const ptr);
bool ml_converged(double *res, const double &max_norm, const double &rel_eps, const double &abs_eps, double &ni_res);
void non_obst_cells(int lev, double &tcells);
double norm_inf(const int lev, double *mf, const bool local);
double norm2 (const int lev, double *mf);
void plus_plus(const int lev, double *dd, double *ff);
void print_ghost(const int lev, double *mf, const int proc, const int loc, const int dim);
void print_phy(const int lev, double *mf, const int proc, const int loc, const int dim);
void rescale(const int lev, double *mf, const double val);
void saxpy(const int lev, double *a, double *b, const double c1, double *c);
void set_stencil();
void setval(const int lev, double *mf, const double val);
void stencil_apply(const int lev, double *const ptr, double *dd, double *uu);
void stencil_copy(const int lev, double *ptr1, double *ptr2) ;
double stencil_norm(const int lev, double *const ptr);
void sub_rescal(const int lev, double *dd, double *ff, const double alp);
void sub_sub(const int lev, double *dd, const double ff);
void top_bicgstab_solve(const int lev, double *uu, double *rh, const double &rel_eps, const int max_iter);
void top_bicgstabL_solve(const int lev, double *uu, double *rh, const double &rel_eps, const int max_iter);
void top_cg_solve(const int lev, double *uu, double *rh, const double &rel_eps, const int max_iter);

//the order of the loops should be (k,j,i)
#define DIM2 0//can be 0 or 1 [for 3D and 2D respectively]
#define mIND(X,Y,Z) ((X)+((Y)+(Z)*ny)*nx)
#define mIJK mIND(i,j,k)

#define mIMJK mIND(i-1,j  ,k  )
#define mIPJK mIND(i+1,j  ,k  )
#define mIJMK mIND(i  ,j-1,k  )
#define mIJPK mIND(i  ,j+1,k  )
#define mIJKM mIND(i  ,j  ,k-1)
#define mIJKP mIND(i  ,j  ,k+1) //these defines have been tested

#define mIND_f(X,Y,Z) ((X)+((Y)+(Z)*ny_f)*nx_f)
int bl_i, bl_j, bl_k;

//mg_param_init(), and bl_mg_memalloc to be called in allocarray

//----------------------FIRST THE MAIN FUNCTIONS-------------------------------------
void mg_param_init() {
	//initializes the parameters associated with the bl_multigrid 
	mg_nu1 = 1;
	mg_nu2 = 1;
	mg_eps = 1.e-9;
	mg_abs_eps = -1.e0;
	mg_bottom_solve_eps = 1.e-9;
	mg_max_iter = 100;
	mg_bottom_max_iter = 1000;
	
	//physical + ghost cells
	mg_bnd[MGLEVS][1] = NX;
	mg_bnd[MGLEVS][2] = NY;
	mg_bnd[MGLEVS][3] = NZ;
		
	for(int n=MGLEVS-1;n>=1;n--) {
	  mg_bnd[n][1] = (mg_bnd[n+1][1]-2)/2 + 2;
	  mg_bnd[n][2] = (mg_bnd[n+1][2]-2)/2 + 2;
	  mg_bnd[n][3] = (mg_bnd[n+1][3]-2)/2 + 2;
	  
#if DIM2
	  mg_bnd[n][2] = 3;
#endif
	  
	}
}

void mg_boxlib() {
	//for testing purposes
	if(mpi.MyRank==0) printf("entered in this function mg_boxlib\n");
	for(int n=MGLEVS; n>=1; n--) {
		const int nx = mg_bnd[n][1];
		const int ny = mg_bnd[n][2];
		const int nz = mg_bnd[n][3];
		const int i = nx-2, j = ny-2, k = nz-2;
		if(mpi.MyRank==0) printf("lev %d: (%d (%d %d %d))\n",n,mIJK,i,j,k);
	}
}

void bl_mg_memalloc() {
	//allocate memory associated with boxlib multigrid ..
	//memory is allocated only at coarser mg levels, 
	//at finest level temps are used
	temp[24] = (double*)memalloc (NX, NY, NZ, sizeof(double));
	
	for(int n=MGLEVS;n>=1;n--) {
		if(n==MGLEVS) {
			//temp[0-6] are reserved for the ss
			mg_ss[n] = temp[0];
			mg_cc[n] = temp[7];
			mg_dd[n] = temp[8]; 
			for(int c=1;c<=3;c++)
				mg_ec[n][c] = temp[c+14]; //edge coeff.
		}
		else {
			const int sx = mg_bnd[n][1],
					  sy = mg_bnd[n][2],
			          sz = mg_bnd[n][3];
			
			mg_ss[n] = (double*)memalloc (sx,sy,7*sz,sizeof(double)); //linear array
			mg_cc[n] = (double*)memalloc (sx,sy,sz,sizeof(double));
			mg_dd[n] = (double*)memalloc (sx,sy,sz,sizeof(double));
			mg_uu[n] = (double*)memalloc (sx,sy,sz,sizeof(double));
			for(int c=1;c<=3;c++)
				mg_ec[n][c] = (double*)memalloc (sx,sy,sz,sizeof(double));
		}
	}
}

void build_edge_coeffs() {
	rhorc=temp[18], rhofc=temp[19], rhooc=temp[20];
	
	//edge-coeff = 1.0/rho
	for(int n=MGLEVS;n>=1;n--) {
		const int nx=mg_bnd[n][1], 
		          ny=mg_bnd[n][2], 
		          nz=mg_bnd[n][3];
		          
		if(n==MGLEVS) {
			mg_dh[n][1] = delx[1];
	        mg_dh[n][2] = dely[1];
			mg_dh[n][3] = delz[1];
			
			for(int k=0;k<nz-1;k++)
			 for(int j=0;j<ny-1;j++)
			  for(int i=0;i<nx-1;i++) {
				//skip undefined regions
				if(j>0 && k>0) mg_ec[n][1][mIJK] = 1.0/rhorc[mIJK];
				if(i>0 && k>0) mg_ec[n][2][mIJK] = 1.0/rhofc[mIJK];
				if(i>0 && j>0) mg_ec[n][3][mIJK] = 1.0/rhooc[mIJK];
			   }
			   
			for(int k=0;k<nz;k++) //we have to consider the obstacle cells
			 for(int j=0;j<ny;j++)//on both low/high ends
			  for(int i=0;i<nx;i++) {
				  //if an obstacle cell
				  if(ac[mIJK] < em6) {
					  if(j>0 && k>0) {
						if(i<nx-1) mg_ec[n][1][mIJK ] = 0.0;
						if(i>   0) mg_ec[n][1][mIMJK] = 0.0;
					  }
					  if(i>0 && k>0) {
						if(j<ny-1) mg_ec[n][2][mIJK ] = 0.0;
						if(j>   0) mg_ec[n][2][mIJMK] = 0.0;
					  }
					  if(i>0 && j>0) {
						if(k<nz-1) mg_ec[n][3][mIJK ] = 0.0;
						if(k>   0) mg_ec[n][3][mIJKM] = 0.0;
					  }
				  }
			  } 
		}
		else {
			//nx,ny,nz already defined above.. lets define nx_f,ny_f,nz_f
			const int nx_f=mg_bnd[n+1][1], 
					  ny_f=mg_bnd[n+1][2], 
			          nz_f=mg_bnd[n+1][3];
			          
			mg_dh[n][1] = 2.0*mg_dh[n+1][1],
			mg_dh[n][2] = 2.0*mg_dh[n+1][2],
			mg_dh[n][3] = 2.0*mg_dh[n+1][3];

#if DIM2
			for(int k=0;k<nz-1;k++)
			 for(int j=0;j<ny-1;j++)
			  for(int i=0;i<nx-1;i++) {
				  if(j>0 && k>0) {
					mg_ec[n][1][mIJK]=0.5e0*(
											  mg_ec[n+1][1][mIND_f(2*i,  2*j-1,2*k-1)]
					                        + mg_ec[n+1][1][mIND_f(2*i  ,2*j-1,2*k  )] 
					                        );
				  }
				  if(i>0 && j>0) {
					mg_ec[n][3][mIJK]=0.5e0*(
					                          mg_ec[n+1][3][mIND_f(2*i-1,2*j-1,2*k  )] 
					                        + mg_ec[n+1][3][mIND_f(2*i  ,2*j-1,2*k  )]
					                        );
				  }
			  } //end for
#else			
			for(int k=0;k<nz-1;k++)
			 for(int j=0;j<ny-1;j++)
			  for(int i=0;i<nx-1;i++) {
				  if(j>0 && k>0) {
					mg_ec[n][1][mIJK]=0.25e0*(mg_ec[n+1][1][mIND_f(2*i  ,2*j-1,2*k-1)] 
											+ mg_ec[n+1][1][mIND_f(2*i,  2*j  ,2*k-1)]
					                        + mg_ec[n+1][1][mIND_f(2*i  ,2*j-1,2*k  )] 
					                        + mg_ec[n+1][1][mIND_f(2*i  ,2*j  ,2*k  )]);
				  }
				  if(i>0 && k>0) {
					mg_ec[n][2][mIJK]=0.25e0*(mg_ec[n+1][2][mIND_f(2*i-1,2*j  ,2*k-1)] 
											+ mg_ec[n+1][2][mIND_f(2*i  ,2*j  ,2*k-1)]
					                        + mg_ec[n+1][2][mIND_f(2*i-1,2*j  ,2*k  )] 
					                        + mg_ec[n+1][2][mIND_f(2*i  ,2*j  ,2*k  )]);
				  }
				  if(i>0 && j>0) {
					mg_ec[n][3][mIJK]=0.25e0*(mg_ec[n+1][3][mIND_f(2*i-1,2*j-1,2*k  )] 
					                        + mg_ec[n+1][3][mIND_f(2*i  ,2*j-1,2*k  )]
					                        + mg_ec[n+1][3][mIND_f(2*i-1,2*j  ,2*k  )] 
					                        + mg_ec[n+1][3][mIND_f(2*i  ,2*j  ,2*k  )]);
				  }
			  } //end for
#endif
		}
	}
}

void set_stencil() {
	
	for(int n=MGLEVS;n>=1;n--) {
		const int nx=mg_bnd[n][1], 
		          ny=mg_bnd[n][2], 
		          nz=mg_bnd[n][3];
		
		double *const ptr   = mg_ss[n];
		double *const betax = mg_ec[n][1]; 
		double *const betay = mg_ec[n][2]; 
		double *const betaz = mg_ec[n][3];
		
		const double f1[4] = {0.0,
							  1.0/(mg_dh[n][1] * mg_dh[n][1]),
							  1.0/(mg_dh[n][2] * mg_dh[n][2]),
							  1.0/(mg_dh[n][3] * mg_dh[n][3])};
		
		for(int k=1;k<nz-1;k++)
		 for(int j=1;j<ny-1;j++)
		  for(int i=1;i<nx-1;i++) {
			  double *const ss = ptr + 7*mIJK;
			  ss[0] = 0.0;
			  ss[1] = -betax[mIJK] *f1[1];
			  ss[2] = -betax[mIMJK]*f1[1];
			  ss[3] = -betay[mIJK] *f1[2];
			  ss[4] = -betay[mIJMK]*f1[2];
			  ss[5] = -betaz[mIJK] *f1[3];
			  ss[6] = -betaz[mIJKM]*f1[3];
		  }
		  
		//neumann on left domain boundary
		if(mpi.Neighbors[0] == -1) {
			for(int k=1;k<nz-1;k++)
			 for(int j=1;j<ny-1;j++) {
				int i = 1;
				double *const ss = ptr + 7*mIJK;
				ss[2] = 0.0;
			}
		}
		
		//neumann on right domain boundary
		if(mpi.Neighbors[1] == -1) {
			for(int k=1;k<nz-1;k++)
			 for(int j=1;j<ny-1;j++) {
				int i = nx-2;
				double *const ss = ptr + 7*mIJK;
				ss[1] = 0.0;
			}
		}
		
		//neumann on bottom domain boundary
		if(mpi.Neighbors[2] == -1) {
			for(int k=1;k<nz-1;k++)
			 for(int i=1;i<nx-1;i++) {
				 int j = 1;
				 double *const ss = ptr + 7*mIJK;
				 ss[4] = 0.0;
			 }
		}
		
		//neumann on top domain boundary
		if(mpi.Neighbors[3] == -1) {
			for(int k=1;k<nz-1;k++)
			 for(int i=1;i<nx-1;i++) {
				 int j = ny-2;
				 double *const ss = ptr + 7*mIJK;
				 ss[3] = 0.0;
			 }
		}
		
		//neumann on under domain boundary
		if(mpi.Neighbors[4] == -1) {
			for(int j=1;j<ny-1;j++)
			 for(int i=1;i<nx-1;i++) {
				 int k = 1;
				 double *const ss = ptr + 7*mIJK;
				 ss[6] = 0.0;
			 }
		}
		
		//neumann on over domain boundary
		if(mpi.Neighbors[5] == -1) {
			for(int j=1;j<ny-1;j++)
			 for(int i=1;i<nx-1;i++) {
				 int k = nz-2;
				 double *const ss = ptr + 7*mIJK;
				 ss[5] = 0.0;
			 }
		}
		
		//now set the central coefficient
		for(int k=1;k<nz-1;k++)
		 for(int j=1;j<ny-1;j++)
		  for(int i=1;i<nx-1;i++) {
			  double *const ss = ptr + 7*mIJK;
			  for(int c=1;c<=6;c++)
				ss[0] += -ss[c];
		  }
	}
}

void referencePressure();

void bl_mg_main() {
	//akin to ml_cc() in boxlib
	double *const rh  = temp[12]; //temp[13] is reserved for div
	double *const res = temp[14];
	double *const uu  = temp[24];
	double *const full_soln = p;
#ifdef balanced_force		
	double *tensx=temp[9], *tensy=temp[10], *tensz=temp[11];
#endif

	bool coeffs_sum_to_zero = false, solved = false;
	if(mpi.MyRank==0) printf("entering boxlib_mg now\n");
	build_edge_coeffs(); //these are in ml_solve in boxlib
	set_stencil();
	
	//memset to zero in undefined regions
	memset (rh ,       0, NX*NY*NZ*sizeof(double));
	memset (full_soln, 0, NX*NY*NZ*sizeof(double));
	memset (res,       0, NX*NY*NZ*sizeof(double));
	
	//referencePressure();
	
	for(int k=1;k<km1;k++)
	 for(int j=1;j<jm1;j++)
	  for(int i=1;i<im1;i++) {
			const double div =(rdx[i]*(ar[IJK]*u[IJK]-ar[IMJK]*u[IMJK])
						+rdy[j]*(af[IJK]*v[IJK]-af[IJMK]*v[IJMK])
						+rdz[k]*(ao[IJK]*w[IJK]-ao[IJKM]*w[IJKM]));
			rh[IJK] = -ac[IJK]*div/delt;
			
#ifdef balanced_force
			double divsft =(rdx[i]*(ar[IJK]*tensx[IJK]/rhorc[IJK]-ar[IMJK]*tensx[IMJK]/rhorc[IMJK])
				    	  +rdy[j]*(af[IJK]*tensy[IJK]/rhofc[IJK]-af[IJMK]*tensy[IJMK]/rhofc[IJMK])
						  +rdz[k]*(ao[IJK]*tensz[IJK]/rhooc[IJK]-ao[IJKM]*tensz[IJKM]/rhooc[IJKM]));
			rh[IJK] =-ac[IJK]*(div/delt + divsft);
#endif
			if(ac[IJK] < em6 && fabs(rh[IJK]) > em6) printf("error: initializing residuals: rank=%d IJK(i,j,k)=%d(%d %d %d) ac[IJK]=%e rh[IJK]=%e\n",mpi.MyRank,IJK,i,j,k,ac[IJK],rh[IJK]);
	  }
	  
	//compute defect
	compute_defect(MGLEVS,mg_ss[MGLEVS],res,rh,full_soln);
	
	double t1[5] = {0.0,
					max_of_stencil_sum(1,mg_ss[1]), //this is the bottom-most level
					stencil_norm(1,mg_ss[1]),
					norm_inf(MGLEVS,res,true),
					norm_inf(MGLEVS,rh ,true) //if initial soln is zero, 					
					};						  //then both rh and res are equal
	
	double t2[5];	
	dallreduce(t1,t2,5,OP_MAX);
	
	const double coeff_sum = t2[1],
	             coeff_max = t2[2],
	             tres0     = t2[3],
	             bnorm     = t2[4];
	
	if(coeff_sum < (1.e-12*coeff_max)) {
		coeffs_sum_to_zero = true;
		if(mpi.MyRank==0) printf("coefficients to sum to zero\n");	
	}
	else {
		if(mpi.MyRank==0) printf("coeff. (sum,max)=(%e %e)\n",coeff_sum,coeff_max);
	}
	
	double ncells; 				//here we are enforcing "solvability"
	if(coeffs_sum_to_zero) {    //same performed in the bottom solves
		non_obst_cells(MGLEVS, ncells); //ncells is the output
		if(mpi.MyRank==0) printf("ncells=%e nprocs=%d\n",ncells,mpi.NProc);
		const double sum = array_sum(MGLEVS,res) / (ncells+tiny);	
		sub_sub(MGLEVS,res,sum); //note that sum_zero may not be "exactly" zero due to machine precision limitations
	}
	
	double max_norm = bnorm;
	if(bnorm < tres0)
		max_norm = tres0;
	
	double ni_res; int iter;
	if(ml_converged(res,max_norm,mg_eps,mg_abs_eps,ni_res)) {
		solved = true;
		if(mpi.MyRank==0) printf("ml_cc: already converged, no iterations required\n");
	}
	else {
		//an option for MG-VCycle provided here
		/*const int max_iter = mg_max_iter,
		          nu1 = mg_nu1,
		          nu2 = mg_nu2;
		for(iter=1;iter<=max_iter;iter++) {
			
			memset(uu,0,NX*NY*NZ*sizeof(double));

			bl_mg_v_cycle(MGLEVS,uu,res,nu1,nu2);
			plus_plus(MGLEVS,full_soln,uu); //full_soln += uu
			
			//compute now the residual
			compute_defect(MGLEVS,mg_ss[MGLEVS],res,rh,full_soln);
						
		    if(ml_converged(res,max_norm,mg_eps,mg_abs_eps,ni_res)) {
				solved = true;
				break;
			}
			if(mpi.MyRank==0) printf("MG At %d iter: ni_res, max_norm = (%.12e %.12e)\n",iter,ni_res,max_norm);
			
			if(coeffs_sum_to_zero) {
				const double sum = array_sum(MGLEVS,res) / (ncells+tiny);
				sub_sub(MGLEVS,res,sum);
			}
		} //for iter*/
		memset(uu,0,NX*NY*NZ*sizeof(double));
		top_bicgstab_solve(MGLEVS,uu,res,mg_eps,mg_max_iter); //the convergence print statements reside in this function
		plus_plus(MGLEVS,full_soln,uu);
	}
	
	/*if(mpi.MyRank==0) {
		if(solved) printf("converged after %d cycles: ni_res, max_norm = (%.12e %.12e)\n",iter,ni_res,max_norm);
		else printf("Past max iter %d cycles: ni_res, max_norm = (%.12e %.12e)\n",iter,ni_res,max_norm);
	}*/
	//xchg and fill boundareis 
	bc();
	//referencePressure();
   	bdycell();
	accel();
	bc();
	//referencePressure();
}

void bl_mg_v_cycle(const int lev, double *uu, double *rh, const int nu1, const int nu2) {
	//akin to mg_tower_v_cycle() in boxlib ...a recursive function
	//the commented lines for looking at the evolution of the residuals ...
	
	const int lbl = 1;
	double omega=1.0; //omega = 1 is for Gauss-Seidel..
					  //omega > 1.0 for excessive dissipation, when the MG would 
					  //not converge with simple Gauss-Seidel, i.e., with omega=1.0
	
	if(lev == lbl) {		
		itsol_bicgstab_solve(lev,uu,rh,mg_bottom_solve_eps,mg_bottom_max_iter);
		//for(int i=1;i<=100;i++)
			//bl_mg_smoother(lev,omega,mg_ss[lev],uu,rh); //an option for GS smoother at the bottom-most level
	}
	else {
		//-------------
		/*FILE *fp;
		char sbuf[20];
		sprintf(sbuf,"res_lev_%d",lev);
		fp=fopen(sbuf,"a+");
		compute_defect(lev,mg_ss[lev],mg_cc[lev],rh,uu);
		double nm_inf = norm_inf(lev,mg_cc[lev],false);
		if(mpi.MyRank==0 && ncyc==588) fprintf(fp,"%e\n",nm_inf);*/
		//-------------------------
		
		for(int i=1;i<=nu1;i++)
			bl_mg_smoother(lev,omega,mg_ss[lev],uu,rh);
		
		compute_defect(lev,mg_ss[lev],mg_cc[lev],rh,uu);       //cc = rh-ss*uu
		bl_mg_restriction(lev-1,mg_dd[lev-1],mg_cc[lev]); //dd[lev-1] = (1/8)*(cc[lev])
		
		//-------------------
		/*nm_inf = norm_inf(lev,mg_cc[lev],false);
		if(mpi.MyRank==0 && ncyc==588) fprintf(fp,"%e\n",nm_inf);*/
		//---------------------
		
		const int nx=mg_bnd[lev-1][1], 
			      ny=mg_bnd[lev-1][2], 
	              nz=mg_bnd[lev-1][3];
		memset(mg_uu[lev-1],0,nx*ny*nz*sizeof(double));          //uu[lev-1] <-- 0 
		
		bl_mg_v_cycle(lev-1,mg_uu[lev-1],mg_dd[lev-1],nu1,nu2);  //[lev-1]: uu = (1/ss)*(dd)
		bl_mg_prolongation(lev-1,mg_uu[lev-1],uu);               // uu[lev] = uu[lev] + uu[lev-1]
		
		//---------
		/*compute_defect(lev,mg_ss[lev],mg_cc[lev],rh,uu);
		nm_inf = norm_inf(lev,mg_cc[lev],false);
		if(mpi.MyRank==0 && ncyc==588) fprintf(fp,"%e\n",nm_inf);*/
		//---------
		
		for(int i=1;i<=nu2;i++)
			bl_mg_smoother(lev,omega,mg_ss[lev],uu,rh);
		
		
		//---------
		/*compute_defect(lev,mg_ss[lev],mg_cc[lev],rh,uu);
		nm_inf = norm_inf(lev,mg_cc[lev],false);
		if(mpi.MyRank==0 && ncyc==588) fprintf(fp,"%e\n",nm_inf);*/
		//---------
		
		//fclose(fp);
	}
}

//--------------NOW THE AUXILIARY FUNCTIONS------------------------------------------------
void compute_defect(const int lev, double *const ptr, double *dd, double *ff, double *uu) {
	stencil_apply(lev,ptr,dd,uu); //dd=ss*uu
	sub_rescal(lev,dd,ff,-1.0); //dd=(-1.0)*(dd-ff)
}

void stencil_apply(const int lev, double *const ptr, double *dd, double *uu) {
	
	const int nx=mg_bnd[lev][1], 
			  ny=mg_bnd[lev][2], 
			  nz=mg_bnd[lev][3];
	
	xchg_lev<double>(lev,uu); 
			   
	for(int k=1;k<nz-1;k++)
	 for(int j=1;j<ny-1;j++)
	  for(int i=1;i<nx-1;i++) {
		  //dd[mIJK] = 0.0;
		  double *const ss = ptr + 7*mIJK;
		  //if(fabs(ss[0]) > 0.0)
		    dd[mIJK] = ss[0]*uu[mIJK] 
		             + ss[1]*uu[mIPJK] + ss[2]*uu[mIMJK]
		             + ss[3]*uu[mIJPK] + ss[4]*uu[mIJMK]
		             + ss[5]*uu[mIJKP] + ss[6]*uu[mIJKM];
	  }
} 

void sub_rescal(const int lev, double *dd, double *ff, const double alp) {
	
	const int nx=mg_bnd[lev][1], 
			  ny=mg_bnd[lev][2], 
			  nz=mg_bnd[lev][3];
	
	//double *const ptr = mg_ss[lev];
	for(int k=1;k<nz-1;k++)
	 for(int j=1;j<ny-1;j++)
	  for(int i=1;i<nx-1;i++) {
		  //double *const ss = ptr + 7*mIJK;
		  //if(fabs(ss[0]) > 0.0)
			dd[mIJK] = alp*(dd[mIJK]-ff[mIJK]);
	  }
}

void sub_sub(const int lev, double *dd, const double ff) {
	
	const int nx=mg_bnd[lev][1], 
	          ny=mg_bnd[lev][2], 
	          nz=mg_bnd[lev][3];
	double *const ptr = mg_ss[lev];
	for(int k=1;k<nz-1;k++)
	 for(int j=1;j<ny-1;j++)
	  for(int i=1;i<nx-1;i++) {
		  double *const ss = ptr + 7*mIJK;
		  if(fabs(ss[0]) > 0.0)
			dd[mIJK] = dd[mIJK]-ff;
	  }
}

void plus_plus(const int lev, double *dd, double *ff) {
	const int nx=mg_bnd[lev][1], 
		      ny=mg_bnd[lev][2], 
			  nz=mg_bnd[lev][3];
	
	//double *const ptr = mg_ss[lev];
	for(int k=1;k<nz-1;k++)
	 for(int j=1;j<ny-1;j++)
	  for(int i=1;i<nx-1;i++) {
		  //double *const ss = ptr + 7*mIJK;
		  //if(fabs(ss[0]) > 0.0)
			dd[mIJK] = dd[mIJK]+ff[mIJK];
	  }
}

double max_of_stencil_sum(const int lev, double *const ptr) {
	//very tight local scopes 
	const int nx=mg_bnd[lev][1], 
			  ny=mg_bnd[lev][2], 
			  nz=mg_bnd[lev][3];
		
	double r1 = -HUGE_VAL;
	for(int k=1;k<nz-1;k++)
	 for(int j=1;j<ny-1;j++)
	  for(int i=1;i<nx-1;i++) {
		  double *const ss = ptr + 7*mIJK;
		  double sum_comps = 0.0;
		  for(int c=0;c<7;c++) {
			sum_comps += ss[c];
		  }
		  r1 = MAX(r1,fabs(sum_comps));
	  }
	return r1;  //local max, do reduction in calling function
}

double stencil_norm(const int lev, double *const ptr) {
	
	const int nx=mg_bnd[lev][1], 
			  ny=mg_bnd[lev][2], 
			  nz=mg_bnd[lev][3];
		
	double r1 = -HUGE_VAL;
	for(int k=1;k<nz-1;k++)
	 for(int j=1;j<ny-1;j++)
	  for(int i=1;i<nx-1;i++) {
		  double *const ss = ptr + 7*mIJK;
		  double sum_comps = 0.0;
		  for(int c=0;c<7;c++)
			sum_comps += fabs(ss[c]);
		  r1 = MAX(r1,sum_comps);
	  }
	return r1; //local max, do reduction in the calling function
}

double norm_inf(const int lev, double *mf, const bool local) {
	
	const int nx=mg_bnd[lev][1], 
			  ny=mg_bnd[lev][2], 
	          nz=mg_bnd[lev][3];
	
	//double *const ptr = mg_ss[lev];
	double r1=0.0;
	for(int k=1;k<nz-1;k++)
	 for(int j=1;j<ny-1;j++)
	  for(int i=1;i<nx-1;i++) {
		  //double *const ss = ptr + 7*mIJK;
		  //if(fabs(ss[0]) > 0.0)
		  r1=MAX(r1,fabs(mf[mIJK]));
		  /*if(r1==fabs(mf[mIJK])) {
			  bl_i = i,
			  bl_j = j,
			  bl_k = k;
		  }*/
	  }
	
	double rr1 = r1;
	if(!local)
		dallreduce(&r1,&rr1,1,OP_MAX);
	/*if(t_prob2==1) {
		if(r1==rr1) {
			printf("norm_inf: rank=%d (i,j,k)=(%d %d %d) r1=%e \n", mpi.MyRank,bl_i,bl_j,
			bl_k,r1);
		}
	}*/
	return rr1;
}

double array_sum(const int lev, double *mf) {
	
	const int nx=mg_bnd[lev][1], 
			  ny=mg_bnd[lev][2], 
	          nz=mg_bnd[lev][3];
	
	double *const ptr = mg_ss[lev];
	double r1=0.0;
	for(int k=1;k<nz-1;k++)
	 for(int j=1;j<ny-1;j++)
	  for(int i=1;i<nx-1;i++) {
		  double *const ss = ptr + 7*mIJK;
		  if(fabs(ss[0]) > 0.0)
			r1 += mf[mIJK];
	  }
	double rr1;
	dallreduce(&r1,&rr1,1,OP_SUM);
	return rr1;
}

bool ml_converged(double *res, const double &max_norm, const double &rel_eps, const double &abs_eps, double &ni_res) {
	double l_ni_res = norm_inf(MGLEVS,res,true); //processor's local norm
	dallreduce(&l_ni_res,&ni_res,1,OP_MAX);
	return (ni_res <= rel_eps*max_norm || ni_res <= abs_eps);
}

void diag_initialize(const int lev, double *const ptr, double *rh) {
	
	const int nx=mg_bnd[lev][1], 
			  ny=mg_bnd[lev][2], 
			  nz=mg_bnd[lev][3];
	
	for(int k=1;k<nz-1;k++)
	 for(int j=1;j<ny-1;j++)
	  for(int i=1;i<nx-1;i++) {
		  double *const ss = ptr + 7*mIJK;
		  if(fabs(ss[0]) > 0.0) { //avoid div by zero
			const double denom = 1.0 / ss[0];
			rh[mIJK] = rh[mIJK] * denom;
			for(int c=1;c<7;c++)
				ss[c] = ss[c] * denom;
			ss[0] = 1.0;
		  }
	  }
}

void array_copy(const int lev, double *mf1, double *mf2) {
	
	const int nx=mg_bnd[lev][1], 
			  ny=mg_bnd[lev][2], 
			  nz=mg_bnd[lev][3];
	
	for(int k=0;k<nz;k++)
	 for(int j=0;j<ny;j++)
	  for(int i=0;i<nx;i++) {
		  mf1[mIJK] = mf2[mIJK];
	  }
}

void setval(const int lev, double *mf, const double val) {
	const int nx=mg_bnd[lev][1], 
			  ny=mg_bnd[lev][2], 
			  nz=mg_bnd[lev][3];
	
	for(int k=1;k<nz-1;k++)
	 for(int j=1;j<ny-1;j++)
	  for(int i=1;i<nx-1;i++) {
		  mf[mIJK] = val;
	  }
}

void stencil_copy(const int lev, double *ptr1, double *ptr2) {
	const int nx=mg_bnd[lev][1], 
			  ny=mg_bnd[lev][2], 
			  nz=mg_bnd[lev][3];
	
	for(int k=1;k<nz-1;k++)
	 for(int j=1;j<ny-1;j++)
	  for(int i=1;i<nx-1;i++) {
		  double *const ss1 = ptr1 + 7*mIJK;
		  double *const ss2 = ptr2 + 7*mIJK;
		  
		  for(int c=0;c<7;c++)
			ss1[c] = ss2[c];
	  }
}

double dot(const int lev, double *mf1, double *mf2, const bool local) {
	const int nx=mg_bnd[lev][1], 
			  ny=mg_bnd[lev][2], 
			  nz=mg_bnd[lev][3];
	
	double *const ptr = mg_ss[lev];
	double r = 0.0;
	for(int k=1;k<nz-1;k++)
	 for(int j=1;j<ny-1;j++)
	  for(int i=1;i<nx-1;i++) {
		  double *const ss = ptr + 7*mIJK;
		  if(fabs(ss[0]) > 0.0)
			r += mf1[mIJK]*mf2[mIJK];
	  }
	
	double rr = r;
	if(!local) {
		dallreduce(&r,&rr,1,OP_SUM); //rr : global sum
	}
	return rr;
}

bool itsol_converged(const int lev, double *rr, double &rrnorm, const double &bnorm, const double &eps) {
	rrnorm=norm_inf(lev,rr,false); //norm across processors
	return (rrnorm <= eps*bnorm || rrnorm <= 1.e-14);
}

bool itsol2_converged(const int lev, double *rr, double &rrnorm, const double &bnorm, const double &eps) {
	rrnorm=norm2(lev,rr); //norm across processors
	return (rrnorm <= eps*bnorm || rrnorm <= 1.e-14);
}

void saxpy(const int lev, double *a, double *b, const double c1, double *c) {
	const int nx=mg_bnd[lev][1], 
			  ny=mg_bnd[lev][2], 
			  nz=mg_bnd[lev][3];
	
	//double *const ptr = mg_ss[lev];
	
	for(int k=1;k<nz-1;k++)
	 for(int j=1;j<ny-1;j++)
	  for(int i=1;i<nx-1;i++) {
		  //double *const ss = ptr + 7*mIJK;
		  //if(fabs(ss[0]) > 0.0)
			a[mIJK] = b[mIJK] + c1 * c[mIJK]; 
	  }
}

void rescale(const int lev, double *mf, const double val) {
	const int nx=mg_bnd[lev][1], 
			  ny=mg_bnd[lev][2], 
			  nz=mg_bnd[lev][3];
	
	//double *const ptr = mg_ss[lev];
	for(int k=1;k<nz-1;k++)
	 for(int j=1;j<ny-1;j++)
	  for(int i=1;i<nx-1;i++) {
		  //double *const ss = ptr + 7*mIJK;
		  //if(fabs(ss[0]) > 0.0)
			mf[mIJK] = val*mf[mIJK]; 
	  }
}

void bl_mg_smoother(const int lev, double &omega, double *const ptr, double *uu, double *rh) {
	const int nx=mg_bnd[lev][1], 
			  ny=mg_bnd[lev][2], 
			  nz=mg_bnd[lev][3];
	
	int lnn[4]={0,1,1,0};
	for(int nn=0; nn<=3; nn++) {
		xchg_lev<double>(lev,uu); //fill_boundary
		for(int k=1;k<nz-1;k++)
		 for(int j=1;j<ny-1;j++) {
			 
		  int ioff=0; if((1+j+k)%2 == lnn[nn]) ioff = 1;
		  for(int i=1+ioff;i<nx-1;i+=2) {
			  double *const ss = ptr + 7*mIJK;
			  if(fabs(ss[0]) > 0.0) {
			    const double dd = ss[0]*uu[mIJK]
				  			    + ss[1]*uu[mIPJK] + ss[2]*uu[mIMJK]
							    + ss[3]*uu[mIJPK] + ss[4]*uu[mIJMK]
							    + ss[5]*uu[mIJKP] + ss[6]*uu[mIJKM];
			    uu[mIJK] = uu[mIJK] + omega*(rh[mIJK] - dd)/(ss[0] + tiny);
			  }
		  }
	     } //for jj
	}//for nn
}

void bl_mg_restriction(const int lev, double *cc, double *ff) {
	//cc_restriction in boxlib
	const int nx = mg_bnd[lev][1],
			  ny = mg_bnd[lev][2],
			  nz = mg_bnd[lev][3];
			  
	const int nx_f = mg_bnd[lev+1][1],
			  ny_f = mg_bnd[lev+1][2],
			  nz_f = mg_bnd[lev+1][3];
	//double *const ptr = mg_ss[lev];
	
#if DIM2
	for(int k=1;k<nz-1;k++)
	 for(int j=1;j<ny-1;j++)
	  for(int i=1;i<nx-1;i++) {
		  //double *const ss = ptr + 7*mIJK;
		  //if(fabs(ss[0]) > 0.0)
		    cc[mIJK] = 0.25 *(
							  ff[mIND_f(2*i-1,2*j-1,2*k-1)]
							+ ff[mIND_f(2*i  ,2*j-1,2*k-1)]
							+ ff[mIND_f(2*i-1,2*j-1,2*k  )]
							+ ff[mIND_f(2*i  ,2*j-1,2*k  )]							
							);
	   }
#else	
	for(int k=1;k<nz-1;k++)
	 for(int j=1;j<ny-1;j++)
	  for(int i=1;i<nx-1;i++) {
		  //double *const ss = ptr + 7*mIJK;
		  //if(fabs(ss[0]) > 0.0)
		    cc[mIJK] = 0.125*(
							  ff[mIND_f(2*i-1,2*j-1,2*k-1)]
							+ ff[mIND_f(2*i  ,2*j-1,2*k-1)]
							+ ff[mIND_f(2*i-1,2*j  ,2*k-1)]
							+ ff[mIND_f(2*i  ,2*j  ,2*k-1)]
							+ ff[mIND_f(2*i-1,2*j-1,2*k  )]
							+ ff[mIND_f(2*i  ,2*j-1,2*k  )]
							+ ff[mIND_f(2*i-1,2*j  ,2*k  )]
							+ ff[mIND_f(2*i  ,2*j  ,2*k  )]							
							);
	  }
#endif
}

void bl_mg_prolongation(const int lev, double *cc, double *ff) {
	//piecewise constant prologation works the best
	const int nx = mg_bnd[lev][1],
			  ny = mg_bnd[lev][2],
			  nz = mg_bnd[lev][3];
			  
	const int nx_f = mg_bnd[lev+1][1],
			  ny_f = mg_bnd[lev+1][2],
			  nz_f = mg_bnd[lev+1][3];
#if DIM2
	for(int k=1;k<nz-1;k++)
	 for(int j=1;j<ny-1;j++)
	  for(int i=1;i<nx-1;i++) {
		  ff[mIND_f(2*i-1,2*j-1,2*k-1)] += cc[mIJK];
		  ff[mIND_f(2*i  ,2*j-1,2*k-1)] += cc[mIJK];
		  ff[mIND_f(2*i-1,2*j-1,2*k  )] += cc[mIJK];
		  ff[mIND_f(2*i  ,2*j-1,2*k  )] += cc[mIJK];		  
	  }
#else			  
	for(int k=1;k<nz-1;k++)
	 for(int j=1;j<ny-1;j++)
	  for(int i=1;i<nx-1;i++) {
		  ff[mIND_f(2*i-1,2*j-1,2*k-1)] += cc[mIJK];
		  ff[mIND_f(2*i  ,2*j-1,2*k-1)] += cc[mIJK];
		  ff[mIND_f(2*i-1,2*j  ,2*k-1)] += cc[mIJK];
		  ff[mIND_f(2*i  ,2*j  ,2*k-1)] += cc[mIJK];
		  ff[mIND_f(2*i-1,2*j-1,2*k  )] += cc[mIJK];
		  ff[mIND_f(2*i  ,2*j-1,2*k  )] += cc[mIJK];
		  ff[mIND_f(2*i-1,2*j  ,2*k  )] += cc[mIJK];
		  ff[mIND_f(2*i  ,2*j  ,2*k  )] += cc[mIJK];		  
	  }
#endif
}

void print_ghost(const int lev, double *mf, const int proc, const int loc, const int dim) {

	const int nx=mg_bnd[lev][1],
			  ny=mg_bnd[lev][2],
			  nz=mg_bnd[lev][3];
	int i=nx-2,
		j=ny-2,
		k=nz-2;
	
	
	if(loc==1) {
		if     (dim==1) i=nx-1;
		else if(dim==2) j=ny-1;
		else if(dim==3) k=nz-1;
	}
	if(loc==0) {
		if     (dim==1) i=0;
		else if(dim==2) j=0;
		else if(dim==3) k=0;
	}
	
	if(mpi.MyRank==proc) printf("ghost proc=%d val=%.12e\n",mpi.MyRank,mf[mIJK]);
}

void print_phy(const int lev, double *mf, const int proc, const int loc, const int dim) {
	
	const int nx=mg_bnd[lev][1],
			  ny=mg_bnd[lev][2],
			  nz=mg_bnd[lev][3];
	
	int i=nx-2,
		j=ny-2,
		k=nz-2;
			
	if(loc==1) {
		if(dim==1) i=nx-2;
		if(dim==2) j=ny-2;
		if(dim==3) k=nz-2;
	}
	if(loc==0) {
		if(dim==1) i=1;
		if(dim==2) j=1;
		if(dim==3) k=1;
	}
	if(mpi.MyRank==proc) printf("phys  proc=%d val=%.12e\n",mpi.MyRank,mf[mIJK]);
}
#undef DIM2

//--------------------EXACT ITER SOLVERS--------------------------------------------------
void itsol_bicgstab_solve(const int lev, double *uu, double *rh, const double &rel_eps, const int max_iter) {
	//look at the comments in top_bicgstab_solve.. this function can do only singular matrices.
	
	const int nx=mg_bnd[lev][1], 
			  ny=mg_bnd[lev][2], 
			  nz=mg_bnd[lev][3];
	
	double *rr,*rt,*pp,*ph,*vv,*tt,*ss,*rh_local,*aa_local;
	rr = (double*)memalloc (nx,ny,nz,sizeof(double));
	rt = (double*)memalloc (nx,ny,nz,sizeof(double));
	pp = (double*)memalloc (nx,ny,nz,sizeof(double));
	ph = (double*)memalloc (nx,ny,nz,sizeof(double));
	vv = (double*)memalloc (nx,ny,nz,sizeof(double));
	tt = (double*)memalloc (nx,ny,nz,sizeof(double));
	ss = (double*)memalloc (nx,ny,nz,sizeof(double));
	
	//local preconditioning
	rh_local = (double*)memalloc (nx,ny,nz,sizeof(double));
	aa_local = (double*)memalloc (nx,ny,7*nz,sizeof(double)); //this is a stencil
	
	array_copy(lev,rh_local,rh);
	stencil_copy(lev,aa_local,mg_ss[lev]);
	
	setval(lev,ss,1.e0);
	double tnorms[3] = {0.0,
						dot(lev,rh_local,ss,true),
						dot(lev,ss,ss,true)
					   };
	double rtnorms[3];
	dallreduce(tnorms,rtnorms,3,OP_SUM);
	double rho = rtnorms[1] / rtnorms[2];
	sub_sub(lev,rh_local,rho); //if(mpi.MyRank==0) printf("bot:rtnorms1=%e rtnorms2=%e\n",rtnorms[1],rtnorms[2]);
	memset(ss,0,nx*ny*nz*sizeof(double));
	
	diag_initialize(lev,aa_local,rh_local);
	array_copy(lev,ph,uu); //this copy includes ghost cells
	
	int cnt = 0;

	compute_defect(lev,aa_local,rr,rh_local,uu);
	cnt++;
	
	array_copy(lev,rt,rr);
	rho=dot(lev,rt,rr,false);
	
	//elide some reductions
	tnorms[1]=norm_inf(lev,rr      ,true);
	tnorms[2]=norm_inf(lev,rh_local,true);
	
	dallreduce(tnorms,rtnorms,3,OP_MAX);
	
	double tres0 = rtnorms[1];
	double bnorm = rtnorms[2];
	
	double Omega = 1.0;
	
	int i;
	double rrnorm;
	if(itsol_converged(lev,rr,rrnorm,bnorm,rel_eps)) {
		if(mpi.MyRank==0) printf("bottom solver Already converged\n");
	}
	else {
		double rho_1 = 0.0;
		double omega=0.0,alpha=0.0;
		for(i=1;i<=max_iter;i++) {
			rho=dot(lev,rt,rr,false);
			if(i==1)
				array_copy(lev,pp,rr);
			else {
				if(rho_1 == 0.0) {
					printf("iter=%d bicgstag rho_1 zero: rrnorm=%e rtnorm-%e\n",i,rrnorm,norm_inf(lev,rt,false));
					goto finish;
					//exit(1);
				}
				if(omega == 0.0) {
					printf("bicgstab omega zero\n");
					goto finish;
					//exit(1);
				}
				double beta = (rho/rho_1)*(alpha/omega);
				saxpy(lev,pp,pp,-omega,vv);
				rescale(lev,pp,beta);
				plus_plus(lev,pp,rr);
			} //if(i>1)
			//array_copy(lev,ph,pp);
			//itsol_precon(lev,aa_local,ph,pp);
			memset(ph,0,nx*ny*nz*sizeof(double));
			for(int ii=1;ii<=1;ii++)
				bl_mg_smoother(lev,Omega,aa_local,ph,pp);
			stencil_apply(lev,aa_local,vv,ph);
			cnt++;
			double den=dot(lev,rt,vv,false);
			
			if(den==0.0) {
				printf("bicgstab den is zero\n");
				goto finish;
				//exit(1);
			}
			alpha = rho/den;
			saxpy(lev,uu,uu,alpha,ph);
			saxpy(lev,ss,rr,-alpha,vv);
			if(itsol_converged(lev,ss,rrnorm,bnorm,rel_eps)) {
				break;
			}
			//array_copy(lev,ph,ss);
			//itsol_precon(lev,aa_local,ph,ss);
			memset(ph,0,nx*ny*nz*sizeof(double));
			for(int ii=1;ii<=1;ii++)
				bl_mg_smoother(lev,Omega,aa_local,ph,ss);
			stencil_apply(lev,aa_local,tt,ph);
			cnt++;
			
			//elide some reductions
			tnorms[1]=dot(lev,tt,tt,true);
			tnorms[2]=dot(lev,tt,ss,true);
			
			dallreduce(tnorms,rtnorms,3,OP_SUM);
			den = rtnorms[1];
			omega = rtnorms[2];
			
			if(den == 0.0) {
				printf("bicgstab: den2 is zero\n");
				goto finish;
				//exit(1);
			}
			omega = omega/den;
			saxpy(lev,uu,uu,omega,ph);
			saxpy(lev,rr,ss,-omega,tt);

			if(itsol_converged(lev,rr,rrnorm,bnorm,rel_eps)) {
				break;
			}
			rho_1 = rho;
		}//for iter
	} //else not converged

/** Commented out this portion to improve code performance	
	if(i <= max_iter) {
		if(mpi.MyRank==0) printf("bicgstab converged: #of cycles %d\n",i);
	}
**/	
	finish:
	
	if(i > max_iter || (rrnorm > rel_eps*bnorm && rrnorm > 1.e-14)) {
		if(mpi.MyRank==0) printf("bicgstab failed to converge: iter=%d (rrnorm,bnorm)=(%e %e) trying smoother\n",i,rrnorm,bnorm);
		memset(uu,0,nx*ny*nz*sizeof(double));
		Omega = 1.0; //consider raising this value [max to 2.0] if not converging.
		for(int c=1;c<=100;c++)
			bl_mg_smoother(lev,Omega,mg_ss[lev],uu,rh);
		//exit(1);
	}
	
	free(rr);
	free(rt);
	free(pp);
	free(ph);
	free(vv);
	free(tt);
	free(ss);
	free(rh_local);
	free(aa_local);
}

void top_bicgstab_solve(const int lev, double *uu, double *rh, const double &rel_eps, const int max_iter) {
	const int nx=mg_bnd[lev][1], 
			  ny=mg_bnd[lev][2], 
			  nz=mg_bnd[lev][3];
	//Please see the boxlib's implementation to extend this solver to dirichlet problems
	//Currently it only solves Neumann BCs, and performs operations that are valid only 
	//for singular matrices.
	
	//if crashing occurs especially at high resolutions, move the following to
	//allocate statements to arraysalloc()
	double *rr,*rt,*pp,*ph,*vv,*tt,*ss,*rh_local,*aa_local;
	rr = (double*)memalloc (nx,ny,nz,sizeof(double));
	rt = (double*)memalloc (nx,ny,nz,sizeof(double));
	pp = (double*)memalloc (nx,ny,nz,sizeof(double));
	ph = (double*)memalloc (nx,ny,nz,sizeof(double));
	vv = (double*)memalloc (nx,ny,nz,sizeof(double));
	tt = (double*)memalloc (nx,ny,nz,sizeof(double));
	ss = (double*)memalloc (nx,ny,nz,sizeof(double));
	
	rh_local = (double*)memalloc (nx,ny,nz,sizeof(double));
	aa_local = (double*)memalloc (nx,ny,7*nz,sizeof(double)); //this is a stencil
	
	array_copy(lev,rh_local,rh);
	stencil_copy(lev,aa_local,mg_ss[lev]);
	
	setval(lev,ss,1.e0);
	double tnorms[3] = {0.0,
						dot(lev,rh_local,ss,true),
						dot(lev,ss,ss,true)
					   };
	double rtnorms[3];
	dallreduce(tnorms,rtnorms,3,OP_SUM);
	double rho = rtnorms[1] / rtnorms[2];
	sub_sub(lev,rh_local,rho); //if(mpi.MyRank==0) printf("bot:rtnorms1=%e rtnorms2=%e\n",rtnorms[1],rtnorms[2]);
	memset(ss,0,nx*ny*nz*sizeof(double));
	
	//diag_initialize(lev,aa_local,rh_local); //no diag_initialization if multigrid preconditioning
	array_copy(lev,ph,uu); //this copy includes ghost cells
	
	int cnt = 0;

	compute_defect(lev,aa_local,rr,rh_local,uu);
	//preconditioning
	//bl_mg_v_cycle(lev,rt,rr,mg_nu1,mg_nu2);
	//array_copy(lev,rr,rt);
	cnt++;
	
	array_copy(lev,rt,rr);
	rho=dot(lev,rt,rr,false);
	
	//elide some reductions
	tnorms[1]=norm_inf(lev,rr      ,true);
	tnorms[2]=norm_inf(lev,rh_local,true);
	
	dallreduce(tnorms,rtnorms,3,OP_MAX);
	
	double tres0 = rtnorms[1];
	double bnorm = rtnorms[2];
	//if(mpi.MyRank==0) printf("bot:tres0=%e bnorm=%e\n",tres0,bnorm);
	
	int i;
	double rrnorm;
	if(itsol_converged(lev,rr,rrnorm,bnorm,rel_eps)) {
		if(mpi.MyRank==0) printf("TOP bicgstab solver Already converged\n");
	}
	else {
		double rho_1 = 0.0;
		double omega=0.0,alpha=0.0;
		for(i=1;i<=max_iter;i++) {
			rho=dot(lev,rt,rr,false);
			if(i==1)
				array_copy(lev,pp,rr);
			else {
				if(rho_1 == 0.0) {
					printf("TOP bicgstag rho_1 zero\n");
					exit(1);
				}
				if(omega == 0.0) {
					printf("TOP bicgstab omega zero\n");
					exit(1);
				}
				double beta = (rho/rho_1)*(alpha/omega);
				saxpy(lev,pp,pp,-omega,vv);
				rescale(lev,pp,beta);
				plus_plus(lev,pp,rr);
			} //if(i>1)
			//array_copy(lev,ph,pp);
			memset(ph,0,nx*ny*nz*sizeof(double));
			bl_mg_v_cycle(lev,ph,pp,mg_nu1,mg_nu2);
			stencil_apply(lev,aa_local,vv,ph);
			cnt++;
			double den=dot(lev,rt,vv,false);
			
			if(den==0.0) {
				printf("TOP bicgstab den is zero\n");
				exit(1);
			}
			alpha = rho/den;
			saxpy(lev,uu,uu,alpha,ph);
			saxpy(lev,ss,rr,-alpha,vv);
			if(itsol_converged(lev,ss,rrnorm,bnorm,rel_eps)) {
				break;
			}
			//array_copy(lev,ph,ss);
			memset(ph,0,nx*ny*nz*sizeof(double));
			bl_mg_v_cycle(lev,ph,ss,mg_nu1,mg_nu2);
			stencil_apply(lev,aa_local,tt,ph);
			cnt++;
			
			//elide some reductions
			tnorms[1]=dot(lev,tt,tt,true);
			tnorms[2]=dot(lev,tt,ss,true);
			
			dallreduce(tnorms,rtnorms,3,OP_SUM);
			den = rtnorms[1];
			omega = rtnorms[2];
			
			if(den == 0.0) {
				printf("TOP bicgstab: den2 is zero\n");
				exit(1);
			}
			omega = omega/den;
			saxpy(lev,uu,uu,omega,ph);
			saxpy(lev,rr,ss,-omega,tt);
			if(itsol_converged(lev,rr,rrnorm,bnorm,rel_eps)) {
				break;
			}
			rho_1 = rho;
//			if(mpi.MyRank==0) printf("top solve iter %d  (rrnorm, bnorm)=(%e %e)\n",i,rrnorm,bnorm);	//Commented out to improve performance
		}//for iter
	} //else not converged
	
	if(rrnorm > bnorm) {
		memset(uu,0,nx*ny*nz*sizeof(double));
		printf("TOP bicgstab: not converged solution reset to zero, try doing MG with SOR smoother\n");
	}
// Commented out this to improve code performance	
	if(i <= max_iter) {
		if(mpi.MyRank==0) printf("TOP bicgstab converged: #of cycles %d res=%e\n",i,rrnorm);
	}
	
	if(i > max_iter) {
		if(mpi.MyRank==0) printf("TOP bicgstab failed to converge: trying smoother\n");
		double omega = 1.0; 
		for(int c=1;c<=20;c++)
			bl_mg_smoother(lev,omega,mg_ss[lev],uu,rh);
	}
	
	free(rr);
	free(rt);
	free(pp);
	free(ph);
	free(vv);
	free(tt);
	free(ss);
	free(rh_local);
	free(aa_local);
}

#define L 2
double norm2 (const int lev, double *mf) {
	const int nx=mg_bnd[lev][1], 
			  ny=mg_bnd[lev][2], 
			  nz=mg_bnd[lev][3];
			  
	int i;
	double xmax = 0.0, scale;
	double sum = 0.0;
	for(int k=1;k<nz-1;k++)
	 for(int j=1;j<ny-1;j++)
	  for(int i=1;i<nx-1;i++) {
		  double xabs = fabs(mf[mIJK]);
		  if(xabs > xmax) xmax = xabs;
	  }
	double rmax;
	dallreduce(&xmax,&rmax,1,OP_MAX);
	
	if(rmax == 0.0) return 0.0;
	scale = 1.0 / rmax;
	for(int k=1;k<nz-1;k++)
	 for(int j=1;j<ny-1;j++)
	  for(int i=1;i<nx-1;i++) {
		  double xs = scale*mf[mIJK];
		  sum += xs*xs;
	  }
	double rsum;
	dallreduce(&sum,&rsum,1,OP_SUM);
	return rmax*sqrt(rsum);
}

//the bicgstabL purportedly is the cure for rho_1 = 0 type breakdowns encountered in bicgstab. However, for our 
//[high density ratios] problems it failed miserably.. 
 
void top_bicgstabL_solve(const int lev, double *uu, double *rh, const double &rel_eps, const int max_iter){
	//bicgstab L hopefully to solve the residual stagnation issue with the
	//regular bicgstab
	const int nx=mg_bnd[lev][1], 
			  ny=mg_bnd[lev][2], 
			  nz=mg_bnd[lev][3];
			  
	double **r = (double**)memalloc(1,1,L+1,sizeof(double*));
	double **u = (double**)memalloc(1,1,L+1,sizeof(double*));
	double *rtilde = (double*)memalloc(nx,ny,nz,sizeof(double));
	
	r[0] = (double*)memalloc (nx,ny,(L+1)*nz,sizeof(double));
	u[0] = (double*)memalloc (nx,ny,(L+1)*nz,sizeof(double));
	 
	for(int i=1; i<=L; ++i) {
		r[i]=r[i-1]+nx*ny*nz;
		u[i]=u[i-1]+nx*ny*nz;
	}
	
	double bnrm = norm_inf(lev,rh,false);
	if(bnrm == 0.0) bnrm = 1.0;
	
	int iter=0;
	
	double *gamma    = (double *)memalloc(1,1,L+1,sizeof(double));
	double *gamma_p  = (double *)memalloc(1,1,L+1,sizeof(double));
	double *gamma_pp = (double *)memalloc(1,1,L+1,sizeof(double));
	double *tau      = (double *)memalloc(1,1,L*L,sizeof(double));
	double *sigma    = (double *)memalloc(1,1,L+1,sizeof(double));
	double *ss       = (double *)memalloc(nx,ny,nz,sizeof(double));
	
	int ierr = 0;
	const double breaktol = 1.e-30;
	
	//rtilde = r[0] = b - Ax
	compute_defect(lev,mg_ss[lev],r[0],rh,uu);
	//array_copy(lev,rtilde,r[0]);
	//preconditioning
	bl_mg_v_cycle(lev,rtilde,r[0],mg_nu1,mg_nu2);
	array_copy(lev,r[0],rtilde);
	bnrm = norm_inf(lev,r[0],false);
	
	/*{
		double s = 1.0/norm_inf(lev,rtilde,false);
		rescale(lev,rtilde,s);
	}*/
	
	memset(u[0],0,nx*ny*nz*sizeof(double));
	double rho = 1.0, alpha = 0.0, omega = 1.0;
	
	double resid;
	while ((resid = norm_inf(lev,r[0],false)) > rel_eps*bnrm) {
		++iter;
		if(mpi.MyRank==0) printf("bicgstabL cyc %d resid,bnorm=(%e,%e)\n",iter,resid,bnrm);
		rho = -omega * rho;
		for(int j=0; j<L;++j) {
			if(fabs(rho) < breaktol) {ierr = -1; goto finish;}
			double rho1 = dot(lev,r[j],rtilde,false);
			double beta = alpha * rho1 / rho;
			rho = rho1;
			for(int i=0; i<=j; ++i)
				saxpy(lev,u[i],r[i],-beta,u[i]);
			stencil_apply(lev,mg_ss[lev],ss,u[j]);
			//preconditioning
			bl_mg_v_cycle(lev,u[j+1],ss,mg_nu1,mg_nu2);
			
			alpha = rho/dot(lev,u[j+1],rtilde,false);
			for(int i=0; i<=j; ++i)
				saxpy(lev,r[i],r[i],-alpha,u[i+1]);
			stencil_apply(lev,mg_ss[lev],ss,r[j]);
			//preconditioning
			bl_mg_v_cycle(lev,r[j+1],ss,mg_nu1,mg_nu2);
			saxpy(lev,uu,uu,alpha,u[0]);
		}
		
		for(int j=1; j<=L; ++j) {
			for(int i=1; i<j; ++i) {
				int ij = (j-1)*L + (i-1);
				tau[ij] = dot(lev,r[j],r[i],false)/sigma[i];
				saxpy(lev,r[j],r[j],-tau[ij],r[i]);
			}
			double rtnorms[3];
			double tnorms[3] = { 0.0,
				                 dot(lev,r[j],r[j],true),
						         dot(lev,r[0],r[j],true)
								};
			//elide some reductions
			dallreduce(tnorms,rtnorms,3,OP_SUM);
			sigma[j] = rtnorms[1];
			gamma_p[j] = rtnorms[2]/sigma[j];
		}
		
		omega = gamma[L] = gamma_p[L];
		for(int j=L-1; j>= 1; --j) {
			gamma[j] = gamma_p[j];
			for(int i=j+1; i<=L; ++i)
				gamma[j] -= tau[(i-1)*L + (j-1)] * gamma[i];
		}
		for(int j=1; j<L; ++j) {
			gamma_pp[j] = gamma[j+1];
			for(int i=j+1; i<L; ++i)
				gamma_pp[j] += tau[(i-1)*L +(j-1)] * gamma[i+1];
		}
		saxpy(lev,uu,uu,gamma[1],r[0]);
		saxpy(lev,r[0],r[0],-gamma_p[L],r[L]);
		saxpy(lev,u[0],u[0],-gamma[L],u[L]);
		for(int j=1; j<L; ++j) {
			saxpy(lev,uu,uu,gamma_pp[j],r[j]);
			saxpy(lev,r[0],r[0],-gamma_p[j],r[j]);
			saxpy(lev,u[0],u[0],-gamma[j],u[j]);
		}
		if(iter == max_iter) {ierr=1; break;}
	}
	
	finish:
	if(mpi.MyRank==0) {
		if(ierr==0) printf("BICGSTABL No errors Converged\n");
		else if(ierr==-1) printf("BICGSTABL: breakdown in rho\n");
		else if(ierr==1) printf("BICGSTABL: Past max iter\n");
		printf("BICGSTABL FINAL iter=%d residual=%e bnrm=%e\n",iter,resid,bnrm);
	}
	
	free(ss);
	free(sigma);
	free(tau);
	free(gamma_pp);
	free(gamma_p);
	free(gamma);
	free(rtilde);
	free(r[0]);
	free(u[0]);
	free(u);
	free(r);
}

void itsol_bicgstabL_solve(const int lev, double *uu, double *rh, const double &rel_eps, const int max_iter){
	//bicgstab L hopefully to solve the residual stagnation issue with the
	//regular bicgstab
	const int nx=mg_bnd[lev][1], 
			  ny=mg_bnd[lev][2], 
			  nz=mg_bnd[lev][3];
			  
	double **r = (double**)memalloc(1,1,L+1,sizeof(double*));
	double **u = (double**)memalloc(1,1,L+1,sizeof(double*));
	double *rtilde = (double*)memalloc(nx,ny,nz,sizeof(double));
	
	r[0] = (double*)memalloc (nx,ny,(L+1)*nz,sizeof(double));
	u[0] = (double*)memalloc (nx,ny,(L+1)*nz,sizeof(double));
	 
	for(int i=1; i<=L; ++i) {
		r[i]=r[i-1]+nx*ny*nz;
		u[i]=u[i-1]+nx*ny*nz;
	}
	
	double bnrm = norm_inf(lev,rh,false);
	if(bnrm == 0.0) bnrm = 1.0;
	
	int iter=0;
	
	double *gamma    = (double *)memalloc(1,1,L+1,sizeof(double));
	double *gamma_p  = (double *)memalloc(1,1,L+1,sizeof(double));
	double *gamma_pp = (double *)memalloc(1,1,L+1,sizeof(double));
	double *tau      = (double *)memalloc(1,1,L*L,sizeof(double));
	double *sigma    = (double *)memalloc(1,1,L+1,sizeof(double));
	double *ss       = (double *)memalloc(nx,ny,nz,sizeof(double));
	
	int ierr = 0;
	const double breaktol = 1.e-30;
	
	//rtilde = r[0] = b - Ax
	compute_defect(lev,mg_ss[lev],r[0],rh,uu);
	//array_copy(lev,rtilde,r[0]);
	//preconditioning
	//bl_mg_v_cycle(lev,rtilde,r[0],mg_nu1,mg_nu2);
	itsol_precon(lev,mg_ss[lev],rtilde,r[0]);
	array_copy(lev,r[0],rtilde);
	bnrm = norm_inf(lev,r[0],false);
	
	/*{
		double s = 1.0/norm_inf(lev,rtilde,false);
		rescale(lev,rtilde,s);
	}*/
	
	memset(u[0],0,nx*ny*nz*sizeof(double));
	double rho = 1.0, alpha = 0.0, omega = 1.0;
	
	double resid = norm_inf(lev,r[0],false);
	while ( resid > rel_eps*bnrm || resid > 1.e-14) {
		++iter;
		//if(mpi.MyRank==0) printf("bicgstabL cyc %d resid,bnorm=(%e,%e)\n",iter,resid,bnrm);
		rho = -omega * rho;
		for(int j=0; j<L;++j) {
			if(fabs(rho) < breaktol) {ierr = -1; goto finish;}
			double rho1 = dot(lev,r[j],rtilde,false);
			double beta = alpha * rho1 / rho;
			rho = rho1;
			for(int i=0; i<=j; ++i)
				saxpy(lev,u[i],r[i],-beta,u[i]);
			stencil_apply(lev,mg_ss[lev],ss,u[j]);
			//preconditioning
			itsol_precon(lev,mg_ss[lev],u[j+1],ss);
			//bl_mg_v_cycle(lev,u[j+1],ss,mg_nu1,mg_nu2);
			
			alpha = rho/dot(lev,u[j+1],rtilde,false);
			for(int i=0; i<=j; ++i)
				saxpy(lev,r[i],r[i],-alpha,u[i+1]);
			stencil_apply(lev,mg_ss[lev],ss,r[j]);
			//preconditioning
			itsol_precon(lev,mg_ss[lev],r[j+1],ss);
			//bl_mg_v_cycle(lev,r[j+1],ss,mg_nu1,mg_nu2);
			saxpy(lev,uu,uu,alpha,u[0]);
		}
		
		for(int j=1; j<=L; ++j) {
			for(int i=1; i<j; ++i) {
				int ij = (j-1)*L + (i-1);
				tau[ij] = dot(lev,r[j],r[i],false)/sigma[i];
				saxpy(lev,r[j],r[j],-tau[ij],r[i]);
			}
			double rtnorms[3];
			double tnorms[3] = { 0.0,
				                 dot(lev,r[j],r[j],true),
						         dot(lev,r[0],r[j],true)
								};
			//elide some reductions
			dallreduce(tnorms,rtnorms,3,OP_SUM);
			sigma[j] = rtnorms[1];
			gamma_p[j] = rtnorms[2]/sigma[j];
		}
		
		omega = gamma[L] = gamma_p[L];
		for(int j=L-1; j>= 1; --j) {
			gamma[j] = gamma_p[j];
			for(int i=j+1; i<=L; ++i)
				gamma[j] -= tau[(i-1)*L + (j-1)] * gamma[i];
		}
		for(int j=1; j<L; ++j) {
			gamma_pp[j] = gamma[j+1];
			for(int i=j+1; i<L; ++i)
				gamma_pp[j] += tau[(i-1)*L +(j-1)] * gamma[i+1];
		}
		saxpy(lev,uu,uu,gamma[1],r[0]);
		saxpy(lev,r[0],r[0],-gamma_p[L],r[L]);
		saxpy(lev,u[0],u[0],-gamma[L],u[L]);
		for(int j=1; j<L; ++j) {
			saxpy(lev,uu,uu,gamma_pp[j],r[j]);
			saxpy(lev,r[0],r[0],-gamma_p[j],r[j]);
			saxpy(lev,u[0],u[0],-gamma[j],u[j]);
		}
		if(iter == max_iter) {ierr=1; break;}
		resid = norm_inf(lev,r[0],false);
	}
	
	finish:
	if(mpi.MyRank==0) {
		if(ierr==0) printf("BICGSTABL No errors Converged\n");
		else if(ierr==-1) printf("BICGSTABL: breakdown in rho\n");
		else if(ierr==1) printf("BICGSTABL: Past max iter\n");
		printf("BICGSTABL FINAL iter=%d residual=%e bnrm=%e\n",iter,resid,bnrm);
	}
	
	free(ss);
	free(sigma);
	free(tau);
	free(gamma_pp);
	free(gamma_p);
	free(gamma);
	free(rtilde);
	free(r[0]);
	free(u[0]);
	free(u);
	free(r);
}
#undef L
//conjugate gradient method
void top_cg_solve(const int lev, double *uu, double *rh, const double &rel_eps, const int max_iter) {
	const int nx=mg_bnd[lev][1], 
			  ny=mg_bnd[lev][2], 
			  nz=mg_bnd[lev][3];
	double *rr, *zz, *pp, *qq, *rh_local, *aa_local;
	rr = (double*)memalloc(nx,ny,nz,sizeof(double));
	zz = (double*)memalloc(nx,ny,nz,sizeof(double));
	pp = (double*)memalloc(nx,ny,nz,sizeof(double));
	qq = (double*)memalloc(nx,ny,nz,sizeof(double));
	
	rh_local = (double*)memalloc(nx,ny,nz,sizeof(double));
	aa_local = (double*)memalloc(nx,ny,7*nz,sizeof(double));
	
	memset(pp,0,nx*ny*nz*sizeof(double));
	array_copy(lev,rh_local,rh);
	stencil_copy(lev,aa_local,mg_ss[lev]);
	//diag_initialize(lev,aa_local,rh_local);//comment this line for using multigrid preconditioner
	
	compute_defect(lev,aa_local,rr,rh_local,uu);
	
	double rnrms[3];
	double nrms[3] = { 0.0,
		               norm_inf(lev,rr,true),
		               norm_inf(lev,rh_local,true)
	                 };
	dallreduce(nrms,rnrms,3,OP_MAX);
	
	double tres0 = rnrms[1];
	double bnorm = rnrms[2];
	double rrnorm;
	
	int i=0;
	if(itsol_converged(lev,rr,rrnorm,bnorm,rel_eps)) {
		if(mpi.MyRank==0) printf("top CG solve: already converged\n");
	}
	else {
		double rho_1 = 0.0;
		double rho;
		for(i=1;i<=max_iter;i++) {
			//itsol_precon(lev,aa_local,zz,rr);
			//array_copy(lev,zz,rr);
			memset(zz,0,nx*ny*nz*sizeof(double));
			bl_mg_v_cycle(lev,zz,rr,mg_nu1,mg_nu2);
			rho = dot(lev,rr,zz,false);
			if(i==1) {
				array_copy(lev,pp,zz);
			}
			else {
				if(rho_1 == 0.0) {
					printf("top cg rho_1=%e\n",rho_1); exit(1);
				}
				double beta = rho/rho_1;
				saxpy(lev,pp,zz,beta,pp);
			}
			stencil_apply(lev,aa_local,qq,pp);
			double den = dot(lev,pp,qq,false);
			if(den==0.0) {
				printf("top CG solve: den=0\n"); exit(1);
			}
			double alpha = rho/den;
			saxpy(lev,uu,uu,alpha,pp);
			saxpy(lev,rr,rr,-alpha,qq);
			if(itsol_converged(lev,rr,rrnorm,bnorm,rel_eps)) break;
			if(mpi.MyRank==0) printf("top cg: iter=%d (rrnorm,bnorm)=(%e %e)\n",i,rrnorm,bnorm);
			rho_1 = rho;
		}
	}
	
	if(rrnorm > bnorm) {
		memset(uu,0,nx*ny*nz*sizeof(double));
		printf("top CG: solution has diverged reset to zero\n");
	}
	
	if(i <= max_iter) {
		if(mpi.MyRank==0) printf("CG converged: #of cycles %d res=%e\n",i,rrnorm);
	}
	
	if(i > max_iter) {
		if(mpi.MyRank==0) printf("top cg failed to converge: trying smoother\n");
		double omega = 1.0;
		for(int c=1;c<=20;c++)
			bl_mg_smoother(lev,omega,mg_ss[lev],uu,rh);
		//exit(1);
	}
	
	free(rr);
	free(zz);
	free(pp);
	free(qq);
	free(rh_local);
	free(aa_local);
}

void itsol_precon(const int lev, double *const ptr, double *uu, double *rh) {
	const int nx=mg_bnd[lev][1], 
			  ny=mg_bnd[lev][2], 
			  nz=mg_bnd[lev][3];
	for(int k=1;k<nz-1;k++)
	 for(int j=1;j<ny-1;j++)
	  for(int i=1;i<nx-1;i++) {
		  double *const ss = ptr + 7*mIJK;
		  if(fabs(ss[0]) > 0.0)
			uu[mIJK] = rh[mIJK] /  (ss[0]);
	  }
}

void itsol_cg_solve(const int lev, double *uu, double *rh, const double &rel_eps, const int max_iter) {
	const int nx=mg_bnd[lev][1], 
			  ny=mg_bnd[lev][2], 
			  nz=mg_bnd[lev][3];
	double *rr, *zz, *pp, *qq, *rh_local, *aa_local;
	rr = (double*)memalloc(nx,ny,nz,sizeof(double));
	zz = (double*)memalloc(nx,ny,nz,sizeof(double));
	pp = (double*)memalloc(nx,ny,nz,sizeof(double));
	qq = (double*)memalloc(nx,ny,nz,sizeof(double));
	
	rh_local = (double*)memalloc(nx,ny,nz,sizeof(double));
	aa_local = (double*)memalloc(nx,ny,7*nz,sizeof(double));
	
	memset(pp,0,nx*ny*nz*sizeof(double));
	array_copy(lev,rh_local,rh);
	stencil_copy(lev,aa_local,mg_ss[lev]);
	//diag_initialize(lev,aa_local,rh_local);//comment this line for using multigrid preconditioner
	
	compute_defect(lev,aa_local,rr,rh_local,uu);
	double Omega = 1.0;
	double rnrms[3];
	double nrms[3] = { 0.0,
		               norm_inf(lev,rr,true),
		               norm_inf(lev,rh_local,true)
	                 };
	dallreduce(nrms,rnrms,3,OP_MAX);
	
	double tres0 = rnrms[1];
	double bnorm = rnrms[2];
	double rrnorm;
	
	int i=0;
	if(itsol_converged(lev,rr,rrnorm,bnorm,rel_eps)) {
		if(mpi.MyRank==0) printf("bottom CG solve: already converged\n");
	}
	else {
		double rho_1 = 0.0;
		double rho;
		for(i=1;i<=max_iter;i++) {
			//itsol_precon(lev,aa_local,zz,rr);
			//array_copy(lev,zz,rr);
			//memset(zz,0,nx*ny*nz*sizeof(double));
			//bl_mg_v_cycle(lev,zz,rr,mg_nu1,mg_nu2);
			memset(zz,0,nx*ny*nz*sizeof(double));
			for(int ii=1;ii<=2;ii++)
				bl_mg_smoother(lev,Omega,mg_ss[lev],zz,rr);
			rho = dot(lev,rr,zz,false);
			if(i==1) {
				array_copy(lev,pp,zz);
			}
			else {
				if(rho_1 == 0.0) {
					printf("bot itsol_cg rho_1=%e\n",rho_1); exit(1);
				}
				double beta = rho/rho_1;
				saxpy(lev,pp,zz,beta,pp);
			}
			stencil_apply(lev,aa_local,qq,pp);
			double den = dot(lev,pp,qq,false);
			if(den==0.0) {
				printf("bottom CG solve: den=0\n"); exit(1);
			}
			double alpha = rho/den;
			saxpy(lev,uu,uu,alpha,pp);
			saxpy(lev,rr,rr,-alpha,qq);
			if(itsol_converged(lev,rr,rrnorm,bnorm,rel_eps)) break;
			//if(mpi.MyRank==0) printf("top cg: iter=%d (rrnorm,bnorm)=(%e %e)\n",i,rrnorm,bnorm);
			rho_1 = rho;
		}
	}
	
	if(rrnorm > bnorm) {
		memset(uu,0,nx*ny*nz*sizeof(double));
		printf("bot CG: solution has diverged reset to zero\n");
	}
	
	if(i <= max_iter) {
		if(mpi.MyRank==0) printf("bot CG converged: #of cycles %d res,bnorm=%e %e\n",i,rrnorm,bnorm);
	}
	
	if(i > max_iter) {
		if(mpi.MyRank==0) printf("bot cg failed to converge: res,bnorm=(%e %e) trying smoother\n",rrnorm,bnorm);
		double omega = 1.0;
		for(int c=1;c<=20;c++)
			bl_mg_smoother(lev,omega,mg_ss[lev],uu,rh);
		//exit(1);
	}
	
	free(rr);
	free(zz);
	free(pp);
	free(qq);
	free(rh_local);
	free(aa_local);
}

//-----------------------------functions for debugging -----------------------------------------------------------------

void debug_tool () {
	int lev = 1;
	//customize the following according to your needs
	const int nx=mg_bnd[lev][1], 
		      ny=mg_bnd[lev][2], 
		      nz=mg_bnd[lev][3];
		      
	if(mpi.MyRank==72) {
		double *const ptr = mg_ss[lev];
		int i=4, j=2, k=1;
		double *const ss = ptr + 7*mIJK;
		
		printf("ss=(%e %e %e %e %e %e %e)\n", ss[0],ss[1],ss[2],ss[3],ss[4],ss[5],ss[6]);
		if(fabs(ss[0] > 0.0)) printf("fabs ss is gt zero\n");
		else printf("fabs ss is == 0.0 \n");
		printf("dd = %e\n",mg_dd[lev][mIJK]);
	}
}

void non_obst_cells(int lev, double &tcells) {
	//returns the tcells
	const int nx=mg_bnd[lev][1], 
		      ny=mg_bnd[lev][2], 
		      nz=mg_bnd[lev][3];
	
	double *const ptr = mg_ss[lev];
	double ncells = 0.0;
	for(int k=1;k<nz-1;k++)
	 for(int j=1;j<ny-1;j++)
	  for(int i=1;i<nx-1;i++) {
		  double *const ss = ptr + 7*mIJK;
		  if(fabs(ss[0]) > 0.0) ncells = ncells + 1.0;
	  }
	
	dallreduce(&ncells,&tcells,1,OP_SUM);	      
}

#endif
