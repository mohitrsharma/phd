#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "testing.h"
#include "ripple.h"
#include "vector.h"
#include <string.h>/*memcpy*/

void inflow_O_ytube(void) {
	
	int i,j,k;
	double tx,ty;
	
	double w_avg = -0.0164742299 * 10;
	double r2 = radius*radius;
	
	k = km1;
	/**
	for(i=1; i<im1; ++i)
		for(j=1; j<jm1; ++j)
		{
			tx = (i+mpi.OProc[0])*delx[1] - 0.5*delx[1]; //global coordinates in coarse-grid
			ty = (j+mpi.OProc[1])*dely[1] - 0.5*dely[1];
			
			if(f[IJKM] >= em6 && ac[IJKM] > em6 && SQUARE(tx-xcent) + SQUARE(ty-ycent) <= r2 )
			{
				u[IJK] 	= uf1;
				v[IJK] 	= vf1;
				//w[IJKM] = 2*w_avg*(1 - ( SQUARE(tx-xcent) + SQUARE(ty-ycent) ) / r2 );
				w[IJK] = w_avg;
				
				f[IJK]	= f[IJKM] = 1.0;
				p[IJK] 	= p[IJKM];
			}
			else if(psimz[IJKM] < em6 && SQUARE(tx-xcent) + SQUARE(ty-ycent) <= r2)
			{
				u[IJK] 	= uf2;
				v[IJK] 	= vf2;
				//w[IJKM] = 2*w_avg*(1 - ( SQUARE(tx-xcent) + SQUARE(ty-ycent) ) / r2 );
				w[IJK] = w_avg;
				
				f[IJK] 	= f[IJKM] = 0.0;
				p[IJK] 	= p[IJKM];
			}
		}
		* **/
}
