#include "ripple.h"
#include <math.h>
#include <stdlib.h>
#include "testing.h"

/******************************************************************************



Subroutine AREA is called by:	TENSION	

Subroutine AREA calls:		

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

bool Triangle (double n1, double n2, double n3, double &h1, double &h2, double &h3, double fijk, int ijk, int &nverts);
bool QuadA (double n1, double n2, double n3, double &h1, double &h2, double &h3, double fijk, int ijk, int &nverts);
bool QuadB(double n1, double n2, double n3, double &h1, double &h2, double &h3, double fijk, int ijk, int &nverts);
bool Pentagon (double n1, double n2, double n3, double &h1, double &h2, double &h3, double fijk, int ijk, int &nverts);
bool Hexagon (double n1, double n2, double n3, double &h1, double &h2, double &h3, double fijk, int ijk, int &nverts);

void area (int ijk, double *face, double *xd, double *yd, double *zd)
{
	int i=ijk%NX;
	int j=ijk/NX % NY;
	int k=ijk/(NX*NY);
	double xn = -avnx[ijk];
	double yn = -avny[ijk];
	double zn = -avnz[ijk];
	//if (xn==0.0 && yn==0.0 && zn == 0.0)
		//xn = yn = zn = em6;
	
	double rlength = 1.0/sqrt(SQUARE(xn)+SQUARE(yn)+SQUARE(zn));
	xn *= rlength;
	yn *= rlength;
	zn *= rlength;

	//swap fluid and void, and negate normals if fn > 1/2.
	double fijk = f[ijk];
	if (fijk > 0.5)
	{
		fijk = 1.0-fijk;
		xn = -xn;
		yn = -yn;
		zn = -zn;
	}

	//define corners and corner numbers
      //what's the purpose of this? (xnn = xn^0.1)
      double xnn=pow(fabs(xn),0.1) * SIGN(xn);
      double ynn=pow(fabs(yn),0.1) * SIGN(yn);
      double znn=pow(fabs(zn),0.1) * SIGN(zn);

      //uh-oh...uh.. do something random!
      //if (xnn==0.0) xnn+=em10;
      //if (ynn==0.0) ynn-=em10;
      //if (znn==0.0) znn+=em10;

	double p0=100.0;
	double p1=1000.0;
	double p2=10000.0;
	int m0=0, m1=0, m2=0;
	int ii,jj,kk;
	
	for (ii=0;ii<2;ii++)
		for (jj=0;jj<2;jj++)
			for (kk=0;kk<2;kk++)
			{
				int m = 4*ii+2*jj+kk+1;
				pcorner[m-1]=xnn*ii + ynn*jj + znn*kk;
				if (pcorner[m-1] < p0)
				{
					p2=p1;
					p1=p0;
					p0=pcorner[m-1];
					m2=m1;
					m1=m0;
					m0=m;
				}
				else if (pcorner[m-1] < p1)
				{
					p2=p1;
					p1=pcorner[m-1];
					m2=m1;
					m1=m;
				}
				else if (pcorner[m-1] < p2)
				{
					p2=pcorner[m-1];
					m2=m;
				}
			}
	//order the normals
	double n1 = MIN(fabs(xn), MIN(fabs(yn), fabs(zn)));
	double n3 = MAX(fabs(xn), MAX(fabs(yn), fabs(zn)));
	double n2=fabs(xn)+fabs(yn)+fabs(zn)-n1-n3;

	int m3=9+m0-m1-m2;
	int m1pm2 = m1+m2;
	int m1pm3 = m1+m3;
	int m2pm3 = m2+m3;
	if (!(m1pm2 == 5 || m1pm2 == 13 || m1pm3 == 5 || m1pm3 == 13 || m2pm3 == 5 || m2pm3 == 13) && n2 > em10)
	{
		printf ("%d %d %d %d Area:M MISMATCH %f %f %f\n", m0,m1,m2,m3, xn, yn, zn);
        fprintf (files.error,"%d %d %d %d Area:M MISMATCH %f %f %f\n", m0,m1,m2,m3, xn, yn, zn);
		printf ("n1,n2,n3 = %e, %e, %e\n", n1,n2,n3);
        fprintf (files.error,"n1,n2,n3 = %e, %e, %e\n", n1,n2,n3);
        printf ("i=%d  j=%d  k=%d\n",i,j,k);
        fprintf (files.error,"i=%d  j=%d  k=%d\n",i,j,k);
		exit(1);
	}
	int nzeroflags=0;
	if (n1==0) {n1=em6; nzeroflags |=1;}
	if (n2 <= 0.0) {n2 = em6; nzeroflags |=2;}
	if (n3==0) {n3=em6; nzeroflags |=4;}
	if (n1 <= em6 || n2 <= em6 || n3 <= em6)
	{
		const double length=sqrt (n1*n1+n2*n2+n3*n3);
		n1 /= length;
		n2 /= length;
		n3 /= length;
	}

	double h1, h2, h3;
	int nverts=0;

	/*Special cases:
	   n2==0 implies n1==0 because n1<=n2: QuadB only.
	   n1==0, n2!=0: a Quad section.
	*/

	if (nzeroflags&2)		//n2==0
		QuadB(n1, n2, n3, h1, h2, h3, fijk, ijk, nverts);
	else if (nzeroflags&1)	//n1==0
	{
		n1=0.0;
		if (QuadA(n1, n2, n3, h1, h2, h3, fijk, ijk, nverts));
		else QuadB(n1, n2, n3, h1, h2, h3, fijk, ijk, nverts);
	}
	else
	{
		if (Triangle (n1, n2, n3, h1, h2, h3, fijk, ijk, nverts));
		else if(QuadA(n1, n2, n3, h1, h2, h3, fijk, ijk, nverts));
		else if(Pentagon(n1, n2, n3, h1, h2, h3, fijk, ijk, nverts));
		else if(Hexagon(n1, n2, n3, h1, h2, h3, fijk, ijk, nverts));
		else QuadB (n1, n2, n3, h1, h2, h3, fijk, ijk, nverts);
	} //n1,n2 != 0
	
	//normalize h1,h2,h3 wrt delx, dely, delz, & evaluate 'face'
	double del1,del2,del3;
	switch (abs(m1-m0))
	{
		case 1:
			h1*=delz[k];
			del1=delz[k];
			if (abs(m2-m0) == 2)
			{
				h2*=dely[j];
				del2=dely[j];
				h3*=delx[i];
				del3=delx[i];
			}
			else 
			{
				h2 *= delx[i];
				del2 = delx[i];
				h3 *= dely[j];
				del3 = dely[j];
			}
			break;
		case 2:
			h1 *= dely[j];
			del1 = dely[j];
			if (abs(m2-m0)==1)
			{
				h2*=delx[i];
				del2=delx[i];
				h3*=delz[k];
				del3=delz[k];
			}
			else
			{
				h2*=delz[k];
				del2=delz[k];
				h3*=delx[i];
				del3=delx[i];
			}
			break;
		case 3:
			fprintf (files.error, "%d %d %d %d PROBLEM in AREA: %d\n", m0, m1, m2, m3, ijk);
			exit(1);
		case 4:
			h1*=delx[i];
			del1=delx[i];
			if (abs(m2-m0)==2)
			{
				h2*=dely[j];
				del2=dely[j];
				h3*=delz[k];
				del3=delz[k];
			}
			else
			{
				h2*=delz[k];
				del2=delz[k];
				h3*=dely[j];
				del3=dely[j];
			}
			break;
	}
	switch (nverts)
	{
		case 1:
		case 2:
			fprintf (files.error, "nverts PROBLEM in AREA: %d\n", ijk);
			exit (1);
		case 3: 
			*face = 0.5*sqrt(SQUARE(h1)*SQUARE(h2) + SQUARE(h1)*SQUARE(h3) + SQUARE(h2)*SQUARE(h3));
			break;
		case 4:
			{
				double sidea=del1*sqrt(1.0+SQUARE(h3/h1));
				double sideb=(1.0-del1/h1)*sqrt(SQUARE(h2)+SQUARE(h3));
				double sidec=del1*sqrt(1.0+SQUARE(h2/h1));
				double sided=sqrt(SQUARE(h2)+SQUARE(h3));
				double cross1=sqrt(SQUARE(del1)+SQUARE(h3)+SQUARE(h2)*SQUARE(1.0-del1/h1));
				double cross2=sqrt(SQUARE(del1)+SQUARE(h2)+SQUARE(h3)*SQUARE(1.0-del1/h1));
				*face=0.25*sqrt(4.0*SQUARE(cross1)*SQUARE(cross2) - SQUARE(SQUARE(sidea)+SQUARE(sidec)-SQUARE(sideb)-SQUARE(sided)));
				break;
			}
		case 5:
			*face = 0.5*sqrt(SQUARE(h1)*SQUARE(h2) + SQUARE(h1)*SQUARE(h3) + SQUARE(h2)*SQUARE(h3))*(1.0-SQUARE((h1-del1)/h1) - SQUARE((h2-del2)/h2));
			break;
		case 6:
			*face = 0.5*sqrt(SQUARE(h1)*SQUARE(h2) + SQUARE(h1)*SQUARE(h3) + SQUARE(h2)*SQUARE(h3))*(1.0-SQUARE((h1-del1)/h1) - SQUARE((h2-del2)/h2) - SQUARE((h3-del3)/h3));
			break;
		case 7:
			*face = del1*del2*sqrt(1.0+SQUARE(h3/h1) + SQUARE(h3/h2));
			nverts=4;
	}

	double xm0=0.0;
	double ym0=0.0;
	double zm0=0.0;
	if (m0 == 5 || m0 == 6 || m0 == 7 || m0 == 8) xm0=1.0;
	if (m0 == 3 || m0 == 4 || m0 == 7 || m0 == 8) ym0=1.0;
	if (m0 == 2 || m0 == 4 || m0 == 6 || m0 == 8) zm0=1.0;
	double xm1=0.0;
	double ym1=0.0;
	double zm1=0.0;
	if (m1 == 5 || m1 == 6 || m1 == 7 || m1 == 8) xm1=1.0;
	if (m1 == 3 || m1 == 4 || m1 == 7 || m1 == 8) ym1=1.0;
	if (m1 == 2 || m1 == 4 || m1 == 6 || m1 == 8) zm1=1.0;
	double xm2=0.0;
	double ym2=0.0;
	double zm2=0.0;
	if (m2 == 5 || m2 == 6 || m2 == 7 || m2 == 8) xm2=1.0;
	if (m2 == 3 || m2 == 4 || m2 == 7 || m2 == 8) ym2=1.0;
	if (m2 == 2 || m2 == 4 || m2 == 6 || m2 == 8) zm2=1.0;
	double xm3=0.0;
	double ym3=0.0;
	double zm3=0.0;
	if (m3 == 5 || m3 == 6 || m3 == 7 || m3 == 8) xm3=1.0;
	if (m3 == 3 || m3 == 4 || m3 == 7 || m3 == 8) ym3=1.0;
	if (m3 == 2 || m3 == 4 || m3 == 6 || m3 == 8) zm3=1.0;

	*xd=0;
	*yd=0;
	*zd=0;
	for (int nn=0;nn<nverts;nn++)
	{
		*xd+=xm0+pp[nn]*(xm1-xm0)+qq[nn]*(xm2-xm0)+rr[nn]*(xm3-xm0);
		*yd+=ym0+pp[nn]*(ym1-ym0)+qq[nn]*(ym2-ym0)+rr[nn]*(ym3-ym0);
		*zd+=zm0+pp[nn]*(zm1-zm0)+qq[nn]*(zm2-zm0)+rr[nn]*(zm3-zm0);
	}
	*xd /= nverts;
	*yd /= nverts;
	*zd /= nverts;
}

bool Triangle(double n1, double n2, double n3, double &h1, double &h2, double &h3, double fijk, int ijk, int &nverts)
{	
	//if(ijk==IND_f(61,1,22)) printf("entered triangle\n");	
	if (6.0 * n2*n3*fijk >= SQUARE(n1))
		return false;
		
	//triangular section, figures 5,11
	double diag=pow((6.0*n1*n2*n3*fijk), (1.0/3.0));
	h1=diag/n1;
	h2=diag/n2;
	h3=diag/n3;
	if (h1 < 0.0 || h1 > 1.0 || h2 < 0.0 || h2 > 1.0 || h3 < 0.0 || h3 > 1.0)
	{
		fprintf (files.error, "Area:TRIANGLE ANOMALY: %d %f %f %f %f\n", ijk, fijk, n1, n2, n3);
		return false;
		//exit (1);
	}
	pp[0]=h1;
	qq[0]=0.0;
	rr[0]=0.0;
	pp[1]=0.0;
	qq[1]=h2;
	rr[1]=0.0;
	pp[2]=0.0;
	qq[2]=0.0;
	rr[2]=h3;
	nverts=3;
	return true;
}
bool QuadA(double n1, double n2, double n3, double &h1, double &h2, double &h3, double fijk, int ijk, int &nverts)
{
	//if(ijk==IND_f(61,1,22)) printf("entered QuadA\n");
	if (6.0*n2*n3*fijk >= 3.0*SQUARE(n2)-3.0*n1*n2+SQUARE(n1))
		return false;
	
	//quadrilateral section A, figures 6,12,13
	double diag=(3.0*n1 + sqrt(72.0*n2*n3*fijk - 3.0*SQUARE(n1)))/6.0;
	h1=diag/(n1+tiny);
	double p1=diag/(n2+tiny);
	h2=p1;
	double q1=diag/(n3+tiny);
	h3=q1;
	double p2=p1*(1.0-n1/diag);
	double q2=q1*(1.0-n1/diag);
	if (p1 > 1.0 || p2 > 1.0 || q1 > 1.0 || q2 > 1.0)
	{
		fprintf (files.error, "Area:QUAD A ANOMALY: %d %f %f %f %f\n", ijk, fijk, n1, n2, n3);
		p1 = MIN(1.0, p1);
		p2 = MIN(1.0, p2);
		q1 = MIN(1.0, q1);
		q2 = MIN(1.0, q2);
		//exit (1);
	}
	pp[0]=1.0;
	qq[0]=0.0;
	rr[0]=q2;
	pp[1]=1.0;
	qq[1]=p2;
	rr[1]=0.0;
	pp[2]=0.0;
	qq[2]=p1;
	rr[2]=0.0;
	pp[3]=0.0;
	qq[3]=0.0;
	rr[3]=q1;
	nverts=4;
	return true;
}
bool QuadB(double n1, double n2, double n3, double &h1, double &h2, double &h3, double fijk, int ijk, int &nverts)
{	
	//if(ijk==IND_f(61,1,22)) printf("entered QuadB\n");
	double diag=0.5*(n1+n2)+fijk*n3;
	h1=diag/(n1+tiny);
	h2=diag/(n2+tiny);
	double p4=diag/(n3+tiny);
	h3=p4;
	double p1=p4*(1.0-n1/diag);
	double p3=p4*(1.0-n2/diag);
	double p2=p1-(p4-p3);
	if (p1<0 || p1>1 ||
		p2<0 || p2>1 ||
		p3<0 || p3>1 ||
		p4<0 || p4>1)
	{
		fprintf (files.error, "Area:QUAD B PROBLEM: %d %f %f %f %f\n", ijk, fijk, n1, n2, n3);
		p1 = MAX(0.0,MIN(1.0, p1));
		p2 = MAX(0.0,MIN(1.0, p2));
		p3 = MAX(0.0,MIN(1.0, p3));
		p4 = MAX(0.0,MIN(1.0, p4));
		//exit (1);
	}
	pp[0]=1.0;
	qq[0]=0.0;
	rr[0]=p1;
	pp[1]=1.0;
	qq[1]=1.0;
	rr[1]=p2;
	pp[2]=0.0;
	qq[2]=1.0;
	rr[2]=p3;
	pp[3]=0.0;
	qq[3]=0.0;
	rr[3]=p4;
	nverts=7;
	return true;
}
bool Pentagon(double n1, double n2, double n3, double &h1, double &h2, double &h3, double fijk, int ijk, int &nverts)
{	
	//if(ijk==IND_f(61,1,22)) printf("entered Pentagon\n");
	if ((n1+n2 >= n3 && 6.0*n1*n2*n3*fijk < CUBE(n3)-CUBE(n3-n1)-CUBE(n3-n2)) || (n1+n2 < n3 && 2.0*n3*fijk < n1+n2))
	{
		//pentagonal section, figures 7,14
		double rsixn3=1.0/(6.0*n1*n2*n3);
		int idiag=0;
		double diag=n2;
		double ppent;
		double rpent;
		double qpent;
		double spent;
		double hpent;

		while (1) //while pent diag problem
		{
			double delta;
			int loop;
			for (delta=em6,loop=0;loop<1000 && fabs(delta) >= em6;loop++)
			{
				delta=-(rsixn3*(CUBE(diag)-CUBE(diag-n1)-CUBE(diag-n2))-fijk)
					  /(3.0*rsixn3*(SQUARE(diag)-SQUARE(diag-n1)-SQUARE(diag-n2)));
				diag += delta;
			}
			h1=diag/n1;
			h2=diag/n2;
			hpent=diag/n3;
			h3=hpent;
			if (hpent > 1.0)
			{
				fprintf (files.error, "Area:PENTAGON ANOMALY: %d %f %f %f %f\n", ijk, fijk, n1, n2, n3);
                printf ("Area:PENTAGON ANOMALY: %d %f %f %f %f\n", ijk, fijk, n1, n2, n3);
                return false;
				//exit(1);
			}
			ppent=hpent*(1.0-n1/diag);
			rpent=hpent*(1.0-n2/diag);
			qpent=ppent/(hpent-rpent);
			spent=rpent/(hpent-ppent);
			if (hpent > 1.0 || hpent < 0.0 || ppent > 1.0 || 
				ppent < 0.0 || qpent > 1.0 || qpent < 0.0 || 
				rpent > 1.0 || rpent < 0.0 || spent > 1.0 || 
				spent < 0.0)
			{
				idiag++;
				if (idiag==11)
				{
					fprintf (files.error, "Area:PEN DIAG PROBLEM: %d %f %f %f %f\n", ijk, fijk, n1, n2, n3);
                    printf ("Area:PEN DIAG PROBLEM: %d %f %f %f %f\n", ijk, fijk, n1, n2, n3);
                    return false; 
					//exit(1);
				}
				diag=n2+(double)idiag*(n3-n2)/10.0;
			}
			else break;
		}	//end while (1)
		pp[0]=0.0;
		qq[0]=1.0;
		rr[0]=rpent;
		pp[1]=spent;
		qq[1]=1.0;
		rr[1]=0.0;
		pp[2]=1.0;
		qq[2]=qpent;
		rr[2]=0.0;
		pp[3]=1.0;
		qq[3]=0.0;
		rr[3]=ppent;
		pp[4]=0.0;
		qq[4]=0.0;
		rr[4]=hpent;
		nverts=5;
		return true;
	}
	else
		return false;
}

bool Hexagon(double n1, double n2, double n3, double &h1, double &h2, double &h3, double fijk, int ijk, int &nverts)
{	
	//if(ijk==IND_f(61,1,22)) printf("entered Hexagon\n");
	if ((n1+n2 > n3) && 6.0*n1*n2*n3*fijk >= CUBE(n3)-CUBE(n3-n1)-CUBE(n3-n2))
	{
		//if(ijk==IND_f(61,1,22)) printf("n1=%.12e n2=%.12e n3=%.12e n1+n2=%.12e fijk=%.12e 6.0*n1*n2*n3*fijk=%.12e CUBE(n3)-CUBE(n3-n1)-CUBE(n3-n2)=%.12e\n",n1,n2,n3,n1+n2,fijk,6.0*n1*n2*n3*fijk,CUBE(n3)-CUBE(n3-n1)-CUBE(n3-n2));
		//hexagonal section, figures 8,15
		double rsixn3=1.0/(6.0*n1*n2*n3);
		int idiag=0;
		double diag=n3;
		double phex,qhex,rhex,shex,thex,uhex;
		while (1)	//while hex diag problem.
		{
			double delta;
			int loop;
			for (delta=em6,loop=0;loop<1000 && fabs(delta)>=em6; loop++)
			{
				delta = -(rsixn3*(CUBE(diag)-CUBE(diag-n1)-CUBE(diag-n2)-CUBE(diag-n3)) -fijk)
						/(3.0*rsixn3*(SQUARE(diag) - SQUARE(diag-n1) - SQUARE(diag-n2) - SQUARE(diag-n3)));
				diag += delta;
			}
			h1=diag/n1;
			h2=diag/n2;
			h3=diag/n3;
			phex=(diag-n2)/n3;
			qhex=(diag-n2)/n1;
			rhex=(diag-n3)/n2;
			shex=(diag-n3)/n1;
			thex=(diag-n1)/n2;
			uhex=(diag-n1)/n3;
			//if(ijk==IND_f(61,1,22)) printf("diag=%.12e phex=%.12e qhex=%.12e rhex=%.12e shex=%.12e thex=%.12e uhex=%.12e\n",diag,phex,qhex,rhex,shex,thex,uhex);
			if (phex>1.0 || phex <0.0 ||
				qhex>1.0 || qhex <0.0 ||
				rhex>1.0 || rhex <0.0 ||
				shex>1.0 || shex <0.0 ||
				thex>1.0 || thex <0.0 ||
				uhex>1.0 || uhex <0.0 )
			{
				idiag++;
				if (idiag == 11)
				{
					fprintf (files.error, "Area:HEX DIAG PROBLEM: %d %f %f %f %f\n", ijk, fijk, n1, n2, n3);
					return false;
					//exit(1);
				}
				diag=n3+(double)idiag*(0.866-n3)/10.0;
			}
			else break;
		}	//end while (1)
		pp[0]=1.0;
		qq[0]=0.0;
		rr[0]=uhex;
		pp[1]=1.0;
		qq[1]=thex;
		rr[1]=0.0;
		pp[2]=qhex;
		qq[2]=1.0;
		rr[2]=0.0;
		pp[3]=0.0;
		qq[3]=1.0;
		rr[3]=phex;
		pp[4]=0.0;
		qq[4]=rhex;
		rr[4]=1.0;
		pp[5]=shex;
		qq[5]=0.0;
		rr[5]=1.0;
		nverts=6;
		return true;
	}
	else return false;
}

#ifdef rudman_fine
#ifdef __solid
//void area_2 (double fijk, int ijk, double xn, double yn, double zn, double *xd, double *yd, double *zd, double *ax, double *ay, double *az)
#define TOL 1.e-14
void area_2(double fijk, int i, int j, int k, int ijk, st_point *nor, st_point *cent, st_point *vec_a)
{							    
	//similar to area but has more output tailored to our needs ..AP
	//fijk can represent actual f_f and also psi_f (solid vol fraction)	
	double xn, yn, zn;
	xn = -(*nor).x; //(xn,yn,zn) triad denotes the normal vector to the surface pointing "outwards"
	yn = -(*nor).y;
	zn = -(*nor).z;
	
	double rlength = 1.0/sqrt(SQUARE(xn)+SQUARE(yn)+SQUARE(zn)+tiny);
	xn *= rlength;
	yn *= rlength;
	zn *= rlength;

	//swap fluid and void, and negate normals if fn > 1/2.
	//double fijk = f[ijk];
	if (fijk > 0.5)
	{
		fijk = 1.0-fijk;
		xn = -xn;
		yn = -yn;
		zn = -zn;
	}
	
	//define corners and corner numbers
      //what's the purpose of this? (xnn = xn^0.1)
      double xnn=pow(fabs(xn),0.1) * SIGN(xn);
      double ynn=pow(fabs(yn),0.1) * SIGN(yn);
      double znn=pow(fabs(zn),0.1) * SIGN(zn);
	
      //uh-oh...uh.. do something random!
      /*if (xnn==0.0) xnn+=em10;
      if (ynn==0.0) ynn-=em10;
      if (znn==0.0) znn+=em10;*/ //this part produced errors for LB .. so commented out

	double p0=100.0;
	double p1=1000.0;
	double p2=10000.0;
	int m0=0, m1=0, m2=0;
	int ii,jj,kk;
	for (ii=0;ii<2;ii++)
		for (jj=0;jj<2;jj++)
			for (kk=0;kk<2;kk++)
			{
				int m = 4*ii+2*jj+kk+1;
				pcorner[m-1]=xnn*ii + ynn*jj + znn*kk;
				if (pcorner[m-1] < p0)
				{
					p2=p1;
					p1=p0;
					p0=pcorner[m-1];
					m2=m1;
					m1=m0;
					m0=m;
				}
				else if (pcorner[m-1] < p1)
				{
					p2=p1;
					p1=pcorner[m-1];
					m2=m1;
					m1=m;
				}
				else if (pcorner[m-1] < p2)
				{
					p2=pcorner[m-1];
					m2=m;
				}
			}
	//order the normals
	double n1 = MIN(fabs(xn), MIN(fabs(yn), fabs(zn)));
	double n3 = MAX(fabs(xn), MAX(fabs(yn), fabs(zn)));
	double n2=fabs(xn)+fabs(yn)+fabs(zn)-n1-n3;

	int m3=9+m0-m1-m2;
	int m1pm2 = m1+m2;
	int m1pm3 = m1+m3;
	int m2pm3 = m2+m3;
	if (!(m1pm2 == 5 || m1pm2 == 13 || m1pm3 == 5 || m1pm3 == 13 || m2pm3 == 5 || m2pm3 == 13) && n2 > em10)
	{
		printf ("%d %d %d %d Area:M MISMATCH %f %f %f\n", m0,m1,m2,m3, xn, yn, zn);
        fprintf (files.error,"%d %d %d %d Area:M MISMATCH %f %f %f\n", m0,m1,m2,m3, xn, yn, zn);
		printf ("n1,n2,n3 = %e, %e, %e\n", n1,n2,n3);
        fprintf (files.error,"n1,n2,n3 = %e, %e, %e\n", n1,n2,n3);
        //printf ("i=%d  j=%d  k=%d\n",i,j,k);
        //fprintf (files.error,"i=%d  j=%d  k=%d\n",i,j,k);
		exit(1);
	}
	int nzeroflags=0;
	if(n1 < em6) nzeroflags |= 1;
	if(n2 < em6) nzeroflags |= 2;
	if(n3 < em6) nzeroflags |= 4;
	/* //commented ... ashish
	if (n1==0) {n1=TOL; nzeroflags |=1;}
	if (n2 <= 0.0) {n2 = TOL; nzeroflags |=2;}
	if (n3==0) {n3=TOL; nzeroflags |=4;}
	if (n1 <= TOL || n2 <= TOL || n3 <= TOL)
	*/
	if(n1 < em6 || n2 < em6 || n3 < em6)
	{
		const double length=sqrt (n1*n1+n2*n2+n3*n3);
		n1 /= length;
		n2 /= length;
		n3 /= length;
	}

	double h1, h2, h3;
	int nverts=0;
	
	//if(i==61 && j==1 && k==22) printf("reached till before reconstruction\n");
	/*Special cases:
	   n2==0 implies n1==0 because n1<=n2: QuadB only.
	   n1==0, n2!=0: a Quad section.
	*/

	if (nzeroflags&2)		{//n2==0
		//if(i==61 && j==1 && k==22) printf("n2==0 before\n");
		QuadB(n1, n2, n3, h1, h2, h3, fijk, ijk, nverts);
		//if(i==61 && j==1 && k==22) printf("n2==0 after\n");
	}
	else if (nzeroflags&1)	//n1==0
	{	
		//if(i==61 && j==1 && k==22) printf("n1==0 before\n");
		n1=0.0;
		if (QuadA(n1, n2, n3, h1, h2, h3, fijk, ijk, nverts));
		else QuadB(n1, n2, n3, h1, h2, h3, fijk, ijk, nverts);
		//if(i==61 && j==1 && k==22) printf("n1==0 after\n");
	}
	else
	{	
		//if(i==61 && j==1 && k==22) printf("else before\n");
		if (Triangle (n1, n2, n3, h1, h2, h3, fijk, ijk, nverts));
		else if(QuadA(n1, n2, n3, h1, h2, h3, fijk, ijk, nverts));
		else if(Pentagon(n1, n2, n3, h1, h2, h3, fijk, ijk, nverts));
		else if(Hexagon(n1, n2, n3, h1, h2, h3, fijk, ijk, nverts));
		else QuadB (n1, n2, n3, h1, h2, h3, fijk, ijk, nverts);
		//if(i==61 && j==1 && k==22) printf("n2==0 after\n");
	} //n1,n2 != 0
	
	if(nverts==7) nverts=4;
	//if(i==61 && j==1 && k==22) printf("reached till after reconstruction\n");
	//map back to actual coordinate system
	double xm0=0.0;
	double ym0=0.0;
	double zm0=0.0;
	if (m0 == 5 || m0 == 6 || m0 == 7 || m0 == 8) xm0=1.0;
	if (m0 == 3 || m0 == 4 || m0 == 7 || m0 == 8) ym0=1.0;
	if (m0 == 2 || m0 == 4 || m0 == 6 || m0 == 8) zm0=1.0;
	double xm1=0.0;
	double ym1=0.0;
	double zm1=0.0;
	if (m1 == 5 || m1 == 6 || m1 == 7 || m1 == 8) xm1=1.0;
	if (m1 == 3 || m1 == 4 || m1 == 7 || m1 == 8) ym1=1.0;
	if (m1 == 2 || m1 == 4 || m1 == 6 || m1 == 8) zm1=1.0;
	double xm2=0.0;
	double ym2=0.0;
	double zm2=0.0;
	if (m2 == 5 || m2 == 6 || m2 == 7 || m2 == 8) xm2=1.0;
	if (m2 == 3 || m2 == 4 || m2 == 7 || m2 == 8) ym2=1.0;
	if (m2 == 2 || m2 == 4 || m2 == 6 || m2 == 8) zm2=1.0;
	double xm3=0.0;
	double ym3=0.0;
	double zm3=0.0;
	if (m3 == 5 || m3 == 6 || m3 == 7 || m3 == 8) xm3=1.0;
	if (m3 == 3 || m3 == 4 || m3 == 7 || m3 == 8) ym3=1.0;
	if (m3 == 2 || m3 == 4 || m3 == 6 || m3 == 8) zm3=1.0;

	cent->x=0.0;
	cent->y=0.0;
	cent->z=0.0;
	
	for (int nn=0;nn<nverts;nn++)
	{
		cent->x+=xm0+pp[nn]*(xm1-xm0)+qq[nn]*(xm2-xm0)+rr[nn]*(xm3-xm0);
		cent->y+=ym0+pp[nn]*(ym1-ym0)+qq[nn]*(ym2-ym0)+rr[nn]*(ym3-ym0);
		cent->z+=zm0+pp[nn]*(zm1-zm0)+qq[nn]*(zm2-zm0)+rr[nn]*(zm3-zm0);
	}
	cent->x /= nverts;
	cent->y /= nverts;
	cent->z /= nverts;
	
	//centroid scaled to real coordinates
	/*cent->x = (i-1+2*mpi.OProc[0] + cent->x)*0.5e0*delx[1];
	cent->y = (j-1+2*mpi.OProc[1] + cent->y)*0.5e0*dely[1];
	cent->z = (k-1+2*mpi.OProc[2] + cent->z)*0.5e0*delz[1];*/
	
	//calculate unit vector vec_a
	vec_a->x = (pp[0]-pp[1])*(xm1-xm0)+(qq[0]-qq[1])*(xm2-xm0)+(rr[0]-rr[1])*(xm3-xm0);
	vec_a->y = (pp[0]-pp[1])*(ym1-ym0)+(qq[0]-qq[1])*(ym2-ym0)+(rr[0]-rr[1])*(ym3-ym0);
	vec_a->z = (pp[0]-pp[1])*(zm1-zm0)+(qq[0]-qq[1])*(zm2-zm0)+(rr[0]-rr[1])*(zm3-zm0);
	
	rlength = 1.0/sqrt(SQUARE(vec_a->x)+SQUARE(vec_a->y)+SQUARE(vec_a->z)+tiny);
	vec_a->x *= rlength;
	vec_a->y *= rlength;
	vec_a->z *= rlength;
}
#undef SIGN
#endif
#endif
