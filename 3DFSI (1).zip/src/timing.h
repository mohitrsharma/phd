#ifndef TIMING_H
#define TIMING_H

#include <stdio.h>
#include <time.h>

// Structure to store timing information
typedef struct {
    double recons_3p_time;
    double recons_contact_line_time;
    double layer_3p_time;
    double flag_2p1p_time;
    double total_reconstruction_time;
    double golden_search_time;      // Time for golden section search
    double ren_method_time;         // Time for Ren's method (volume fraction reconstruction)
} ReconstructionTiming;

// Global timing structure
extern ReconstructionTiming recon_timing;

// Function to initialize timing
void init_timing();

// Function to print timing results
void print_timing_results();

// Function to reset timing counters
void reset_timing();

#endif // TIMING_H 