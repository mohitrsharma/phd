#include "ripple.h"
#include <math.h>
#include <string.h>
#include <stdlib.h> //exit
#include "testing.h"
#define SIGN(A) (((A)<0)?(-1):(1))

#define TOL 1e-6
/******************************************************************************


Subroutine VOFDLY is called by: RIPPLE

Subroutine VOFDLY calls:    LIMIT, BCF, NORMALS, VOFERR, SETNF, setproperties

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION                                         NAME        DATE

- Subroutine modified for OVER and UNDER jet		Babak		Sep 24 2009
  boundary conditions
  
- Subroutine modified for variable properties		Babak		Sep 16 2009
  
- Subroutine modified to convect enthalpy the		Babak		May 17 2009
  same way VOF is convected.
  
- Commented part which applies velocity bcs to      Ben         Aug 2 2005
  newly filled cells.  This is done in bc.cpp 
  anyways

- Sub. setrho with setproperties                    Amirreza    Dec 2 2005
  2005

_________________________________TO DO LIST____________________________________

DESCRIPTION                                         NAME        DATE


*******************************************************************************/

bool isTriangle (double &epsi1, double n1, double n2, double n3, double epsi, double fijkd, int m1pm2, int m1pm3, int m2pm3);
bool isQuadA (double &epsi1, double n1, double n2, double n3, double epsi, double fijkd, int m1pm2, int m1pm3, int m2pm3);
bool isPentagon (double &epsi1, double n1, double n2, double n3, double epsi, double fijkd, int m1pm2, int m1pm3, int m2pm3);
bool isHexagon (double &epsi1, double n1, double n2, double n3, double epsi, double fijkd, int m1pm2, int m1pm3, int m2pm3);
bool isQuadB (double &epsi1, double n1, double n2, double n3, double epsi, double fijkd, int m1pm2, int m1pm3, int m2pm3);
#ifdef rudman_fine
double f_mom_x(int i, int j, int k);
double f_mom_y(int i, int j, int k);
double f_mom_z(int i, int j, int k);
//double recons_2P(double xn, double yn, double zn, double fijkd, double epsi, int ijkd, int ijka); //moved to ripple.h
void set_mom_vof();
void bc_mom();
template <class T> void fetch_mom(int i, int j, int k, T &val, T *array, T *gArray);
#ifdef __solid
double psi_mom_x(int i, int j, int k);
double psi_mom_y(int i, int j, int k);
double psi_mom_z(int i, int j, int k);
#endif
#endif

void advect_scalar(int looper, double *s, double *S, double *c, double *fn, double *vold_f, 
	                   double *vnew_f, double *u_f, double *flx);
void clean_scal(double *s);
void vofdly()
{
    int i,j,k,OBC = 16;
    double *ftilde=temp[0];
    double *vold=temp[1];
    double *vnew=temp[2];
    double *fold=temp[3];
	double *hold=temp[4];
	double *tmpold=temp[5];
	double dtadp,dtadm,taddmax,taddmin,taddc2,dtadd,tadd,htadd,htaddf1,htaddf2;
	double cpTf1,cpTf2;

    int looper[6][3] = {{3,2,1},{1,2,3},{2,3,1},{1,3,2},{2,1,3},{3,1,2}};

    //if too much VOF is being fluxed
#ifdef pres_v
      for(i=0;i<im1;i++)
            for(j=0;j<jm1;j++)
                  for(k=0;k<km1;k++)
                  {
                        u[IJK]=1.e0;
                        v[IJK]=0.e0;
                        w[IJK]=0.e0;
                  }
#endif

    double vofadverror = 0.0;   //use double for convenience.
    for (i=1;i<im1 && vofadverror==0;i++)
        for (j=1;j<jm1 && vofadverror==0;j++)
            for (k=1;k<km1;k++)
            {
                const double abvx=fabs(u[IJK])*delt;
                const double abvy=fabs(v[IJK])*delt;
                const double abvz=fabs(w[IJK])*delt;
                if ( ((abvx > delx[i]) || (abvy > dely[j]) || (abvz > delz[k])) && (ac[IJK] > em6))
                {
                    vofadverror = 1.0;  //report local error
                    printf("p%d: VOFADV ERROR  ncyc=%7d, t=%14.6e, delt=%12.4e, i,j,k=%4d %4d %4d, abvx=%12.4e, delx=%12.4e, abvy=%12.4e, dely=%12.4e, abvz=%12.4e, delz=%12.4e\n",mpi.MyRank, ncyc, t, delt, i,j,k, abvx, delx[i], abvy, dely[j], abvz, delz[k]);
                    printf("i=%d  j=%d  k=%d %7.6e  %7.6e  %7.6e\n",i,j,k,u[IJK],v[IJK],w[IJK]);
                    fprintf(files.error,"VOFADV ERROR  ncyc=%7d, t=%14.6e, delt=%12.4e, i,j,k=%4d %4d %4d, abvx=%12.4e, delx=%12.4e, abvy=%12.4e, dely=%12.4e, abvz=%12.4e, delz=%12.4e\n", ncyc, t, delt, i,j,k, abvx, delx[i], abvy, dely[j], abvz, delz[k]);
                    break;
                }
            }
    //dallreduce will set flgc to 1.0 if any processor's vofadverror is 1.0
    dallreduce (&vofadverror, &flgc, 1, OP_MAX);
    if (flgc > 0.5) return;

    //store fn in a safe spot until the end of the subroutine
    memcpy (fold, fn, NX*NY*NZ*sizeof(double));

    memset (ijkfr, 0, NX*NY*NZ*sizeof(int));
    //if (t > 4.39e-2 && t < 4.41e-2)
    //  printf ("nf = %d\n", nf[IND(im1,26,26)]);
    for(i=0;i<imax;i++)
        for(j=0;j<jmax;j++)
            for(k=0;k<kmax;k++)
                if (nf[IJK] < 7) ijkfr[IJK]=1;

    //to start, define vnew=vol 
    memcpy (vnew, vol, NX*NY*NZ*sizeof(double));

	//store energy related variables
	if (ENERGY)
	{
		memcpy (tmpold, tmp, NX*NY*NZ*sizeof(double));

		for (i=0;i<imax;i++)
			for (j=0;j<jmax;j++)
				for (k=0;k<kmax;k++)
					hold[IJK]=h[IJK]*rho[IJK];

		memcpy (h, hold, NX*NY*NZ*sizeof(double));
	}

	//START OF THE BIG LOOP
    
	int isweep = ncyc%6;

    for (int nsubcyc=0;nsubcyc<3;nsubcyc++) //3 sweeps for three directions.
    {
		bcf();

//		for (i=0;i<imax;i++)
//			for (j=0;j<jmax;j++)
//				for (k=0;k<kmax;k++)
//					{
//						rho[IJK]=rhof1*f[IJK]+rhof2*(1.0-f[IJK]);
//					}				

        setproperties();
        normals();
        memcpy (vold, vnew, NX*NY*NZ*sizeof(double));

        for (i=1;i<im1;i++)
            for (j=1;j<jm1;j++)
                for (k=1;k<km1;k++)
				{
                    //define new volumes, normalize f wrt the new volumes
                    f[IJK]=fn[IJK]*vnew[IJK];
					//normalize h wrt the new volumes
					if (ENERGY) h[IJK]=hold[IJK]*vnew[IJK];
				}

        for (i=1;i<im1;i++)
            for (j=1;j<jm1;j++)
                for (k=1;k<km1;k++)
                {
                    if (ijkfr[IJK]==0) continue;

                    switch (looper[isweep][nsubcyc])
                    {
                        case 1:
                            vnew[IJK] += (u[IMJK]-u[IJK])*dely[j]*delz[k]*delt;
                            break;
                        case 2:
                            vnew[IJK] += (v[IJMK]-v[IJK])*delx[i]*delz[k]*delt;
                            break;
                        case 3:
                            vnew[IJK] += (w[IJKM]-w[IJK])*delx[i]*dely[j]*delt;
                            break;
                    }
                }

        xchg<double>(vnew);

        for (i=1;i<im1;i++)
            for (j=1;j<jm1;j++)
                for (k=1;k<km1;k++)
                {
                    f[IJK]/=vnew[IJK];
					if (ENERGY) h[IJK]/=vnew[IJK];
                }

		//START OF THE FLUXING LOOP

        for (i=0;i<im1;i++)
            for (j=0;j<jm1;j++)
                for (k=0;k<km1;k++)
                {
                    int id=i,jd=j,kd=k;
                    int ijkd, ijka, ijkd1;
                    double xn, yn, zn;
                    double epsi,epsi1;
                    epsi = epsi1 = 0.0;

                    switch (looper[isweep][nsubcyc])
                    {
                        case 1:
                            if (j==0 || k==0) continue;
                            if (u[IJK] == 0) continue;
                            if (u[IJK] > 0)
                            {
                                ijkd=IJK;
                                ijka=IJK+1;
								ijkd1=ijkd-1;
								if (i==0) ijkd1=ijkd;
                                xn=-avnx[ijkd]*rdx[id];
                                yn=-avny[ijkd]*rdy[jd];
                                zn=-avnz[ijkd]*rdz[kd];
                            }
                            else
                            {
                                ijkd=IJK+1;
                                ijka=IJK;
								ijkd1=ijkd+1;
								if (i==im1) ijkd1=ijkd;
                                id=i+1;
                                xn=avnx[ijkd]*rdx[id];
                                yn=-avny[ijkd]*rdy[jd];
                                zn=avnz[ijkd]*rdz[kd];
                            }
                            epsi=fabs(u[IJK])*dely[jd]*delz[kd]*delt/vold[ijkd];
                            break;
                        case 2:
                            if (i==0 || k==0) continue;
                            if (v[IJK] == 0) continue;
                            if (v[IJK] > 0)
                            {
                                ijkd=IJK;
                                ijka=IJK+imax;
								ijkd1=IJK-imax;
								if (j==0) ijkd1=ijkd;
                                xn=-avny[ijkd]*rdy[jd];
                                yn=avnx[ijkd]*rdx[id];
                                zn=-avnz[ijkd]*rdz[kd];
                            }
                            else
                            {
                                ijkd=IJK+imax;
                                ijka=IJK;
								ijkd1=ijkd+imax;
								if (j==jm1) ijkd1=ijkd;
                                jd=j+1;
                                xn=avny[ijkd]*rdy[jd];
                                yn=-avnx[ijkd]*rdx[id];
                                zn=-avnz[ijkd]*rdz[kd];
                            }
                            epsi=fabs(v[IJK])*delx[id]*delz[kd]*delt/vold[ijkd];
                            break;
                        case 3:
                            //skip ghost cell donating to ghost cell
                            if (i==0 || j==0) continue;
                            if (w[IJK] == 0) continue;
                            if (w[IJK] > 0)
                            {
                                ijkd=IJK;
                                ijka=IJK+ijmax;
								ijkd1=IJK-ijmax;
								if (k==0) ijkd1=ijkd;
                                xn=-avnz[ijkd]*rdz[kd];
                                yn=-avny[ijkd]*rdy[jd];
                                zn=avnx[ijkd]*rdx[id];
                            }
                            else
                            {
                                ijkd=IJK+ijmax;
                                ijka=IJK;
								ijkd1=ijkd+ijmax;
								if (k==km1) ijkd1=ijkd;
                                kd=k+1;
                                xn=avnz[ijkd]*rdz[kd];
                                yn=-avny[ijkd]*rdy[jd];
                                zn=-avnx[ijkd]*rdx[id];
                            }
                            epsi=fabs(w[IJK])*delx[id]*dely[jd]*delt/vold[ijkd];
                            break;
                    }//switch

					//calculating the advection temperature
					if (ENERGY)
					{
						dtadp=tmpold[ijka]-tmpold[ijkd];
						dtadm=tmpold[ijkd]-tmpold[ijkd1];
						taddmax=MAX(tmpold[ijkd],MAX(tmpold[ijka],tmpold[ijkd1]));
						taddmin=MIN(tmpold[ijkd],MIN(tmpold[ijka],tmpold[ijkd1]));

						if (taddmax > MAX(tif1,tif2))
							taddmax=MAX(tif1,tif2);
						if (taddmin < MIN(tif1,tif2))
							taddmin=MIN(tif1,tif2);

						//calculating c2 (vala thesis, eq4.16-p70)

						taddc2=pow(taddmax-taddmin,2.0)/8.0;

						//calculating avr(t) (vala thesis, eq4.15-p70)

						dtadd=0.5*(dtadp+dtadm)*(1.0-pow(dtadp-dtadm,2.0)/
							(pow(dtadp,2.0)+pow(dtadm,2.0)+2.0*taddc2+tiny));

						//calculating vanleer advection temp (vala thesis, eq4.12-p70)

						tadd=tmpold[ijkd]+0.5*dtadd;

						//to eliminate oscillations

						if (tadd > taddmax)	tadd=taddmax;
						if (tadd < taddmin)	tadd=taddmin;

						//applying jet exit condition at the UNDER face
						
//						if (ku == 5 && k+mpi.OProc[2] < OBC)		//To find global coordinates
//							tadd = tif2;

						//calculating Cp at tadd
						
						if (VARPROP)
						{
							cpTf1 = interp(FLUID1_T,FLUID1_Cp,tadd);
							cpTf2 = interp(FLUID2_T,FLUID2_Cp,tadd);
						}
						else
						{
							cpTf1 = cpf1;
							cpTf2 = cpf2;
						}	
				
					}

					//SWEEPING VOLUMES AND ENTHALPIES
					
					//if donor cell is empty or full,...
                    if (fn[ijkd] < em6)
					{
						if (ENERGY)
						{
							htadd=rhof2*(h0f2+cpTf2*tadd);
							h[ijkd]=h[ijkd]-htadd*epsi*vold[ijkd]/vnew[ijkd];
							h[ijka]=h[ijka]+htadd*epsi*vold[ijkd]/vnew[ijka];
						}
						continue;
					}
                    if (ijkfr[ijkd]==0) continue;

                    if (fn[ijkd] > em61)
                    {
                        f[ijkd] -= epsi*vold[ijkd]/vnew[ijkd];
                        f[ijka] += epsi*vold[ijkd]/vnew[ijka];

						if (ENERGY)
						{
							
							htadd=rhof1*cpTf1*tadd;

							h[ijkd]=h[ijkd]-htadd*epsi*vold[ijkd]/vnew[ijkd];
							h[ijka]=h[ijka]+htadd*epsi*vold[ijkd]/vnew[ijka];
						}

                        continue;
                    }

                    //make _n's unit normal
                    double rlength = 1.0/sqrt(xn*xn+yn*yn+zn*zn + tiny);
                    xn *= rlength;
                    yn *= rlength;
                    zn *= rlength;

                    //swap fluid and void. Negate normals if fn > 1/2
                    int iswap = 0;
                    double fijkd = fn[ijkd];
                    if (fijkd > 0.5)
                    {
                        fijkd = 1.0-fijkd;
                        xn = -xn;
                        yn = -yn;
                        zn = -zn;
                        iswap=1;
                    }

                    //define corners and corner numbers
                    //what's the purpose of this? (xnn = xn^0.1)
                    double xnn=pow(fabs(xn),0.1) * SIGN(xn);
                    double ynn=pow(fabs(yn),0.1) * SIGN(yn);
                    double znn=pow(fabs(zn),0.1) * SIGN(zn);

                    //uh-oh...uh.. do something random!
                    if (xnn==0.0) xnn+=em10;
                    if (ynn==0.0) ynn-=em10;
                    if (znn==0.0) znn+=em10;

                    double p0=100.0;
                    double p1=1000.0;
                    double p2=10000.0;
                    int m=0,m0=0,m1=0,m2=0;
                    int ii,jj,kk;
                    for (ii=0;ii<2;ii++)
                        for (jj=0;jj<2;jj++)
                            for (kk=0;kk<2;kk++)
                            {
                                m=4*ii+2*jj+kk+1;
                                pcorner[m-1]=xnn*ii+ynn*jj+znn*kk;
								if (!equal(pcorner[m-1],p0, TOL) && pcorner[m-1] < p0)
                                {
                                    p2=p1;
                                    p1=p0;
                                    p0=pcorner[m-1];
                                    m2=m1;
                                    m1=m0;
                                    m0=m;
                                }
								else if(!equal(pcorner[m-1],p1, TOL) && pcorner[m-1]<p1)
                                {
                                    p2=p1;
                                    p1=pcorner[m-1];
                                    m2=m1;
                                    m1=m;
                                }
								else if (!equal(pcorner[m-1],p2, TOL) && pcorner[m-1]<p2)
                                {
                                    p2=pcorner[m-1];
                                    m2=m;
                                }
                            }
                    //order the normals
                    double absxn=fabs(xn);
                    double absyn=fabs(yn);
                    double abszn=fabs(zn);
                    n1=MIN(MIN(absxn,absyn),abszn);
                    n3=MAX(MAX(absxn,absyn),abszn);
                    n2=absxn+absyn+abszn-n1-n3;

                    int m3=9+m0-m1-m2;
                    int m1pm2=m1+m2;
                    int m1pm3=m1+m3;
                    int m2pm3=m2+m3;
                    //if n2==0 then we approach four vertices simultaneously,
                    //which means the m's might not make sense.
                    if (!(m1pm2==5 || m1pm2==13 || m1pm3==5
                          || m1pm3==13 || m2pm3==5 || m2pm3==13) && n2 > em10)
                    {
                        printf ("p%2d: %d %d %d %d M MISMATCH %f %f %f %d  %d\n",mpi.MyRank,m0,m1,m2,m3,xn,yn,zn,ijkd,ijka);
                        fprintf (files.error, "p%2d: %d %d %d %d M MISMATCH %f %f %f %d %d\n",mpi.MyRank,m0,m1,m2,m3,xn,yn,zn,ijkd,ijka);
//                        exit(1);
                    }

                    int nzeroflags=0;
                    if (n1 < em6) nzeroflags|=1;
                    if (n2 < em6) nzeroflags|=2;
                    if (n3 < em6) nzeroflags|=4;
                    //note if modifying n1,n2,n3 to avoid division by zero (e.g. if (n1==0)n1=em6;) do so
                    //after the nzeroflags have been set. (i.e. here.)

                    if (nzeroflags&2)   //n2==0
                    {
                        isQuadB(epsi1,n1,n2,n3,epsi,fijkd,m1pm2,m1pm3,m2pm3);
                    }
                    else if (nzeroflags&1)  //n1==0
                    {
                        n1=0.0; //in case n1 was modified to avoid division by zero. (e.g. n1=em6)
                        if (isQuadA(epsi1,n1,n2,n3,epsi,fijkd,m1pm2,m1pm3,m2pm3));
                        else isQuadB(epsi1,n1,n2,n3,epsi,fijkd,m1pm2,m1pm3,m2pm3);
                    }
                    else
                    {
                        if (isTriangle(epsi1,n1,n2,n3,epsi,fijkd,m1pm2,m1pm3,m2pm3));
                        else if (isQuadA(epsi1,n1,n2,n3,epsi,fijkd,m1pm2,m1pm3,m2pm3));
                        else if (isPentagon(epsi1,n1,n2,n3,epsi,fijkd,m1pm2,m1pm3,m2pm3));
                        else if (isHexagon(epsi1,n1,n2,n3,epsi,fijkd,m1pm2,m1pm3,m2pm3));
                        else isQuadB(epsi1,n1,n2,n3,epsi,fijkd,m1pm2,m1pm3,m2pm3);
                    }

                    //the is[Shape] functions should have set epsi1 to the proper value.
                    if (iswap==1) epsi1=epsi-epsi1;
                    if (epsi1-epsi < em10 && epsi1-epsi >= 0.0 && epsi > em6) epsi1=epsi;
                    if (epsi1>epsi+tiny && epsi > em6)
                    {
                        printf ("DLY ERROR 1: %d %d %d %d %f %f\n", ncyc, nsubcyc, ijkd,ijka, epsi1, epsi);
                        fprintf (files.error, "DLY ERROR 1: %d %d %d %d %f %f\n", ncyc, nsubcyc, ijkd,ijka, epsi1, epsi);
                        //error rather than crash.
                        epsi1 = epsi;
                    }
                    if (epsi1-fn[ijkd] < em10 && epsi1-fn[ijkd] >= 0.0) epsi1=fn[ijkd];
                    if (epsi1 > fn[ijkd])
                    {
                        fprintf (files.error, "DLY ERROR 2: %d %d %d %d %f %f. Retrying...\n", ncyc, nsubcyc, ijkd,ijka, epsi1, fn[ijkd]);
                        printf ("DLY ERROR 2: %d %d %d %d %f %f\n", ncyc, nsubcyc, ijkd,ijka, epsi1, fn[ijkd]);
                        //error rather than crash.
                        epsi1 = fn[ijkd];
                    }

					//NOW ADVECTING VOLUMES
                    f[ijkd] -= epsi1*vold[ijkd]/vnew[ijkd];
                    f[ijka] += epsi1*vold[ijkd]/vnew[ijka];

					//NOW ADVECTING ENTHALPIES
					if (ENERGY)
					{
						htaddf1=rhof1*cpTf1*tadd;
						htaddf2=rhof2*(h0f2+cpTf2*tadd);

						htadd=htaddf1*epsi1+htaddf2*(epsi-epsi1);

						h[ijkd]=h[ijkd]-htadd*vold[ijkd]/vnew[ijkd];
						h[ijka]=h[ijka]+htadd*vold[ijkd]/vnew[ijka];
					}
                }//for(i,j,k)

		//After each sweep, updating temperatures
		if (ENERGY)
		{
			for (i=0;i<imax;i++)
				for (j=0;j<jmax;j++)
					for (k=0;k<kmax;k++)
					{
						rho[IJK]=rhof1*f[IJK]+rhof2*(1.0-f[IJK]);
						h[IJK]=h[IJK]/rho[IJK];
					}

			//Applying jet condition on the OVER boundary

			if (ko == 3)
			{
				for (i=0;i<imax;i++)
					for (j=0;j<jmax;j++)
						for (k=km1;k<km1+2;k++)
						{
							const int ijko = IND(i, j, k);
							double ff1 = f[ijko]*rhof1/rho[ijko];
							double ff2 = (1.0-f[ijko])*rhof2/rho[ijko];

							if (VARPROP)
							{
								cpTf1 = interp(FLUID1_T,FLUID1_Cp,tif1);
								cpTf2 = interp(FLUID2_T,FLUID2_Cp,tif1);
							}
							else
							{
								cpTf1 = cpf1;
								cpTf2 = cpf2;
							}	
		
							h[ijko] = ff1*cpTf1*tif1+ff2*(h0f2+cpTf2*tif1);
						}
			}

			//Applying jet exit condition on UNDER boundary

			enthtmp();
		}

		//exchange f, h, and tmp with neighbors after calculating.
        xchg<double> (f);
		if (ENERGY) xchg<double> (h);
		if (ENERGY) xchg<double> (tmp);

        //after each sweep, set fn=f
        memcpy (fn, f, NX*NY*NZ*sizeof(double));

        //after each sweep, set energy variables
		if (ENERGY)
		{
			for (i=0;i<imax;i++)
				for (j=0;j<jmax;j++)
					for (k=0;k<kmax;k++)
						rho[IJK]=rhof1*f[IJK]+rhof2*(1.0-f[IJK]);
						h[IJK]=h[IJK]*rho[IJK];

			memcpy (hold, h, NX*NY*NZ*sizeof(double));
			memcpy (tmpold, tmp, NX*NY*NZ*sizeof(double));
		}
        
		if (nsubcyc < 2)
            normals();

    }//for (nsubcyc=0;nsubcyc<3;nsubcyc++);
    voferr();
	bcf();
    setproperties();
    setnf();
    normals();
    bc();//apply boundary conditions

	if (ENERGY)
	{
		for (i=0;i<imax;i++)
			for (j=0;j<jmax;j++)
				for (k=0;k<kmax;k++)
					{
						rho[IJK]=rhof1*f[IJK]+rhof2*(1.0-f[IJK]);
						h[IJK]=h[IJK]/rho[IJK];
					}				
		enthtmp();
		bce();
	}
}

//#undef SIGN  ... moved to the end -ashish


//**********************************************************************************************************************

bool isTriangle (double &epsi1, double n1, double n2, double n3, double epsi, double fijkd, int m1pm2, int m1pm3, int m2pm3)
{
    //Returns true if triangular section. Else returns false.
    //if return=true then epsi1 is set to proper value.

    //triangular section, figures 5,11

    if (6.0*n2*n3*fijkd >= n1*n1) return false;     //not a triangle.

    double ptri;
    //triangular section, figures 5,11
    double diag=pow ((6.0*n1*n2*n3*fijkd), 1.0/3.0);
    if (m2pm3 == 13)
    {
        ptri=diag/n1;
        if (ptri > 1.0)
            return false;
    }
    else if(m1pm3==13)
        ptri=diag/n2;
    else if(m1pm2==13)
        ptri=diag/n3;
    else//112
        if (m2pm3==5)
    {
        ptri=diag/n1;
        if (ptri > 1.0)
            return false;
    }
    else if (m1pm3==5)
        ptri=diag/n2;
    else if (m1pm2==5)
        ptri=diag/n3;

    if (m2pm3 == 13 || m1pm3 == 13 || m1pm2==13)
    {
        if (epsi>ptri)
            epsi1=fijkd;
        else
            epsi1=fijkd*(1.0-CUBE((ptri-epsi)/ptri));
    }
    else if (m2pm3==5 || m1pm3==5 || m1pm2==5)
    {
        if (epsi < 1.0-ptri)
            epsi1=0.0;
        else
            epsi1=fijkd*CUBE((epsi-1.0+ptri)/ptri);
    }
    return true;
}

bool isQuadA (double &epsi1, double n1, double n2, double n3, double epsi, double fijkd, int m1pm2, int m1pm3, int m2pm3)
{
    //quadrilateral section A, figures 6,12,13
    if (6.0*n2*n3*fijkd >= 3.0*n2*n2 - 3.0*n1*n2 + n1*n1) return false;

    double diag = (3.0*n1+sqrt(72.0*n2*n3*fijkd-3.0*n1*n1)) /6.0;
    double p1=diag/n2;
    double q1=diag/n3;
    double p2=p1*(1.0-n1/diag);
    double q2=q1*(1.0-n1/diag);

    if (p1>1.0 || p2>1.0 || q1>1.0 || q2>1.0)
    {	
        //printf("p1=%.12e p2=%.12e q1=%.12e q2=%.12e t1-t2=%.12e \n",p1-1.0,p2-1.0,q1-1.0,q2-1.0,6.0*n2*n3*fijkd-3.0*n2*n2 + 3.0*n1*n2 - n1*n1);
        fprintf (files.error,"QUAD A ANOMALY: %f %f %f %f\n",fijkd,n1,n2,n3);
        p1 = MIN(1.0, p1);
        p2 = MIN(1.0, p2);
        q1 = MIN(1.0, q1);
        q2 = MIN(1.0, q2);
        
        //exit(1);
    }
    if (m2pm3==13)
    {
        double pquad=p1+epsi*(p2-p1);
        double qquad=q1+epsi*(q2-q1);
        epsi1=epsi * (p1*q1 + pquad*q1 + pquad*qquad)/6.0;
    }
    else if (m1pm3==13)
    {
        if (epsi>p1)
            epsi1=fijkd;
        else if (epsi>p2)
            epsi1=fijkd - CUBE(p1-epsi)*q1/(6.0*p1*(p1-p2));
        else
            epsi1=epsi/4.0*( q1*(2.0*p1-epsi)/p1 + q2*(2.0*p2-epsi)/p2 );
    }
    else if (m1pm2==13)
    {
        if (epsi>q1)
            epsi1=fijkd;
        else if (epsi>q2)
            epsi1=fijkd - CUBE(q1-epsi)*p1/(6.0*q1*(q1-q2));
        else
            epsi1=epsi/4.0*( p1*(2.0*q1-epsi)/q1 + p2*(2.0*q2-epsi)/q2 );
    }
    else if (m2pm3==5)
    {
        double pquad=p2+epsi*(p1-p2);
        double qquad=q2+epsi*(q1-q2);
        epsi1=epsi * (p2*q2 + pquad*q2 + pquad*qquad)/6.0;
    }
    else if (m1pm3==5)
    {
        if (epsi<1.0-p1)
            epsi1=0.0;
        else if (epsi < 1.0-p2)
            epsi1=CUBE(p1+epsi-1.0)*q1/(6.0*p1*(p1-p2));
        else
            epsi1=fijkd-(1.0-epsi)/4.0*( q1*(2.0*p1+epsi-1.0)/p1 + q2*(2.0*p2+epsi-1.0)/p2 );
    }
    else if (m1pm2==5)
    {
        if (epsi<1.0-q1)
            epsi1=0.0;
        else if (epsi<1.0-q2)
            epsi1=CUBE(q1+epsi-1.0)*p1/(6.0*q1*(q1-q2));
        else
            epsi1=fijkd-(1.0-epsi)/4.0*( p1*(2.0*q1+epsi-1.0)/q1 + p2*(2.0*q2+epsi-1.0)/q2 );
    }
    return true;
}

bool isPentagon (double &epsi1, double n1, double n2, double n3, double epsi, double fijkd, int m1pm2, int m1pm3, int m2pm3)
{
    //pentagonal section, figures 7,14

    if (n1+n2 < n3 || 6.0*n1*n2*n3*fijkd >= CUBE(n3)-CUBE(n3-n1)-CUBE(n3-n2))
    if (n1+n2 >= n3 || 2.0*n3*fijkd >= n1+n2)
        return false;
    double rsixn3=1.0/(6.0*n1*n2*n3);
    int idiag=0;
    double diag=n2;
    double ppent,rpent,qpent,spent,hpent;
    while (1)
    {
        double delta;
        int loop;
        for (delta=em6,loop=0;loop<1000 && fabs(delta) >= em6;loop++)
        {
            delta=-(rsixn3*(CUBE(diag)-CUBE(diag-n1)-CUBE(diag-n2))-fijkd)
                  /(3.0*rsixn3*(SQUARE(diag)-SQUARE(diag-n1)-SQUARE(diag-n2)));
            diag += delta;
        }
        hpent=diag/n3;
        if (hpent>1)
        {
            fprintf (files.error, "PENTAGON ANOMALY: %f %f %f %f\n", fijkd, n1, n2, n3);
            return false; 
            //exit(1);
        }
        ppent=hpent*(1.0-n1/diag);
        rpent=hpent*(1.0-n2/diag);
        qpent=ppent/(hpent-rpent);
        spent=rpent/(hpent-ppent);
        if (hpent>1.0 || hpent<0.0 || ppent>1.0 || ppent<0.0 || qpent>1.0 || qpent<0.0
            || rpent>1.0 || rpent<0.0 || spent>1.0 || spent<0.0)
        {
            idiag++;
            if (idiag==11)
            {
                fprintf (files.error,"PEN DIAG PROBLEM: %f %f %f %f\n", fijkd, n1, n2, n3);
                return false;
                //exit(1);
            }
            diag=n2+(double)idiag*(n3-n2)/10.0;
        }
        else break;
    }

    if (m2pm3==13)
    {
        double p1=diag/n1;
        double q1=hpent;
        double p2=spent;
        double q2=rpent;
        if (epsi<p2)
            epsi1=epsi*( q1*(2.0*p1-epsi)/p1 + q2*(2.0*p2-epsi)/p2 )/4.0;
        else
        {
            double alpha=1.0+(1.0-epsi)*(hpent-ppent)/ppent;
            epsi1=fijkd-ppent*qpent*(1.0-epsi)*(1.0+alpha+alpha*alpha)/6.0;
        }
    }
    else if (m1pm3==13)
    {
        double p1=diag/n2;
        double q1=hpent;
        double p2=qpent;
        double q2=ppent;
        if (epsi<p2)
            epsi1=epsi*( q1*(2.0*p1-epsi)/p1 + q2*(2.0*p2-epsi)/p2 )/4.0;
        else
        {
            double alpha=1.0+(1.0-epsi)*(hpent-rpent)/rpent;
            epsi1=fijkd-rpent*spent*(1.0-epsi)*(1.0+alpha+alpha*alpha)/6.0;
        }
    }
    else if (m1pm2==13)
    {
        if (epsi>hpent)
            epsi1=fijkd;
        else if (epsi>ppent)
            epsi1=fijkd-CUBE(hpent-epsi)/(6.0*(hpent-ppent)*(hpent-rpent));
        else if (epsi>rpent)
        {
            double alpha=(ppent-epsi)/(hpent-epsi);
            epsi1=fijkd-(hpent-epsi)*(hpent-epsi)*(1.0+alpha+alpha*alpha)/(6.0*(hpent-rpent));
        }
        else
        {
            double alpha=(ppent-epsi)/(hpent-epsi);
            double beta=(rpent-epsi)/(hpent-epsi);
            epsi1=fijkd-CUBE(hpent-epsi)*(1.0-CUBE(alpha)-CUBE(beta))/(6.0*(hpent-ppent)*(hpent-rpent));
        }
    }
    else if (m2pm3==5)
    {
        if (epsi<1.0-spent)
        {
            double alpha=1.0+epsi*(hpent-ppent)/ppent;
            epsi1=ppent*qpent*epsi*(1.0+alpha+alpha*alpha)/6.0;
        }
        else
            epsi1=fijkd-(1.0-epsi)/4.0*(rpent + hpent + (spent+epsi-1.0)*rpent/spent + ppent + epsi*(hpent-ppent));
    }
    else if (m1pm3==5)
    {
        if (epsi<1.0-qpent)
        {
            double alpha=1.0+epsi*(hpent-rpent)/rpent;
            epsi1=rpent*spent*epsi*(1.0+alpha+alpha*alpha)/6.0;
        }
        else
            epsi1=fijkd-(1.0-epsi)/4.0*(ppent + hpent + (qpent+epsi-1.0)*ppent/qpent + rpent + epsi*(hpent-rpent));
    }
    else if (m1pm2==5)
    {
        if (epsi<1.0-hpent)
            epsi1=0.0;
        else if (epsi<1.0-ppent)
            epsi1=CUBE(hpent+epsi-1.0)/(6.0*(hpent-ppent)*(hpent-rpent));
        else if (epsi<1.0-rpent)
        {
            double alpha=(ppent+epsi-1.0)/(hpent+epsi-1.0);
            epsi1=(hpent+epsi-1.0)*(hpent+epsi-1.0)*(1.0+alpha+alpha*alpha)/ (6.0*(hpent-rpent));
        }
        else
        {
            double alpha=(ppent+epsi-1.0)/(hpent+epsi-1.0);
            double beta=(rpent+epsi-1.0)/(hpent+epsi-1.0);
            epsi1=CUBE(hpent+epsi-1.0)*(1.0-CUBE(alpha)-CUBE(beta))/(6.0*(hpent-ppent)*(hpent-rpent));
        }
    }
    return true;
}

bool isHexagon (double &epsi1, double n1, double n2, double n3, double epsi, double fijkd, int m1pm2, int m1pm3, int m2pm3)
{
    //hexagonal section, figures 8,15
    if ((n1+n2<=n3) || 6.0*n1*n2*n3*fijkd < CUBE(n3)-CUBE(n3-n1)-CUBE(n3-n2))
        return false;
    double rsixn3=1.0/(6.0*n1*n2*n3);
    int idiag=0;
    double diag=n3;
    double phex,qhex,rhex,shex,thex,uhex;
    while (1)
    {
        double delta;
        int loop;
        for (delta=em6,loop=0;loop<1000 && fabs(delta)>=em6; loop++)
        {
            delta = -(rsixn3*(CUBE(diag)-CUBE(diag-n1)-CUBE(diag-n2)-CUBE(diag-n3)) -fijkd)
                    /(3.0*rsixn3*(SQUARE(diag) - SQUARE(diag-n1) - SQUARE(diag-n2) - SQUARE(diag-n3)));
            diag += delta;
        }
        phex=(diag-n2)/n3;
        qhex=(diag-n2)/n1;
        rhex=(diag-n3)/n2;
        shex=(diag-n3)/n1;
        thex=(diag-n1)/n2;
        uhex=(diag-n1)/n3;
        if (phex>1.0 || phex <0.0 ||
            qhex>1.0 || qhex <0.0 ||
            rhex>1.0 || rhex <0.0 ||
            shex>1.0 || shex <0.0 ||
            thex>1.0 || thex <0.0 ||
            uhex>1.0 || uhex <0.0 )
        {
            idiag++;
            if (idiag == 11)
            {
                fprintf (files.error, "HEX DIAG PROBLEM: %f %f %f %f\n", fijkd, n1, n2, n3);
                return false;
                //exit(1);
            }
            diag=n3+(double)idiag*(0.866-n3)/10.0;
        }
        else break;
    }

    double phx,qhx,rhx,shx,thx,uhx;
    if (m2pm3==13)
    {
        if (1.0-shex > 1.0-qhex)
        {
            rhx=(1.0-qhex);
            shx=(1.0-thex);
            thx=(1.0-shex);
            uhx=(1.0-uhex);
            phx=(1.0-phex);
            qhx=(1.0-rhex);
        }
        else
        {
            rhx=(1.0-shex);
            shx=(1.0-uhex);
            thx=(1.0-qhex);
            uhx=(1.0-thex);
            phx=(1.0-rhex);
            qhx=(1.0-phex);
        }
    }
    else if (m1pm3==13)
    {
        if (1.0-rhex > 1.0-thex)
        {
            rhx=(1.0-thex);
            shx=(1.0-qhex);
            thx=(1.0-rhex);
            uhx=(1.0-phex);
            phx=(1.0-uhex);
            qhx=(1.0-shex);
        }
        else
        {
            rhx=(1.0-rhex);
            shx=(1.0-phex);
            thx=(1.0-thex);
            uhx=(1.0-qhex);
            phx=(1.0-shex);
            qhx=(1.0-uhex);
        }
    }
    else if (m1pm2==13)
    {
        if (1.0-phex > 1.0-uhex)
        {
            rhx=(1.0-uhex);
            shx=(1.0-shex);
            thx=(1.0-phex);
            uhx=(1.0-rhex);
            phx=(1.0-thex);
            qhx=(1.0-qhex);
        }
        else
        {
            rhx=(1.0-phex);
            shx=(1.0-rhex);
            thx=(1.0-uhex);
            uhx=(1.0-shex);
            phx=(1.0-qhex);
            qhx=(1.0-thex);
        }
    }
    else if (m2pm3==5)
    {
        if (qhex > shex)
        {
            rhx=shex;
            shx=rhex;
            thx=qhex;
            uhx=phex;
            phx=uhex;
            qhx=thex;
        }
        else
        {
            rhx=qhex;
            shx=phex;
            thx=shex;
            uhx=rhex;
            phx=thex;
            qhx=uhex;
        }
    }
    else if (m1pm3==5)
    {
        if (thex > rhex)
        {
            phx=phex;
            qhx=qhex;
            rhx=rhex;
            shx=shex;
            thx=thex;
            uhx=uhex;
        }
        else
        {
            phx=qhex;
            qhx=phex;
            rhx=thex;
            shx=uhex;
            thx=rhex;
            uhx=shex;
        }
    }
    else if (m1pm2==5)
    {
        if (uhex > phex)
        {
            rhx=phex;
            shx=qhex;
            thx=uhex;
            uhx=thex;
            phx=rhex;
            qhx=shex;
        }
        else
        {
            rhx=uhex;
            shx=thex;
            thx=phex;
            uhx=qhex;
            phx=shex;
            qhx=rhex;
        }
    }

    if (m1pm2==13 || m2pm3==13 || m1pm3==13)
    {
        if (epsi < 1.0-thx)
        {
            double alpha=1.0+epsi*(1.0-phx)/(phx*(1.0-rhx));
            epsi1=epsi-(phx*qhx*epsi*(1.0+alpha+alpha*alpha)/6.0);
        }
        else if (epsi<1.0-rhx)
        {
            double p1=uhx/thx*(epsi+thx-1.0);
            double p2=phx+(1.0-thx)*(1.0-phx)/(1.0-rhx);
            double p3=phx+epsi*(1.0-phx)/(1.0-rhx);
            double alpha=p2/phx;
            epsi1=epsi-(phx*qhx*(1.0-thx)*(1.0+alpha+alpha*alpha)/6.0 + (p1+p2+p3)*(thx+epsi-1.0)/4.0);
        }
        else
        {
            double alpha=1.0+(1.0-epsi)*uhx/(thx*(1.0-uhx));
            double vhx=(1.0-uhx)*(1.0-shx)*(1.0-epsi)*(1.0+alpha+alpha*alpha)/6.0;
            epsi1=epsi-((1.0-fijkd)-(1.0-epsi-vhx));
        }
    }
    else if (m1pm2==5 || m2pm3==5 || m1pm3==5)
    {
        if (epsi < 1.0-thx)
        {
            double alpha=1.0+epsi*(1.0-phx)/(phx*(1.0-rhx));
            epsi1=phx*qhx*epsi*(1.0+alpha+alpha*alpha)/6.0;
        }
        else if (epsi<1.0-rhx)
        {
            double p1=uhx/thx*(epsi+thx-1.0);
            double p2=phx+(1.0-thx)*(1.0-phx)/(1.0-rhx);
            double p3=phx+epsi*(1.0-phx)/(1.0-rhx);
            double alpha=p2/phx;
            epsi1=phx*qhx*(1.0-thx)*(1.0+alpha+alpha*alpha)/6.0 + (p1+p2+p3)*(thx+epsi-1.0)/4.0;
        }
        else
        {
            double alpha=1.0+(1.0-epsi)*uhx/(thx*(1.0-uhx));
            double vhx=(1.0-uhx)*(1.0-shx)*(1.0-epsi)*(1.0+alpha+alpha*alpha)/6.0;
            epsi1=(fijkd)-(1.0-epsi-vhx);
        }
    }
    return true;
}

bool isQuadB (double &epsi1, double n1, double n2, double n3, double epsi, double fijkd, int m1pm2, int m1pm3, int m2pm3)
{
    //quadrilateral section B, figure 9

    double diag=0.5*(n1+n2)+fijkd*n3;
    double p4=diag/n3;
    double p1=p4*(1.0-n1/diag);
    double p3=p4*(1.0-n2/diag);
    double p2=p1-(p4-p3);
    if (p1<0 || p1>1 ||
        p2<0 || p2>1 ||
        p3<0 || p3>1 ||
        p4<0 || p4>1)
    {
        fprintf (files.error, "QUAD B PROBLEM: %d %f %f %f %f, %f %f %f %f\n", ncyc, fijkd, n1, n2, n3, p1, p2, p3, p4);
        p1 = MAX(0.0,MIN(1.0, p1));
        p2 = MAX(0.0,MIN(1.0, p2));
        p3 = MAX(0.0,MIN(1.0, p3));
        p4 = MAX(0.0,MIN(1.0, p4));
        //exit (1);
    }

    if (m2pm3==13)
    {
        double p3quad=p3+epsi*(p2-p3);
        double p4quad=p4+epsi*(p1-p4);
        epsi1=epsi/4.0*(p3+p4+p3quad+p4quad);
    }
    else if (m1pm3==13)
    {
        double p1quad=p1+epsi*(p2-p1);
        double p4quad=p4+epsi*(p3-p4);
        epsi1=epsi/4.0*(p1+p4+p1quad+p4quad);
    }
    else if (m1pm2==13)
    {
        if (epsi<p2)
            epsi1=epsi;
        else if (epsi<p3)
            epsi1=epsi-CUBE(epsi-p2)/(6.0*(p1-p2)*(p3-p2)+tiny);
        else if (epsi<p1)
        {
            double alpha=(epsi-p3)/(epsi-p2+tiny);
            epsi1=epsi-SQUARE(epsi-p2)*(1.0+alpha+SQUARE(alpha))/(6.0*(p1-p2)+tiny);
        }
        else if (epsi<p4)
            epsi1=fijkd-CUBE(p4-epsi)/(6.0*(p4-p1)*(p4-p3)+tiny);
        else
            epsi1=fijkd;
    }
    else if (m2pm3==5)
    {
        double p1quad=p1+epsi*(p4-p1);
        double p2quad=p2+epsi*(p3-p2);
        epsi1=epsi/4.0*(p1+p2+p1quad+p2quad);
    }
    else if (m1pm3==5)
    {
        double p2quad=p2+epsi*(p1-p2);
        double p3quad=p3+epsi*(p4-p3);
        epsi1=epsi/4.0*(p2+p3+p2quad+p3quad);
    }
    else if (m1pm2==5)
    {
        if (epsi<1.0-p4)
            epsi1=0.0;
        else if (epsi<1.0-p1)
            epsi1=CUBE(epsi-(1.0-p4))/(6.0*(p4-p3)*(p4-p1));
        else if (epsi<1.0-p3)
        {
            double alpha=(epsi-(1.0-p4))/(epsi-(1.0-p1));
            epsi1=SQUARE(epsi-(1.0-p1))*(1.0+alpha+SQUARE(alpha))/(6.0*(p1-p2));
        }
        else if (epsi<1.0-p2)
            epsi1=fijkd-((1.0-epsi)-CUBE((1.0-p2)-epsi)/(6.0*(p3-p2)*(p1-p2)));
        else
            epsi1=fijkd-(1.0-epsi);
    }

    return true;
}

#ifdef rudman_fine

void normals_fvirt_curvature();
void ytube_under_bc();

void vofdly_f () 
{
	int i,j,k;
	//new compact set of declarations
	double *vnew_f = temp_f[0];
	double *rho_f = temp_f[1];
	double *ftilde_f = temp_f[2];
	double *gradrox_f = temp_f[3];
	double *gradroy_f = temp_f[4];
	double *gradroz_f = temp_f[5]; 
	double *avnx_f = temp_f[6];
	double *avny_f = temp_f[7];
	double *avnz_f = temp_f[8];
	double *u_f = temp_f[3]; 
	double *v_f = temp_f[4]; 
	double *w_f = temp_f[5];
	
	double *mass_adv = temp_f[1]; 
	double *vold_f = temp_f[2];

#ifdef __solid	
	double *psirho_f = temp_f[1];
	double *psiftilde_f = temp_f[2];
	double *psigradrox_f = temp_f[3];
	double *psigradroy_f = temp_f[4];
	double *psigradroz_f = temp_f[5];
	double *psiavnx_f = temp_f[9];
	double *psiavny_f = temp_f[10];
	double *psiavnz_f = temp_f[11];
#endif
	
	//now standard grid arrays
	double *rgux=temp[0], *rguy=temp[1], *rguz=temp[2];
	double *rgvx=temp[3], *rgvy=temp[4], *rgvz=temp[5];
	double *rgwx=temp[6], *rgwy=temp[7], *rgwz=temp[8];
	
	double *rhoU=temp[9];
	double *rhoV=temp[10];
	double *rhoW=temp[11];
	double *vnew_stgx=temp[12]; //control volumes for x,y and z momentum
	double *vnew_stgy=temp[13];
	double *vnew_stgz=temp[14];
	double *util=u;
	double *vtil=v;
	double *wtil=w;
	
	double *fmx = temp[15], *fmy = temp[16], *fmz = temp[17];
	double *rho_stgx=temp[18], *rho_stgy=temp[19], *rho_stgz=temp[20];
#ifdef __solid
	double *psimx = temp[21], *psimy = temp[22], *psimz = temp[23];
#endif

	double *velocity;
	 
	//compact declarations end here
	int looper[6][3]={{3,2,1},{1,2,3},{2,3,1},{1,3,2},{2,1,3},{3,1,2}};

	//ijkfr not used in the fine-f advection
			
	//in the beginning define vnew=vol
	memcpy(vnew_f,vol_f,NX_f*NY_f*NZ_f*sizeof(double));
	
	//calculate volume and density in staggered grid 
	stag_vol();
	stag_den();
	//initialize rhoU rhoV and rhoW
	for(k=1;k<km1;k++)
		for(j=1;j<jm1;j++)
			for(i=1;i<im1;i++) {
				//calculate rhoU rhoV rhoW
				rhoU[IJK]=rho_stgx[IJK]*u[IJK];
				rhoV[IJK]=rho_stgy[IJK]*v[IJK];
				rhoW[IJK]=rho_stgz[IJK]*w[IJK];
			}
	
	//start of the big f-fluxing loop
	int isweep=ncyc%6;
	
	for(int nsubcyc=0; nsubcyc<3; nsubcyc++)
	{
		     //update rho to be used in normals_f()
#ifndef __solid
            for(k=0;k<kmax_f;k++)
                  for(j=0;j<jmax_f;j++)
                       for(i=0;i<imax_f;i++) 
                              rho_f[IJK_f]=rhof1*f_f[IJK_f]+1.0*(1.e0-f_f[IJK_f]);
	    
			normals_f(); //calculates gradrox_f avnx_f etc on the fine grid ... bcf_f and rho_f are pre-requisites
#endif
                              
#ifdef __solid
		if(nsubcyc>0 || (ncyc==1 && nsubcyc==0)) {
			for(k=0;k<kmax_f;k++)
	                  for(j=0;j<jmax_f;j++)
							for(i=0;i<imax_f;i++)  
	                              psirho_f[IJK_f]=rhof0*psi_f[IJK_f]+1.e0*(1.e0-psi_f[IJK_f]); //correct it afterwards

			normalspsi_f(); //psirho_f and bcpsi_f are prerequisites.
			recons_contact_line(); //calculates f_virt and (avnx_f,avny_f,avnz_f)
		}
#endif
#ifdef fine_plt
		if(nsubcyc==0) {
		  if( p_flg == 1) {
			 tecpf_f();
			 if(mpi.MyRank == 0)				
			 {
				printf("Compressing fine grid RBD files...\n");
				char command[50];
				//sprintf(command, "zip -qm -1 F%03d-%04d.gz f%03d-*-%04d.rbd &", mpi.NProc, iplot, mpi.NProc, iplot);
				sprintf(command, "gzip f%03d-*-%04d.rbd &", mpi.NProc, iplot);
				system(command);
			 }
			 p_flg = 0;
		  }
		}
#endif
		//bar();
		//if(mpi.MyRank==0) printf("exiting now after first nsubcyc\n"); 
		//bar();
		//exit(1);
	//rudman definition of velocities
	//for now let the velocities be prescribed
#ifdef pres_v
	
	for(k=0;k<km1_f;k++)
	 for(j=0;j<jm1_f;j++)
	  for(i=0;i<im1_f;i++)
			 { //at boundaries of real domain
				switch(looper[isweep][nsubcyc]) {
				case 1:
					if(j==0 || k==0) continue;
					u_f[IJK_f]=0.5e0;
					break;
				case 2:
					if(i==0 || k==0) continue;
					v_f[IJK_f]=0.e0;
					break;
				case 3:
					if(j==0 || i==0) continue;
					w_f[IJK_f]=1.e0;
					break;
				}
				/*double tx,ty,tz;
				tx = (i+2*mpi.OProc[0]-0.5)*(0.5*delx[1]);
				ty = (j+2*mpi.OProc[1]-0.5)*(0.5*dely[1]);
				tz = (k+2*mpi.OProc[2]-0.5)*(0.5*delz[1]);
				
				u_f[IJK_f] = (tz-t_cent.z*0.5*delz[1]);
				v_f[IJK_f] = 0.0;
				w_f[IJK_f] = -(tx-t_cent.x*0.5*delx[1]);*/
			}
#endif
#ifndef pres_v
	//interpolate from the standard grid velocities... u and un were made equal in newcyc()
	// the interpolation is taken from rudman(1998).. p360 .. resulting velocities are also divergence-free
	for(k=0;k<km1;k++)
		for(j=0;j<jm1;j++)
			for(i=0;i<im1;i++) {
				switch(looper[isweep][nsubcyc]) {
				case 1:
					if(j==0 || k==0) continue;
					u_f[IND_f(2*i,2*j,2*k)]=un[IJK];
					u_f[IND_f(2*i,2*j-1,2*k)]=un[IJK];
					u_f[IND_f(2*i,2*j-1,2*k-1)]=un[IJK];
					u_f[IND_f(2*i,2*j,2*k-1)]=un[IJK];
					
					u_f[IND_f(2*i+1,2*j,2*k)]=0.5e0*(un[IJK]+un[IJK+1]);
					u_f[IND_f(2*i+1,2*j-1,2*k)]=0.5e0*(un[IJK]+un[IJK+1]);
					u_f[IND_f(2*i+1,2*j-1,2*k-1)]=0.5e0*(un[IJK]+un[IJK+1]);
					u_f[IND_f(2*i+1,2*j,2*k-1)]=0.5e0*(un[IJK]+un[IJK+1]);
					break;
				
				case 2:
					//initialize v_f
					if(i==0 || k==0) continue;
					v_f[IND_f(2*i,2*j,2*k)]=vn[IJK];
					v_f[IND_f(2*i-1,2*j,2*k)]=vn[IJK];
					v_f[IND_f(2*i-1,2*j,2*k-1)]=vn[IJK];
					v_f[IND_f(2*i,2*j,2*k-1)]=vn[IJK];
					
					v_f[IND_f(2*i,2*j+1,2*k)]=0.5e0*(vn[IJK]+vn[IJK+imax]);
					v_f[IND_f(2*i-1,2*j+1,2*k)]=0.5e0*(vn[IJK]+vn[IJK+imax]);
					v_f[IND_f(2*i-1,2*j+1,2*k-1)]=0.5e0*(vn[IJK]+vn[IJK+imax]);
					v_f[IND_f(2*i,2*j+1,2*k-1)]=0.5e0*(vn[IJK]+vn[IJK+imax]);
					break;
				
				case 3:
					//initialize w_f
					if(j==0 || i==0) continue;
					w_f[IND_f(2*i,2*j,2*k)]=wn[IJK];
					w_f[IND_f(2*i-1,2*j,2*k)]=wn[IJK];
					w_f[IND_f(2*i-1,2*j-1,2*k)]=wn[IJK];
					w_f[IND_f(2*i,2*j-1,2*k)]=wn[IJK];
					
					w_f[IND_f(2*i,2*j,2*k+1)]=0.5e0*(wn[IJK]+wn[IJK+ijmax]);
					w_f[IND_f(2*i-1,2*j,2*k+1)]=0.5e0*(wn[IJK]+wn[IJK+ijmax]);
					w_f[IND_f(2*i-1,2*j-1,2*k+1)]=0.5e0*(wn[IJK]+wn[IJK+ijmax]);
					w_f[IND_f(2*i,2*j-1,2*k+1)]=0.5e0*(wn[IJK]+wn[IJK+ijmax]);
					break;
				}
			}
#endif

		memcpy(vold_f,vnew_f,NX_f*NY_f*NZ_f*sizeof(double));
		//normalize f wrt to new volumes
		for(k=1;k<km1_f;k++)
			for(j=1;j<jm1_f;j++)
				for(i=1;i<im1_f;i++)
					f_f[IJK_f]=fn_f[IJK_f]*vnew_f[IJK_f];

#ifdef __solid		
#ifndef pres_v
		//modify u_f, v_f etc. enforce rigidity in a narrow band around the fine grid solid interface
		for(i=1;i<=NBODY;i++) Nset_rigid_body_vel(looper[isweep][nsubcyc],i);
#endif
		for(k=1;k<km1_f;k++)
			for(j=1;j<jm1_f;j++)
				for(i=1;i<im1_f;i++)
					psi_f[IJK_f]=psin_f[IJK_f]*vnew_f[IJK_f];
#endif			

		//normalize the momentum fluxes
		for(k=1;k<km1;k++)
			for(j=1;j<jm1;j++)
				for(i=1;i<im1;i++) {
					rhoU[IJK]*=vnew_stgx[IJK];
					rhoV[IJK]*=vnew_stgy[IJK];
					rhoW[IJK]*=vnew_stgz[IJK];
				}
		
		//define vnew
		for(k=1;k<km1_f;k++) 
			for(j=1;j<jm1_f;j++)
				for(i=1;i<im1_f;i++)
				{
					switch(looper[isweep][nsubcyc])
					{
						case 1:
							vnew_f[IJK_f]+=(u_f[IMJK_f]-u_f[IJK_f])*0.25e0*dely[1]*delz[1]*delt;
							break;
						case 2:
							vnew_f[IJK_f]+=(v_f[IJMK_f]-v_f[IJK_f])*0.25e0*delx[1]*delz[1]*delt;
							break;
						case 3:
							vnew_f[IJK_f]+=(w_f[IJKM_f]-w_f[IJK_f])*0.25e0*delx[1]*dely[1]*delt;
							break;
					}
				}
				
		xchg_f<double>(vnew_f);
		
		for(k=1;k<km1_f;k++) //the reconstruction is being performed on fn_f 
			for(j=1;j<jm1_f;j++) //which is available on subdomain ghost cells
				for(i=1;i<im1_f;i++) 
					f_f[IJK_f]/=vnew_f[IJK_f];

#ifdef __solid
		for(k=1;k<km1_f;k++)
			for(j=1;j<jm1_f;j++)
				for(i=1;i<im1_f;i++)
					psi_f[IJK_f]/=vnew_f[IJK_f];
#endif
					
		//now time to send f_f across virtual boundaries
		//xchg_f<double>(f_f); //exchanges information across virtual boundaries//reconstruction hapenning based on fn
		
		//compute vnew for momentum fluxes...
		stag_vol();
		for(k=1;k<km1;k++)
			for(j=1;j<jm1;j++)
				for(i=1;i<im1;i++) {
							  
					rhoU[IJK]/=vnew_stgx[IJK];
					rhoV[IJK]/=vnew_stgy[IJK];
					rhoW[IJK]/=vnew_stgz[IJK];
				}
				
		//initialize mass_adv to zero before the start of the subcyc loop
		memset(mass_adv,0,NX_f*NY_f*NZ_f*sizeof(double));
		memset(flx,0,NX_f*NY_f*NZ_f*sizeof(double));
		
		//start of the fluxing loop
		for(k=0;k<km1_f;k++) 
			for(j=0;j<jm1_f;j++)
				for(i=0;i<im1_f;i++) 
				{	
					int ijkd, ijka;
					int id, jd, kd;
					double xn, yn, zn;
#ifdef __solid
				        double xns, yns, zns;
#endif
					double epsi, epsi1, epsi0; 
					double s_epsi; //sign of epsi
					epsi=epsi1=0.0;
					epsi0=0.0;
					
					switch(looper[isweep][nsubcyc])
					{
						case 1:
							if(j==0 || k==0) continue;
							if(u_f[IJK_f]==0.0) continue;
							if(u_f[IJK_f]>0.0)
							{
								ijkd=IJK_f;
								ijka=IJK_f+1;
								id=i; jd=j; kd=k;
								
								xn=-avnx_f[ijkd]*2.e0*rdx[1];
								yn=-avny_f[ijkd]*2.e0*rdy[1];
								zn=-avnz_f[ijkd]*2.e0*rdz[1];

#ifdef __solid
								xns=-psiavnx_f[ijkd]*2.e0*rdx[1];
								yns=-psiavny_f[ijkd]*2.e0*rdy[1];
								zns=-psiavnz_f[ijkd]*2.e0*rdz[1];
#endif
							}
							else
							{
								ijkd=IJK_f+1;
								ijka=IJK_f;
								id=i+1; jd=j; kd=k;
								
								xn=avnx_f[ijkd]*2.e0*rdx[1];
								yn=-avny_f[ijkd]*2.e0*rdy[1];
								zn=avnz_f[ijkd]*2.e0*rdz[1];
#ifdef __solid
								xns=psiavnx_f[ijkd]*2.e0*rdx[1];
								yns=-psiavny_f[ijkd]*2.e0*rdy[1];
								zns=psiavnz_f[ijkd]*2.e0*rdz[1];
#endif
							}
							epsi=fabs(u_f[IJK_f])*0.25e0*dely[1]*delz[1]*delt/vold_f[ijkd];
							s_epsi=SIGN(u_f[IJK_f]);
							break;
							
						case 2:
							if(i==0 || k==0) continue;
							if(v_f[IJK_f] == 0.0) continue;
							if(v_f[IJK_f] > 0.0)
							{
								ijkd=IJK_f;
								ijka=IJK_f+imax_f;
								id=i; jd=j; kd=k;
								
								xn=-avny_f[ijkd]*2.e0*rdy[1];
								yn=avnx_f[ijkd]*2.e0*rdx[1];
								zn=-avnz_f[ijkd]*2.e0*rdz[1];
#ifdef __solid
							        xns=-psiavny_f[ijkd]*2.e0*rdy[1];
								yns=psiavnx_f[ijkd]*2.e0*rdx[1];
								zns=-psiavnz_f[ijkd]*2.e0*rdz[1];
#endif
							}
							else
							{
								ijkd=IJK_f+imax_f;
								ijka=IJK_f;
								id=i; jd=j+1; kd=k;
								
								xn=avny_f[ijkd]*2.e0*rdy[1];
								yn=-avnx_f[ijkd]*2.e0*rdx[1];
								zn=-avnz_f[ijkd]*2.e0*rdz[1];
#ifdef __solid
								xns=psiavny_f[ijkd]*2.e0*rdy[1];
								yns=-psiavnx_f[ijkd]*2.e0*rdx[1];
								zns=-psiavnz_f[ijkd]*2.e0*rdz[1];								
#endif
							}
							epsi=fabs(v_f[IJK_f])*0.25e0*delx[1]*delz[1]*delt/vold_f[ijkd];
							s_epsi=SIGN(v_f[IJK_f]);
							break;
							
						case 3:
							if(i==0 || j==0) continue;
							if(w_f[IJK_f]==0.0) continue;
							if(w_f[IJK_f]>0.0)
							{
								ijkd=IJK_f;
								ijka=IJK_f+ijmax_f;
								id=i; jd=j; kd=k;
								
								xn=-avnz_f[ijkd]*2.e0*rdz[1];
								yn=-avny_f[ijkd]*2.e0*rdy[1];
								zn=avnx_f[ijkd]*2.e0*rdx[1];								
#ifdef __solid
								xns=-psiavnz_f[ijkd]*2.e0*rdz[1];
								yns=-psiavny_f[ijkd]*2.e0*rdy[1];
								zns=psiavnx_f[ijkd]*2.e0*rdx[1];
#endif
							}
							else
							{
								ijkd=IJK_f+ijmax_f;
								ijka=IJK_f;
								id=i; jd=j; kd=k+1;
								
								xn=avnz_f[ijkd]*2.e0*rdz[1];
								yn=-avny_f[ijkd]*2.e0*rdy[1];
								zn=-avnx_f[ijkd]*2.e0*rdx[1];
								
#ifdef __solid
								xns=psiavnz_f[ijkd]*2.e0*rdz[1];
								yns=-psiavny_f[ijkd]*2.e0*rdy[1];
								zns=-psiavnx_f[ijkd]*2.e0*rdx[1];
#endif
							}
							epsi=fabs(w_f[IJK_f])*0.25e0*delx[1]*dely[1]*delt/vold_f[ijkd];
							s_epsi=SIGN(w_f[IJK_f]);
							break;
					}//switch

					//only liquid
					if(fn_f[ijkd] > em61)
					{	
						f_f[ijkd]-=epsi*vold_f[ijkd]/vnew_f[ijkd];
						f_f[ijka]+=epsi*vold_f[ijkd]/vnew_f[ijka];
						mass_adv[IJK_f]=rhof1*s_epsi*epsi*vold_f[ijkd];
						
						flx[IJK_f] = s_epsi * epsi * vold_f[ijkd];
						continue;
					}
					
#ifndef __solid
				         if(fn_f[ijkd] < em6) 
					 {
						mass_adv[IJK_f]=rhof2*s_epsi*epsi*vold_f[ijkd];
						
						flx[IJK_f] = 0.0; 
						//if(ijka == IND_f(32,179,108) && mpi.MyRank==4 && ncyc==9 && nsubcyc==2) printf("2:I=%e II=%e\n",0,s_epsi); 
						continue;
					 }
					  
					  epsi1=recons_2P(xn,yn,zn,fn_f[ijkd],epsi,ijkd,ijka);
					  
					  f_f[ijkd]-=epsi1*vold_f[ijkd]/vnew_f[ijkd];
					  f_f[ijka]+=epsi1*vold_f[ijkd]/vnew_f[ijka];
					  mass_adv[IJK_f]=rhof1*epsi1*s_epsi*vold_f[ijkd]+rhof2*(epsi-epsi1)*s_epsi*vold_f[ijkd];
					  
					  flx[IJK_f] = epsi1 * s_epsi * vold_f[ijkd];
					  
					  continue;
#endif

#ifdef __solid

					//only gas
					if( psin_f[ijkd]+fn_f[ijkd] <em6) 
					{
						mass_adv[IJK_f]=rhof2*s_epsi*epsi*vold_f[ijkd];
						continue;
					}
					
					//only solid
					if( psin_f[ijkd]>em61) 
					{
						psi_f[ijkd]-=epsi*vold_f[ijkd]/vnew_f[ijkd];
						psi_f[ijka]+=epsi*vold_f[ijkd]/vnew_f[ijka];
						mass_adv[IJK_f]=rhof0*s_epsi*epsi*vold_f[ijkd];
						continue;
					}
					
					//two-phase: solid-liquid
					if( fn_f[ijkd] + psin_f[ijkd] > em61 && fn_f[ijkd] >= em6 && psin_f[ijkd] >= em6)
					{
						epsi1=recons_2P(xns,yns,zns,psin_f[ijkd],epsi,ijkd,ijka);
						
						psi_f[ijkd]-=epsi1*vold_f[ijkd]/vnew_f[ijkd];
						psi_f[ijka]+=epsi1*vold_f[ijkd]/vnew_f[ijka];
						
						f_f[ijkd]-=(epsi-epsi1)*vold_f[ijkd]/vnew_f[ijkd];
						f_f[ijka]+=(epsi-epsi1)*vold_f[ijkd]/vnew_f[ijka];
						
						mass_adv[IJK_f]=rhof0*epsi1*s_epsi*vold_f[ijkd]+rhof1*(epsi-epsi1)*s_epsi*vold_f[ijkd];
						continue;
					}
					//solid-gas
					if( fn_f[ijkd] < em6 && psin_f[ijkd] >= em6 && psin_f[ijkd] <= em61) 
					{
						epsi1=recons_2P(xns,yns,zns,psin_f[ijkd],epsi,ijkd,ijka);
						psi_f[ijkd]-=epsi1*vold_f[ijkd]/vnew_f[ijkd];
						psi_f[ijka]+=epsi1*vold_f[ijkd]/vnew_f[ijka];
						mass_adv[IJK_f]=rhof0*epsi1*s_epsi*vold_f[ijkd]+rhof2*(epsi-epsi1)*s_epsi*vold_f[ijkd];
						continue;
						
					}
					//liquid-gas
					if( psin_f[ijkd] < em6 && fn_f[ijkd] >= em6 && fn_f[ijkd] <= em61)
					{	
						epsi1=recons_2P(xn,yn,zn,fn_f[ijkd],epsi,ijkd,ijka);
						f_f[ijkd]-=epsi1*vold_f[ijkd]/vnew_f[ijkd];
						f_f[ijka]+=epsi1*vold_f[ijkd]/vnew_f[ijka];
						
						mass_adv[IJK_f]=rhof1*epsi1*s_epsi*vold_f[ijkd]+rhof2*(epsi-epsi1)*s_epsi*vold_f[ijkd];
						
						flx[IJK_f] = s_epsi * epsi1 * vold_f[ijkd];
						continue;
					}
					
					//liquid-gas-solid
					if(psin_f[ijkd] >= em6 && fn_f[ijkd] >= em6 && fn_f[ijkd] + psin_f[ijkd] <= em61)
					{	
						st_point nor,cent,nor1,cent1,nor2,cent2,vec_a;
						st_polyhedron liq_poly, cube_poly, epsi_poly;
						st_polyhedron *tmp_poly;
						double l_vol;
						//the reconstruction is performed always on the right face of donor cell
						//only normals are flipped accordingly to make the scheme coherent
						nor.x = 1.0; nor.y = 0.0; nor.z = 0.0;
						
						cent.x = 1.0 - epsi;  //point is in unit coordinate system
						cent.y = 0.5;
						cent.z = 0.5;
						
						//construct the epsi_poly
						const_sim_polyhedron(&cube_poly);
						const_com_polyhedron(&cube_poly,&epsi_poly,&cent,&nor,1);
						
						//nor1, cent1 are orientation and location of solid plane
						//nor2, cent2 are orientation and location of f-plane
						
						nor1.x = -xns; nor1.y = -yns; nor1.z = -zns;
						make_unity(&nor1);
						area_2(psin_f[ijkd],id,jd,kd,ijkd,&nor1,&cent1,&vec_a); //cent1 -- output
						
						nor2.x = -xn; nor2.y = -yn; nor2.z = -zn;
						make_unity(&nor2);
						area_2(fvirt_f[ijkd],id,jd,kd,ijkd,&nor2,&cent2,&vec_a); //fvirt_f is used to locate the liquid plane
						//cent2 -- output
						
						//alternate method
						st_point inor; st_polyhedron isol_poly; double ivol;
						inor.x = -nor1.x, inor.y = -nor1.y, inor.z = -nor1.z;
						const_com_polyhedron(&epsi_poly,&isol_poly,&cent1,&inor,1);
						
						if(isol_poly.n < 4) ivol = 0.0;
						else ivol = calc_poly_vol(&isol_poly);
						
						epsi0 = epsi - ivol; //advected solid volume
						
						if(equal(epsi,ivol,TOL)) tmp_poly = &epsi_poly;
						else tmp_poly = &isol_poly;
						
						if(ivol == 0.0) l_vol = 0.0;
						else {
						      const_com_polyhedron(tmp_poly, &liq_poly, &cent2, &nor2, 0);
						      if(liq_poly.n < 4) l_vol = 0.0;
						      else l_vol = calc_poly_vol(&liq_poly);
						}
						epsi1 = l_vol;
						
						psi_f[ijkd] -= epsi0 * vold_f[ijkd] / vnew_f[ijkd];
						psi_f[ijka] += epsi0 * vold_f[ijkd] / vnew_f[ijka];
						
						f_f[ijkd] -= epsi1*vold_f[ijkd] / vnew_f[ijkd];
						f_f[ijka] += epsi1*vold_f[ijkd] / vnew_f[ijka];
												
						mass_adv[IJK_f] = rhof0*epsi0*s_epsi*vold_f[ijkd]
								+ rhof1*epsi1*s_epsi*vold_f[ijkd]
								+ rhof2*(epsi - epsi1 - epsi0)*s_epsi*vold_f[ijkd];
						continue;
					}
#endif
				} //for loop
				
				//calculate the volume fractions in momentum control volumes
				//has to be fn_f and psin_f to be consistent with volume fraction 
				//advection
				set_mom_vof();

#ifdef passive_scalar				
				// passive scalar transport
				switch (looper[isweep][nsubcyc]) {
						case 1:
							velocity = u_f;
							break;
						case 2:
							velocity = v_f;
							break;
						case 3:	
							velocity = w_f;
							break;
				}
				
				advect_scalar(looper[isweep][nsubcyc],scal,crse_scal,scal_c,fn_f,vold_f,vnew_f,velocity,flx);

				//ToDo
				// make crse_scal, scal, scala_c and flx, global variables and allocate memory
				// to them. Then export crse_scal to tecplot
#endif
				    
#ifdef __solid		
				bcpsi_f();
				memcpy(psin_f,psi_f,NX_f*NY_f*NZ_f*sizeof(double));
#endif
	
				bcf_f(); //f in ghost cells at virtual boundaries are copied here... normals_f() needs updated f in ghost cells at virtual boundaries
				memcpy(fn_f,f_f,NX_f*NY_f*NZ_f*sizeof(double));

#ifndef pres_v
				//exchange mass_adv at the virtual boundaries
				xchg_f<double>(mass_adv);
				velgrad_new(); //calculate derivatives to be used in calculation of Uadvd, Vadvd & Wadvd.
				
				//put mass_adv in perspective
				for(k=1;k<=km1;k++)
					for(j=1;j<=jm1;j++)
						for(i=1;i<=im1;i++) {
							
							double vel_avg, Uadvd, Vadvd, Wadvd, mass_flux;
							double tf1, tf2, tf3;
#ifdef __solid
						      double tp1, tp2, tp3;
#endif
							switch(looper[isweep][nsubcyc]) {
								case 1:
									if(j==jm1 || k==km1) continue; //last index cross to advection direction is redundant (j,k are cross to x-direction advection)
									mass_flux=(mass_adv[IND_f(2*i-1,2*j,2*k)]+mass_adv[IND_f(2*i-1,2*j-1,2*k)]+mass_adv[IND_f(2*i-1,2*j-1,2*k-1)]+mass_adv[IND_f(2*i-1,2*j,2*k-1)]);
									vel_avg=SIGN(mass_flux);
									//vel_avg=0.5e0*(un[IJK]+un[IJK-1]); //left face of C.V. for x-momentum
									if(vel_avg>0.e0) {
#ifndef __solid
										//following line acknowleges the 2nd layer of ghost cells
										fetch_mom<double>(i,j,k,tf1,fmx,f2mx); fetch_mom<double>(i-1,j,k,tf2,fmx,f2mx); fetch_mom<double>(i-2,j,k,tf3,fmx,f2mx);										
										if((tf1<em6 && tf2<em6 && tf3<em6) || (tf1>em61 && tf2>em61 && tf3>em61))
											Uadvd = util[IJK-1]+0.5e0*delx[1]*rgux[IJK-1];
										else
											Uadvd=util[IJK-1];
#endif

#ifdef __solid
										fetch_mom<double>(i,j,k,tf1,fmx,f2mx); fetch_mom<double>(i-1,j,k,tf2,fmx,f2mx); fetch_mom<double>(i-2,j,k,tf3,fmx,f2mx);
										fetch_mom<double>(i,j,k,tp1,psimx,psi2mx); fetch_mom<double>(i-1,j,k,tp2,psimx,psi2mx); fetch_mom<double>(i-2,j,k,tp3,psimx,psi2mx);
										//if( only liquid || only solid || only gas)
										if((tf1>em61 && tf2>em61 && tf3>em61)||(tp1>em61 && tp2>em61 && tp3>em61)||(tf1+tp1<em6 && tf2+tp2<em6 && tf3+tp3<em6))
										        Uadvd = util[IJK-1]+0.5e0*delx[1]*rgux[IJK-1];
									        else
										        Uadvd=util[IJK-1];
#endif
									}
									else  {
									      
#ifndef __solid
									      fetch_mom<double>(i,j,k,tf1,fmx,f2mx); fetch_mom<double>(i-1,j,k,tf2,fmx,f2mx); fetch_mom<double>(i+1,j,k,tf3,fmx,f2mx);
									      if((tf1<em6 && tf2<em6 && tf3<em6) || (tf1>em61 && tf2>em61 && tf3>em61))
											Uadvd = util[IJK]-0.5e0*delx[1]*rgux[IJK];
										else 
											Uadvd=util[IJK];
#endif

#ifdef __solid
									      fetch_mom<double>(i,j,k,tf1,fmx,f2mx); fetch_mom<double>(i-1,j,k,tf2,fmx,f2mx); fetch_mom<double>(i+1,j,k,tf3,fmx,f2mx);
										fetch_mom<double>(i,j,k,tp1,psimx,psi2mx); fetch_mom<double>(i-1,j,k,tp2,psimx,psi2mx); fetch_mom<double>(i+1,j,k,tp3,psimx,psi2mx);
									      if((tf1>em61 && tf2>em61 && tf3>em61)||(tp1>em61 && tp2>em61 && tp3>em61)||(tf1+tp1<em6 && tf2+tp2<em6 && tf3+tp3<em6))
										        Uadvd = util[IJK]-0.5e0*delx[1]*rgux[IJK];
										else 
											  Uadvd=util[IJK];
#endif
									}
									
									rhoU[IJK-1]-=(mass_flux)*Uadvd/vnew_stgx[IJK-1];
									rhoU[IJK]+=(mass_flux)*Uadvd/vnew_stgx[IJK];
									
									mass_flux=(mass_adv[IND_f(2*i-2,2*j,2*k)]+mass_adv[IND_f(2*i-2,2*j+1,2*k)]+mass_adv[IND_f(2*i-2,2*j+1,2*k-1)]+mass_adv[IND_f(2*i-2,2*j,2*k-1)]);
									vel_avg=SIGN(mass_flux);
									//vel_avg=0.5e0*(un[IJK-1]+un[IJK-1+imax]);
									if(vel_avg>0.e0) {
#ifndef __solid
										fetch_mom<double>(i,j,k,tf1,fmy,f2my); fetch_mom<double>(i-1,j,k,tf2,fmy,f2my); fetch_mom<double>(i-2,j,k,tf3,fmy,f2my);
										if((tf1<em6 && tf2<em6 && tf3<em6) || (tf1>em61 && tf2>em61 && tf3>em61))
											Vadvd = vtil[IJK-1]+0.5e0*delx[1]*rgvx[IJK-1];
										else
											Vadvd=vtil[IJK-1];
#endif

#ifdef __solid
										fetch_mom<double>(i,j,k,tf1,fmy,f2my); fetch_mom<double>(i-1,j,k,tf2,fmy,f2my); fetch_mom<double>(i-2,j,k,tf3,fmy,f2my);
										fetch_mom<double>(i,j,k,tp1,psimy,psi2my); fetch_mom<double>(i-1,j,k,tp2,psimy,psi2my); fetch_mom<double>(i-2,j,k,tp3,psimy,psi2my);
										if((tf1>em61 && tf2>em61 && tf3>em61)||(tp1>em61 && tp2>em61 && tp3>em61)||(tf1+tp1<em6 && tf2+tp2<em6 && tf3+tp3<em6))
										        Vadvd = vtil[IJK-1]+0.5e0*delx[1]*rgvx[IJK-1];
										else
											Vadvd=vtil[IJK-1];
#endif
									}
									else {
#ifndef __solid
										fetch_mom<double>(i,j,k,tf1,fmy,f2my); fetch_mom<double>(i-1,j,k,tf2,fmy,f2my); fetch_mom<double>(i+1,j,k,tf3,fmy,f2my);
										if((tf1<em6 && tf2<em6 && tf3<em6) || (tf1>em61 && tf2>em61 && tf3>em61))
											Vadvd=vtil[IJK]-0.5e0*delx[1]*rgvx[IJK];
										else
											Vadvd=vtil[IJK];
#endif

#ifdef __solid
										fetch_mom<double>(i,j,k,tf1,fmy,f2my); fetch_mom<double>(i-1,j,k,tf2,fmy,f2my); fetch_mom<double>(i+1,j,k,tf3,fmy,f2my);
										fetch_mom<double>(i,j,k,tp1,psimy,psi2my); fetch_mom<double>(i-1,j,k,tp2,psimy,psi2my); fetch_mom<double>(i+1,j,k,tp3,psimy,psi2my);
										if((tf1>em61 && tf2>em61 && tf3>em61)||(tp1>em61 && tp2>em61 && tp3>em61)||(tf1+tp1<em6 && tf2+tp2<em6 && tf3+tp3<em6))
										        Vadvd=vtil[IJK]-0.5e0*delx[1]*rgvx[IJK];
										else
											Vadvd=vtil[IJK];
#endif
									}
									
									
									rhoV[IJK-1]-=(mass_flux)*Vadvd/vnew_stgy[IJK-1];
									rhoV[IJK]+=(mass_flux)*Vadvd/vnew_stgy[IJK];
									
									mass_flux=(mass_adv[IND_f(2*i-2,2*j,2*k)]+mass_adv[IND_f(2*i-2,2*j-1,2*k)]+mass_adv[IND_f(2*i-2,2*j-1,2*k+1)]+mass_adv[IND_f(2*i-2,2*j,2*k+1)]);
									vel_avg=SIGN(mass_flux);	
									//vel_avg=0.5e0*(un[IJK-1]+un[IJK-1+ijmax]);
									if(vel_avg>0.e0) {
#ifndef __solid
										fetch_mom<double>(i,j,k,tf1,fmz,f2mz); fetch_mom<double>(i-1,j,k,tf2,fmz,f2mz); fetch_mom<double>(i-2,j,k,tf3,fmz,f2mz);
										if((tf1<em6 && tf2<em6 && tf3<em6) || (tf1>em61 && tf2>em61 && tf3>em61))
											Wadvd=wtil[IJK-1]+0.5e0*delx[1]*rgwx[IJK-1];
										else
											Wadvd=wtil[IJK-1];
#endif

#ifdef __solid									   
										fetch_mom<double>(i,j,k,tf1,fmz,f2mz); fetch_mom<double>(i-1,j,k,tf2,fmz,f2mz); fetch_mom<double>(i-2,j,k,tf3,fmz,f2mz);
										fetch_mom<double>(i,j,k,tp1,psimz,psi2mz); fetch_mom<double>(i-1,j,k,tp2,psimz,psi2mz); fetch_mom<double>(i-2,j,k,tp3,psimz,psi2mz);
										if((tf1>em61 && tf2>em61 && tf3>em61)||(tp1>em61 && tp2>em61 && tp3>em61)||(tf1+tp1<em6 && tf2+tp2<em6 && tf3+tp3<em6))
										        Wadvd=wtil[IJK-1]+0.5e0*delx[1]*rgwx[IJK-1];
										else
											Wadvd=wtil[IJK-1];
#endif
									}
									else {
#ifndef __solid										
										fetch_mom<double>(i,j,k,tf1,fmz,f2mz); fetch_mom<double>(i-1,j,k,tf2,fmz,f2mz); fetch_mom<double>(i+1,j,k,tf3,fmz,f2mz);
										if((tf1<em6 && tf2<em6 && tf3<em6) || (tf1>em61 && tf2>em61 && tf3>em61))
											Wadvd=wtil[IJK]-0.5e0*delx[1]*rgwx[IJK];
										else
											Wadvd=wtil[IJK];
#endif

#ifdef __solid									      
										fetch_mom<double>(i,j,k,tf1,fmz,f2mz); fetch_mom<double>(i-1,j,k,tf2,fmz,f2mz); fetch_mom<double>(i+1,j,k,tf3,fmz,f2mz);
										fetch_mom<double>(i,j,k,tp1,psimz,psi2mz); fetch_mom<double>(i-1,j,k,tp2,psimz,psi2mz); fetch_mom<double>(i+1,j,k,tp3,psimz,psi2mz);
										if((tf1>em61 && tf2>em61 && tf3>em61)||(tp1>em61 && tp2>em61 && tp3>em61)||(tf1+tp1<em6 && tf2+tp2<em6 && tf3+tp3<em6))
										        Wadvd=wtil[IJK]-0.5e0*delx[1]*rgwx[IJK];
										else
											Wadvd=wtil[IJK];
#endif
									}
										
									rhoW[IJK-1]-=(mass_flux)*Wadvd/vnew_stgz[IJK-1];
									rhoW[IJK]+=(mass_flux)*Wadvd/vnew_stgz[IJK];
									break;
								
								case 2:
									if(i==im1 || k==km1) continue;
									mass_flux=(mass_adv[IND_f(2*i,2*j-2,2*k)]+mass_adv[IND_f(2*i+1,2*j-2,2*k)]+mass_adv[IND_f(2*i+1,2*j-2,2*k-1)]+mass_adv[IND_f(2*i,2*j-2,2*k-1)]);
									vel_avg=SIGN(mass_flux);
									//vel_avg=0.5e0*(vn[IJK-imax]+vn[IJK-imax+1]);
									if(vel_avg>0.e0) {
#ifndef __solid										
										fetch_mom<double>(i,j,k,tf1,fmx,f2mx); fetch_mom<double>(i,j-1,k,tf2,fmx,f2mx); fetch_mom<double>(i,j-2,k,tf3,fmx,f2mx);
										if((tf1<em6 && tf2<em6 && tf3<em6) || (tf1>em61 && tf2>em61 && tf3>em61))
										    Uadvd=util[IJK-imax]+0.5e0*dely[1]*rguy[IJK-imax];
										else
										    Uadvd=util[IJK-imax];
#endif

#ifdef __solid									       
										 fetch_mom<double>(i,j,k,tf1,fmx,f2mx); fetch_mom<double>(i,j-1,k,tf2,fmx,f2mx); fetch_mom<double>(i,j-2,k,tf3,fmx,f2mx);
										 fetch_mom<double>(i,j,k,tp1,psimx,psi2mx); fetch_mom<double>(i,j-1,k,tp2,psimx,psi2mx); fetch_mom<double>(i,j-2,k,tp3,psimx,psi2mx);
										 if((tf1>em61 && tf2>em61 && tf3>em61)||(tp1>em61 && tp2>em61 && tp3>em61)||(tf1+tp1<em6 && tf2+tp2<em6 && tf3+tp3<em6))
										    Uadvd=util[IJK-imax]+0.5e0*dely[1]*rguy[IJK-imax];
										 else
										    Uadvd=util[IJK-imax];
#endif
									}
									else {
#ifndef __solid										
										fetch_mom<double>(i,j,k,tf1,fmx,f2mx); fetch_mom<double>(i,j-1,k,tf2,fmx,f2mx); fetch_mom<double>(i,j+1,k,tf3,fmx,f2mx);
										if((tf1<em6 && tf2<em6 && tf3<em6) || (tf1>em61 && tf2>em61 && tf3>em61))
										    Uadvd=util[IJK]-0.5e0*dely[1]*rguy[IJK];
										else
										    Uadvd=util[IJK];
#endif

#ifdef __solid									        
									       fetch_mom<double>(i,j,k,tf1,fmx,f2mx); fetch_mom<double>(i,j-1,k,tf2,fmx,f2mx); fetch_mom<double>(i,j+1,k,tf3,fmx,f2mx);
										 fetch_mom<double>(i,j,k,tp1,psimx,psi2mx); fetch_mom<double>(i,j-1,k,tp2,psimx,psi2mx); fetch_mom<double>(i,j+1,k,tp3,psimx,psi2mx);
									        if((tf1>em61 && tf2>em61 && tf3>em61)||(tp1>em61 && tp2>em61 && tp3>em61)||(tf1+tp1<em6 && tf2+tp2<em6 && tf3+tp3<em6))
										    Uadvd=util[IJK]-0.5e0*dely[1]*rguy[IJK];
										else
										    Uadvd=util[IJK];
#endif									
									}
										
									rhoU[IJK-imax]-=(mass_flux)*Uadvd/vnew_stgx[IJK-imax];
									rhoU[IJK]+=(mass_flux)*Uadvd/vnew_stgx[IJK];
									
									mass_flux=(mass_adv[IND_f(2*i,2*j-1,2*k)]+mass_adv[IND_f(2*i-1,2*j-1,2*k)]+mass_adv[IND_f(2*i-1,2*j-1,2*k-1)]+mass_adv[IND_f(2*i,2*j-1,2*k-1)]);
									vel_avg=SIGN(mass_flux);
									//vel_avg=0.5e0*(vn[IJK]+vn[IJK-imax]);
									if(vel_avg>0.e0) {
#ifndef __solid
										fetch_mom<double>(i,j,k,tf1,fmy,f2my); fetch_mom<double>(i,j-1,k,tf2,fmy,f2my); fetch_mom<double>(i,j-2,k,tf3,fmy,f2my);
										if((tf1<em6 && tf2<em6 && tf3<em6) || (tf1>em61 && tf2>em61 && tf3>em61))
										    Vadvd = vtil[IJK-imax]+0.5e0*dely[1]*rgvy[IJK-imax];
										else 
										    Vadvd=vtil[IJK-imax];
#endif

#ifdef __solid
										fetch_mom<double>(i,j,k,tf1,fmy,f2my); fetch_mom<double>(i,j-1,k,tf2,fmy,f2my); fetch_mom<double>(i,j-2,k,tf3,fmy,f2my);
										fetch_mom<double>(i,j,k,tp1,psimy,psi2my); fetch_mom<double>(i,j-1,k,tp2,psimy,psi2my); fetch_mom<double>(i,j-2,k,tp3,psimy,psi2my);
										if((tf1>em61 && tf2>em61 && tf3>em61)||(tp1>em61 && tp2>em61 && tp3>em61)||(tf1+tp1<em6 && tf2+tp2<em6 && tf3+tp3<em6))
										    Vadvd = vtil[IJK-imax]+0.5e0*dely[1]*rgvy[IJK-imax];
										else 
										    Vadvd=vtil[IJK-imax];
#endif
									}
									else {
#ifndef __solid
										fetch_mom<double>(i,j,k,tf1,fmy,f2my); fetch_mom<double>(i,j-1,k,tf2,fmy,f2my); fetch_mom<double>(i,j+1,k,tf3,fmy,f2my);
										if((tf1<em6 && tf2<em6 && tf3<em6) || (tf1>em61 && tf2>em61 && tf3>em61))
										    Vadvd=vtil[IJK]-0.5e0*dely[1]*rgvy[IJK];
										else
										    Vadvd=vtil[IJK];
#endif

#ifdef __solid
										fetch_mom<double>(i,j,k,tf1,fmy,f2my); fetch_mom<double>(i,j-1,k,tf2,fmy,f2my); fetch_mom<double>(i,j+1,k,tf3,fmy,f2my);
										fetch_mom<double>(i,j,k,tp1,psimy,psi2my); fetch_mom<double>(i,j-1,k,tp2,psimy,psi2my); fetch_mom<double>(i,j+1,k,tp3,psimy,psi2my);
										if((tf1>em61 && tf2>em61 && tf3>em61)||(tp1>em61 && tp2>em61 && tp3>em61)||(tf1+tp1<em6 && tf2+tp2<em6 && tf3+tp3<em6))
										    Vadvd=vtil[IJK]-0.5e0*dely[1]*rgvy[IJK];
										else
										    Vadvd=vtil[IJK];
#endif
									}
										
									rhoV[IJK-imax]-=(mass_flux)*Vadvd/vnew_stgy[IJK-imax];
									rhoV[IJK]+=(mass_flux)*Vadvd/vnew_stgy[IJK];
									
									mass_flux=(mass_adv[IND_f(2*i,2*j-2,2*k)]+mass_adv[IND_f(2*i-1,2*j-2,2*k)]+mass_adv[IND_f(2*i-1,2*j-2,2*k+1)]+mass_adv[IND_f(2*i,2*j-2,2*k+1)]);
									vel_avg=SIGN(mass_flux);
									//vel_avg=0.5e0*(vn[IJK-imax]+vn[IJK-imax+ijmax]);
									if(vel_avg>0.e0) {
#ifndef __solid
										fetch_mom<double>(i,j,k,tf1,fmz,f2mz); fetch_mom<double>(i,j-1,k,tf2,fmz,f2mz); fetch_mom<double>(i,j-2,k,tf3,fmz,f2mz);
										if((tf1<em6 && tf2<em6 && tf3<em6) || (tf1>em61 && tf2>em61 && tf3>em61))
										    Wadvd=wtil[IJK-imax]+0.5e0*dely[1]*rgwy[IJK-imax];
										else 
										    Wadvd=wtil[IJK-imax];
#endif

#ifdef __solid
										fetch_mom<double>(i,j,k,tf1,fmz,f2mz); fetch_mom<double>(i,j-1,k,tf2,fmz,f2mz); fetch_mom<double>(i,j-2,k,tf3,fmz,f2mz);
										fetch_mom<double>(i,j,k,tp1,psimz,psi2mz); fetch_mom<double>(i,j-1,k,tp2,psimz,psi2mz); fetch_mom<double>(i,j-2,k,tp3,psimz,psi2mz);
										if((tf1>em61 && tf2>em61 && tf3>em61)||(tp1>em61 && tp2>em61 && tp3>em61)||(tf1+tp1<em6 && tf2+tp2<em6 && tf3+tp3<em6))
										    Wadvd=wtil[IJK-imax]+0.5e0*dely[1]*rgwy[IJK-imax];
										else 
										    Wadvd=wtil[IJK-imax];
#endif
									}
									else {
#ifndef __solid
										fetch_mom<double>(i,j,k,tf1,fmz,f2mz); fetch_mom<double>(i,j-1,k,tf2,fmz,f2mz); fetch_mom<double>(i,j+1,k,tf3,fmz,f2mz);
										if((tf1<em6 && tf2<em6 && tf3<em6) || (tf1>em61 && tf2>em61 && tf3>em61))
										    Wadvd=wtil[IJK]-0.5e0*dely[1]*rgwy[IJK];
										else
										    Wadvd=wtil[IJK];
#endif

#ifdef __solid
										fetch_mom<double>(i,j,k,tf1,fmz,f2mz); fetch_mom<double>(i,j-1,k,tf2,fmz,f2mz); fetch_mom<double>(i,j+1,k,tf3,fmz,f2mz);
										fetch_mom<double>(i,j,k,tp1,psimz,psi2mz); fetch_mom<double>(i,j-1,k,tp2,psimz,psi2mz); fetch_mom<double>(i,j+1,k,tp3,psimz,psi2mz);
										if((tf1>em61 && tf2>em61 && tf3>em61)||(tp1>em61 && tp2>em61 && tp3>em61)||(tf1+tp1<em6 && tf2+tp2<em6 && tf3+tp3<em6))
										    Wadvd=wtil[IJK]-0.5e0*dely[1]*rgwy[IJK];
										else
										    Wadvd=wtil[IJK];
#endif
									}
										
									rhoW[IJK-imax]-=(mass_flux)*Wadvd/vnew_stgz[IJK-imax];
									rhoW[IJK]+=(mass_flux)*Wadvd/vnew_stgz[IJK];
									
									break;
								case 3:
									if(i==im1 || j==jm1) continue;
									mass_flux=(mass_adv[IND_f(2*i,2*j,2*k-2)]+mass_adv[IND_f(2*i+1,2*j,2*k-2)]+mass_adv[IND_f(2*i+1,2*j-1,2*k-2)]+mass_adv[IND_f(2*i,2*j-1,2*k-2)]);
									vel_avg=SIGN(mass_flux);
									//vel_avg=0.5e0*(wn[IJK-ijmax]+wn[IJK-ijmax+1]);
									if(vel_avg>0.e0) {
#ifndef __solid
										fetch_mom<double>(i,j,k,tf1,fmx,f2mx); fetch_mom<double>(i,j,k-1,tf2,fmx,f2mx); fetch_mom<double>(i,j,k-2,tf3,fmx,f2mx);
										if((tf1<em6 && tf2<em6 && tf3<em6) || (tf1>em61 && tf2>em61 && tf3>em61))
										    Uadvd=util[IJK-ijmax]+0.5e0*delz[1]*rguz[IJK-ijmax];
										else
										    Uadvd=util[IJK-ijmax];
#endif

#ifdef __solid
										fetch_mom<double>(i,j,k,tf1,fmx,f2mx); fetch_mom<double>(i,j,k-1,tf2,fmx,f2mx); fetch_mom<double>(i,j,k-2,tf3,fmx,f2mx);
										fetch_mom<double>(i,j,k,tp1,psimx,psi2mx); fetch_mom<double>(i,j,k-1,tp2,psimx,psi2mx); fetch_mom<double>(i,j,k-2,tp3,psimx,psi2mx);
										if((tf1>em61 && tf2>em61 && tf3>em61)||(tp1>em61 && tp2>em61 && tp3>em61)||(tf1+tp1<em6 && tf2+tp2<em6 && tf3+tp3<em6))
										    Uadvd=util[IJK-ijmax]+0.5e0*delz[1]*rguz[IJK-ijmax];
										else
										    Uadvd=util[IJK-ijmax];
#endif
									}
									else {
#ifndef __solid
										fetch_mom<double>(i,j,k,tf1,fmx,f2mx); fetch_mom<double>(i,j,k-1,tf2,fmx,f2mx); fetch_mom<double>(i,j,k+1,tf3,fmx,f2mx);
										if((tf1<em6 && tf2<em6 && tf3<em6) || (tf1>em61 && tf2>em61 && tf3>em61))
										    Uadvd=util[IJK]-0.5e0*delz[1]*rguz[IJK];
										else
										    Uadvd=util[IJK];
#endif

#ifdef __solid
										fetch_mom<double>(i,j,k,tf1,fmx,f2mx); fetch_mom<double>(i,j,k-1,tf2,fmx,f2mx); fetch_mom<double>(i,j,k+1,tf3,fmx,f2mx);
										fetch_mom<double>(i,j,k,tp1,psimx,psi2mx); fetch_mom<double>(i,j,k-1,tp2,psimx,psi2mx); fetch_mom<double>(i,j,k+1,tp3,psimx,psi2mx);
										if((tf1>em61 && tf2>em61 && tf3>em61)||(tp1>em61 && tp2>em61 && tp3>em61)||(tf1+tp1<em6 && tf2+tp2<em6 && tf3+tp3<em6))
										    Uadvd=util[IJK]-0.5e0*delz[1]*rguz[IJK];
										else
										    Uadvd=util[IJK];
#endif
									}
									rhoU[IJK-ijmax]-=(mass_flux)*Uadvd/vnew_stgx[IJK-ijmax];
									rhoU[IJK]+=(mass_flux)*Uadvd/vnew_stgx[IJK];
									
									mass_flux=(mass_adv[IND_f(2*i,2*j,2*k-2)]+mass_adv[IND_f(2*i-1,2*j,2*k-2)]+mass_adv[IND_f(2*i-1,2*j+1,2*k-2)]+mass_adv[IND_f(2*i,2*j+1,2*k-2)]);
									vel_avg=SIGN(mass_flux);
									//vel_avg=0.5e0*(wn[IJK-ijmax]+wn[IJK-ijmax+imax]);
									if(vel_avg>0.e0) {
#ifndef __solid
										fetch_mom<double>(i,j,k,tf1,fmy,f2my); fetch_mom<double>(i,j,k-1,tf2,fmy,f2my); fetch_mom<double>(i,j,k-2,tf3,fmy,f2my);
										if((tf1<em6 && tf2<em6 && tf3<em6) || (tf1>em61 && tf2>em61 && tf3>em61))
										    Vadvd=vtil[IJK-ijmax]+0.5e0*delz[1]*rgvz[IJK-ijmax];
										else 
										    Vadvd=vtil[IJK-ijmax];
#endif

#ifdef __solid
										fetch_mom<double>(i,j,k,tf1,fmy,f2my); fetch_mom<double>(i,j,k-1,tf2,fmy,f2my); fetch_mom<double>(i,j,k-2,tf3,fmy,f2my);
										fetch_mom<double>(i,j,k,tp1,psimy,psi2my); fetch_mom<double>(i,j,k-1,tp2,psimy,psi2my); fetch_mom<double>(i,j,k-2,tp3,psimy,psi2my);
										if((tf1>em61 && tf2>em61 && tf3>em61)||(tp1>em61 && tp2>em61 && tp3>em61)||(tf1+tp1<em6 && tf2+tp2<em6 && tf3+tp3<em6))
										    Vadvd=vtil[IJK-ijmax]+0.5e0*delz[1]*rgvz[IJK-ijmax];
										else 
										    Vadvd=vtil[IJK-ijmax];
#endif
									}
									else  {
#ifndef __solid
										fetch_mom<double>(i,j,k,tf1,fmy,f2my); fetch_mom<double>(i,j,k-1,tf2,fmy,f2my); fetch_mom<double>(i,j,k+1,tf3,fmy,f2my);
										if((tf1<em6 && tf2<em6 && tf3<em6) || (tf1>em61 && tf2>em61 && tf3>em61))
										    Vadvd=vtil[IJK]-0.5e0*delz[1]*rgvz[IJK];
										else
										    Vadvd=vtil[IJK];
#endif

#ifdef __solid
										fetch_mom<double>(i,j,k,tf1,fmy,f2my); fetch_mom<double>(i,j,k-1,tf2,fmy,f2my); fetch_mom<double>(i,j,k+1,tf3,fmy,f2my);
										fetch_mom<double>(i,j,k,tp1,psimy,psi2my); fetch_mom<double>(i,j,k-1,tp2,psimy,psi2my); fetch_mom<double>(i,j,k+1,tp3,psimy,psi2my);
										if((tf1>em61 && tf2>em61 && tf3>em61)||(tp1>em61 && tp2>em61 && tp3>em61)||(tf1+tp1<em6 && tf2+tp2<em6 && tf3+tp3<em6))
										    Vadvd=vtil[IJK]-0.5e0*delz[1]*rgvz[IJK];
										else
										    Vadvd=vtil[IJK];
#endif
									}
										
									rhoV[IJK-ijmax]-=(mass_flux)*Vadvd/vnew_stgy[IJK-ijmax];
									rhoV[IJK]+=(mass_flux)*Vadvd/vnew_stgy[IJK];
									
									mass_flux=(mass_adv[IND_f(2*i,2*j,2*k-1)]+mass_adv[IND_f(2*i-1,2*j,2*k-1)]+mass_adv[IND_f(2*i-1,2*j-1,2*k-1)]+mass_adv[IND_f(2*i,2*j-1,2*k-1)]);
									vel_avg=SIGN(mass_flux);
									//vel_avg=0.5e0*(wn[IJK-ijmax]+wn[IJK]);
									if(vel_avg>0.e0) {
#ifndef __solid
										fetch_mom<double>(i,j,k,tf1,fmz,f2mz); fetch_mom<double>(i,j,k-1,tf2,fmz,f2mz); fetch_mom<double>(i,j,k-2,tf3,fmz,f2mz);
										if((tf1<em6 && tf2<em6 && tf3<em6) || (tf1>em61 && tf2>em61 && tf3>em61))
										    Wadvd=wtil[IJK-ijmax]+0.5e0*delz[1]*rgwz[IJK-ijmax];
										else
										    Wadvd=wtil[IJK-ijmax];
#endif

#ifdef __solid
										fetch_mom<double>(i,j,k,tf1,fmz,f2mz); fetch_mom<double>(i,j,k-1,tf2,fmz,f2mz); fetch_mom<double>(i,j,k-2,tf3,fmz,f2mz);
										fetch_mom<double>(i,j,k,tp1,psimz,psi2mz); fetch_mom<double>(i,j,k-1,tp2,psimz,psi2mz); fetch_mom<double>(i,j,k-2,tp3,psimz,psi2mz);
										if((tf1>em61 && tf2>em61 && tf3>em61)||(tp1>em61 && tp2>em61 && tp3>em61)||(tf1+tp1<em6 && tf2+tp2<em6 && tf3+tp3<em6))
										    Wadvd=wtil[IJK-ijmax]+0.5e0*delz[1]*rgwz[IJK-ijmax];
										else
										    Wadvd=wtil[IJK-ijmax];
#endif
									}
									else {
#ifndef __solid
										fetch_mom<double>(i,j,k,tf1,fmz,f2mz); fetch_mom<double>(i,j,k-1,tf2,fmz,f2mz); fetch_mom<double>(i,j,k+1,tf3,fmz,f2mz);
										if((tf1<em6 && tf2<em6 && tf3<em6) || (tf1>em61 && tf2>em61 && tf3>em61))
										    Wadvd=wtil[IJK]-0.5e0*delz[1]*rgwz[IJK];
										else
										    Wadvd=wtil[IJK];
#endif

#ifdef __solid
										fetch_mom<double>(i,j,k,tf1,fmz,f2mz); fetch_mom<double>(i,j,k-1,tf2,fmz,f2mz); fetch_mom<double>(i,j,k+1,tf3,fmz,f2mz);
										fetch_mom<double>(i,j,k,tp1,psimz,psi2mz); fetch_mom<double>(i,j,k-1,tp2,psimz,psi2mz); fetch_mom<double>(i,j,k+1,tp3,psimz,psi2mz);
										if((tf1>em61 && tf2>em61 && tf3>em61)||(tp1>em61 && tp2>em61 && tp3>em61)||(tf1+tp1<em6 && tf2+tp2<em6 && tf3+tp3<em6))
										    Wadvd=wtil[IJK]-0.5e0*delz[1]*rgwz[IJK];
										else
										    Wadvd=wtil[IJK];
#endif
									}
										
									rhoW[IJK-ijmax]-=(mass_flux)*Wadvd/vnew_stgz[IJK-ijmax];
									rhoW[IJK]+=(mass_flux)*Wadvd/vnew_stgz[IJK];
									break;
							} //end switch looper
						} //endfor(i,j,k)
							
				//obtain velocities from rhoU ... use updated rho to divide .. note fn is updated f now
				stag_den();
				for(k=1;k<km1;k++)
					for(j=1;j<jm1;j++)
						for(i=1;i<im1;i++) {
							u[IJK]=rhoU[IJK] / rho_stgx[IJK];
							v[IJK]=rhoV[IJK] / rho_stgy[IJK];
							w[IJK]=rhoW[IJK] / rho_stgz[IJK];
						}
				bcvel(); //xchanges information across mpi subdomains and imposes velocity boundary condition.
#endif				
	} //subcyc loop

#ifdef __solid
#ifndef pres_v		
	for(i=1;i<=NBODY;i++) scale_psi_cells(i); //at the end of advection, scale the solid cells (and fluid cells) to conserve solid mass
#endif
	//ashish-rig.
	bcf_f();
	bcpsi_f();
	memcpy(fn_f,f_f,NX_f*NY_f*NZ_f*sizeof(double));
	memcpy(psin_f,psi_f,NX_f*NY_f*NZ_f*sizeof(double));
	clean_VOF(); //three-phase version of voferr_f()
	bcpsi_f();
	bcf_f();
	memcpy(psin_f,psi_f,NX_f*NY_f*NZ_f*sizeof(double));//needed for set_mom_vof
	memcpy(fn_f,f_f,NX_f*NY_f*NZ_f*sizeof(double));
#endif	

#ifdef passive_scalar	
	clean_scal(scal);
#endif

#ifndef __solid
	bcf_f();
	memcpy(fn_f,f_f,NX_f*NY_f*NZ_f*sizeof(double));
	voferr_f();
	bcf_f();
	memcpy(fn_f,f_f,NX_f*NY_f*NZ_f*sizeof(double));
#endif


#ifdef __solid
	psifine2stnd();
	bcpsi();
	memcpy(vold_f,vol_f,NX_f*NY_f*NZ_f*sizeof(double));
	set_mom_vof(); //to be used in rigid body velocity calculation...fn_f and psin_f has to be updated before using it.

	//calculate the normals to the solid surface
	for(k=0;k<=km1_f;k++)
	 for(j=0;j<=jm1_f;j++)  
	  for(i=0;i<=im1_f;i++) {
		  psirho_f[IJK_f] = rhof0*(psi_f[IJK_f]) + 1.0*(1.0-psi_f[IJK_f]); //the density is only for the purpose of calculating normals
	  }
	normalspsi_f(); // calculates psiavnx_f, psiavny_f etc.
	for(i=NBODY;i<=NBODY;i++) Ncalc_psi_centroid(&Cent[i],i); //centroid is not needed for now ...psiavnx_f prerequisite for centroid calculation
	recons_contact_line(); //fvirt_f () available now.
	
	for(i=1;i<=NBODY;i++) {
		Theta[i].x += Omega[i].x*delt;
		Theta[i].y += Omega[i].y*delt;
		Theta[i].z += Omega[i].z*delt;
	}
	
	double f_total=0.0;
	calc_total_fluid(&f_total);
	
	char bufp[50];
	FILE *fp;
	if(mpi.MyRank==0) {
		for(i=1;i<=NBODY;i++) {
			sprintf(bufp,"rig_pos_%d",i);
			fp=fopen(bufp,"a+");
			fprintf(fp,"%.22e %.22e %.22e %.22e\n",t,Omega[i].y,Theta[i].y,f_total);
			fclose(fp);
			fp=fopen("rig_vel_1","a+");
			fprintf(fp,"%.22e %.22e\n",t-delt,Omega[i].y);
			fclose(fp);
		}
	}
#endif
		
	//standard cell operations
#ifdef Ytube
	ytube_under_bc(); // Added by Cory
#endif
	fine2stnd(); //calculates f on standard cells from fine cells
	bcf(); //share f with neighbors and at the ghost cells
	memcpy(fn,f,NX*NY*NZ*sizeof(double));
	//voferr(); //performed already on fine grid no need here for now

	setproperties(); //sets rho
	normals(); //bcf and setting rho prerequisites for normals
	
//	normals_fvirt_curvature(); //calculates the normals on the basis of fvirt_f and exchanges them across virtual boundaries
	
	
//	normals_from_fine(gradrox,  gradroy,  gradroz,
//					  gradrox_f,gradroy_f,gradroz_f); //gradrox_f etc. should already have been computed...recons_contact_line()
	
	bc(); //apply boundary conditions
	
}

//functions that calculate the volume fractions inside momenta C.V.s
void set_mom_vof() {
	int i,j,k;
	double *fmx = temp[15], *fmy = temp[16], *fmz = temp[17];
	memset(fmx,0,NX*NY*NZ*sizeof(double));
	memset(fmy,0,NX*NY*NZ*sizeof(double));
	memset(fmz,0,NX*NY*NZ*sizeof(double));
#ifdef __solid
	double *psimx = temp[21], *psimy = temp[22], *psimz = temp[23];
	memset(psimx,0,NX*NY*NZ*sizeof(double));
	memset(psimy,0,NX*NY*NZ*sizeof(double));
	memset(psimz,0,NX*NY*NZ*sizeof(double));
#endif
	for(k=0;k<km1;k++)
	 for(j=0;j<jm1;j++)
	  for(i=0;i<im1;i++) {
		  if(j>0 && k>0) fmx[IJK] = f_mom_x(i,j,k);
		  if(i>0 && k>0) fmy[IJK] = f_mom_y(i,j,k);
		  if(i>0 && j>0) fmz[IJK] = f_mom_z(i,j,k);
#ifdef __solid
		  if(j>0 && k>0) psimx[IJK] = psi_mom_x(i,j,k);
		  if(i>0 && k>0) psimy[IJK] = psi_mom_y(i,j,k);
		  if(i>0 && j>0) psimz[IJK] = psi_mom_z(i,j,k);
#endif
	  }
	  
	xchg<double>(fmx); xchg<double>(fmy); xchg<double>(fmz); //first layer of ghost cells
	xchg2<double>(fmx,f2mx,splanDo2); //second layer of ghost cells
	xchg2<double>(fmy,f2my,splanDo2);
	xchg2<double>(fmz,f2mz,splanDo2);
#ifdef __solid
	xchg<double>(psimx); xchg<double>(psimy); xchg<double>(psimz);
	xchg2<double>(psimx,psi2mx,splanDo2);
	xchg2<double>(psimy,psi2my,splanDo2);
	xchg2<double>(psimz,psi2mz,splanDo2);
#endif
	bc_mom(); //sets values in two layers of ghost cells.
}

void bc_mom() {
	int i,j,k, i2,j2,k2;
	int st_indx, gx,gy,gz;
	double *fmx = temp[15], *fmy = temp[16], *fmz = temp[17];
#ifdef __solid
	double *psimx = temp[21], *psimy = temp[22], *psimz = temp[23];
#endif
	//left boundary
	if(mpi.Neighbors[0] == -1) {
		st_indx=0;
		i2=0, gx=1, gy=(jmax+2), gz=(kmax+2);
		for(k=1;k<km1;k++)
		 for(j=1;j<jm1;j++) {
			 j2=j+1, k2=k+1;
			 //fmx[IND(0,j,k)] = fmx[IND(1,j,k)]; //first layer of ghost cells
			 fmy[IND(0,j,k)] = fmy[IND(1,j,k)];
			 fmz[IND(0,j,k)] = fmz[IND(1,j,k)];
			 f2mx[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = fmx[IND(0,j,k)]; //second layer of ghost cells
			 f2my[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = fmy[IND(1,j,k)];
			 f2mz[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = fmz[IND(1,j,k)];
#ifdef __solid
			 //psimx[IND(0,j,k)] = psimx[IND(1,j,k)];
			 psimy[IND(0,j,k)] = psimy[IND(1,j,k)];
			 psimz[IND(0,j,k)] = psimz[IND(1,j,k)];
			 psi2mx[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = psimx[IND(0,j,k)];
			 psi2my[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = psimy[IND(1,j,k)];
			 psi2mz[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = psimz[IND(1,j,k)];
#endif
		 }
	}
	
	//right boundary
	if(mpi.Neighbors[1] == -1) {
		st_indx=(jmax+2)*(kmax+2);
		i2=0, gx=1, gy=(jmax+2), gz=(kmax+2);
		for(k=1;k<km1;k++)
		 for(j=1;j<jm1;j++) {
			 j2=j+1, k2=k+1;
			 fmx[IND(im1,j,k)] = fmx[IND(im2,j,k)];
			 fmy[IND(im1,j,k)] = fmy[IND(im2,j,k)];
			 fmz[IND(im1,j,k)] = fmz[IND(im2,j,k)];
			 f2mx[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = fmx[IND(im2,j,k)];
			 f2my[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = fmy[IND(im2,j,k)];
			 f2mz[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = fmz[IND(im2,j,k)];
#ifdef __solid
			 psimx[IND(im1,j,k)] = psimx[IND(im2,j,k)];
			 psimy[IND(im1,j,k)] = psimy[IND(im2,j,k)];
			 psimz[IND(im1,j,k)] = psimz[IND(im2,j,k)];
			 psi2mx[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = psimx[IND(im2,j,k)];
			 psi2my[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = psimy[IND(im2,j,k)];
			 psi2mz[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = psimz[IND(im2,j,k)];
#endif
		 }
	}
	
	//back boundary
	if(mpi.Neighbors[2] == -1) {
		st_indx=2*(jmax+2)*(kmax+2);
		j2=0, gx=(imax+2), gy=1, gz=(kmax+2);
		for(k=1;k<km1;k++)
		 for(i=1;i<im1;i++) {
			 i2=i+1, k2=k+1;
			 fmx[IND(i,0,k)] = fmx[IND(i,1,k)];
			 //fmy[IND(i,0,k)] = fmy[IND(i,1,k)];
			 fmz[IND(i,0,k)] = fmz[IND(i,1,k)];
			 f2mx[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = fmx[IND(i,1,k)];
			 f2my[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = fmy[IND(i,0,k)];
			 f2mz[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = fmz[IND(i,1,k)];
#ifdef __solid
			 psimx[IND(i,0,k)] = psimx[IND(i,1,k)];
			 //psimy[IND(i,0,k)] = psimy[IND(i,1,k)];
			 psimz[IND(i,0,k)] = psimz[IND(i,1,k)];
			 psi2mx[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = psimx[IND(i,1,k)];
			 psi2my[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = psimy[IND(i,0,k)];
			 psi2mz[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = psimz[IND(i,1,k)];
#endif
		 }
	}
	
	//front boundary
	if(mpi.Neighbors[3] == -1) {
		st_indx=2*(jmax+2)*(kmax+2)+(imax+2)*(kmax+2); 
		j2=0, gx=(imax+2), gy=1, gz=(kmax+2);
		for(k=1;k<km1;k++) 
		 for(i=1;i<im1;i++) {
			 i2=i+1, k2=k+1;
			 fmx[IND(i,jm1,k)] = fmx[IND(i,jm2,k)];
			 fmy[IND(i,jm1,k)] = fmy[IND(i,jm2,k)];
			 fmz[IND(i,jm1,k)] = fmz[IND(i,jm2,k)];
			 f2mx[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = fmx[IND(i,jm2,k)];
			 f2my[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = fmy[IND(i,jm2,k)];
			 f2mz[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = fmz[IND(i,jm2,k)];
#ifdef __solid
			 psimx[IND(i,jm1,k)] = psimx[IND(i,jm2,k)];
			 psimy[IND(i,jm1,k)] = psimy[IND(i,jm2,k)];
			 psimz[IND(i,jm1,k)] = psimz[IND(i,jm2,k)];
			 psi2mx[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = psimx[IND(i,jm2,k)];
			 psi2my[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = psimy[IND(i,jm2,k)];
			 psi2mz[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = psimz[IND(i,jm2,k)];
#endif
		 }
	}
	
	//under boundary
	if(mpi.Neighbors[4] == -1) {
		st_indx=2*(jmax+2)*(kmax+2)+2*(imax+2)*(kmax+2);
		k2=0, gx=(imax+2), gy=(jmax+2), gz=1;
		for(j=1;j<jm1;j++) 
		 for(i=1;i<im1;i++) {
			 i2=i+1, j2=j+1;
			 fmx[IND(i,j,0)] = fmx[IND(i,j,1)];
			 fmy[IND(i,j,0)] = fmy[IND(i,j,1)];
			 //fmz[IND(i,j,0)] = fmz[IND(i,j,1)];
			 f2mx[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = fmx[IND(i,j,1)];
			 f2my[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = fmy[IND(i,j,1)];
			 f2mz[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = fmz[IND(i,j,0)];
#ifdef __solid
			 psimx[IND(i,j,0)] = psimx[IND(i,j,1)];
			 psimy[IND(i,j,0)] = psimy[IND(i,j,1)];
			 //psimz[IND(i,j,0)] = psimz[IND(i,j,1)];
			 psi2mx[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = psimx[IND(i,j,1)];
			 psi2my[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = psimy[IND(i,j,1)];
			 psi2mz[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = psimz[IND(i,j,0)];
#endif
		 }
	}
	
	//over boundary
	if(mpi.Neighbors[5] == -1) {
		st_indx=2*(jmax+2)*(kmax+2)+2*(imax+2)*(kmax+2)+(imax+2)*(jmax+2);
		k2=0, gx=(imax+2), gy=(jmax+2), gz=1;
		for(j=1;j<jm1;j++) 
		 for(i=1;i<im1;i++) {
			 i2=i+1, j2=j+1;
			 fmx[IND(i,j,km1)] = fmx[IND(i,j,km2)];
			 fmy[IND(i,j,km1)] = fmy[IND(i,j,km2)];
			 fmz[IND(i,j,km1)] = fmz[IND(i,j,km2)];
			 f2mx[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = fmx[IND(i,j,km2)];
			 f2my[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = fmy[IND(i,j,km2)];
			 f2mz[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = fmz[IND(i,j,km2)];
#ifdef __solid
			 psimx[IND(i,j,km1)] = psimx[IND(i,j,km2)];
			 psimy[IND(i,j,km1)] = psimy[IND(i,j,km2)];
			 psimz[IND(i,j,km1)] = psimz[IND(i,j,km2)];
			 psi2mx[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = psimx[IND(i,j,km2)];
			 psi2my[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = psimy[IND(i,j,km2)];
			 psi2mz[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)] = psimz[IND(i,j,km2)];
#endif
		 }
	}
}

template <class T> void fetch_mom(int i, int j, int k, T &val, T *array, T *gArray)
{	
	//sets val from either the main array [*array] or
	//2nd layer of ghost cell [*gArray] whichever is appropriate
	int i2,j2,k2, gx,gy,gz, st_indx;
	
	val = 0;
	if(i<imax && i>-1 && j<jmax && j>-1 && k<kmax && k>-1)
		val = array[IJK];
	else {
		if(i==-1) {
			st_indx = 0;
			i2=0, j2=j+1, k2=k+1; //indices in gArray
			gx=1, gy=(jmax+2), gz =(kmax+2); //dimensions of gArray
		}
		if(i==imax) {
			st_indx = (jmax+2)*(kmax+2);
			i2=0, j2=j+1, k2=k+1;
			gx=1, gy=(jmax+2), gz =(kmax+2);
		}
		if(j==-1) {
			st_indx = 2*(jmax+2)*(kmax+2);
			i2=i+1, j2=0, k2=k+1;
			gx=imax+2, gy=1, gz=kmax+2;
		}
		if(j==jmax) {
			st_indx = 2*(jmax+2)*(kmax+2) + (imax+2)*(kmax+2);
			i2=i+1, j2=0, k2=k+1;
			gx=imax+2, gy=1, gz=kmax+2;
		}
		if(k==-1) {
			st_indx = 2*(jmax+2)*(kmax+2) + 2*(imax+2)*(kmax+2);
			i2=i+1, j2=j+1, k2=0;
			gx=(imax+2), gy=jmax+2, gz=1;
		}
		if(k==kmax) {
			st_indx = 2*(jmax+2)*(kmax+2) + 2*(imax+2)*(kmax+2)
				  + (imax+2)*(jmax+2);
			i2=i+1, j2=j+1, k2=0;
			gx=(imax+2), gy=(jmax+2), gz=1;
		}
		val = gArray[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)];
	}
}

double f_mom_x(int i, int j, int k) {
	//calculate the volume fraction in an x-momentum C.V.
	double *vold_f=temp_f[2];
	double vol_frac, vol_temp;
	
	vol_frac=fn_f[IND_f(2*i,2*j,2*k)]*vold_f[IND_f(2*i,2*j,2*k)]+fn_f[IND_f(2*i,2*j-1,2*k)]*vold_f[IND_f(2*i,2*j-1,2*k)]+fn_f[IND_f(2*i,2*j-1,2*k-1)]*vold_f[IND_f(2*i,2*j-1,2*k-1)]+fn_f[IND_f(2*i,2*j,2*k-1)]*vold_f[IND_f(2*i,2*j,2*k-1)]
		  +fn_f[IND_f(2*i+1,2*j,2*k)]*vold_f[IND_f(2*i+1,2*j,2*k)]+fn_f[IND_f(2*i+1,2*j-1,2*k)]*vold_f[IND_f(2*i+1,2*j-1,2*k)]+fn_f[IND_f(2*i+1,2*j-1,2*k-1)]*vold_f[IND_f(2*i+1,2*j-1,2*k-1)]+fn_f[IND_f(2*i+1,2*j,2*k-1)]*vold_f[IND_f(2*i+1,2*j,2*k-1)];
	
	vol_temp=vold_f[IND_f(2*i,2*j,2*k)]+vold_f[IND_f(2*i,2*j-1,2*k)]+vold_f[IND_f(2*i,2*j-1,2*k-1)]+vold_f[IND_f(2*i,2*j,2*k-1)]
		  +vold_f[IND_f(2*i+1,2*j,2*k)]+vold_f[IND_f(2*i+1,2*j-1,2*k)]+vold_f[IND_f(2*i+1,2*j-1,2*k-1)]+vold_f[IND_f(2*i+1,2*j,2*k-1)];
		  
	vol_frac = vol_frac/vol_temp;
	return vol_frac;
	
}

double f_mom_y(int i, int j, int k) {
	//calculates volume fraction in an y-momentum C.V.
	double *vold_f=temp_f[2];
	double vol_frac, vol_temp;
	
	vol_frac=fn_f[IND_f(2*i,2*j,2*k)]*vold_f[IND_f(2*i,2*j,2*k)]+fn_f[IND_f(2*i-1,2*j,2*k)]*vold_f[IND_f(2*i-1,2*j,2*k)]+fn_f[IND_f(2*i-1,2*j,2*k-1)]*vold_f[IND_f(2*i-1,2*j,2*k-1)]+fn_f[IND_f(2*i,2*j,2*k-1)]*vold_f[IND_f(2*i,2*j,2*k-1)]
		  +fn_f[IND_f(2*i,2*j+1,2*k)]*vold_f[IND_f(2*i,2*j+1,2*k)]+fn_f[IND_f(2*i-1,2*j+1,2*k)]*vold_f[IND_f(2*i-1,2*j+1,2*k)]+fn_f[IND_f(2*i-1,2*j+1,2*k-1)]*vold_f[IND_f(2*i-1,2*j+1,2*k-1)]+fn_f[IND_f(2*i,2*j+1,2*k-1)]*vold_f[IND_f(2*i,2*j+1,2*k-1)];
		  
	vol_temp=vold_f[IND_f(2*i,2*j,2*k)]+vold_f[IND_f(2*i-1,2*j,2*k)]+vold_f[IND_f(2*i-1,2*j,2*k-1)]+vold_f[IND_f(2*i,2*j,2*k-1)]
		  +vold_f[IND_f(2*i,2*j+1,2*k)]+vold_f[IND_f(2*i-1,2*j+1,2*k)]+vold_f[IND_f(2*i-1,2*j+1,2*k-1)]+vold_f[IND_f(2*i,2*j+1,2*k-1)];
		  
	vol_frac = vol_frac / vol_temp;
	return vol_frac;
}

double f_mom_z(int i, int j, int k) {
	//calculates volume fraction in a z-momentum C.V.
	double *vold_f=temp_f[2];
	double vol_frac, vol_temp;
	
	vol_frac=fn_f[IND_f(2*i,2*j,2*k)]*vold_f[IND_f(2*i,2*j,2*k)]+fn_f[IND_f(2*i-1,2*j,2*k)]*vold_f[IND_f(2*i-1,2*j,2*k)]+fn_f[IND_f(2*i-1,2*j-1,2*k)]*vold_f[IND_f(2*i-1,2*j-1,2*k)]+fn_f[IND_f(2*i,2*j-1,2*k)]*vold_f[IND_f(2*i,2*j-1,2*k)]
		  +fn_f[IND_f(2*i,2*j,2*k+1)]*vold_f[IND_f(2*i,2*j,2*k+1)]+fn_f[IND_f(2*i-1,2*j,2*k+1)]*vold_f[IND_f(2*i-1,2*j,2*k+1)]+fn_f[IND_f(2*i-1,2*j-1,2*k+1)]*vold_f[IND_f(2*i-1,2*j-1,2*k+1)]+fn_f[IND_f(2*i,2*j-1,2*k+1)]*vold_f[IND_f(2*i,2*j-1,2*k+1)];
		  
	vol_temp=vold_f[IND_f(2*i,2*j,2*k)]+vold_f[IND_f(2*i-1,2*j,2*k)]+vold_f[IND_f(2*i-1,2*j-1,2*k)]+vold_f[IND_f(2*i,2*j-1,2*k)]
		  +vold_f[IND_f(2*i,2*j,2*k+1)]+vold_f[IND_f(2*i-1,2*j,2*k+1)]+vold_f[IND_f(2*i-1,2*j-1,2*k+1)]+vold_f[IND_f(2*i,2*j-1,2*k+1)];
		  
	vol_frac = vol_frac / vol_temp;
	return vol_frac;
}

#ifdef __solid
double psi_mom_x(int i, int j, int k) {
	//calculate the solid volume fraction in an x-momentum C.V.
	double *vold_f=temp_f[2];
	double vol_frac, vol_temp;
	
	vol_frac=psin_f[IND_f(2*i,2*j,2*k)]*vold_f[IND_f(2*i,2*j,2*k)]+psin_f[IND_f(2*i,2*j-1,2*k)]*vold_f[IND_f(2*i,2*j-1,2*k)]+psin_f[IND_f(2*i,2*j-1,2*k-1)]*vold_f[IND_f(2*i,2*j-1,2*k-1)]+psin_f[IND_f(2*i,2*j,2*k-1)]*vold_f[IND_f(2*i,2*j,2*k-1)]
		  +psin_f[IND_f(2*i+1,2*j,2*k)]*vold_f[IND_f(2*i+1,2*j,2*k)]+psin_f[IND_f(2*i+1,2*j-1,2*k)]*vold_f[IND_f(2*i+1,2*j-1,2*k)]+psin_f[IND_f(2*i+1,2*j-1,2*k-1)]*vold_f[IND_f(2*i+1,2*j-1,2*k-1)]+psin_f[IND_f(2*i+1,2*j,2*k-1)]*vold_f[IND_f(2*i+1,2*j,2*k-1)];
	
	vol_temp=vold_f[IND_f(2*i,2*j,2*k)]+vold_f[IND_f(2*i,2*j-1,2*k)]+vold_f[IND_f(2*i,2*j-1,2*k-1)]+vold_f[IND_f(2*i,2*j,2*k-1)]
		  +vold_f[IND_f(2*i+1,2*j,2*k)]+vold_f[IND_f(2*i+1,2*j-1,2*k)]+vold_f[IND_f(2*i+1,2*j-1,2*k-1)]+vold_f[IND_f(2*i+1,2*j,2*k-1)];
		  
	vol_frac = vol_frac/vol_temp;
	return vol_frac;
	
}

double psi_mom_y(int i, int j, int k) {
	//calculates volume fraction in an y-momentum C.V.
	double *vold_f=temp_f[2];
	double vol_frac, vol_temp;
	
	vol_frac=psin_f[IND_f(2*i,2*j,2*k)]*vold_f[IND_f(2*i,2*j,2*k)]+psin_f[IND_f(2*i-1,2*j,2*k)]*vold_f[IND_f(2*i-1,2*j,2*k)]+psin_f[IND_f(2*i-1,2*j,2*k-1)]*vold_f[IND_f(2*i-1,2*j,2*k-1)]+psin_f[IND_f(2*i,2*j,2*k-1)]*vold_f[IND_f(2*i,2*j,2*k-1)]
		  +psin_f[IND_f(2*i,2*j+1,2*k)]*vold_f[IND_f(2*i,2*j+1,2*k)]+psin_f[IND_f(2*i-1,2*j+1,2*k)]*vold_f[IND_f(2*i-1,2*j+1,2*k)]+psin_f[IND_f(2*i-1,2*j+1,2*k-1)]*vold_f[IND_f(2*i-1,2*j+1,2*k-1)]+psin_f[IND_f(2*i,2*j+1,2*k-1)]*vold_f[IND_f(2*i,2*j+1,2*k-1)];
		  
	vol_temp=vold_f[IND_f(2*i,2*j,2*k)]+vold_f[IND_f(2*i-1,2*j,2*k)]+vold_f[IND_f(2*i-1,2*j,2*k-1)]+vold_f[IND_f(2*i,2*j,2*k-1)]
		  +vold_f[IND_f(2*i,2*j+1,2*k)]+vold_f[IND_f(2*i-1,2*j+1,2*k)]+vold_f[IND_f(2*i-1,2*j+1,2*k-1)]+vold_f[IND_f(2*i,2*j+1,2*k-1)];
		  
	vol_frac = vol_frac / vol_temp;
	return vol_frac;
}

double psi_mom_z(int i, int j, int k) {
	//calculates volume fraction in a z-momentum C.V.
	double *vold_f=temp_f[2];
	double vol_frac, vol_temp;
	
	vol_frac=psin_f[IND_f(2*i,2*j,2*k)]*vold_f[IND_f(2*i,2*j,2*k)]+psin_f[IND_f(2*i-1,2*j,2*k)]*vold_f[IND_f(2*i-1,2*j,2*k)]+psin_f[IND_f(2*i-1,2*j-1,2*k)]*vold_f[IND_f(2*i-1,2*j-1,2*k)]+psin_f[IND_f(2*i,2*j-1,2*k)]*vold_f[IND_f(2*i,2*j-1,2*k)]
		  +psin_f[IND_f(2*i,2*j,2*k+1)]*vold_f[IND_f(2*i,2*j,2*k+1)]+psin_f[IND_f(2*i-1,2*j,2*k+1)]*vold_f[IND_f(2*i-1,2*j,2*k+1)]+psin_f[IND_f(2*i-1,2*j-1,2*k+1)]*vold_f[IND_f(2*i-1,2*j-1,2*k+1)]+psin_f[IND_f(2*i,2*j-1,2*k+1)]*vold_f[IND_f(2*i,2*j-1,2*k+1)];
		  
	vol_temp=vold_f[IND_f(2*i,2*j,2*k)]+vold_f[IND_f(2*i-1,2*j,2*k)]+vold_f[IND_f(2*i-1,2*j-1,2*k)]+vold_f[IND_f(2*i,2*j-1,2*k)]
		  +vold_f[IND_f(2*i,2*j,2*k+1)]+vold_f[IND_f(2*i-1,2*j,2*k+1)]+vold_f[IND_f(2*i-1,2*j-1,2*k+1)]+vold_f[IND_f(2*i,2*j-1,2*k+1)];
		  
	vol_frac = vol_frac / vol_temp;
	return vol_frac;
}
#endif

void stag_vol() {
      //calculates volume of the 'regular' staggered grid from the fine grid cells
      double *vnew_f=temp_f[0];
      
      double *vnew_stgx=temp[12]; //control volumes for x,y and z momentum
      double *vnew_stgy=temp[13];
      double *vnew_stgz=temp[14];     
      int i,j,k;
      for(k=0;k<km1;k++)
	    for(j=0;j<jm1;j++)
		  for(i=0;i<im1;i++) {
			//x-mom CV
			if(j > 0 && k > 0)
			vnew_stgx[IJK]=vnew_f[IND_f(2*i,2*j,2*k)]+vnew_f[IND_f(2*i,2*j-1,2*k)]+vnew_f[IND_f(2*i,2*j-1,2*k-1)]+vnew_f[IND_f(2*i,2*j,2*k-1)]
					    +vnew_f[IND_f(2*i+1,2*j,2*k)]+vnew_f[IND_f(2*i+1,2*j-1,2*k)]+vnew_f[IND_f(2*i+1,2*j-1,2*k-1)]+vnew_f[IND_f(2*i+1,2*j,2*k-1)];
			//y-mom CV
			if(k>0 && i>0)
			vnew_stgy[IJK]=vnew_f[IND_f(2*i,2*j,2*k)]+vnew_f[IND_f(2*i-1,2*j,2*k)]+vnew_f[IND_f(2*i-1,2*j,2*k-1)]+vnew_f[IND_f(2*i,2*j,2*k-1)]
					    +vnew_f[IND_f(2*i,2*j+1,2*k)]+vnew_f[IND_f(2*i-1,2*j+1,2*k)]+vnew_f[IND_f(2*i-1,2*j+1,2*k-1)]+vnew_f[IND_f(2*i,2*j+1,2*k-1)];
					    
			//z-mom CV
			if(i>0 && j>0)
			vnew_stgz[IJK]=vnew_f[IND_f(2*i,2*j,2*k)]+vnew_f[IND_f(2*i-1,2*j,2*k)]+vnew_f[IND_f(2*i-1,2*j-1,2*k)]+vnew_f[IND_f(2*i,2*j-1,2*k)]
				        +vnew_f[IND_f(2*i,2*j,2*k+1)]+vnew_f[IND_f(2*i-1,2*j,2*k+1)]+vnew_f[IND_f(2*i-1,2*j-1,2*k+1)]+vnew_f[IND_f(2*i,2*j-1,2*k+1)];
		  }   
}

void stag_den() {
      //calculates density in the staggered grid: mom-x CV, mom-y CV and mom-z CV
      double *vnew_f=temp_f[0];
      
      double *vnew_stgx=temp[12]; //control volumes for x,y and z momentum
      double *vnew_stgy=temp[13];
      double *vnew_stgz=temp[14];
      
      double *rho_stgx=temp[18];
      double *rho_stgy=temp[19];
      double *rho_stgz=temp[20];
      
      memset(rho_stgx,0,NX*NY*NZ*sizeof(double));
      memset(rho_stgy,0,NX*NY*NZ*sizeof(double));
      memset(rho_stgz,0,NX*NY*NZ*sizeof(double));
      int i,j,k;
      
#ifndef __solid
      for(k=0;k<km1;k++)
	    for(j=0;j<jm1;j++)
		  for(i=0;i<im1;i++)
		  {
			if(j>0 && k>0) {
			      rho_stgx[IJK]= f_f[IND_f(2*i,2*j,2*k)]*rhof1*vnew_f[IND_f(2*i,2*j,2*k)]+(1.e0-f_f[IND_f(2*i,2*j,2*k)])*rhof2*vnew_f[IND_f(2*i,2*j,2*k)]
				      +f_f[IND_f(2*i,2*j-1,2*k)]*rhof1*vnew_f[IND_f(2*i,2*j-1,2*k)]+(1.e0-f_f[IND_f(2*i,2*j-1,2*k)])*rhof2*vnew_f[IND_f(2*i,2*j-1,2*k)]
				      +f_f[IND_f(2*i,2*j-1,2*k-1)]*rhof1*vnew_f[IND_f(2*i,2*j-1,2*k-1)]+(1.e0-f_f[IND_f(2*i,2*j-1,2*k-1)])*rhof2*vnew_f[IND_f(2*i,2*j-1,2*k-1)]
				      +f_f[IND_f(2*i,2*j,2*k-1)]*rhof1*vnew_f[IND_f(2*i,2*j,2*k-1)]+(1.e0-f_f[IND_f(2*i,2*j,2*k-1)])*rhof2*vnew_f[IND_f(2*i,2*j,2*k-1)]
						   
				      +f_f[IND_f(2*i+1,2*j,2*k)]*rhof1*vnew_f[IND_f(2*i+1,2*j,2*k)]+(1.e0-f_f[IND_f(2*i+1,2*j,2*k)])*rhof2*vnew_f[IND_f(2*i+1,2*j,2*k)]
				      +f_f[IND_f(2*i+1,2*j-1,2*k)]*rhof1*vnew_f[IND_f(2*i+1,2*j-1,2*k)]+(1.e0-f_f[IND_f(2*i+1,2*j-1,2*k)])*rhof2*vnew_f[IND_f(2*i+1,2*j-1,2*k)]
				      +f_f[IND_f(2*i+1,2*j-1,2*k-1)]*rhof1*vnew_f[IND_f(2*i+1,2*j-1,2*k-1)]+(1.e0-f_f[IND_f(2*i+1,2*j-1,2*k-1)])*rhof2*vnew_f[IND_f(2*i+1,2*j-1,2*k-1)]
				      +f_f[IND_f(2*i+1,2*j,2*k-1)]*rhof1*vnew_f[IND_f(2*i+1,2*j,2*k-1)]+(1.e0-f_f[IND_f(2*i+1,2*j,2*k-1)])*rhof2*vnew_f[IND_f(2*i+1,2*j,2*k-1)];
						   
			      rho_stgx[IJK]/= vnew_stgx[IJK];
			}
			      
			      
			if(i>0 && k>0) {
			      rho_stgy[IJK]= f_f[IND_f(2*i,2*j,2*k)]*rhof1*vnew_f[IND_f(2*i,2*j,2*k)]+(1.e0-f_f[IND_f(2*i,2*j,2*k)])*rhof2*vnew_f[IND_f(2*i,2*j,2*k)]
				      +f_f[IND_f(2*i-1,2*j,2*k)]*rhof1*vnew_f[IND_f(2*i-1,2*j,2*k)]+(1.e0-f_f[IND_f(2*i-1,2*j,2*k)])*rhof2*vnew_f[IND_f(2*i-1,2*j,2*k)]
				      +f_f[IND_f(2*i-1,2*j,2*k-1)]*rhof1*vnew_f[IND_f(2*i-1,2*j,2*k-1)]+(1.e0-f_f[IND_f(2*i-1,2*j,2*k-1)])*rhof2*vnew_f[IND_f(2*i-1,2*j,2*k-1)]
				      +f_f[IND_f(2*i,2*j,2*k-1)]*rhof1*vnew_f[IND_f(2*i,2*j,2*k-1)]+(1.e0-f_f[IND_f(2*i,2*j,2*k-1)])*rhof2*vnew_f[IND_f(2*i,2*j,2*k-1)]
						  
				      +f_f[IND_f(2*i,2*j+1,2*k)]*rhof1*vnew_f[IND_f(2*i,2*j+1,2*k)]+(1.e0-f_f[IND_f(2*i,2*j+1,2*k)])*rhof2*vnew_f[IND_f(2*i,2*j+1,2*k)]
				      +f_f[IND_f(2*i-1,2*j+1,2*k)]*rhof1*vnew_f[IND_f(2*i-1,2*j+1,2*k)]+(1.e0-f_f[IND_f(2*i-1,2*j+1,2*k)])*rhof2*vnew_f[IND_f(2*i-1,2*j+1,2*k)]
				      +f_f[IND_f(2*i-1,2*j+1,2*k-1)]*rhof1*vnew_f[IND_f(2*i-1,2*j+1,2*k-1)]+(1.e0-f_f[IND_f(2*i-1,2*j+1,2*k-1)])*rhof2*vnew_f[IND_f(2*i-1,2*j+1,2*k-1)]
				      +f_f[IND_f(2*i,2*j+1,2*k-1)]*rhof1*vnew_f[IND_f(2*i,2*j+1,2*k-1)]+(1.e0-f_f[IND_f(2*i,2*j+1,2*k-1)])*rhof2*vnew_f[IND_f(2*i,2*j+1,2*k-1)];
						   
			      rho_stgy[IJK]/= vnew_stgy[IJK];
			}
			      
			if(i>0 && j>0) {
			      rho_stgz[IJK]= f_f[IND_f(2*i,2*j,2*k)]*rhof1*vnew_f[IND_f(2*i,2*j,2*k)]+(1.e0-f_f[IND_f(2*i,2*j,2*k)])*rhof2*vnew_f[IND_f(2*i,2*j,2*k)]
				      +f_f[IND_f(2*i-1,2*j,2*k)]*rhof1*vnew_f[IND_f(2*i-1,2*j,2*k)]+(1.e0-f_f[IND_f(2*i-1,2*j,2*k)])*rhof2*vnew_f[IND_f(2*i-1,2*j,2*k)]
				      +f_f[IND_f(2*i-1,2*j-1,2*k)]*rhof1*vnew_f[IND_f(2*i-1,2*j-1,2*k)]+(1.e0-f_f[IND_f(2*i-1,2*j-1,2*k)])*rhof2*vnew_f[IND_f(2*i-1,2*j-1,2*k)]
				      +f_f[IND_f(2*i,2*j-1,2*k)]*rhof1*vnew_f[IND_f(2*i,2*j-1,2*k)]+(1.e0-f_f[IND_f(2*i,2*j-1,2*k)])*rhof2*vnew_f[IND_f(2*i,2*j-1,2*k)]
						  
				      +f_f[IND_f(2*i,2*j,2*k+1)]*rhof1*vnew_f[IND_f(2*i,2*j,2*k+1)]+(1.e0-f_f[IND_f(2*i,2*j,2*k+1)])*rhof2*vnew_f[IND_f(2*i,2*j,2*k+1)]
				      +f_f[IND_f(2*i-1,2*j,2*k+1)]*rhof1*vnew_f[IND_f(2*i-1,2*j,2*k+1)]+(1.e0-f_f[IND_f(2*i-1,2*j,2*k+1)])*rhof2*vnew_f[IND_f(2*i-1,2*j,2*k+1)]
				      +f_f[IND_f(2*i-1,2*j-1,2*k+1)]*rhof1*vnew_f[IND_f(2*i-1,2*j-1,2*k+1)]+(1.e0-f_f[IND_f(2*i-1,2*j-1,2*k+1)])*rhof2*vnew_f[IND_f(2*i-1,2*j-1,2*k+1)]
				      +f_f[IND_f(2*i,2*j-1,2*k+1)]*rhof1*vnew_f[IND_f(2*i,2*j-1,2*k+1)]+(1.e0-f_f[IND_f(2*i,2*j-1,2*k+1)])*rhof2*vnew_f[IND_f(2*i,2*j-1,2*k+1)];
							 
			      rho_stgz[IJK]/= vnew_stgz[IJK];
			}
		  }
#endif

#ifdef __solid
	for(k=0;k<km1;k++)
	    for(j=0;j<jm1;j++)
		  for(i=0;i<im1;i++)
		  { //density of solid initialized in rinput
			if(j>0 && k>0) {
				rho_stgx[IJK]= ( psi_f[IND_f(2*i,2*j,2*k)]*rhof0 + f_f[IND_f(2*i,2*j,2*k)]*rhof1 + (1.e0-f_f[IND_f(2*i,2*j,2*k)]-psi_f[IND_f(2*i,2*j,2*k)])*rhof2 ) * vnew_f[IND_f(2*i,2*j,2*k)]
					+( psi_f[IND_f(2*i,2*j-1,2*k)]*rhof0 + f_f[IND_f(2*i,2*j-1,2*k)]*rhof1 + (1.e0-f_f[IND_f(2*i,2*j-1,2*k)]-psi_f[IND_f(2*i,2*j-1,2*k)])*rhof2 ) * vnew_f[IND_f(2*i,2*j-1,2*k)]
					+( psi_f[IND_f(2*i,2*j-1,2*k-1)]*rhof0 + f_f[IND_f(2*i,2*j-1,2*k-1)]*rhof1 + (1.e0-f_f[IND_f(2*i,2*j-1,2*k-1)]-psi_f[IND_f(2*i,2*j-1,2*k-1)])*rhof2 ) * vnew_f[IND_f(2*i,2*j-1,2*k-1)]
					+( psi_f[IND_f(2*i,2*j,2*k-1)]*rhof0 + f_f[IND_f(2*i,2*j,2*k-1)]*rhof1 + (1.e0-f_f[IND_f(2*i,2*j,2*k-1)]-psi_f[IND_f(2*i,2*j,2*k-1)])*rhof2 ) * vnew_f[IND_f(2*i,2*j,2*k-1)]
					
					+( psi_f[IND_f(2*i+1,2*j,2*k)]*rhof0 + f_f[IND_f(2*i+1,2*j,2*k)]*rhof1 + (1.e0-f_f[IND_f(2*i+1,2*j,2*k)]-psi_f[IND_f(2*i+1,2*j,2*k)])*rhof2 ) * vnew_f[IND_f(2*i+1,2*j,2*k)]
					+( psi_f[IND_f(2*i+1,2*j-1,2*k)]*rhof0 + f_f[IND_f(2*i+1,2*j-1,2*k)]*rhof1 + (1.e0-f_f[IND_f(2*i+1,2*j-1,2*k)]-psi_f[IND_f(2*i+1,2*j-1,2*k)])*rhof2 ) * vnew_f[IND_f(2*i+1,2*j-1,2*k)]
					+( psi_f[IND_f(2*i+1,2*j-1,2*k-1)]*rhof0 + f_f[IND_f(2*i+1,2*j-1,2*k-1)]*rhof1 + (1.e0-f_f[IND_f(2*i+1,2*j-1,2*k-1)]-psi_f[IND_f(2*i+1,2*j-1,2*k-1)])*rhof2 ) * vnew_f[IND_f(2*i+1,2*j-1,2*k-1)]
					+( psi_f[IND_f(2*i+1,2*j,2*k-1)]*rhof0 + f_f[IND_f(2*i+1,2*j,2*k-1)]*rhof1 + (1.e0-f_f[IND_f(2*i+1,2*j,2*k-1)]-psi_f[IND_f(2*i+1,2*j,2*k-1)])*rhof2 ) * vnew_f[IND_f(2*i+1,2*j,2*k-1)];
						   
			      rho_stgx[IJK]/= vnew_stgx[IJK];
			}
			      
			      
			if(i>0 && k>0) {
				
				rho_stgy[IJK]= ( psi_f[IND_f(2*i,2*j,2*k)]*rhof0 + f_f[IND_f(2*i,2*j,2*k)]*rhof1 + (1.e0-f_f[IND_f(2*i,2*j,2*k)]-psi_f[IND_f(2*i,2*j,2*k)])*rhof2 ) * vnew_f[IND_f(2*i,2*j,2*k)]
					+( psi_f[IND_f(2*i-1,2*j,2*k)]*rhof0 + f_f[IND_f(2*i-1,2*j,2*k)]*rhof1 + (1.e0-f_f[IND_f(2*i-1,2*j,2*k)]-psi_f[IND_f(2*i-1,2*j,2*k)])*rhof2 ) * vnew_f[IND_f(2*i-1,2*j,2*k)]
					+( psi_f[IND_f(2*i-1,2*j,2*k-1)]*rhof0 + f_f[IND_f(2*i-1,2*j,2*k-1)]*rhof1 + (1.e0-f_f[IND_f(2*i-1,2*j,2*k-1)]-psi_f[IND_f(2*i-1,2*j,2*k-1)])*rhof2 ) * vnew_f[IND_f(2*i-1,2*j,2*k-1)]
					+( psi_f[IND_f(2*i,2*j,2*k-1)]*rhof0 + f_f[IND_f(2*i,2*j,2*k-1)]*rhof1 + (1.e0-f_f[IND_f(2*i,2*j,2*k-1)]-psi_f[IND_f(2*i,2*j,2*k-1)])*rhof2 ) * vnew_f[IND_f(2*i,2*j,2*k-1)]
					
					+( psi_f[IND_f(2*i,2*j+1,2*k)]*rhof0 + f_f[IND_f(2*i,2*j+1,2*k)]*rhof1 + (1.e0-f_f[IND_f(2*i,2*j+1,2*k)]-psi_f[IND_f(2*i,2*j+1,2*k)])*rhof2 ) * vnew_f[IND_f(2*i,2*j+1,2*k)]
					+( psi_f[IND_f(2*i-1,2*j+1,2*k)]*rhof0 + f_f[IND_f(2*i-1,2*j+1,2*k)]*rhof1 + (1.e0-f_f[IND_f(2*i-1,2*j+1,2*k)]-psi_f[IND_f(2*i-1,2*j+1,2*k)])*rhof2 ) * vnew_f[IND_f(2*i-1,2*j+1,2*k)]
					+( psi_f[IND_f(2*i-1,2*j+1,2*k-1)]*rhof0 + f_f[IND_f(2*i-1,2*j+1,2*k-1)]*rhof1 + (1.e0-f_f[IND_f(2*i-1,2*j+1,2*k-1)]-psi_f[IND_f(2*i-1,2*j+1,2*k-1)])*rhof2 ) * vnew_f[IND_f(2*i-1,2*j+1,2*k-1)]
					+( psi_f[IND_f(2*i,2*j+1,2*k-1)]*rhof0 + f_f[IND_f(2*i,2*j+1,2*k-1)]*rhof1 + (1.e0-f_f[IND_f(2*i,2*j+1,2*k-1)]-psi_f[IND_f(2*i,2*j+1,2*k-1)])*rhof2 ) * vnew_f[IND_f(2*i,2*j+1,2*k-1)];

			      rho_stgy[IJK]/= vnew_stgy[IJK];
			}
			      
			if(j>0 && i>0) {
				rho_stgz[IJK]= ( psi_f[IND_f(2*i,2*j,2*k)]*rhof0 + f_f[IND_f(2*i,2*j,2*k)]*rhof1 + (1.e0-f_f[IND_f(2*i,2*j,2*k)]-psi_f[IND_f(2*i,2*j,2*k)])*rhof2 ) * vnew_f[IND_f(2*i,2*j,2*k)]
					+( psi_f[IND_f(2*i-1,2*j,2*k)]*rhof0 + f_f[IND_f(2*i-1,2*j,2*k)]*rhof1 + (1.e0-f_f[IND_f(2*i-1,2*j,2*k)]-psi_f[IND_f(2*i-1,2*j,2*k)])*rhof2 ) * vnew_f[IND_f(2*i-1,2*j,2*k)]
					+( psi_f[IND_f(2*i-1,2*j-1,2*k)]*rhof0 + f_f[IND_f(2*i-1,2*j-1,2*k)]*rhof1 + (1.e0-f_f[IND_f(2*i-1,2*j-1,2*k)]-psi_f[IND_f(2*i-1,2*j-1,2*k)])*rhof2 ) * vnew_f[IND_f(2*i-1,2*j-1,2*k)]
					+( psi_f[IND_f(2*i,2*j-1,2*k)]*rhof0 + f_f[IND_f(2*i,2*j-1,2*k)]*rhof1 + (1.e0-f_f[IND_f(2*i,2*j-1,2*k)]-psi_f[IND_f(2*i,2*j-1,2*k)])*rhof2 ) * vnew_f[IND_f(2*i,2*j-1,2*k)]
					
					+( psi_f[IND_f(2*i,2*j,2*k+1)]*rhof0 + f_f[IND_f(2*i,2*j,2*k+1)]*rhof1 + (1.e0-f_f[IND_f(2*i,2*j,2*k+1)]-psi_f[IND_f(2*i,2*j,2*k+1)])*rhof2 ) * vnew_f[IND_f(2*i,2*j,2*k+1)]
					+( psi_f[IND_f(2*i-1,2*j,2*k+1)]*rhof0 + f_f[IND_f(2*i-1,2*j,2*k+1)]*rhof1 + (1.e0-f_f[IND_f(2*i-1,2*j,2*k+1)]-psi_f[IND_f(2*i-1,2*j,2*k+1)])*rhof2 ) * vnew_f[IND_f(2*i-1,2*j,2*k+1)]
					+( psi_f[IND_f(2*i-1,2*j-1,2*k+1)]*rhof0 + f_f[IND_f(2*i-1,2*j-1,2*k+1)]*rhof1 + (1.e0-f_f[IND_f(2*i-1,2*j-1,2*k+1)]-psi_f[IND_f(2*i-1,2*j-1,2*k+1)])*rhof2 ) * vnew_f[IND_f(2*i-1,2*j-1,2*k+1)]
					+( psi_f[IND_f(2*i,2*j-1,2*k+1)]*rhof0 + f_f[IND_f(2*i,2*j-1,2*k+1)]*rhof1 + (1.e0-f_f[IND_f(2*i,2*j-1,2*k+1)]-psi_f[IND_f(2*i,2*j-1,2*k+1)])*rhof2 ) * vnew_f[IND_f(2*i,2*j-1,2*k+1)];
							 
			      rho_stgz[IJK]/= vnew_stgz[IJK];
			}
		  }
#endif
}

double recons_2P(double xn, double yn, double zn, double fijkd, double epsi, int ijkd, int ijka) {
	double epsi1;
	double rlength=1.e0/sqrt(xn*xn+yn*yn+zn*zn+tiny);
	xn*=rlength;
	yn*=rlength;
	zn*=rlength;
	
	int iswap=0;
	double ofijkd = fijkd;
	
	if(fijkd>0.5)
	{
		fijkd=1.e0-fijkd;
		xn=-xn;
		yn=-yn;
		zn=-zn;
		iswap=1;
	}	
	
	double xnn=pow(fabs(xn),0.1) * SIGN(xn);
	double ynn=pow(fabs(yn),0.1) * SIGN(yn);
	double znn=pow(fabs(zn),0.1) * SIGN(zn);
	
	//uh-oh...uh.. do something random!
	//if (xnn==0.0) xnn+=em10;
	//if (ynn==0.0) ynn-=em10;
	//if (znn==0.0) znn+=em10;

	double p0=100.0;
	double p1=1000.0;
	double p2=10000.0;
	int m=0,m0=0,m1=0,m2=0;
	int ii,jj,kk;
	
	for (ii=0;ii<2;ii++)
		for (jj=0;jj<2;jj++)
			for (kk=0;kk<2;kk++)
			{
				m=4*ii+2*jj+kk+1;
                        pcorner[m-1]=xnn*ii+ynn*jj+znn*kk;
				if (!equal(pcorner[m-1],p0, TOL) && pcorner[m-1] < p0)
				{
					p2=p1;
					p1=p0;
					p0=pcorner[m-1];
					m2=m1;
					m1=m0;
					m0=m;
				}
				else if(!equal(pcorner[m-1],p1, TOL) && pcorner[m-1]<p1)
				{
					p2=p1;
					p1=pcorner[m-1];
					m2=m1;
					m1=m;
				}
				else if (!equal(pcorner[m-1],p2, TOL) && pcorner[m-1]<p2)
				{
					p2=pcorner[m-1];
					m2=m;
				}
                  }
                  
      //order the normals
	double absxn=fabs(xn);
	double absyn=fabs(yn);
	double abszn=fabs(zn);
				        
	n1=MIN(MIN(absxn,absyn),abszn);
	n3=MAX(MAX(absxn,absyn),abszn);
	n2=absxn+absyn+abszn-n1-n3;
	
	
	int m3=9+m0-m1-m2;
	int m1pm2=m1+m2;
	int m1pm3=m1+m3;
	int m2pm3=m2+m3;
	//if n2==0 then we approach four vertices simultaneously,
	//which means the m's might not make sense.
	if (!(m1pm2==5 || m1pm2==13 || m1pm3==5
	    || m1pm3==13 || m2pm3==5 || m2pm3==13) && n2 > em10)
	{
		printf ("p%2d: %d %d %d %d M MISMATCH %f %e %f %d  %d\n",mpi.MyRank,m0,m1,m2,m3,xn,yn,zn,ijkd,ijka);
		fprintf (files.error, "p%2d: %d %d %d %d M MISMATCH %f %f %f %d %d\n",mpi.MyRank,m0,m1,m2,m3,xn,yn,zn,ijkd,ijka);
	//                        exit(1);
	}
	
	int nzeroflags=0;
	if (n1 < em6) nzeroflags|=1;
	if (n2 < em6) nzeroflags|=2;
	if (n3 < em6) nzeroflags|=4;
	//note if modifying n1,n2,n3 to avoid division by zero (e.g. if (n1==0)n1=em6;) do so
	//after the nzeroflags have been set. (i.e. here.)
	if (nzeroflags&2)   //n2==0
	{
		isQuadB(epsi1,n1,n2,n3,epsi,fijkd,m1pm2,m1pm3,m2pm3);
	}
					  
	else if (nzeroflags&1)  //n1==0
	{
		n1=0.0; //in case n1 was modified to avoid division by zero. (e.g. n1=em6)
		if (isQuadA(epsi1,n1,n2,n3,epsi,fijkd,m1pm2,m1pm3,m2pm3)); 
		else isQuadB(epsi1,n1,n2,n3,epsi,fijkd,m1pm2,m1pm3,m2pm3); 
	}
	else
	{
		if (isTriangle(epsi1,n1,n2,n3,epsi,fijkd,m1pm2,m1pm3,m2pm3)); 
		else if (isQuadA(epsi1,n1,n2,n3,epsi,fijkd,m1pm2,m1pm3,m2pm3)); 
		else if (isPentagon(epsi1,n1,n2,n3,epsi,fijkd,m1pm2,m1pm3,m2pm3));
		else if (isHexagon(epsi1,n1,n2,n3,epsi,fijkd,m1pm2,m1pm3,m2pm3));
		else isQuadB(epsi1,n1,n2,n3,epsi,fijkd,m1pm2,m1pm3,m2pm3);
	}
	
	 //reconstruction finished by now ...epsi1 calculated
	if(iswap==1) epsi1=epsi-epsi1;
	if(fabs(epsi1)-epsi < em10 && fabs(epsi1)-epsi >=0.0 && epsi > em6) epsi1=epsi;
	if(fabs(epsi1)>epsi+tiny && epsi>em6)
	{
		printf ("DLY ERROR 1: %d %d %d %d %f %f\n", mpi.MyRank,ncyc, ijkd,ijka, epsi1, epsi);
		fprintf (files.error, "DLY ERROR 1: %d %d %d %d %f %f\n", mpi.MyRank,ncyc, ijkd,ijka, epsi1, epsi);
		epsi1=epsi;
	}
	if(fabs(epsi1)-ofijkd<em10 && fabs(epsi1)-ofijkd>=0.0) epsi1=ofijkd;
	if(fabs(epsi1)>ofijkd)
	{
		fprintf (files.error, "DLY ERROR 2: %d %d %d %d %f %f. Retrying...\n", mpi.MyRank,ncyc, ijkd,ijka, epsi1, ofijkd);
		printf ("DLY ERROR 2: %d %d %d %d %f %f. Retrying...\n", mpi.MyRank,ncyc, ijkd,ijka, epsi1, ofijkd);
		epsi1=ofijkd;
	}
	return epsi1;
}

#undef SIGN
	
#endif
