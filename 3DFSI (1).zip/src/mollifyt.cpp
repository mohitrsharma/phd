#include "ripple.h"
#include "comm.h"
#include <string.h> //memset
#include "testing.h"

/******************************************************************************


Subroutine MOLLIFYT is called by:	TENSION

Subroutine MOLLIFYT calls:			

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-addes 6 if conditions to check if the side walls	Ben			May 26 2005
 are "real" ghost cell walls or "virtual" walls
 Also added a condition which sets tensx, tensy
 tensz in obst. interface cells just like its done
 for ghost cells
-Commented a nonsensical line						Ben			May 25 2005
-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

void mollifyt()
{
	double *tensx = temp[0];
	double *tensy = temp[1];
	double *tensz = temp[2];
	double *txtilde = temp[3];
	double *tytilde = temp[4];
	double *tztilde = temp[5];
	int i,j,k;

	//strategy? - set tensx,tensy,tensz properly in all ghost
    //   cells, then do simple summation

	memset (txtilde, 0, NX*NY*NZ*sizeof(double));
	memset (tytilde, 0, NX*NY*NZ*sizeof(double));
	memset (tztilde, 0, NX*NY*NZ*sizeof(double));
	
	//start with the six sides, minus edges, remembering that forces
	//normal to a side reflect negatively
	//MPI: do this anyway. Data exchange later will overwrite.
		
		for (j=1;j<jm1;j++)
			for (k=1;k<km1;k++)
			{
				//left face
				tensx[IND(0,j,k)]=tensx[IND(1,j,k)];
				tensy[IND(0,j,k)]=tensy[IND(1,j,k)];
				tensz[IND(0,j,k)]=tensz[IND(1,j,k)];
				if (kl==1) tensx[IND(0,j,k)]=-tensx[IND(0,j,k)];
				//right face
				tensx[IND(im1,j,k)]=tensx[IND(im1-1,j,k)];
				tensy[IND(im1,j,k)]=tensy[IND(im1-1,j,k)];
				tensz[IND(im1,j,k)]=tensz[IND(im1-1,j,k)];
				if (kr==1) tensx[IND(im1,j,k)]=-tensx[IND(im1,j,k)];				
			}

		
		for (i=1;i<im1;i++)
			for (k=1;k<km1;k++)
			{
				//back face
				tensx[IND(i,0,k)]=tensx[IND(i,1,k)];
				tensy[IND(i,0,k)]=tensy[IND(i,1,k)];
				tensz[IND(i,0,k)]=tensz[IND(i,1,k)];
				if (kb==1) tensy[IND(i,0,k)]=-tensy[IND(i,0,k)];
				//front face
				tensx[IND(i,jm1,k)]=tensx[IND(i,jm1-1,k)];
				tensy[IND(i,jm1,k)]=tensy[IND(i,jm1-1,k)];
				tensz[IND(i,jm1,k)]=tensz[IND(i,jm1-1,k)];
				if (kf==1) tensy[IND(i,jm1,k)]=-tensy[IND(i,jm1,k)];				
			}

		
		for (i=1;i<im1;i++)
			for (j=1;j<jm1;j++)
			{
				//under face
				tensx[IND(i,j,0)]=tensx[IND(i,j,1)];
				tensy[IND(i,j,0)]=tensy[IND(i,j,1)];
				tensz[IND(i,j,0)]=tensz[IND(i,j,1)];
				if (ku==1) tensz[IND(i,j,0)] = -tensz[IND(i,j,0)];
				//over face
				tensx[IND(i,j,km1)]=tensx[IND(i,j,km1-1)];
				tensy[IND(i,j,km1)]=tensy[IND(i,j,km1-1)];
				tensz[IND(i,j,km1)]=tensz[IND(i,j,km1-1)];
				if (ko==1) tensz[IND(i,j,km1)]=-tensz[IND(i,j,km1)];				
			}
		
#ifndef no_obs
	xchg<double> (tensx); //communicate before copy into obstacle cells
	xchg<double> (tensy);
	xchg<double> (tensz);
#endif
    /*copy tens_ into obstacle surface cells*/
	if( mpi.obst_flag )
	{	

		mollifytobs(tensx,tensy,tensz);	
	}
					
/*... now worry about the 12 edges of the grid, remembering that
       when two reflective sides meet, two normals get 
       turned around; when one solid and one reflective 
       side meet, one normal gets turned around

	MPI: do this anyway. Data exchange later will overwrite data.
*/
	for (i=1;i<im1;i++)
	{
		tensx[IND(i,0,0)]=tensx[IND(i,1,1)];
		tensy[IND(i,0,0)]=tensy[IND(i,1,1)];
		tensz[IND(i,0,0)]=tensz[IND(i,1,1)];
		if (kb==1) tensy[IND(i,0,0)]=-tensy[IND(i,0,0)];
		if (ku==1) tensz[IND(i,0,0)]=-tensz[IND(i,0,0)];
		tensx[IND(i,jm1,0)]=tensx[IND(i,jm1-1,1)];
		tensy[IND(i,jm1,0)]=tensy[IND(i,jm1-1,1)];
		tensz[IND(i,jm1,0)]=tensz[IND(i,jm1-1,1)];
		if (kf==1) tensy[IND(i,jm1,0)]=-tensy[IND(i,jm1,0)];
		if (ku==1) tensz[IND(i,jm1,0)]=-tensz[IND(i,jm1,0)];
		tensx[IND(i,0,km1)]=tensx[IND(i,1,km1-1)];
		tensy[IND(i,0,km1)]=tensy[IND(i,1,km1-1)];
		tensz[IND(i,0,km1)]=tensz[IND(i,1,km1-1)];
		if (kb==1) tensy[IND(i,0,km1)]=-tensy[IND(i,0,km1)];
		if (ko==1) tensz[IND(i,0,km1)]=-tensz[IND(i,0,km1)];
		tensx[IND(i,jm1,km1)]=tensx[IND(i,jm1-1,km1-1)];
		tensy[IND(i,jm1,km1)]=tensy[IND(i,jm1-1,km1-1)];
		tensz[IND(i,jm1,km1)]=tensz[IND(i,jm1-1,km1-1)];
		if (kf==1) tensy[IND(i,jm1,km1)]=-tensy[IND(i,jm1,km1)];
		if (ko==1) tensz[IND(i,jm1,km1)]=-tensz[IND(i,jm1,km1)];
	}
	for (j=1;j<jm1;j++)
	{
		tensx[IND(0,j,0)]=tensx[IND(1,j,1)];
		tensy[IND(0,j,0)]=tensy[IND(1,j,1)];
		tensz[IND(0,j,0)]=tensz[IND(1,j,1)];
		if (kl==1) tensx[IND(0,j,0)]=-tensx[IND(0,j,0)];
		if (ku==1) tensz[IND(0,j,0)]=-tensz[IND(0,j,0)];
		tensx[IND(im1,j,0)]=tensx[IND(im1-1,j,1)];
		tensy[IND(im1,j,0)]=tensy[IND(im1-1,j,1)];
		tensz[IND(im1,j,0)]=tensz[IND(im1-1,j,1)];
		if (kr==1) tensx[IND(im1,j,0)]=-tensx[IND(im1,j,0)];
		if (ku==1) tensz[IND(im1,j,0)]=-tensz[IND(im1,j,0)];
		tensx[IND(0,j,km1)]=tensx[IND(1,j,km1-1)];
		tensy[IND(0,j,km1)]=tensy[IND(1,j,km1-1)];
		tensz[IND(0,j,km1)]=tensz[IND(1,j,km1-1)];
		if (kl==1) tensx[IND(0,j,km1)]=-tensx[IND(0,j,km1)];
		if (ko==1) tensz[IND(0,j,km1)]=-tensz[IND(0,j,km1)];
		tensx[IND(im1,j,km1)]=tensx[IND(im1-1,j,km1-1)];
		tensy[IND(im1,j,km1)]=tensy[IND(im1-1,j,km1-1)];
		tensz[IND(im1,j,km1)]=tensz[IND(im1-1,j,km1-1)];
		if (kr==1) tensx[IND(im1,j,km1)]=-tensx[IND(im1,j,km1)];
		if (ko==1) tensz[IND(im1,j,km1)]=-tensz[IND(im1,j,km1)];
	}
	for (k=1;k<km1;k++)
	{
		tensx[IND(0,0,k)]=tensx[IND(1,1,k)];
		tensy[IND(0,0,k)]=tensy[IND(1,1,k)];
		tensz[IND(0,0,k)]=tensz[IND(1,1,k)];
		if (kl==1) tensx[IND(0,0,k)]=-tensx[IND(0,0,k)];
		if (kb==1) tensy[IND(0,0,k)]=-tensy[IND(0,0,k)];
		tensx[IND(im1,0,k)]=tensx[IND(im1-1,1,k)];
		tensy[IND(im1,0,k)]=tensy[IND(im1-1,1,k)];
		tensz[IND(im1,0,k)]=tensz[IND(im1-1,1,k)];
		if (kr==1) tensx[IND(im1,0,k)]=-tensx[IND(im1,0,k)];
		if (kb==1) tensy[IND(im1,0,k)]=-tensy[IND(im1,0,k)];
		tensx[IND(0,jm1,k)]=tensx[IND(1,jm1-1,k)];
		tensy[IND(0,jm1,k)]=tensy[IND(1,jm1-1,k)];
		tensz[IND(0,jm1,k)]=tensz[IND(1,jm1-1,k)];
		if (kl==1) tensx[IND(0,jm1,k)]=-tensx[IND(0,jm1,k)];
		if (kf==1) tensy[IND(0,jm1,k)]=-tensy[IND(0,jm1,k)];
		tensx[IND(im1,jm1,k)]=tensx[IND(im1-1,jm1-1,k)];
		tensy[IND(im1,jm1,k)]=tensy[IND(im1-1,jm1-1,k)];
		tensz[IND(im1,jm1,k)]=tensz[IND(im1-1,jm1-1,k)];
		if (kr==1) tensx[IND(im1,jm1,k)]=-tensx[IND(im1,jm1,k)];
		if (kf==1) tensy[IND(im1,jm1,k)]=-tensy[IND(im1,jm1,k)];
	}

	//finally deal with the eight corner cells
	//MPI: do this anyway. Data exchange later will overwrite.
	tensx[IND(0,0,0)]=tensx[IND(1,1,1)];
	tensy[IND(0,0,0)]=tensy[IND(1,1,1)];
	tensz[IND(0,0,0)]=tensz[IND(1,1,1)];
	if (kl==1) tensx[IND(0,0,0)]=-tensx[IND(0,0,0)];
	if (kb==1) tensy[IND(0,0,0)]=-tensy[IND(0,0,0)];
	if (ku==1) tensz[IND(0,0,0)]=-tensz[IND(0,0,0)];

	tensx[IND(im1,0,0)]=tensx[IND(im1-1,1,1)];
	tensy[IND(im1,0,0)]=tensy[IND(im1-1,1,1)];
	tensz[IND(im1,0,0)]=tensz[IND(im1-1,1,1)];
	if (kr==1) tensx[IND(im1,0,0)]=-tensx[IND(im1,0,0)];
	if (kb==1) tensy[IND(im1,0,0)]=-tensy[IND(im1,0,0)];
	if (ku==1) tensz[IND(im1,0,0)]=-tensz[IND(im1,0,0)];

	tensx[IND(0,jm1,0)]=tensx[IND(1,jm1-1,1)];
	tensy[IND(0,jm1,0)]=tensy[IND(1,jm1-1,1)];
	tensz[IND(0,jm1,0)]=tensz[IND(1,jm1-1,1)];
	if (kl==1) tensx[IND(0,jm1,0)]=-tensx[IND(0,jm1,0)];
	if (kf==1) tensy[IND(0,jm1,0)]=-tensy[IND(0,jm1,0)];
	if (ku==1) tensz[IND(0,jm1,0)]=-tensz[IND(0,jm1,0)];

	tensx[IND(im1,jm1,0)]=tensx[IND(im1-1,jm1-1,1)];
	tensy[IND(im1,jm1,0)]=tensy[IND(im1-1,jm1-1,1)];
	tensz[IND(im1,jm1,0)]=tensz[IND(im1-1,jm1-1,1)];
	if (kr==1) tensx[IND(im1,jm1,0)]=-tensx[IND(im1,jm1,0)];
	if (kf==1) tensy[IND(im1,jm1,0)]=-tensy[IND(im1,jm1,0)];
	if (ku==1) tensz[IND(im1,jm1,0)]=-tensz[IND(im1,jm1,0)];

	tensx[IND(0,0,km1)]=tensx[IND(1,1,km1-1)];
	tensy[IND(0,0,km1)]=tensy[IND(1,1,km1-1)];
	tensz[IND(0,0,km1)]=tensz[IND(1,1,km1-1)];
	if (kl==1) tensx[IND(0,0,km1)]=-tensx[IND(0,0,km1)];
	if (kb==1) tensy[IND(0,0,km1)]=-tensy[IND(0,0,km1)];
	if (ko==1) tensz[IND(0,0,km1)]=-tensz[IND(0,0,km1)];

	tensx[IND(im1,0,km1)]=tensx[IND(im1-1,1,km1-1)];
	tensy[IND(im1,0,km1)]=tensy[IND(im1-1,1,km1-1)];
	tensz[IND(im1,0,km1)]=tensz[IND(im1-1,1,km1-1)];
	if (kr==1) tensx[IND(im1,0,km1)]=-tensx[IND(im1,0,km1)];
	if (kb==1) tensy[IND(im1,0,km1)]=-tensy[IND(im1,0,km1)];
	if (ko==1) tensz[IND(im1,0,km1)]=-tensz[IND(im1,0,km1)];

	tensx[IND(0,jm1,km1)]=tensx[IND(1,jm1-1,km1-1)];
	tensy[IND(0,jm1,km1)]=tensy[IND(1,jm1-1,km1-1)];
	tensz[IND(0,jm1,km1)]=tensz[IND(1,jm1-1,km1-1)];
	if (kl==1) tensx[IND(0,jm1,km1)]=-tensx[IND(0,jm1,km1)];
	if (kf==1) tensy[IND(0,jm1,km1)]=-tensy[IND(0,jm1,km1)];
	if (ko==1) tensz[IND(0,jm1,km1)]=-tensz[IND(0,jm1,km1)];

	tensx[IND(im1,jm1,km1)]=tensx[IND(im1-1,jm1-1,km1-1)];
	tensy[IND(im1,jm1,km1)]=tensy[IND(im1-1,jm1-1,km1-1)];
	tensz[IND(im1,jm1,km1)]=tensz[IND(im1-1,jm1-1,km1-1)];
	if (kr==1) tensx[IND(im1,jm1,km1)]=-tensx[IND(im1,jm1,km1)];
	if (kf==1) tensy[IND(im1,jm1,km1)]=-tensy[IND(im1,jm1,km1)];
	if (ko==1) tensz[IND(im1,jm1,km1)]=-tensz[IND(im1,jm1,km1)];

	//MPI: exchange data. (note directions are 1-based: 1-6.)
    xchg<double> (tensx);
    xchg<double> (tensy);
    xchg<double> (tensz);

	//tensx,tensy,tensz valid in ghost cells.
	for (i=1;i<im1;i++)
		for (j=1;j<jm1;j++)
			for (k=1;k<km1;k++)
			{
				txtilde[IJK]=0.272763484095e+0*tensx[IJK]
							+0.817880197305e-1*(tensx[IPJK]+tensx[IMJK]
							+tensx[IJPK]+tensx[IJMK]+tensx[IJKP]
							+tensx[IJKM])+0.178706656436e-1*(tensx[IPJPK]
							+tensx[IMJPK]+tensx[IPJMK]+tensx[IMJMK]
							+tensx[IJPKP]+tensx[IJMKP]+tensx[IJPKM]
							+tensx[IJMKM]+tensx[IPJKP]+tensx[IPJKM]
							+tensx[IMJKP]+tensx[IMJKM])
							+0.275755122485e-2*(tensx[IPJPKP]+tensx[IMJPKP]
							+tensx[IPJMKP]+tensx[IMJMKP]+tensx[IPJPKM]
							+tensx[IMJPKM]+tensx[IPJMKM]+tensx[IMJMKM]);
				tytilde[IJK]=0.272763484095e+0*tensy[IJK]
                          	+.817880197305e-1*(tensy[IPJK]+tensy[IMJK]
                          	+tensy[IJPK]+tensy[IJMK]+tensy[IJKP]
                          	+tensy[IJKM])+0.178706656436e-1*(tensy[IPJPK]
                          	+tensy[IMJPK]+tensy[IPJMK]+tensy[IMJMK]
                          	+tensy[IJPKP]+tensy[IJMKP]+tensy[IJPKM]
                          	+tensy[IJMKM]+tensy[IPJKP]+tensy[IPJKM]
                          	+tensy[IMJKP]+tensy[IMJKM])
                          	+0.275755122485e-2*(tensy[IPJPKP]+tensy[IMJPKP]
                          	+tensy[IPJMKP]+tensy[IMJMKP]+tensy[IPJPKM]
                          	+tensy[IMJPKM]+tensy[IPJMKM]+tensy[IMJMKM]);
				tztilde[IJK]=0.272763484095e+0*tensz[IJK]
                	        +0.817880197305e-1*(tensz[IPJK]+tensz[IMJK]
                    	    +tensz[IJPK]+tensz[IJMK]+tensz[IJKP]
                        	+tensz[IJKM])+0.178706656436e-1*(tensz[IPJPK]
	                        +tensz[IMJPK]+tensz[IPJMK]+tensz[IMJMK]
    	                    +tensz[IJPKP]+tensz[IJMKP]+tensz[IJPKM]
        	                +tensz[IJMKM]+tensz[IPJKP]+tensz[IPJKM]
            	            +tensz[IMJKP]+tensz[IMJKM])
                	        +0.275755122485e-2*(tensz[IPJPKP]+tensz[IMJPKP]
                    	    +tensz[IPJMKP]+tensz[IMJMKP]+tensz[IPJPKM]
                        	+tensz[IMJPKM]+tensz[IPJMKM]+tensz[IMJMKM]);
			}
	//exchange txtilde, tytilde, tztilde
    xchg<double> (txtilde);
    xchg<double> (tytilde);
    xchg<double> (tztilde);
}
