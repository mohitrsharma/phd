#include "ripple.h"
#include "testing.h"
#include "comm.h"
#include <math.h>
#include <string.h> //memcpy

/******************************************************************************


Subroutine NORMALS is called by:	SETUP, VOFDLY

Subroutine NORMALS calls:	AREA, CANGLE, MOLLIFYT

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION                                         NAME        DATE

-Added a call to exhange gradrox_'s before cal-     Ben        July 25 2006
 culating avn_'s because I noticed this was causing
 parallel results to be different from serial ones
-Commented the part which sets the normal at the    Ben         July 19 2006
 point of impact straight down.  I find it compli-
 cates things when I use MPI and it is not in any
 other version other than Markus's
-Uncommented a line labeld "for whole droplet" and  Ben         May 24 2005
 commented line labeled "for quarter droplet"
-Created this template for tracking changes         Ben         April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION                                         NAME        DATE


*******************************************************************************/

void normals()
{
	double *ftilde = temp[0];
	int i,j,k;

    /*
    ** This is a 3x3x3 mollify
    */
    for (k=1;k<km1;k++)
		for (j=1;j<jm1;j++)
			for (i=1;i<im1;i++)
			{
				const double temp = 0.2728665*f[IJK]+0.0818442*(f[IPJK]+f[IMJK]
					+f[IJPK]+f[IJMK]+f[IJKP]+f[IJKM])+0.0178215
                    *(f[IPJPK]+f[IMJPK]+f[IPJMK]+f[IMJMK]
                    +f[IJPKP]+f[IJMKP]+f[IJPKM]+f[IJMKM]+f[IPJKP]
                    +f[IPJKM]+f[IMJKP]+f[IMJKM])+0.0027763
                    *(f[IPJPKP]+f[IMJPKP]+f[IPJMKP]+f[IMJMKP]
                    +f[IPJPKM]+f[IMJPKM]+f[IPJMKM]+f[IMJMKM]);
				ftilde[IJK]=temp;
			}

	/*
    ** Copy ftilde into ghost cells
    */
	if (mpi.Neighbors[0] == -1)            /* If not a virtual boundary on the left */
		for (k = 0; k < kmax; k++)
			for (j = 0; j < jmax; j++)
				ftilde[IND(0, j, k)] = ftilde[IND(1, j, k)];

    if (mpi.Neighbors[1] == -1)            /* If not a virtual boundary on the right */
		for (k = 0; k < kmax; k++)
			for (j = 0; j < jmax; j++)
				ftilde[IND(im1, j, k)] = ftilde[IND(im1-1, j, k)];

    if (mpi.Neighbors[2] == -1)              /* If not a virtual boundary on the back */
		for (k = 0; k < kmax; k++)
			for (i = 0; i < imax; i++)
				ftilde[IND(i, 0, k)] = ftilde[IND(i, 1, k)];

    if (mpi.Neighbors[3] == -1)              /* If not a virtual boundary on the front */
		for (k = 0; k < kmax; k++)
			for (i = 0; i < imax; i++)
				ftilde[IND(i, jm1, k)] = ftilde[IND(i, jm1-1, k)];

    if (mpi.Neighbors[4] == -1)              /* If not a virtual boundary on the under */
		for (j = 0; j < jmax; j++)
			for (i = 0; i < imax; i++)
				ftilde[IND(i, j, 0)] = ftilde[IND(i, j, 1)];

    if (mpi.Neighbors[5] == -1)              /* Iff not a virtual boundary on the over */
		for (j = 0; j < jmax; j++)
			for (i = 0; i < imax; i++)
				ftilde[IND(i, j, km1)] = ftilde[IND(i, j, km1-1)];

    /*
    ** Copy ftilde in obstacle interface cells
    */
#ifndef no_obs
	xchg<double> (ftilde);
#endif
    if(mpi.obst_flag)
    {

		normalsobs(ftilde);
    }
    /*
    ** exchange ftilde with neighbors
    */
    xchg<double> (ftilde);

    /*
    ** compute vertex-centered normal vectors
    */
   
    
    for (k=1;k<kmax;k++)
		for (j=1;j<jmax;j++)
			for (i=1;i<imax;i++)
			{
				const double rhor=((rho[IJMKM]+rho[IJKM]+rho[IJMK]+rho[IJK])/4.0)
					*(delz[k]*(dely[j]*ftilde[IJMKM]+dely[j-1]
					*ftilde[IJKM])+delz[k-1]*(dely[j]*ftilde[IJMK]
					+dely[j-1]*ftilde[IJK]))/((delz[k]+delz[k-1])
					*(dely[j]+dely[j-1]));
				const double rhol=((rho[IMJMKM]+rho[IMJKM]+rho[IMJMK]+rho[IMJK])/4.0)
					*(delz[k]*(dely[j]*ftilde[IMJMKM]+dely[j-1]
					*ftilde[IMJKM])+delz[k-1]*(dely[j]*ftilde[IMJMK]
					+dely[j-1]*ftilde[IMJK]))/((delz[k]+delz[k-1])
					*(dely[j]+dely[j-1]));
				const double rhot=((rho[IMJKM]+rho[IMJK]+rho[IJKM]+rho[IJK])/4.0)
					*(delx[i]*(delz[k]*ftilde[IMJKM]+delz[k-1]
					*ftilde[IMJK])+delx[i-1]*(delz[k]*ftilde[IJKM]
					+delz[k-1]*ftilde[IJK]))/((delz[k]+delz[k-1])
					*(delx[i]+delx[i-1]));
				const double rhob=((rho[IMJMKM]+rho[IMJMK]+rho[IJMKM]+rho[IJMK])/4.0)
					*(delx[i]*(delz[k]*ftilde[IMJMKM]+delz[k-1]
					*ftilde[IMJMK])+delx[i-1]*(delz[k]*ftilde[IJMKM]
					+delz[k-1]*ftilde[IJMK]))/((delz[k]+delz[k-1])
					*(delx[i]+delx[i-1]));
				const double rhoo=((rho[IMJMK]+rho[IMJK]+rho[IJMK]+rho[IJK])/4.0)
					*(delx[i]*(dely[j]*ftilde[IMJMK]+dely[j-1]
					*ftilde[IMJK])+delx[i-1]*(dely[j]*ftilde[IJMK]
					+dely[j-1]*ftilde[IJK]))/((dely[j]+dely[j-1])
					*(delx[i]+delx[i-1]));
				const double rhou=((rho[IMJMKM]+rho[IMJKM]+rho[IJMKM]+rho[IJKM])/4.0)
					*(delx[i]*(dely[j]*ftilde[IMJMKM]+dely[j-1]
					*ftilde[IMJKM])+delx[i-1]*(dely[j]*ftilde[IJMKM]
					+dely[j-1]*ftilde[IJKM]))/((dely[j]+dely[j-1])
					*(delx[i]+delx[i-1]));

				gradrox[IJK]=(rhor-rhol)*rdelxl[i];
				gradroy[IJK]=(rhot-rhob)*rdelyb[j];
				gradroz[IJK]=(rhoo-rhou)*rdelzu[k];
			}
    /*
    ** Apply contact angles
    */
     
#ifdef impose_CA    
    CA_Under();     /* apply to k = 1 face */
#endif
    	
	/*
    ** Compute AVNX, AVNY, AVNZ
    */
    for(k=1;k<km1;k++)
		for(j=1;j<jm1;j++)
			for(i=1;i<im1;i++)
			{
				avnx[IJK]=(gradrox[IPJK]+gradrox[IPJPK]
					+gradrox[IJPK]+gradrox[IJK]+gradrox[IPJKP]
					+gradrox[IPJPKP]+gradrox[IJPKP]+gradrox[IJKP]) / 8.0;
				avny[IJK]=(gradroy[IPJK]+gradroy[IPJPK]
					+gradroy[IJPK]+gradroy[IJK]+gradroy[IPJKP]
					+gradroy[IPJPKP]+gradroy[IJPKP]+gradroy[IJKP]) / 8.0;
				avnz[IJK]=(gradroz[IPJK]+gradroz[IPJPK]
					+gradroz[IJPK]+gradroz[IJK]+gradroz[IPJKP]
					+gradroz[IPJPKP]+gradroz[IJPKP]+gradroz[IJKP]) / 8.0;
			}
	/*
     * Since in VOFDLY we loop from i=0 to i<im1 etc...
	 * it is necessary to copy avn_'s from i=1 plane to i=0 plane
	 * and same for other components...but only if the boundary is real
 	 */
	if (kl > 2 && mpi.Neighbors[0] == -1)
	{
		for (k=1;k<km1;k++)
			for (j=1;j<jm1;j++)
			{
				avnx[IND(0,j,k)]=avnx[IND(1,j,k)];
				avny[IND(0,j,k)]=avny[IND(1,j,k)];
				avnz[IND(0,j,k)]=avnz[IND(1,j,k)];
			}
	}
	if (kr > 2 && mpi.Neighbors[1] == -1)
	{
		for (k=1;k<km1;k++)
			for (j=1;j<jm1;j++)
		{
			avnx[IND(im1,j,k)]=avnx[IND(im2,j,k)];
			avny[IND(im1,j,k)]=avny[IND(im2,j,k)];
			avnz[IND(im1,j,k)]=avnz[IND(im2,j,k)];
		}
	}
	if (kb > 2 && mpi.Neighbors[2] == -1)
	{
		for (k=1;k<km1;k++)
			for (i=1;i<imax;i++)
			{
				avnx[IND(i,0,k)]=avnx[IND(i,1,k)];
				avny[IND(i,0,k)]=avnx[IND(i,1,k)];
				avnz[IND(i,0,k)]=avnx[IND(i,1,k)];
			}
	}
	if (kf > 2 && mpi.Neighbors[3] == -1)
	{
		for (k=1;k<km1;k++)
			for (i=1;i<imax;i++)
		{
			avnx[IND(i,jm1,k)]=avnx[IND(i,jm2,k)];
			avny[IND(i,jm1,k)]=avnx[IND(i,jm2,k)];
			avnz[IND(i,jm1,k)]=avnx[IND(i,jm2,k)];
		}
	}
	if (ku > 2 && mpi.Neighbors[4] == -1)
	{
		memcpy (&avnx[IND(0,0,0)], &avnx[IND(0,0,1)], NX*NY*sizeof(double));
		memcpy (&avny[IND(0,0,0)], &avny[IND(0,0,1)], NX*NY*sizeof(double));
		memcpy (&avnz[IND(0,0,0)], &avnz[IND(0,0,1)], NX*NY*sizeof(double));
	}
	if (ko > 2 && mpi.Neighbors[5] == -1)
	{
		memcpy (&avnx[IND(0,0,km1)], &avnx[IND(0,0,km2)], NX*NY*sizeof(double));
		memcpy (&avny[IND(0,0,km1)], &avny[IND(0,0,km2)], NX*NY*sizeof(double));
		memcpy (&avnz[IND(0,0,km1)], &avnz[IND(0,0,km2)], NX*NY*sizeof(double));
	}

	/*
    ** Exchange normals
    */
	xchg<double> (avnx);
	xchg<double> (avny);
	xchg<double> (avnz);

	/*
    ** Normalize the normal vectors
    */
	for (k=1;k<kmax;k++)
		for (j=1;j<jmax;j++)
			for (i=1;i<imax;i++)
			{
				const double rgradmag=1.0/sqrt(SQUARE(gradrox[IJK])+SQUARE(gradroy[IJK])+SQUARE(gradroz[IJK])+tiny);
				gradrox[IJK] *= rgradmag;
				gradroy[IJK] *= rgradmag;
				gradroz[IJK] *= rgradmag;
			}


	/*
    ** Exchange gradro_ arrays
    */
	arecvplane<double> (gradrox, 1);
	arecvplane<double> (gradroy, 1);
	arecvplane<double> (gradroz, 1);
	sendplane<double> (gradrox, 2);
	sendplane<double> (gradroy, 2);
	sendplane<double> (gradroz, 2);
	arecvspacewait();
	arecvplane<double> (gradrox, 3);
	arecvplane<double> (gradroy, 3);
	arecvplane<double> (gradroz, 3);
	sendplane<double> (gradrox, 4);
	sendplane<double> (gradroy, 4);
	sendplane<double> (gradroz, 4);
	arecvspacewait();
	arecvplane<double> (gradrox, 5);
	arecvplane<double> (gradroy, 5);
	arecvplane<double> (gradroz, 5);
	sendplane<double> (gradrox, 6);
	sendplane<double> (gradroy, 6);
	sendplane<double> (gradroz, 6);
	arecvspacewait();
}

void normals_fvirt_curvature( double *fvirt )
{
	double *ftilde = temp[0];
	int i,j,k;

    /*
    ** This is a 3x3x3 mollify
    */
    for (k=1;k<km1;k++)
		for (j=1;j<jm1;j++)
			for (i=1;i<im1;i++)
			{
				const double temp = 0.2728665*fvirt[IJK]+0.0818442*(fvirt[IPJK]+fvirt[IMJK]
					+fvirt[IJPK]+fvirt[IJMK]+fvirt[IJKP]+fvirt[IJKM])+0.0178215
                    *(fvirt[IPJPK]+fvirt[IMJPK]+fvirt[IPJMK]+fvirt[IMJMK]
                    +fvirt[IJPKP]+fvirt[IJMKP]+fvirt[IJPKM]+fvirt[IJMKM]+fvirt[IPJKP]
                    +fvirt[IPJKM]+fvirt[IMJKP]+fvirt[IMJKM])+0.0027763
                    *(fvirt[IPJPKP]+fvirt[IMJPKP]+fvirt[IPJMKP]+fvirt[IMJMKP]
                    +fvirt[IPJPKM]+fvirt[IMJPKM]+fvirt[IPJMKM]+fvirt[IMJMKM]);
				ftilde[IJK]=temp;
			}

	/*
    ** Copy ftilde into ghost cells
    */
	if (mpi.Neighbors[0] == -1)            /* If not a virtual boundary on the left */
		for (k = 0; k < kmax; k++)
			for (j = 0; j < jmax; j++)
				ftilde[IND(0, j, k)] = ftilde[IND(1, j, k)];

    if (mpi.Neighbors[1] == -1)            /* If not a virtual boundary on the right */
		for (k = 0; k < kmax; k++)
			for (j = 0; j < jmax; j++)
				ftilde[IND(im1, j, k)] = ftilde[IND(im1-1, j, k)];

    if (mpi.Neighbors[2] == -1)              /* If not a virtual boundary on the back */
		for (k = 0; k < kmax; k++)
			for (i = 0; i < imax; i++)
				ftilde[IND(i, 0, k)] = ftilde[IND(i, 1, k)];

    if (mpi.Neighbors[3] == -1)              /* If not a virtual boundary on the front */
		for (k = 0; k < kmax; k++)
			for (i = 0; i < imax; i++)
				ftilde[IND(i, jm1, k)] = ftilde[IND(i, jm1-1, k)];

    if (mpi.Neighbors[4] == -1)              /* If not a virtual boundary on the under */
		for (j = 0; j < jmax; j++)
			for (i = 0; i < imax; i++)
				ftilde[IND(i, j, 0)] = ftilde[IND(i, j, 1)];

    if (mpi.Neighbors[5] == -1)              /* Iff not a virtual boundary on the over */
		for (j = 0; j < jmax; j++)
			for (i = 0; i < imax; i++)
				ftilde[IND(i, j, km1)] = ftilde[IND(i, j, km1-1)];

    /*
    ** Copy ftilde in obstacle interface cells
    */
#ifndef no_obs
	xchg<double> (ftilde);
#endif
    if(mpi.obst_flag)
    {

		normalsobs(ftilde);
    }
    /*
    ** exchange ftilde with neighbors
    */
    xchg<double> (ftilde);

    /*
    ** compute vertex-centered normal vectors
    */
   
    
    for (k=1;k<kmax;k++)
		for (j=1;j<jmax;j++)
			for (i=1;i<imax;i++)
			{
				const double rhor=((rho[IJMKM]+rho[IJKM]+rho[IJMK]+rho[IJK])/4.0)
					*(delz[k]*(dely[j]*ftilde[IJMKM]+dely[j-1]
					*ftilde[IJKM])+delz[k-1]*(dely[j]*ftilde[IJMK]
					+dely[j-1]*ftilde[IJK]))/((delz[k]+delz[k-1])
					*(dely[j]+dely[j-1]));
				const double rhol=((rho[IMJMKM]+rho[IMJKM]+rho[IMJMK]+rho[IMJK])/4.0)
					*(delz[k]*(dely[j]*ftilde[IMJMKM]+dely[j-1]
					*ftilde[IMJKM])+delz[k-1]*(dely[j]*ftilde[IMJMK]
					+dely[j-1]*ftilde[IMJK]))/((delz[k]+delz[k-1])
					*(dely[j]+dely[j-1]));
				const double rhot=((rho[IMJKM]+rho[IMJK]+rho[IJKM]+rho[IJK])/4.0)
					*(delx[i]*(delz[k]*ftilde[IMJKM]+delz[k-1]
					*ftilde[IMJK])+delx[i-1]*(delz[k]*ftilde[IJKM]
					+delz[k-1]*ftilde[IJK]))/((delz[k]+delz[k-1])
					*(delx[i]+delx[i-1]));
				const double rhob=((rho[IMJMKM]+rho[IMJMK]+rho[IJMKM]+rho[IJMK])/4.0)
					*(delx[i]*(delz[k]*ftilde[IMJMKM]+delz[k-1]
					*ftilde[IMJMK])+delx[i-1]*(delz[k]*ftilde[IJMKM]
					+delz[k-1]*ftilde[IJMK]))/((delz[k]+delz[k-1])
					*(delx[i]+delx[i-1]));
				const double rhoo=((rho[IMJMK]+rho[IMJK]+rho[IJMK]+rho[IJK])/4.0)
					*(delx[i]*(dely[j]*ftilde[IMJMK]+dely[j-1]
					*ftilde[IMJK])+delx[i-1]*(dely[j]*ftilde[IJMK]
					+dely[j-1]*ftilde[IJK]))/((dely[j]+dely[j-1])
					*(delx[i]+delx[i-1]));
				const double rhou=((rho[IMJMKM]+rho[IMJKM]+rho[IJMKM]+rho[IJKM])/4.0)
					*(delx[i]*(dely[j]*ftilde[IMJMKM]+dely[j-1]
					*ftilde[IMJKM])+delx[i-1]*(dely[j]*ftilde[IJMKM]
					+dely[j-1]*ftilde[IJKM]))/((dely[j]+dely[j-1])
					*(delx[i]+delx[i-1]));

				gradrox[IJK]=(rhor-rhol)*rdelxl[i];
				gradroy[IJK]=(rhot-rhob)*rdelyb[j];
				gradroz[IJK]=(rhoo-rhou)*rdelzu[k];
			}
	
    /*
    ** Apply contact angles
    */
     
#ifdef impose_CA    
    CA_Under();     /* apply to k = 1 face */
#endif
    	
	/*
    ** Compute AVNX, AVNY, AVNZ
    */
    for(k=1;k<km1;k++)
		for(j=1;j<jm1;j++)
			for(i=1;i<im1;i++)
			{
				avnx[IJK]=(gradrox[IPJK]+gradrox[IPJPK]
					+gradrox[IJPK]+gradrox[IJK]+gradrox[IPJKP]
					+gradrox[IPJPKP]+gradrox[IJPKP]+gradrox[IJKP]) / 8.0;
				avny[IJK]=(gradroy[IPJK]+gradroy[IPJPK]
					+gradroy[IJPK]+gradroy[IJK]+gradroy[IPJKP]
					+gradroy[IPJPKP]+gradroy[IJPKP]+gradroy[IJKP]) / 8.0;
				avnz[IJK]=(gradroz[IPJK]+gradroz[IPJPK]
					+gradroz[IJPK]+gradroz[IJK]+gradroz[IPJKP]
					+gradroz[IPJPKP]+gradroz[IJPKP]+gradroz[IJKP]) / 8.0;
			}
	/*
     * Since in VOFDLY we loop from i=0 to i<im1 etc...
	 * it is necessary to copy avn_'s from i=1 plane to i=0 plane
	 * and same for other components...but only if the boundary is real
 	 */
	if (kl > 2 && mpi.Neighbors[0] == -1)
	{
		for (k=1;k<km1;k++)
			for (j=1;j<jm1;j++)
			{
				avnx[IND(0,j,k)]=avnx[IND(1,j,k)];
				avny[IND(0,j,k)]=avny[IND(1,j,k)];
				avnz[IND(0,j,k)]=avnz[IND(1,j,k)];
			}
	}
	if (kr > 2 && mpi.Neighbors[1] == -1)
	{
		for (k=1;k<km1;k++)
			for (j=1;j<jm1;j++)
		{
			avnx[IND(im1,j,k)]=avnx[IND(im2,j,k)];
			avny[IND(im1,j,k)]=avny[IND(im2,j,k)];
			avnz[IND(im1,j,k)]=avnz[IND(im2,j,k)];
		}
	}
	if (kb > 2 && mpi.Neighbors[2] == -1)
	{
		for (k=1;k<km1;k++)
			for (i=1;i<imax;i++)
			{
				avnx[IND(i,0,k)]=avnx[IND(i,1,k)];
				avny[IND(i,0,k)]=avnx[IND(i,1,k)];
				avnz[IND(i,0,k)]=avnx[IND(i,1,k)];
			}
	}
	if (kf > 2 && mpi.Neighbors[3] == -1)
	{
		for (k=1;k<km1;k++)
			for (i=1;i<imax;i++)
		{
			avnx[IND(i,jm1,k)]=avnx[IND(i,jm2,k)];
			avny[IND(i,jm1,k)]=avnx[IND(i,jm2,k)];
			avnz[IND(i,jm1,k)]=avnx[IND(i,jm2,k)];
		}
	}
	if (ku > 2 && mpi.Neighbors[4] == -1)
	{
		memcpy (&avnx[IND(0,0,0)], &avnx[IND(0,0,1)], NX*NY*sizeof(double));
		memcpy (&avny[IND(0,0,0)], &avny[IND(0,0,1)], NX*NY*sizeof(double));
		memcpy (&avnz[IND(0,0,0)], &avnz[IND(0,0,1)], NX*NY*sizeof(double));
	}
	if (ko > 2 && mpi.Neighbors[5] == -1)
	{
		memcpy (&avnx[IND(0,0,km1)], &avnx[IND(0,0,km2)], NX*NY*sizeof(double));
		memcpy (&avny[IND(0,0,km1)], &avny[IND(0,0,km2)], NX*NY*sizeof(double));
		memcpy (&avnz[IND(0,0,km1)], &avnz[IND(0,0,km2)], NX*NY*sizeof(double));
	}

	/*
    ** Exchange normals
    */
	xchg<double> (avnx);
	xchg<double> (avny);
	xchg<double> (avnz);

	/*
    ** Normalize the normal vectors
    */
	for (k=1;k<kmax;k++)
		for (j=1;j<jmax;j++)
			for (i=1;i<imax;i++)
			{
				const double rgradmag=1.0/sqrt(SQUARE(gradrox[IJK])+SQUARE(gradroy[IJK])+SQUARE(gradroz[IJK])+tiny);
				gradrox[IJK] *= rgradmag;
				gradroy[IJK] *= rgradmag;
				gradroz[IJK] *= rgradmag;
			}
	
	/*
    ** Exchange gradro_ arrays
    */
	arecvplane<double> (gradrox, 1);
	arecvplane<double> (gradroy, 1);
	arecvplane<double> (gradroz, 1);
	sendplane<double> (gradrox, 2);
	sendplane<double> (gradroy, 2);
	sendplane<double> (gradroz, 2);
	arecvspacewait();
	arecvplane<double> (gradrox, 3);
	arecvplane<double> (gradroy, 3);
	arecvplane<double> (gradroz, 3);
	sendplane<double> (gradrox, 4);
	sendplane<double> (gradroy, 4);
	sendplane<double> (gradroz, 4);
	arecvspacewait();
	arecvplane<double> (gradrox, 5);
	arecvplane<double> (gradroy, 5);
	arecvplane<double> (gradroz, 5);
	sendplane<double> (gradrox, 6);
	sendplane<double> (gradroy, 6);
	sendplane<double> (gradroz, 6);
	arecvspacewait();
}

#ifdef rudman_fine

void normals_f()
{
	double *rho_f = temp_f[1];
	double *ftilde_f = temp_f[2];
	double *gradrox_f = temp_f[3];
	double *gradroy_f = temp_f[4];
	double *gradroz_f = temp_f[5]; 
	double *avnx_f = temp_f[6];
	double *avny_f = temp_f[7];
	double *avnz_f = temp_f[8];
	int i,j,k;
	
	//calculate ftilde in REAL cells
	for(k=1;k<km1_f;k++)
		for(j=1;j<jm1_f;j++)
			for(i=1;i<im1_f;i++)
			{
				const double temp = 0.2728665*f_f[IJK_f]+0.0818442*(f_f[IPJK_f]+f_f[IMJK_f]
					+f_f[IJPK_f]+f_f[IJMK_f]+f_f[IJKP_f]+f_f[IJKM_f])+0.0178215
                    *(f_f[IPJPK_f]+f_f[IMJPK_f]+f_f[IPJMK_f]+f_f[IMJMK_f]
                    +f_f[IJPKP_f]+f_f[IJMKP_f]+f_f[IJPKM_f]+f_f[IJMKM_f]+f_f[IPJKP_f]
                    +f_f[IPJKM_f]+f_f[IMJKP_f]+f_f[IMJKM_f])+0.0027763
                    *(f_f[IPJPKP_f]+f_f[IMJPKP_f]+f_f[IPJMKP_f]+f_f[IMJMKP_f]
                    +f_f[IPJPKM_f]+f_f[IMJPKM_f]+f_f[IPJMKM_f]+f_f[IMJMKM_f]);
				ftilde_f[IJK_f]=temp;
			}
			
	//copy ftilde into ghost cells
	if (mpi.Neighbors[0] == -1)            /* If not a virtual boundary on the left */
		for (k = 0; k < kmax_f; k++)
			for (j = 0; j < jmax_f; j++)
				ftilde_f[IND_f(0, j, k)] = ftilde_f[IND_f(1, j, k)];

	if (mpi.Neighbors[1] == -1)            /* If not a virtual boundary on the right */
		for (k = 0; k < kmax_f; k++)
			for (j = 0; j < jmax_f; j++)
				ftilde_f[IND_f(im1_f, j, k)] = ftilde_f[IND_f(im1_f-1, j, k)];

	if (mpi.Neighbors[2] == -1)              /* If not a virtual boundary on the back */
		for (k = 0; k < kmax_f; k++)
			for (i = 0; i < imax_f; i++)
				ftilde_f[IND_f(i, 0, k)] = ftilde_f[IND_f(i, 1, k)];

	if (mpi.Neighbors[3] == -1)              /* If not a virtual boundary on the front */
		for (k = 0; k < kmax_f; k++)
			for (i = 0; i < imax_f; i++)			
				ftilde_f[IND_f(i, jm1_f, k)] = ftilde_f[IND_f(i, jm1_f-1, k)];

	if (mpi.Neighbors[4] == -1)              /* If not a virtual boundary on the under */
		for (j = 0; j < jmax_f; j++)
			for (i = 0; i < imax_f; i++)			
				ftilde_f[IND_f(i, j, 0)] = ftilde_f[IND_f(i, j, 1)];

	if (mpi.Neighbors[5] == -1)              /* Iff not a virtual boundary on the over */
		for (j = 0; j < jmax_f; j++)
			for (i = 0; i < imax_f; i++)			
				ftilde_f[IND_f(i, j, km1_f)] = ftilde_f[IND_f(i, j, km1_f-1)];
				
#ifndef no_obs
	xchg_f<double>(ftilde_f);
#endif
	if(mpi.obst_flag)
	{
		normalsobs_f(ftilde_f);
	}
	xchg_f<double>(ftilde_f);
	
	//compute vertex-centered normals vectors (includes physical boundary on either side)
	 for (k=1;k<kmax_f;k++)
		for (j=1;j<jmax_f;j++)
			for (i=1;i<imax_f;i++)
			{
				const double rhor=((rho_f[IJMKM_f]+rho_f[IJKM_f]+rho_f[IJMK_f]+rho_f[IJK_f])/4.0)
					*(delz[1]*(dely[1]*ftilde_f[IJMKM_f]+dely[1]
					*ftilde_f[IJKM_f])+delz[1]*(dely[1]*ftilde_f[IJMK_f]
					+dely[1]*ftilde_f[IJK_f]))/((delz[1]+delz[1])
					*(dely[1]+dely[1]));
				const double rhol=((rho_f[IMJMKM_f]+rho_f[IMJKM_f]+rho_f[IMJMK_f]+rho_f[IMJK_f])/4.0)
					*(delz[1]*(dely[1]*ftilde_f[IMJMKM_f]+dely[1]
					*ftilde_f[IMJKM_f])+delz[1]*(dely[1]*ftilde_f[IMJMK_f]
					+dely[1]*ftilde_f[IMJK_f]))/((delz[1]+delz[1])
					*(dely[1]+dely[1]));
				const double rhot=((rho_f[IMJKM_f]+rho_f[IMJK_f]+rho_f[IJKM_f]+rho_f[IJK_f])/4.0)
					*(delx[1]*(delz[1]*ftilde_f[IMJKM_f]+delz[1]
					*ftilde_f[IMJK_f])+delx[1]*(delz[1]*ftilde_f[IJKM_f]
					+delz[1]*ftilde_f[IJK_f]))/((delz[1]+delz[1])
					*(delx[1]+delx[1]));
				const double rhob=((rho_f[IMJMKM_f]+rho_f[IMJMK_f]+rho_f[IJMKM_f]+rho_f[IJMK_f])/4.0)
					*(delx[1]*(delz[1]*ftilde_f[IMJMKM_f]+delz[1]
					*ftilde_f[IMJMK_f])+delx[1]*(delz[1]*ftilde_f[IJMKM_f]
					+delz[1]*ftilde_f[IJMK_f]))/((delz[1]+delz[1])
					*(delx[1]+delx[1]));
				const double rhoo=((rho_f[IMJMK_f]+rho_f[IMJK_f]+rho_f[IJMK_f]+rho_f[IJK_f])/4.0)
					*(delx[1]*(dely[1]*ftilde_f[IMJMK_f]+dely[1]
					*ftilde_f[IMJK_f])+delx[1]*(dely[1]*ftilde_f[IJMK_f]
					+dely[1]*ftilde_f[IJK_f]))/((dely[1]+dely[1])
					*(delx[1]+delx[1]));
				const double rhou=((rho_f[IMJMKM_f]+rho_f[IMJKM_f]+rho_f[IJMKM_f]+rho_f[IJKM_f])/4.0)
					*(delx[1]*(dely[1]*ftilde_f[IMJMKM_f]+dely[1]
					*ftilde_f[IMJKM_f])+delx[1]*(dely[1]*ftilde_f[IJMKM_f]
					+dely[1]*ftilde_f[IJKM_f]))/((dely[1]+dely[1])
					*(delx[1]+delx[1]));

				gradrox_f[IJK_f]=(rhor-rhol)*rdelxl[1];
				gradroy_f[IJK_f]=(rhot-rhob)*rdelyb[1];
				gradroz_f[IJK_f]=(rhoo-rhou)*rdelzu[1];
			}
			
	//impose contact angle later ...ashish

	//compute avnx,avny,avnz
	for(k=1;k<km1_f;k++)
		for(j=1;j<jm1_f;j++)
			for(i=1;i<im1_f;i++)
			{
				avnx_f[IJK_f]=(gradrox_f[IPJK_f]+gradrox_f[IPJPK_f]
					+gradrox_f[IJPK_f]+gradrox_f[IJK_f]+gradrox_f[IPJKP_f]
					+gradrox_f[IPJPKP_f]+gradrox_f[IJPKP_f]+gradrox_f[IJKP_f]) / 8.0;
				avny_f[IJK_f]=(gradroy_f[IPJK_f]+gradroy_f[IPJPK_f]
					+gradroy_f[IJPK_f]+gradroy_f[IJK_f]+gradroy_f[IPJKP_f]
					+gradroy_f[IPJPKP_f]+gradroy_f[IJPKP_f]+gradroy_f[IJKP_f]) / 8.0;
				avnz_f[IJK_f]=(gradroz_f[IPJK_f]+gradroz_f[IPJPK_f]
					+gradroz_f[IJPK_f]+gradroz_f[IJK_f]+gradroz_f[IPJKP_f]
					+gradroz_f[IPJPKP_f]+gradroz_f[IJPKP_f]+gradroz_f[IJKP_f]) / 8.0;
			}
			
	//copy avnx from i=1 to i=0 plane and similar for other components.. at real computational boundaries
	if (kl > 2 && mpi.Neighbors[0] == -1)
	{
		for (k=1;k<km1_f;k++)
			for (j=1;j<jm1_f;j++)
			{
				avnx_f[IND_f(0,j,k)]=avnx_f[IND_f(1,j,k)];
				avny_f[IND_f(0,j,k)]=avny_f[IND_f(1,j,k)];
				avnz_f[IND_f(0,j,k)]=avnz_f[IND_f(1,j,k)];
			}
	}
	if (kr > 2 && mpi.Neighbors[1] == -1)
	{
		for (k=1;k<km1_f;k++)
			for (j=1;j<jm1_f;j++)
		{
			avnx_f[IND_f(im1_f,j,k)]=avnx_f[IND_f(im2_f,j,k)];
			avny_f[IND_f(im1_f,j,k)]=avny_f[IND_f(im2_f,j,k)];
			avnz_f[IND_f(im1_f,j,k)]=avnz_f[IND_f(im2_f,j,k)];
		}
	}
	if (kb > 2 && mpi.Neighbors[2] == -1)
	{
		for (k=1;k<km1_f;k++)
			for (i=1;i<imax_f;i++)
			{
				avnx_f[IND_f(i,0,k)]=avnx_f[IND_f(i,1,k)];
				avny_f[IND_f(i,0,k)]=avny_f[IND_f(i,1,k)];
				avnz_f[IND_f(i,0,k)]=avnz_f[IND_f(i,1,k)];
			}
	}
	if (kf > 2 && mpi.Neighbors[3] == -1)
	{
		for (k=1;k<km1_f;k++)
			for (i=1;i<imax_f;i++)
		{
			avnx_f[IND_f(i,jm1_f,k)]=avnx_f[IND_f(i,jm2_f,k)];
			avny_f[IND_f(i,jm1_f,k)]=avny_f[IND_f(i,jm2_f,k)];
			avnz_f[IND_f(i,jm1_f,k)]=avnz_f[IND_f(i,jm2_f,k)];
		}
	}
	if (ku > 2 && mpi.Neighbors[4] == -1)
	{
		memcpy (&avnx_f[IND_f(0,0,0)], &avnx_f[IND_f(0,0,1)], NX_f*NY_f*sizeof(double));
		memcpy (&avny_f[IND_f(0,0,0)], &avny_f[IND_f(0,0,1)], NX_f*NY_f*sizeof(double));
		memcpy (&avnz_f[IND_f(0,0,0)], &avnz_f[IND_f(0,0,1)], NX_f*NY_f*sizeof(double));
	}
	if (ko > 2 && mpi.Neighbors[5] == -1)
	{
		memcpy (&avnx_f[IND_f(0,0,km1_f)], &avnx_f[IND_f(0,0,km2_f)], NX_f*NY_f*sizeof(double));
		memcpy (&avny_f[IND_f(0,0,km1_f)], &avny_f[IND_f(0,0,km2_f)], NX_f*NY_f*sizeof(double));
		memcpy (&avnz_f[IND_f(0,0,km1_f)], &avnz_f[IND_f(0,0,km2_f)], NX_f*NY_f*sizeof(double));
	}
	
	//exchange normals
	xchg_f<double>(avnx_f);
	xchg_f<double>(avny_f);
	xchg_f<double>(avnz_f);
	
	//normalize the normal vectors
	for(k=1;k<kmax_f;k++)
		for(j=1;j<jmax_f;j++)
			for(i=1;i<imax_f;i++)
			{
				const double rgradmag=1.e0/sqrt(SQUARE(gradrox_f[IJK_f])+SQUARE(gradroy_f[IJK_f])+SQUARE(gradroz_f[IJK_f])+tiny);
				gradrox_f[IJK_f]*=rgradmag;
				gradroy_f[IJK_f]*=rgradmag;
				gradroz_f[IJK_f]*=rgradmag;
			}
			
	//exchange gradro_ arrays
	arecvplane_f<double> (gradrox_f, 1);
	arecvplane_f<double> (gradroy_f, 1);
	arecvplane_f<double> (gradroz_f, 1);
	sendplane_f<double> (gradrox_f, 2);
	sendplane_f<double> (gradroy_f, 2);
	sendplane_f<double> (gradroz_f, 2);
	arecvspacewait();
	arecvplane_f<double> (gradrox_f, 3);
	arecvplane_f<double> (gradroy_f, 3);
	arecvplane_f<double> (gradroz_f, 3);
	sendplane_f<double> (gradrox_f, 4);
	sendplane_f<double> (gradroy_f, 4);
	sendplane_f<double> (gradroz_f, 4);
	arecvspacewait();
	arecvplane_f<double> (gradrox_f, 5);
	arecvplane_f<double> (gradroy_f, 5);
	arecvplane_f<double> (gradroz_f, 5);
	sendplane_f<double> (gradrox_f, 6);
	sendplane_f<double> (gradroy_f, 6);
	sendplane_f<double> (gradroz_f, 6);
	arecvspacewait();
}

void normals_alpha_f()
{
	double *alpharho_f = temp_f[1];
	double *alphatilde_f = temp_f[2];
	double *alphagradrox_f = temp_f[3];
	double *alphagradroy_f = temp_f[4];
	double *alphagradroz_f = temp_f[5];
	double *alpha_avnx_f = temp_f[6];
	double *alpha_avny_f = temp_f[7];
	double *alpha_avnz_f = temp_f[8];
	int i,j,k;

	for (k=1;k<km1_f;k++)
		for (j=1;j<jm1_f;j++)
			for (i=1;i<im1_f;i++)
			{
				alpha_f[IJK_f] = 1 - f_f[IJK_f] - psi_f[IJK_f]; //Air fraction
				
			}
	for(k=1;k<km1_f;k++)
		for(j=1;j<jm1_f;j++)
			for(i=1;i<im1_f;i++)
			{
				const double temp = 0.2728665*alpha_f[IJK_f]+0.0818442*(alpha_f[IPJK_f]+alpha_f[IMJK_f]
					+alpha_f[IJPK_f]+alpha_f[IJMK_f]+alpha_f[IJKP_f]+alpha_f[IJKM_f])+0.0178215
                    *(alpha_f[IPJPK_f]+alpha_f[IMJPK_f]+alpha_f[IPJMK_f]+alpha_f[IMJMK_f]
                    +alpha_f[IJPKP_f]+alpha_f[IJMKP_f]+alpha_f[IJPKM_f]+alpha_f[IJMKM_f]+alpha_f[IPJKP_f]
                    +alpha_f[IPJKM_f]+alpha_f[IMJKP_f]+alpha_f[IMJKM_f])+0.0027763
                    *(alpha_f[IPJPKP_f]+alpha_f[IMJPKP_f]+alpha_f[IPJMKP_f]+alpha_f[IMJMKP_f]
                    +alpha_f[IPJPKM_f]+alpha_f[IMJPKM_f]+alpha_f[IPJMKM_f]+alpha_f[IMJMKM_f]);
				alphatilde_f[IJK_f]=temp;
			}		

	//copy ftilde into ghost cells
	if (mpi.Neighbors[0] == -1)            /* If not a virtual boundary on the left */
		for (k = 0; k < kmax_f; k++)
			for (j = 0; j < jmax_f; j++)
				alphatilde_f[IND_f(0, j, k)] = alphatilde_f[IND_f(1, j, k)];

	if (mpi.Neighbors[1] == -1)            /* If not a virtual boundary on the right */
		for (k = 0; k < kmax_f; k++)
			for (j = 0; j < jmax_f; j++)
				alphatilde_f[IND_f(im1_f, j, k)] = alphatilde_f[IND_f(im1_f-1, j, k)];

	if (mpi.Neighbors[2] == -1)              /* If not a virtual boundary on the back */
		for (k = 0; k < kmax_f; k++)
			for (i = 0; i < imax_f; i++)			
				alphatilde_f[IND_f(i, 0, k)] = alphatilde_f[IND_f(i, 1, k)];

	if (mpi.Neighbors[3] == -1)              /* If not a virtual boundary on the front */
		for (k = 0; k < kmax_f; k++)
			for (i = 0; i < imax_f; i++)
				alphatilde_f[IND_f(i, jm1_f, k)] = alphatilde_f[IND_f(i, jm1_f-1, k)];

	if (mpi.Neighbors[4] == -1)              /* If not a virtual boundary on the under */
		for (j = 0; j < jmax_f; j++)
			for (i = 0; i < imax_f; i++)
				alphatilde_f[IND_f(i, j, 0)] = alphatilde_f[IND_f(i, j, 1)];

	if (mpi.Neighbors[5] == -1)              /* Iff not a virtual boundary on the over */
		for (j = 0; j < jmax_f; j++)
			for (i = 0; i < imax_f; i++)
				alphatilde_f[IND_f(i, j, km1_f)] = alphatilde_f[IND_f(i, j, km1_f-1)];

	//compute vertex-centered normals vectors (includes physical boundary on either side)
	 for (k=1;k<kmax_f;k++)
		for (j=1;j<jmax_f;j++)
			for (i=1;i<imax_f;i++)
			{
				const double rhor=((alpharho_f[IJMKM_f]+alpharho_f[IJKM_f]+alpharho_f[IJMK_f]+alpharho_f[IJK_f])/4.0)
					*(delz[1]*(dely[1]*alphatilde_f[IJMKM_f]+dely[1]
					*alphatilde_f[IJKM_f])+delz[1]*(dely[1]*alphatilde_f[IJMK_f]
					+dely[1]*alphatilde_f[IJK_f]))/((delz[1]+delz[1])
					*(dely[1]+dely[1]));
				const double rhol=((alpharho_f[IMJMKM_f]+alpharho_f[IMJKM_f]+alpharho_f[IMJMK_f]+alpharho_f[IMJK_f])/4.0)
					*(delz[1]*(dely[1]*alphatilde_f[IMJMKM_f]+dely[1]
					*alphatilde_f[IMJKM_f])+delz[1]*(dely[1]*alphatilde_f[IMJMK_f]
					+dely[1]*alphatilde_f[IMJK_f]))/((delz[1]+delz[1])
					*(dely[1]+dely[1]));
				const double rhot=((alpharho_f[IMJKM_f]+alpharho_f[IMJK_f]+alpharho_f[IJKM_f]+alpharho_f[IJK_f])/4.0)
					*(delx[1]*(delz[1]*alphatilde_f[IMJKM_f]+delz[1]
					*alphatilde_f[IMJK_f])+delx[1]*(delz[1]*alphatilde_f[IJKM_f]
					+delz[1]*alphatilde_f[IJK_f]))/((delz[1]+delz[1])
					*(delx[1]+delx[1]));
				const double rhob=((alpharho_f[IMJMKM_f]+alpharho_f[IMJMK_f]+alpharho_f[IJMKM_f]+alpharho_f[IJMK_f])/4.0)
					*(delx[1]*(delz[1]*alphatilde_f[IMJMKM_f]+delz[1]
					*alphatilde_f[IMJMK_f])+delx[1]*(delz[1]*alphatilde_f[IJMKM_f]
					+delz[1]*alphatilde_f[IJMK_f]))/((delz[1]+delz[1])
					*(delx[1]+delx[1]));
				const double rhoo=((alpharho_f[IMJMK_f]+alpharho_f[IMJK_f]+alpharho_f[IJMK_f]+alpharho_f[IJK_f])/4.0)
					*(delx[1]*(dely[1]*alphatilde_f[IMJMK_f]+dely[1]
					*alphatilde_f[IMJK_f])+delx[1]*(dely[1]*alphatilde_f[IJMK_f]
					+dely[1]*alphatilde_f[IJK_f]))/((dely[1]+dely[1])
					*(delx[1]+delx[1]));
				const double rhou=((alpharho_f[IMJMKM_f]+alpharho_f[IMJKM_f]+alpharho_f[IJMKM_f]+alpharho_f[IJKM_f])/4.0)
					*(delx[1]*(dely[1]*alphatilde_f[IMJMKM_f]+dely[1]
					*alphatilde_f[IMJKM_f])+delx[1]*(dely[1]*alphatilde_f[IJMKM_f]
					+dely[1]*alphatilde_f[IJKM_f]))/((dely[1]+dely[1])
					*(delx[1]+delx[1]));

				alphagradrox_f[IJK_f]=(rhor-rhol)*rdelxl[1];
				alphagradroy_f[IJK_f]=(rhot-rhob)*rdelyb[1];
				alphagradroz_f[IJK_f]=(rhoo-rhou)*rdelzu[1];
			}

	//compute avnx,avny,avnz
	for(k=1;k<km1_f;k++)
		for(j=1;j<jm1_f;j++)
			for(i=1;i<im1_f;i++)
			{
				alpha_avnx_f[IJK_f]=(alphagradrox_f[IPJK_f]+alphagradrox_f[IPJPK_f]
					+alphagradrox_f[IJPK_f]+alphagradrox_f[IJK_f]+alphagradrox_f[IPJKP_f]
					+alphagradrox_f[IPJPKP_f]+alphagradrox_f[IJPKP_f]+alphagradrox_f[IJKP_f]) / 8.0;
				alpha_avny_f[IJK_f]=(alphagradroy_f[IPJK_f]+alphagradroy_f[IPJPK_f]
					+alphagradroy_f[IJPK_f]+alphagradroy_f[IJK_f]+alphagradroy_f[IPJKP_f]
					+alphagradroy_f[IPJPKP_f]+alphagradroy_f[IJPKP_f]+alphagradroy_f[IJKP_f]) / 8.0;
				alpha_avnz_f[IJK_f]=(alphagradroz_f[IPJK_f]+alphagradroz_f[IPJPK_f]
					+alphagradroz_f[IJPK_f]+alphagradroz_f[IJK_f]+alphagradroz_f[IPJKP_f]
					+alphagradroz_f[IPJPKP_f]+alphagradroz_f[IJPKP_f]+alphagradroz_f[IJKP_f]) / 8.0;
			}

//copy avnx from i=1 to i=0 plane and similar for other components.. at real computational boundaries
	//if (kl > 2 && mpi.Neighbors[0] == -1)
	if (mpi.Neighbors[0] == -1)
	{
		for (k=1;k<km1_f;k++)
			for (j=1;j<jm1_f;j++)
			{
				alpha_avnx_f[IND_f(0,j,k)]=alpha_avnx_f[IND_f(1,j,k)];
				alpha_avny_f[IND_f(0,j,k)]=alpha_avny_f[IND_f(1,j,k)];
				alpha_avnz_f[IND_f(0,j,k)]=alpha_avnz_f[IND_f(1,j,k)];
			}
	}
	//if (kr > 2 && mpi.Neighbors[1] == -1)
	if (mpi.Neighbors[1] == -1)
	{
		for (k=1;k<km1_f;k++)
			for (j=1;j<jm1_f;j++)
		{
			alpha_avnx_f[IND_f(im1_f,j,k)]=alpha_avnx_f[IND_f(im2_f,j,k)];
			alpha_avny_f[IND_f(im1_f,j,k)]=alpha_avny_f[IND_f(im2_f,j,k)];
			alpha_avnz_f[IND_f(im1_f,j,k)]=alpha_avnz_f[IND_f(im2_f,j,k)];
		}
	}
	//if (kb > 2 && mpi.Neighbors[2] == -1)
	if (mpi.Neighbors[2] == -1)
	{
		for (k=1;k<km1_f;k++)
			for (i=1;i<imax_f;i++)
			{
				alpha_avnx_f[IND_f(i,0,k)]=alpha_avnx_f[IND_f(i,1,k)];
				alpha_avny_f[IND_f(i,0,k)]=alpha_avny_f[IND_f(i,1,k)];
				alpha_avnz_f[IND_f(i,0,k)]=alpha_avnz_f[IND_f(i,1,k)];
			}
	}
	//if (kf > 2 && mpi.Neighbors[3] == -1)
	if (mpi.Neighbors[3] == -1)
	{
		for (k=1;k<km1_f;k++)
			for (i=1;i<imax_f;i++)
		{
			alpha_avnx_f[IND_f(i,jm1_f,k)]=alpha_avnx_f[IND_f(i,jm2_f,k)];
			alpha_avny_f[IND_f(i,jm1_f,k)]=alpha_avny_f[IND_f(i,jm2_f,k)];
			alpha_avnz_f[IND_f(i,jm1_f,k)]=alpha_avnz_f[IND_f(i,jm2_f,k)];
		}
	}
	//if (ku > 2 && mpi.Neighbors[4] == -1)
	if (mpi.Neighbors[4] == -1)
	{
		memcpy (&alpha_avnx_f[IND_f(0,0,0)], &alpha_avnx_f[IND_f(0,0,1)], NX_f*NY_f*sizeof(double));
		memcpy (&alpha_avny_f[IND_f(0,0,0)], &alpha_avny_f[IND_f(0,0,1)], NX_f*NY_f*sizeof(double));
		memcpy (&alpha_avnz_f[IND_f(0,0,0)], &alpha_avnz_f[IND_f(0,0,1)], NX_f*NY_f*sizeof(double));
	}
	//if (ko > 2 && mpi.Neighbors[5] == -1)
	if (mpi.Neighbors[5] == -1)
	{
		memcpy (&alpha_avnx_f[IND_f(0,0,km1_f)], &alpha_avnx_f[IND_f(0,0,km2_f)], NX_f*NY_f*sizeof(double));
		memcpy (&alpha_avny_f[IND_f(0,0,km1_f)], &alpha_avny_f[IND_f(0,0,km2_f)], NX_f*NY_f*sizeof(double));
		memcpy (&alpha_avnz_f[IND_f(0,0,km1_f)], &alpha_avnz_f[IND_f(0,0,km2_f)], NX_f*NY_f*sizeof(double));
	}
	
	
	//exchange normals
	xchg_f<double>(alpha_avnx_f);
	xchg_f<double>(alpha_avny_f);
	xchg_f<double>(alpha_avnz_f);

	
	//normalize the normal vectors
	for(k=1;k<kmax_f;k++)
		for(j=1;j<jmax_f;j++)
			for(i=1;i<imax_f;i++)
			{
				const double rgradmag=1.e0/sqrt(SQUARE(alphagradrox_f[IJK_f])+SQUARE(alphagradroy_f[IJK_f])+SQUARE(alphagradroz_f[IJK_f])+tiny);
				alphagradrox_f[IJK_f]*=rgradmag;
				alphagradroy_f[IJK_f]*=rgradmag;
				alphagradroz_f[IJK_f]*=rgradmag;
			}

	//exchange gradro_ arrays
	arecvplane_f<double> (alphagradrox_f, 1);
	arecvplane_f<double> (alphagradroy_f, 1);
	arecvplane_f<double> (alphagradroz_f, 1);
	sendplane_f<double> (alphagradrox_f, 2);
	sendplane_f<double> (alphagradroy_f, 2);
	sendplane_f<double> (alphagradroz_f, 2);
	arecvspacewait();
	arecvplane_f<double> (alphagradrox_f, 3);
	arecvplane_f<double> (alphagradroy_f, 3);
	arecvplane_f<double> (alphagradroz_f, 3);
	sendplane_f<double> (alphagradrox_f, 4);
	sendplane_f<double> (alphagradroy_f, 4);
	sendplane_f<double> (alphagradroz_f, 4);
	arecvspacewait();
	arecvplane_f<double> (alphagradrox_f, 5);
	arecvplane_f<double> (alphagradroy_f, 5);
	arecvplane_f<double> (alphagradroz_f, 5);
	sendplane_f<double> (alphagradrox_f, 6);
	sendplane_f<double> (alphagradroy_f, 6);
	sendplane_f<double> (alphagradroz_f, 6);
	arecvspacewait();
	
}

#ifdef __solid
void normalspsi_f()
{
	double *psirho_f = temp_f[1];
	double *psitilde_f = temp_f[2];
	double *psigradrox_f = temp_f[3];
	double *psigradroy_f = temp_f[4];
	double *psigradroz_f = temp_f[5];
	double *psiavnx_f = temp_f[9];
	double *psiavny_f = temp_f[10];
	double *psiavnz_f = temp_f[11];
	int i,j,k;
	
	//calculate psitilde in REAL cells
	for(k=1;k<km1_f;k++)
		for(j=1;j<jm1_f;j++)
			for(i=1;i<im1_f;i++)
			{
				const double temp = 0.2728665*psi_f[IJK_f]+0.0818442*(psi_f[IPJK_f]+psi_f[IMJK_f]
					+psi_f[IJPK_f]+psi_f[IJMK_f]+psi_f[IJKP_f]+psi_f[IJKM_f])+0.0178215
                    *(psi_f[IPJPK_f]+psi_f[IMJPK_f]+psi_f[IPJMK_f]+psi_f[IMJMK_f]
                    +psi_f[IJPKP_f]+psi_f[IJMKP_f]+psi_f[IJPKM_f]+psi_f[IJMKM_f]+psi_f[IPJKP_f]
                    +psi_f[IPJKM_f]+psi_f[IMJKP_f]+psi_f[IMJKM_f])+0.0027763
                    *(psi_f[IPJPKP_f]+psi_f[IMJPKP_f]+psi_f[IPJMKP_f]+psi_f[IMJMKP_f]
                    +psi_f[IPJPKM_f]+psi_f[IMJPKM_f]+psi_f[IPJMKM_f]+psi_f[IMJMKM_f]);
				psitilde_f[IJK_f]=temp;
			}
			
	//copy ftilde into ghost cells
	if (mpi.Neighbors[0] == -1)            /* If not a virtual boundary on the left */
		for (k = 0; k < kmax_f; k++)
			for (j = 0; j < jmax_f; j++)
				psitilde_f[IND_f(0, j, k)] = psitilde_f[IND_f(1, j, k)];

	if (mpi.Neighbors[1] == -1)            /* If not a virtual boundary on the right */
		for (k = 0; k < kmax_f; k++)
			for (j = 0; j < jmax_f; j++)
				psitilde_f[IND_f(im1_f, j, k)] = psitilde_f[IND_f(im1_f-1, j, k)];

	if (mpi.Neighbors[2] == -1)              /* If not a virtual boundary on the back */
		for (k = 0; k < kmax_f; k++)
			for (i = 0; i < imax_f; i++)			
				psitilde_f[IND_f(i, 0, k)] = psitilde_f[IND_f(i, 1, k)];

	if (mpi.Neighbors[3] == -1)              /* If not a virtual boundary on the front */
		for (k = 0; k < kmax_f; k++)
			for (i = 0; i < imax_f; i++)
				psitilde_f[IND_f(i, jm1_f, k)] = psitilde_f[IND_f(i, jm1_f-1, k)];

	if (mpi.Neighbors[4] == -1)              /* If not a virtual boundary on the under */
		for (j = 0; j < jmax_f; j++)
			for (i = 0; i < imax_f; i++)
				psitilde_f[IND_f(i, j, 0)] = psitilde_f[IND_f(i, j, 1)];

	if (mpi.Neighbors[5] == -1)              /* Iff not a virtual boundary on the over */
		for (j = 0; j < jmax_f; j++)
			for (i = 0; i < imax_f; i++)
				psitilde_f[IND_f(i, j, km1_f)] = psitilde_f[IND_f(i, j, km1_f-1)];
				
#ifndef no_obs
	xchg_f<double>(psitilde_f);
#endif
	if(mpi.obst_flag)
	{
		normalsobs_f(psitilde_f);
	}
	xchg_f<double>(psitilde_f);
	
	//compute vertex-centered normals vectors (includes physical boundary on either side)
	 for (k=1;k<kmax_f;k++)
		for (j=1;j<jmax_f;j++)
			for (i=1;i<imax_f;i++)
			{
				const double rhor=((psirho_f[IJMKM_f]+psirho_f[IJKM_f]+psirho_f[IJMK_f]+psirho_f[IJK_f])/4.0)
					*(delz[1]*(dely[1]*psitilde_f[IJMKM_f]+dely[1]
					*psitilde_f[IJKM_f])+delz[1]*(dely[1]*psitilde_f[IJMK_f]
					+dely[1]*psitilde_f[IJK_f]))/((delz[1]+delz[1])
					*(dely[1]+dely[1]));
				const double rhol=((psirho_f[IMJMKM_f]+psirho_f[IMJKM_f]+psirho_f[IMJMK_f]+psirho_f[IMJK_f])/4.0)
					*(delz[1]*(dely[1]*psitilde_f[IMJMKM_f]+dely[1]
					*psitilde_f[IMJKM_f])+delz[1]*(dely[1]*psitilde_f[IMJMK_f]
					+dely[1]*psitilde_f[IMJK_f]))/((delz[1]+delz[1])
					*(dely[1]+dely[1]));
				const double rhot=((psirho_f[IMJKM_f]+psirho_f[IMJK_f]+psirho_f[IJKM_f]+psirho_f[IJK_f])/4.0)
					*(delx[1]*(delz[1]*psitilde_f[IMJKM_f]+delz[1]
					*psitilde_f[IMJK_f])+delx[1]*(delz[1]*psitilde_f[IJKM_f]
					+delz[1]*psitilde_f[IJK_f]))/((delz[1]+delz[1])
					*(delx[1]+delx[1]));
				const double rhob=((psirho_f[IMJMKM_f]+psirho_f[IMJMK_f]+psirho_f[IJMKM_f]+psirho_f[IJMK_f])/4.0)
					*(delx[1]*(delz[1]*psitilde_f[IMJMKM_f]+delz[1]
					*psitilde_f[IMJMK_f])+delx[1]*(delz[1]*psitilde_f[IJMKM_f]
					+delz[1]*psitilde_f[IJMK_f]))/((delz[1]+delz[1])
					*(delx[1]+delx[1]));
				const double rhoo=((psirho_f[IMJMK_f]+psirho_f[IMJK_f]+psirho_f[IJMK_f]+psirho_f[IJK_f])/4.0)
					*(delx[1]*(dely[1]*psitilde_f[IMJMK_f]+dely[1]
					*psitilde_f[IMJK_f])+delx[1]*(dely[1]*psitilde_f[IJMK_f]
					+dely[1]*psitilde_f[IJK_f]))/((dely[1]+dely[1])
					*(delx[1]+delx[1]));
				const double rhou=((psirho_f[IMJMKM_f]+psirho_f[IMJKM_f]+psirho_f[IJMKM_f]+psirho_f[IJKM_f])/4.0)
					*(delx[1]*(dely[1]*psitilde_f[IMJMKM_f]+dely[1]
					*psitilde_f[IMJKM_f])+delx[1]*(dely[1]*psitilde_f[IJMKM_f]
					+dely[1]*psitilde_f[IJKM_f]))/((dely[1]+dely[1])
					*(delx[1]+delx[1]));

				psigradrox_f[IJK_f]=(rhor-rhol)*rdelxl[1];
				psigradroy_f[IJK_f]=(rhot-rhob)*rdelyb[1];
				psigradroz_f[IJK_f]=(rhoo-rhou)*rdelzu[1];
			}
			
	//compute avnx,avny,avnz
	for(k=1;k<km1_f;k++)
		for(j=1;j<jm1_f;j++)
			for(i=1;i<im1_f;i++)
			{
				psiavnx_f[IJK_f]=(psigradrox_f[IPJK_f]+psigradrox_f[IPJPK_f]
					+psigradrox_f[IJPK_f]+psigradrox_f[IJK_f]+psigradrox_f[IPJKP_f]
					+psigradrox_f[IPJPKP_f]+psigradrox_f[IJPKP_f]+psigradrox_f[IJKP_f]) / 8.0;
				psiavny_f[IJK_f]=(psigradroy_f[IPJK_f]+psigradroy_f[IPJPK_f]
					+psigradroy_f[IJPK_f]+psigradroy_f[IJK_f]+psigradroy_f[IPJKP_f]
					+psigradroy_f[IPJPKP_f]+psigradroy_f[IJPKP_f]+psigradroy_f[IJKP_f]) / 8.0;
				psiavnz_f[IJK_f]=(psigradroz_f[IPJK_f]+psigradroz_f[IPJPK_f]
					+psigradroz_f[IJPK_f]+psigradroz_f[IJK_f]+psigradroz_f[IPJKP_f]
					+psigradroz_f[IPJPKP_f]+psigradroz_f[IJPKP_f]+psigradroz_f[IJKP_f]) / 8.0;
			}

			
	//copy avnx from i=1 to i=0 plane and similar for other components.. at real computational boundaries
	//if (kl > 2 && mpi.Neighbors[0] == -1)
	if (mpi.Neighbors[0] == -1)
	{
		for (k=1;k<km1_f;k++)
			for (j=1;j<jm1_f;j++)
			{
				psiavnx_f[IND_f(0,j,k)]=psiavnx_f[IND_f(1,j,k)];
				psiavny_f[IND_f(0,j,k)]=psiavny_f[IND_f(1,j,k)];
				psiavnz_f[IND_f(0,j,k)]=psiavnz_f[IND_f(1,j,k)];
			}
	}
	//if (kr > 2 && mpi.Neighbors[1] == -1)
	if (mpi.Neighbors[1] == -1)
	{
		for (k=1;k<km1_f;k++)
			for (j=1;j<jm1_f;j++)
		{
			psiavnx_f[IND_f(im1_f,j,k)]=psiavnx_f[IND_f(im2_f,j,k)];
			psiavny_f[IND_f(im1_f,j,k)]=psiavny_f[IND_f(im2_f,j,k)];
			psiavnz_f[IND_f(im1_f,j,k)]=psiavnz_f[IND_f(im2_f,j,k)];
		}
	}
	//if (kb > 2 && mpi.Neighbors[2] == -1)
	if (mpi.Neighbors[2] == -1)
	{
		for (k=1;k<km1_f;k++)
			for (i=1;i<imax_f;i++)
			{
				psiavnx_f[IND_f(i,0,k)]=psiavnx_f[IND_f(i,1,k)];
				psiavny_f[IND_f(i,0,k)]=psiavny_f[IND_f(i,1,k)];
				psiavnz_f[IND_f(i,0,k)]=psiavnz_f[IND_f(i,1,k)];
			}
	}
	//if (kf > 2 && mpi.Neighbors[3] == -1)
	if (mpi.Neighbors[3] == -1)
	{
		for (k=1;k<km1_f;k++)
			for (i=1;i<imax_f;i++)
		{
			psiavnx_f[IND_f(i,jm1_f,k)]=psiavnx_f[IND_f(i,jm2_f,k)];
			psiavny_f[IND_f(i,jm1_f,k)]=psiavny_f[IND_f(i,jm2_f,k)];
			psiavnz_f[IND_f(i,jm1_f,k)]=psiavnz_f[IND_f(i,jm2_f,k)];
		}
	}
	//if (ku > 2 && mpi.Neighbors[4] == -1)
	if (mpi.Neighbors[4] == -1)
	{
		memcpy (&psiavnx_f[IND_f(0,0,0)], &psiavnx_f[IND_f(0,0,1)], NX_f*NY_f*sizeof(double));
		memcpy (&psiavny_f[IND_f(0,0,0)], &psiavny_f[IND_f(0,0,1)], NX_f*NY_f*sizeof(double));
		memcpy (&psiavnz_f[IND_f(0,0,0)], &psiavnz_f[IND_f(0,0,1)], NX_f*NY_f*sizeof(double));
	}
	//if (ko > 2 && mpi.Neighbors[5] == -1)
	if (mpi.Neighbors[5] == -1)
	{
		memcpy (&psiavnx_f[IND_f(0,0,km1_f)], &psiavnx_f[IND_f(0,0,km2_f)], NX_f*NY_f*sizeof(double));
		memcpy (&psiavny_f[IND_f(0,0,km1_f)], &psiavny_f[IND_f(0,0,km2_f)], NX_f*NY_f*sizeof(double));
		memcpy (&psiavnz_f[IND_f(0,0,km1_f)], &psiavnz_f[IND_f(0,0,km2_f)], NX_f*NY_f*sizeof(double));
	}
	
	
	//exchange normals
#ifndef no_obs
	xchg_f<double>(psiavnx_f);
	xchg_f<double>(psiavny_f);
	xchg_f<double>(psiavnz_f);
#endif
	if(mpi.obst_flag)
	 {
		normalspsiobs_f(psiavnx_f, psiavny_f, psiavnz_f);
	 }
	xchg_f<double>(psiavnx_f);
	xchg_f<double>(psiavny_f);
	xchg_f<double>(psiavnz_f);
	
	//normalize the normal vectors
	for(k=1;k<kmax_f;k++)
		for(j=1;j<jmax_f;j++)
			for(i=1;i<imax_f;i++)
			{
				const double rgradmag=1.e0/sqrt(SQUARE(psigradrox_f[IJK_f])+SQUARE(psigradroy_f[IJK_f])+SQUARE(psigradroz_f[IJK_f])+tiny);
				psigradrox_f[IJK_f]*=rgradmag;
				psigradroy_f[IJK_f]*=rgradmag;
				psigradroz_f[IJK_f]*=rgradmag;
			}
	
	/*if(mpi.MyRank==2) {
		i=142, j=1, k=320;
		int ii,jj,kk;
		for(kk=-2;kk<3;kk++) {
			printf("--------------########---------------\n");
		 for(jj=-1;jj<2;jj++) {
		  for(ii=-2;ii<3;ii++) {
			  printf("%.18e ",psi_f[IND_f(i+ii,j+jj,k+kk)]);
		  }
		  printf("\n");
		 }
		}
		
		i=142, j=5, k=320;
		for(kk=-2;kk<3;kk++) {
			printf("--------------########---------------\n");
		 for(jj=-1;jj<2;jj++) {
		  for(ii=-2;ii<3;ii++) {
			  printf("%.18e ",psi_f[IND_f(i+ii,j+jj,k+kk)]);
		  }
		  printf("\n");
		 }
		}	
	}*/
			
	//exchange gradro_ arrays
	arecvplane_f<double> (psigradrox_f, 1);
	arecvplane_f<double> (psigradroy_f, 1);
	arecvplane_f<double> (psigradroz_f, 1);
	sendplane_f<double> (psigradrox_f, 2);
	sendplane_f<double> (psigradroy_f, 2);
	sendplane_f<double> (psigradroz_f, 2);
	arecvspacewait();
	arecvplane_f<double> (psigradrox_f, 3);
	arecvplane_f<double> (psigradroy_f, 3);
	arecvplane_f<double> (psigradroz_f, 3);
	sendplane_f<double> (psigradrox_f, 4);
	sendplane_f<double> (psigradroy_f, 4);
	sendplane_f<double> (psigradroz_f, 4);
	arecvspacewait();
	arecvplane_f<double> (psigradrox_f, 5);
	arecvplane_f<double> (psigradroy_f, 5);
	arecvplane_f<double> (psigradroz_f, 5);
	sendplane_f<double> (psigradrox_f, 6);
	sendplane_f<double> (psigradroy_f, 6);
	sendplane_f<double> (psigradroz_f, 6);
	arecvspacewait();			
}

void normals_fvirt() {
	
	double *rho_f = temp_f[1];
	double *ftilde_f = temp_f[2];
	double *gradrox_f = temp_f[3];
	double *gradroy_f = temp_f[4];
	double *gradroz_f = temp_f[5]; 
	double *avnx_f = temp_f[6];
	double *avny_f = temp_f[7];
	double *avnz_f = temp_f[8];
	int i,j,k;
	//do not forget to compute rho before the normals calculation... rho should be based on fvirt_f
	//calculate ftilde in REAL cells
	for(k=1;k<km1_f;k++)
		for(j=1;j<jm1_f;j++)
			for(i=1;i<im1_f;i++)
			{
				const double temp = 0.2728665*fvirt_f[IJK_f]+0.0818442*(fvirt_f[IPJK_f]+fvirt_f[IMJK_f]
					+fvirt_f[IJPK_f]+fvirt_f[IJMK_f]+fvirt_f[IJKP_f]+fvirt_f[IJKM_f])+0.0178215
                    *(fvirt_f[IPJPK_f]+fvirt_f[IMJPK_f]+fvirt_f[IPJMK_f]+fvirt_f[IMJMK_f]
                    +fvirt_f[IJPKP_f]+fvirt_f[IJMKP_f]+fvirt_f[IJPKM_f]+fvirt_f[IJMKM_f]+fvirt_f[IPJKP_f]
                    +fvirt_f[IPJKM_f]+fvirt_f[IMJKP_f]+fvirt_f[IMJKM_f])+0.0027763
                    *(fvirt_f[IPJPKP_f]+fvirt_f[IMJPKP_f]+fvirt_f[IPJMKP_f]+fvirt_f[IMJMKP_f]
                    +fvirt_f[IPJPKM_f]+fvirt_f[IMJPKM_f]+fvirt_f[IPJMKM_f]+fvirt_f[IMJMKM_f]);
				ftilde_f[IJK_f]=temp;
			}
		
	//copy ftilde into ghost cells
	if (mpi.Neighbors[0] == -1)            /* If not a virtual boundary on the left */
		for (k = 0; k < kmax_f; k++)
			for (j = 0; j < jmax_f; j++)	
				ftilde_f[IND_f(0, j, k)] = ftilde_f[IND_f(1, j, k)];

	if (mpi.Neighbors[1] == -1)            /* If not a virtual boundary on the right */
		for (k = 0; k < kmax_f; k++)
			for (j = 0; j < jmax_f; j++)
				ftilde_f[IND_f(im1_f, j, k)] = ftilde_f[IND_f(im1_f-1, j, k)];

	if (mpi.Neighbors[2] == -1)              /* If not a virtual boundary on the back */
		for (k = 0; k < kmax_f; k++)
			for (i = 0; i < imax_f; i++)
				ftilde_f[IND_f(i, 0, k)] = ftilde_f[IND_f(i, 1, k)];

	if (mpi.Neighbors[3] == -1)              /* If not a virtual boundary on the front */
		for (k = 0; k < kmax_f; k++)
			for (i = 0; i < imax_f; i++)
				ftilde_f[IND_f(i, jm1_f, k)] = ftilde_f[IND_f(i, jm1_f-1, k)];

	if (mpi.Neighbors[4] == -1)              /* If not a virtual boundary on the under */
		for (j = 0; j < jmax_f; j++)
			for (i = 0; i < imax_f; i++)
				ftilde_f[IND_f(i, j, 0)] = ftilde_f[IND_f(i, j, 1)];

	if (mpi.Neighbors[5] == -1)              /* Iff not a virtual boundary on the over */
		for (j = 0; j < jmax_f; j++)
			for (i = 0; i < imax_f; i++)	
				ftilde_f[IND_f(i, j, km1_f)] = ftilde_f[IND_f(i, j, km1_f-1)];
				
#ifndef no_obs
	xchg_f<double>(ftilde_f);
#endif
	if(mpi.obst_flag)
	{
		normalsobs_f(ftilde_f);
	}
	xchg_f<double>(ftilde_f);

	//compute vertex-centered normals vectors (includes physical boundary on either side)
	 for (k=1;k<kmax_f;k++)
		for (j=1;j<jmax_f;j++)
			for (i=1;i<imax_f;i++)
			{
				const double rhor=((rho_f[IJMKM_f]+rho_f[IJKM_f]+rho_f[IJMK_f]+rho_f[IJK_f])/4.0)
					*(delz[1]*(dely[1]*ftilde_f[IJMKM_f]+dely[1]
					*ftilde_f[IJKM_f])+delz[1]*(dely[1]*ftilde_f[IJMK_f]
					+dely[1]*ftilde_f[IJK_f]))/((delz[1]+delz[1])
					*(dely[1]+dely[1]));
				const double rhol=((rho_f[IMJMKM_f]+rho_f[IMJKM_f]+rho_f[IMJMK_f]+rho_f[IMJK_f])/4.0)
					*(delz[1]*(dely[1]*ftilde_f[IMJMKM_f]+dely[1]
					*ftilde_f[IMJKM_f])+delz[1]*(dely[1]*ftilde_f[IMJMK_f]
					+dely[1]*ftilde_f[IMJK_f]))/((delz[1]+delz[1])
					*(dely[1]+dely[1]));
				const double rhot=((rho_f[IMJKM_f]+rho_f[IMJK_f]+rho_f[IJKM_f]+rho_f[IJK_f])/4.0)
					*(delx[1]*(delz[1]*ftilde_f[IMJKM_f]+delz[1]
					*ftilde_f[IMJK_f])+delx[1]*(delz[1]*ftilde_f[IJKM_f]
					+delz[1]*ftilde_f[IJK_f]))/((delz[1]+delz[1])
					*(delx[1]+delx[1]));
				const double rhob=((rho_f[IMJMKM_f]+rho_f[IMJMK_f]+rho_f[IJMKM_f]+rho_f[IJMK_f])/4.0)
					*(delx[1]*(delz[1]*ftilde_f[IMJMKM_f]+delz[1]
					*ftilde_f[IMJMK_f])+delx[1]*(delz[1]*ftilde_f[IJMKM_f]
					+delz[1]*ftilde_f[IJMK_f]))/((delz[1]+delz[1])
					*(delx[1]+delx[1]));
				const double rhoo=((rho_f[IMJMK_f]+rho_f[IMJK_f]+rho_f[IJMK_f]+rho_f[IJK_f])/4.0)
					*(delx[1]*(dely[1]*ftilde_f[IMJMK_f]+dely[1]
					*ftilde_f[IMJK_f])+delx[1]*(dely[1]*ftilde_f[IJMK_f]
					+dely[1]*ftilde_f[IJK_f]))/((dely[1]+dely[1])
					*(delx[1]+delx[1]));
				const double rhou=((rho_f[IMJMKM_f]+rho_f[IMJKM_f]+rho_f[IJMKM_f]+rho_f[IJKM_f])/4.0)
					*(delx[1]*(dely[1]*ftilde_f[IMJMKM_f]+dely[1]
					*ftilde_f[IMJKM_f])+delx[1]*(dely[1]*ftilde_f[IJMKM_f]
					+dely[1]*ftilde_f[IJKM_f]))/((dely[1]+dely[1])
					*(delx[1]+delx[1]));

				gradrox_f[IJK_f]=(rhor-rhol)*rdelxl[1];
				gradroy_f[IJK_f]=(rhot-rhob)*rdelyb[1];
				gradroz_f[IJK_f]=(rhoo-rhou)*rdelzu[1];
			}
			
	//impose contact angle later ...ashish
	
	//compute avnx,avny,avnz
	for(k=1;k<km1_f;k++)
		for(j=1;j<jm1_f;j++)
			for(i=1;i<im1_f;i++)
			{	
				//if(not a triple-point && not a three-phase)
				if(triple_flg[IJK_f] == 0 && !(psi_f[IJK_f] >= em6 && f_f[IJK_f] >= em6 && 1.0-f_f[IJK_f]-psi_f[IJK_f] >= em6)) {
				//if(triple_flg[IJK_f]==0) {
					avnx_f[IJK_f]=(gradrox_f[IPJK_f]+gradrox_f[IPJPK_f]
						+gradrox_f[IJPK_f]+gradrox_f[IJK_f]+gradrox_f[IPJKP_f]
						+gradrox_f[IPJPKP_f]+gradrox_f[IJPKP_f]+gradrox_f[IJKP_f]) / 8.0;
					avny_f[IJK_f]=(gradroy_f[IPJK_f]+gradroy_f[IPJPK_f]
						+gradroy_f[IJPK_f]+gradroy_f[IJK_f]+gradroy_f[IPJKP_f]
						+gradroy_f[IPJPKP_f]+gradroy_f[IJPKP_f]+gradroy_f[IJKP_f]) / 8.0;
					avnz_f[IJK_f]=(gradroz_f[IPJK_f]+gradroz_f[IPJPK_f]
						+gradroz_f[IJPK_f]+gradroz_f[IJK_f]+gradroz_f[IPJKP_f]
						+gradroz_f[IPJPKP_f]+gradroz_f[IJPKP_f]+gradroz_f[IJKP_f]) / 8.0;
				}
			}
			
	//copy avnx from i=1 to i=0 plane and similar for other components.. at real computational boundaries
	//if (kl > 2 && mpi.Neighbors[0] == -1)
	if (mpi.Neighbors[0] == -1)
	{
		for (k=1;k<km1_f;k++)
			for (j=1;j<jm1_f;j++)
			{
				avnx_f[IND_f(0,j,k)]=avnx_f[IND_f(1,j,k)];
				avny_f[IND_f(0,j,k)]=avny_f[IND_f(1,j,k)];
				avnz_f[IND_f(0,j,k)]=avnz_f[IND_f(1,j,k)];
				
			}
			
			/*for(i=0;i<3;i++) 
			 for(j=0;j<=jm1_f;j++)
			  for(k=0;k<=km1_f;k++) {
				  avnx_f[IJK_f] = t_nor.x; avny_f[IJK_f] = t_nor.y; avnz_f[IJK_f] = t_nor.z;
			  }*/
	}
	//if (kr > 2 && mpi.Neighbors[1] == -1)
	if (mpi.Neighbors[1] == -1)
	{
		for (k=1;k<km1_f;k++)
			for (j=1;j<jm1_f;j++)
		{
			avnx_f[IND_f(im1_f,j,k)]=avnx_f[IND_f(im2_f,j,k)];
			avny_f[IND_f(im1_f,j,k)]=avny_f[IND_f(im2_f,j,k)];
			avnz_f[IND_f(im1_f,j,k)]=avnz_f[IND_f(im2_f,j,k)];
		}
		
		/*for(i=im1_f;i>im1_f-3;i--) 
		 for(j=0;j<=jm1_f;j++)
		  for(k=0;k<=km1_f;k++) {
			avnx_f[IJK_f] = t_nor.x; avny_f[IJK_f] = t_nor.y; avnz_f[IJK_f] = t_nor.z;
		  }*/
	}
	//if (kb > 2 && mpi.Neighbors[2] == -1)
	if (mpi.Neighbors[2] == -1)
	{
		for (k=1;k<km1_f;k++)
			for (i=1;i<imax_f;i++)
			{
				avnx_f[IND_f(i,0,k)]=avnx_f[IND_f(i,1,k)];
				avny_f[IND_f(i,0,k)]=avny_f[IND_f(i,1,k)];
				avnz_f[IND_f(i,0,k)]=avnz_f[IND_f(i,1,k)];
			}
			
		/*for(j=0;j<3;j++)
		 for(k=0;k<=km1_f;k++)
		  for(i=0;i<=im1_f;i++) {
			  avnx_f[IJK_f] = t_nor.x; avny_f[IJK_f] = t_nor.y; avnz_f[IJK_f] = t_nor.z;
		  }*/
	}
	//if (kf > 2 && mpi.Neighbors[3] == -1)
	if (mpi.Neighbors[3] == -1)
	{
		for (k=1;k<km1_f;k++)
			for (i=1;i<imax_f;i++)
		{
			avnx_f[IND_f(i,jm1_f,k)]=avnx_f[IND_f(i,jm2_f,k)];
			avny_f[IND_f(i,jm1_f,k)]=avny_f[IND_f(i,jm2_f,k)];
			avnz_f[IND_f(i,jm1_f,k)]=avnz_f[IND_f(i,jm2_f,k)];
		}
		
	   	/*for(j=jm1_f;j>= jm2_f-1;j--)
		 for(i=0;i<=im1_f;i++)
		  for(k=0;k<=km1_f;k++) {
			 avnx_f[IJK_f] = t_nor.x; avny_f[IJK_f] = t_nor.y; avnz_f[IJK_f] = t_nor.z;
		   }*/
	}
	//if (ku > 2 && mpi.Neighbors[4] == -1)
	if (mpi.Neighbors[4] == -1)
	{
		memcpy (&avnx_f[IND_f(0,0,0)], &avnx_f[IND_f(0,0,1)], NX_f*NY_f*sizeof(double));
		memcpy (&avny_f[IND_f(0,0,0)], &avny_f[IND_f(0,0,1)], NX_f*NY_f*sizeof(double));
		memcpy (&avnz_f[IND_f(0,0,0)], &avnz_f[IND_f(0,0,1)], NX_f*NY_f*sizeof(double));
		
		/*for(k=0;k<3;k++)
		 for(j=0;j<=jm1_f;j++)
		  for(i=0;i<=im1_f;i++) {
			  avnx_f[IJK_f] = t_nor.x; avny_f[IJK_f] = t_nor.y; avnz_f[IJK_f] = t_nor.z;
		  }*/
	}
	//if (ko > 2 && mpi.Neighbors[5] == -1)
	if (mpi.Neighbors[5] == -1)
	{
		memcpy (&avnx_f[IND_f(0,0,km1_f)], &avnx_f[IND_f(0,0,km2_f)], NX_f*NY_f*sizeof(double));
		memcpy (&avny_f[IND_f(0,0,km1_f)], &avny_f[IND_f(0,0,km2_f)], NX_f*NY_f*sizeof(double));
		memcpy (&avnz_f[IND_f(0,0,km1_f)], &avnz_f[IND_f(0,0,km2_f)], NX_f*NY_f*sizeof(double));
		
		//following is a fix for Y-advection ... remove later ... ashish
		/*for(k=km1_f;k>= km2_f-1;k--)
		 for(i=0;i<=im1_f;i++)
		  for(j=0;j<=jm1_f;j++) {
			 avnx_f[IJK_f] = t_nor.x; avny_f[IJK_f] = t_nor.y; avnz_f[IJK_f] = t_nor.z;
		   }*/
	}
	
	//exchange normals
	xchg_f<double>(avnx_f);
	xchg_f<double>(avny_f);
	xchg_f<double>(avnz_f);
	
	//normalize the normal vectors
	for(k=1;k<kmax_f;k++)
		for(j=1;j<jmax_f;j++)
			for(i=1;i<imax_f;i++)
			{
				const double rgradmag=1.e0/sqrt(SQUARE(gradrox_f[IJK_f])+SQUARE(gradroy_f[IJK_f])+SQUARE(gradroz_f[IJK_f])+tiny);
				gradrox_f[IJK_f]*=rgradmag;
				gradroy_f[IJK_f]*=rgradmag;
				gradroz_f[IJK_f]*=rgradmag;
			}
			
	//exchange gradro_ arrays
	arecvplane_f<double> (gradrox_f, 1);
	arecvplane_f<double> (gradroy_f, 1);
	arecvplane_f<double> (gradroz_f, 1);
	sendplane_f<double> (gradrox_f, 2);
	sendplane_f<double> (gradroy_f, 2);
	sendplane_f<double> (gradroz_f, 2);
	arecvspacewait();
	arecvplane_f<double> (gradrox_f, 3);
	arecvplane_f<double> (gradroy_f, 3);
	arecvplane_f<double> (gradroz_f, 3);
	sendplane_f<double> (gradrox_f, 4);
	sendplane_f<double> (gradroy_f, 4);
	sendplane_f<double> (gradroz_f, 4);
	arecvspacewait();
	arecvplane_f<double> (gradrox_f, 5);
	arecvplane_f<double> (gradroy_f, 5);
	arecvplane_f<double> (gradroz_f, 5);
	sendplane_f<double> (gradrox_f, 6);
	sendplane_f<double> (gradroy_f, 6);
	sendplane_f<double> (gradroz_f, 6);
	arecvspacewait();
}
#endif
void normals_from_fine(double *cnx, double *cny, double *cnz,
					   double *fnx, double *fny, double *fnz) {
	 for(int k=1;k<=km1;k++)
	  for(int j=1;j<=jm1;j++)
	   for(int i=1;i<=im1;i++) {
		   cnx[IND(i,j,k)] = fnx[IND_f(2*i-1,2*j-1,2*k-1)];
		   cny[IND(i,j,k)] = fny[IND_f(2*i-1,2*j-1,2*k-1)];
		   cnz[IND(i,j,k)] = fnz[IND_f(2*i-1,2*j-1,2*k-1)];
	   }
}
#endif
