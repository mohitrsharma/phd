#include <stdlib.h>
#include <math.h>
#include "testing.h"
#include "ripple.h"
#include "vector.h"
#include <string.h>/*memcpy*/
#include "setup_airway_tree.h"

template <class T> void rval(const char *value, T &data);
void read_values(double *plane, double *symmetry, double *N_plug_blockages, double *plug_length, double *plug_center_z, double  *radius_array, double *length_array);

double distance_line_to_point(st_point *vec_c, st_point *vec_a, st_point *vec_b);
void init_cutting_plane_2(st_point *pcent, double phi0);
void constructTube(double ref_x, double x_dim, double y_dim, double z_dim, double radius, double length, double angle, int plane, int tapering, double film_array, int last_bi);

class BST
{
public:
	
	struct node
	{
		int n_key;
		
		double x_pos, y_pos, z_pos;
		double angle;
		double angle_y;
		double radius;
		double length;
		double f_thickness;
		
		node *left;
		node *right;
		node *center;
	};
	
	node *root; // points to the top of our tree
	BST(double x, double y, double z, double r, double l, double f)
	{
		root = new node;
		
		root -> left = NULL;
		root -> right = NULL;
		root -> center = NULL;

		root -> angle = 90.0*pi/180;
		root -> radius = r;
		root -> length = l;
		root -> x_pos = x;
		root -> y_pos = y;
		root -> z_pos = z;
		root -> f_thickness = f;
	}
	
	node* createTube(int key) // Creates a leaf node that returns a type of node*
	{
		node *n = new node;
		
		n -> n_key = key;
		n -> left = NULL;
		n -> right = NULL;
		n -> center = NULL;
	
		return n;
	}
	
	void addTube(int key, double myRadius, double myLength, int plane, int tapering, double film_array, int last_bi)
	{
		addTube(key, root, myRadius, myLength, plane, tapering, film_array, last_bi); 
	}
	
	void addTube(int key, node *ptr, double myRadius, double myLength, int plane, int tapering, double film_array, int last_bi)
	{
		double a, p, b, px;
		
		if (myRadius == 2.e-3)
		{
			root -> n_key = key;
			
			constructTube(root->x_pos, root->x_pos, root->y_pos, root->z_pos, root->radius, root->length, root->angle, plane, tapering, film_array, last_bi);
		}
		else if (key < ptr -> n_key) // If the key is less than the root key, the new daughter tube is on the left
		{
			if (ptr -> left == NULL) // If the left daughter tube is not created, lets create it.
			{
				ptr -> left = createTube(key); // Set my empty left node to a new node which will have its own key and left and right daughter tube
				ptr -> left -> length = myLength;
				ptr -> left -> radius = myRadius; 
				ptr -> left -> angle = ptr -> angle - tube_angle/2;
				
				if( ptr -> left -> angle == 90*pi/180) // Determines if it is a straight pipe
				{
					ptr -> left -> x_pos = ptr -> x_pos;
					ptr -> left -> y_pos = ptr -> y_pos;
					ptr -> left -> z_pos = ptr -> z_pos - myLength;
					
					goto skip_1;
				}
				
				ptr -> left -> x_pos = ptr -> x_pos - myLength*cos(ptr -> left -> angle) - myRadius*cos(90*pi/180 - ptr -> left -> angle);
				if (ptr -> angle != 90*pi/180) ptr -> left -> x_pos = ptr -> x_pos - myLength*cos(ptr -> left -> angle) - myRadius*cos(90*pi/180 - ptr -> left -> angle)*cos(ptr -> left -> angle);

				ptr -> left -> y_pos = ptr -> y_pos;

				p = (ptr -> z_pos) + (ptr -> radius)*tan(ptr -> left -> angle)*sin(ptr -> angle); // pz
				px = ptr -> x_pos + (ptr -> radius)*tan(ptr -> left -> angle)*cos(ptr -> angle); // px

				b = (ptr -> left -> radius)*sin(90*pi/180 - ptr -> left -> angle); // Correct
				
				a = ptr -> left -> x_pos - (ptr -> left -> radius)*cos(90*pi/180 - ptr -> left -> angle) - b/tan(ptr -> left -> angle); // Correct
				
				ptr -> left -> z_pos = p - (ptr -> x_pos - a)*tan(ptr -> left -> angle)*sin(ptr -> angle); // Correct
				if (px != ptr -> x_pos) 
				{
					ptr -> left -> z_pos = p - (px - a)*tan(ptr -> left -> angle) + 10e-4;
					// if (mpi.MyRank == 0) printf("Made it into this new px statement\n");
				}
				// if (mpi.MyRank == 0) printf("angle = %e, %e %e\n %e %e\n", ptr -> left -> angle*180/pi, ptr -> x_pos, ptr -> z_pos, ptr -> left -> x_pos, ptr -> left -> z_pos);
				
				skip_1:
				if (plane == 1) // If daughter tubes are out of plane
				{
					constructTube(ptr->x_pos, ptr->left->x_pos, ptr->left->y_pos, ptr->left->z_pos, myRadius, myLength, ptr->left->angle, plane, tapering, film_array, last_bi);
					
					ptr -> left -> x_pos = (ptr->left->x_pos)*cos(90*pi/180) - (ptr->left->y_pos)*sin(90*pi/180);
					ptr -> left -> y_pos = (ptr->left->x_pos)*sin(90*pi/180) + (ptr->left->y_pos)*cos(90*pi/180);
				}
				
				if (plane == 0) constructTube(ptr->x_pos, ptr->left->x_pos, ptr->left->y_pos, ptr->left->z_pos, myRadius, myLength, ptr->left->angle, plane, tapering, film_array, last_bi);
			}
			else 
			{
				addTube(key, ptr -> left, myRadius, myLength, plane, tapering, film_array, last_bi);
			}
		}
		else if (key > ptr -> n_key)
		{
			if (ptr -> right == NULL)
			{
				ptr -> right = createTube(key);
				
				ptr -> right -> length = myLength;
				ptr -> right -> radius = myRadius; 
				ptr -> right -> angle = ptr -> angle + tube_angle/2;
				
				if( ptr -> right -> angle == 90*pi/180) // Determins if it is a straight pipe
				{
					ptr -> right -> x_pos = ptr -> x_pos;
					ptr -> right -> y_pos = ptr -> y_pos;
					ptr -> right -> z_pos = ptr -> z_pos - myLength;
					
					goto skip_2;
				}
				
				double temp_angle;
				if (ptr -> right -> angle > 90*pi/180) temp_angle = 270*pi/180 - ptr -> right -> angle;
				else temp_angle = 90*pi/180 - ptr -> right -> angle;
				
				ptr -> right -> x_pos = ptr -> x_pos - myLength*cos(ptr -> right -> angle) - myRadius*cos(temp_angle);
				if (ptr -> angle != 90*pi/180) ptr -> right -> x_pos = ptr -> x_pos - myLength*cos(ptr -> right -> angle) - myRadius*cos(temp_angle)*cos(30*pi/180); // small fix here
				ptr -> right -> y_pos = ptr -> y_pos;
				
				p = (ptr -> z_pos) - (ptr -> radius)*tan(ptr -> right -> angle)*sin(ptr -> angle);
				px = ptr -> x_pos - (ptr -> radius)*tan(ptr -> right -> angle)*cos(ptr -> angle); // px
				
				b = (ptr -> right -> radius)*sin(temp_angle); // Correct
				a = ptr -> right -> x_pos - (ptr -> right -> radius)*cos(temp_angle) - b/tan(ptr -> right -> angle);
				
				ptr -> right -> z_pos = p + (a - ptr -> x_pos)*tan(ptr -> right -> angle)*sin(ptr -> angle);
				if (px != ptr -> x_pos) 
				{
					ptr -> right -> z_pos = p + (a - px)*tan(ptr -> right -> angle) + 10e-4;
				}
				
				skip_2:
				
				if (plane == 1) // If daughter tubes are out of plane
				{
					constructTube(ptr->x_pos, ptr->right->x_pos, ptr->right->y_pos, ptr->right->z_pos, myRadius, myLength, ptr->right->angle, plane, tapering, film_array, last_bi);
					
					ptr -> right -> x_pos = (ptr->right->x_pos)*cos(90*pi/180) - (ptr->right->y_pos)*sin(90*pi/180);
					ptr -> right -> y_pos = (ptr->right->x_pos)*sin(90*pi/180) + (ptr->right->y_pos)*cos(90*pi/180);
				}

				if (plane == 0) constructTube(ptr->x_pos, ptr->right->x_pos, ptr->right->y_pos, ptr->right->z_pos, myRadius, myLength, ptr->right->angle, plane, tapering, film_array, last_bi);
			}
			else 
			{
				addTube(key, ptr -> right, myRadius, myLength, plane, tapering, film_array, last_bi);
			}
			
		}
		else if (key == ptr -> n_key)
		{
			if (ptr -> center == NULL)
			{
				ptr -> center = createTube(key);
				
				ptr -> center -> length = myLength;
				ptr -> center -> radius = myRadius; 
				ptr -> center -> angle = 90*pi/180;
				
				ptr -> center -> x_pos = ptr -> x_pos;
				ptr -> center -> y_pos = ptr -> y_pos;
				ptr -> center -> z_pos = ptr -> z_pos - myLength;
					
				constructTube(ptr->x_pos, ptr->center->x_pos, ptr->center->y_pos, ptr->center->z_pos, myRadius, myLength, ptr->center->angle, plane, tapering, film_array, last_bi);
				
			}
		}
		else
		{
			printf("They key = %d has already been added, Rank = %d", key, mpi.MyRank);
		}
		
	}
};

void init_cutting_plane_2(st_point *pcent, double phi0)
{
	double H,L;
	st_point pt[4],ct[4]; st_point cent;
	st_point nor[4];
	st_polyhedron cube_poly, cube_poly2, tmp_poly1, tmp_poly2, tmp_poly3, tmp_poly4;
	int i,j,k,ii;
	
	equate_pt(&cent,pcent);
	
	pt[0].x = cent.x, pt[0].y = cent.y, pt[0].z = cent.z;
	nor[0].x = -cos(phi0), nor[0].y = 0.0, nor[0].z = -sin(phi0);
	
	for(ii=0;ii<1;ii++) {
		pt[ii].x /= (0.5*delx[1]);
		pt[ii].y /= (0.5*dely[1]);
		pt[ii].z /= (0.5*delz[1]);
	}
	
	const_sim_polyhedron(&cube_poly);
	
	for(i=1;i<im1_f;i++)
	 for(j=1;j<jm1_f;j++)
	  for(k=1;k<km1_f;k++) {
			//perform scaling in unit coordinate system of current cell
			for(ii=0;ii<1;ii++) {
				ct[ii].x = pt[ii].x-(double)(i-1+2*mpi.OProc[0]);
				ct[ii].y = pt[ii].y-(double)(j-1+2*mpi.OProc[1]);
				ct[ii].z = pt[ii].z-(double)(k-1+2*mpi.OProc[2]); 
			}
			
			const_com_polyhedron(&cube_poly,&tmp_poly1,&(ct[0]),&(nor[0]),0);
			
			psi_f[IJK_f] -= calc_poly_vol(&tmp_poly1);
			f_f[IJK_f] -= calc_poly_vol(&tmp_poly1);
	  }
}

void vec_dot(double *d, st_point *vec_a, st_point *vec_b);
void constructTube(double ref_x, double x_dim, double y_dim, double z_dim, double radius, double length, double angle, int plane, int tapering, double film_array, int last_bi)
{
	int i,j,k;
	double tx, ty, tz, txm, tym, tzm, p_vol, f_vol;
	st_point X0, X00, X1, X11;

	double thetax = angle;
	
	double thetaz;
	if (angle > 90*pi/180) thetaz= 270*pi/180 - angle;
	else thetaz = 90*pi/180 - angle;
	
	double dist[8]; //distance from vertex point of cell to center line
	int cnt1; //counter for number of vertexes outside of the cylinder
	int cnt2; //counter for number of vertexes inside the hollow part
	
	double radius_waterfilm; // for a two fine cell thick water film coating the solid
	radius_waterfilm = radius - film_array*radius; // = 0.36*(1 - exp(-2*Ca^0.523)) * radius
	
	double right_face;
	double left_face;
	double over_face;
	double under_face;
	double top_face;
	double bottom_face;
	
	//double P, opp;
	
	//right_face = x_dim + (length*cos(thetax)) + (radius*cos(thetaz));
	//x_carina = right_face; // global
	
	//left_face = x_dim - (radius/cos(thetaz));
	
	//P = (right_face - left_face)*tan(thetax) + z_dim;  // Must account for height above the boundary.
	//opp = radius*tan(thetax);
	
	//double z3 = P - opp; // Recalculation
	//z_bifurcation = z3; // global
	
	//z_upper_bound = z3 + length; //global, needed for y boundary condition
	
	
	if (ref_x == x_dim)
	{
		right_face = floor(2*((x_dim + (radius*cos(thetaz)) + (delx[1]/20))/delx[1]));
		left_face = floor(2*((x_dim - (radius/cos(thetaz)) - (delx[1]/20))/delx[1]));
		over_face = floor(2*(z_dim + length)/delz[1]);
		under_face = floor(2*((z_dim + (delx[1]/20))/delx[1]));
		top_face = floor(2*((y_dim + radius + (delx[1]/20))/delx[1]));
		bottom_face = floor(2*((y_dim - radius - (delx[1]/20))/delx[1]));
		
		if (last_bi == 2) {
			over_face += floor(1.5e-3/delx[1]);
		}
	}
	else if (x_dim < ref_x)
	{
		right_face = floor(2*((x_dim + (length*cos(thetax)) + (radius*cos(thetaz)) + (delx[1]/20))/delx[1]));
		left_face = floor(2*((x_dim - (radius/cos(thetaz)) + (delx[1]/20))/delx[1]));
		over_face = (right_face - left_face)*tan(thetax) + 2*z_dim/delx[1];
		under_face = floor(2*((z_dim - (radius*sin(thetaz)) + (delx[1]/20))/delx[1]));
		top_face = floor(2*((y_dim + radius + (delx[1]/20))/delx[1]));
		bottom_face = floor(2*((y_dim - radius - (delx[1]/20))/delx[1]));
		
		if (last_bi == 1) {
			left_face = floor(2*((x_dim - 0.485*(radius/cos(thetaz)) + (delx[1]/20))/delx[1]));
			//left_face = floor(2*((x_dim - 0.35*(radius/cos(thetaz)) + (delx[1]/20))/delx[1])); // old method, not smooth transition

		}
	}
	else
	{
		right_face = floor(2*((x_dim - (radius/cos(thetaz)) + (delx[1]/20))/delx[1]));
		left_face = floor(2*((x_dim + (length*cos(thetax)) + (radius*cos(thetaz)) + (delx[1]/20))/delx[1]));
		over_face = -(right_face - left_face)*tan(thetax) + 2*z_dim/delx[1];
		under_face = floor(2*((z_dim - (radius*sin(thetaz)) + (delx[1]/20))/delx[1]));
		top_face = floor(2*((y_dim + radius + (delx[1]/20))/delx[1]));
		bottom_face = floor(2*((y_dim - radius - (delx[1]/20))/delx[1]));
		
		if (last_bi == 1) {
			right_face = floor(2*((x_dim - 0.485*(radius/cos(thetaz)) + (delx[1]/20))/delx[1]));
			//right_face = floor(2*((x_dim - 0.35*(radius/cos(thetaz)) + (delx[1]/20))/delx[1]));
		}
	}
	
	int o_f = ((int)over_face) +1;
	int u_f = ((int)under_face) +1;
	int r_f = ((int)right_face) +1;
	int l_f = ((int)left_face) +1;
	int t_f = ((int)top_face) +1;
	int b_f = ((int)bottom_face) +1;
	
	// Need to Check if the box is correct or if it should be the mpi boundary and make coordinates local not global
	if( o_f > (km1_f+2*mpi.OProc[2]) ) 
	{
		o_f = km1_f;
	}
	else 
	{
		o_f -= 2*mpi.OProc[2];
	}
	
	if( u_f < (1+2*mpi.OProc[2]) ) 
	{
		u_f = 1;
	}
	else
	{
		u_f -= 2*mpi.OProc[2];
	}
	// Need to now do the right and left faces
	if( r_f > (im1_f+2*mpi.OProc[0]) ) 
	{
		r_f = im1_f;
	}
	else 
	{
		r_f -= 2*mpi.OProc[0];
	}
	
	if( l_f < (1+2*mpi.OProc[0]) ) 
	{
		l_f = 1;
	}
	else
	{
		l_f -= 2*mpi.OProc[0];
	}
	if( t_f > (jm1_f+2*mpi.OProc[1]) ) 
	{
		t_f = jm1_f;
	}
	else 
	{
		t_f -= 2*mpi.OProc[1];
	}
	
	if( b_f < (1+2*mpi.OProc[1]) ) 
	{
		b_f = 1;
	}
	else
	{
		b_f -= 2*mpi.OProc[1];
	}
	
	if (mpi.MyRank == 0) {
		
		printf("x1 = %e x2 = %e z1 = %e z2 = %e\n", x_dim, x_dim+length*cos(thetax), z_dim, z_dim+length*sin(thetax));
		
	}
	
	for(int i=l_f; i<r_f; i++)
		for(int j=b_f; j<t_f; j++)
			for(int k=u_f; k<o_f; k++)
			{
				tx = (i+2*mpi.OProc[0]) * (0.5*delx[1]);
				ty = (j+2*mpi.OProc[1]) * (0.5*dely[1]);
				tz = (k+2*mpi.OProc[2]) * (0.5*delz[1]);
				txm = tx - (0.5*delx[1]);
				tym = ty - (0.5*dely[1]);
				tzm = tz - (0.5*delz[1]);
				
				X1.x = x_dim;
				X1.y = y_dim;
				X1.z = z_dim;
				X11.x = x_dim + length*cos(thetax); // this needs to be changed
				X11.y = y_dim; // + length*cos(90*pi/180); // always 90 for in plane
				X11.z = z_dim + length*sin(thetax); // this needs to be changed, just temporary
				
				X0.x = txm;
				X0.y = tym;
				X0.z = tzm;
				dist[0] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = txm;
				X0.y = ty;
				X0.z = tzm;
				dist[1] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = txm;
				X0.y = tym;
				X0.z = tz;
				dist[2] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = txm;
				X0.y = ty;
				X0.z = tz;
				dist[3] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = tx;
				X0.y = ty;
				X0.z = tzm;
				dist[4] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = tx;
				X0.y = tym;
				X0.z = tzm;
				dist[5] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = tx;
				X0.y = tym;
				X0.z = tz;
				dist[6] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = tx;
				X0.y = ty;
				X0.z = tz;
				dist[7] = distance_line_to_point(&X0, &X1, &X11);
				
				cnt1=0; //outside of cylinder
				cnt2=0; //inside of hollow part
				
				for(int qq=0;qq<8;qq++)
				{
					if(dist[qq]>radius) cnt1++;
					if(dist[qq]>radius_waterfilm) cnt2++;
				}
					if(cnt2==8) f_vol=0.0;
					else if(cnt2==0) f_vol=1.0;
					else
					{	f_vol=0.0;
						for(int l=0;l<25;l++)
							for(int m=0;m<25;m++)
								for(int n=0;n<25;n++)
								{	X00.x=txm+(l+0.5)/25.0*delx[1]*0.5e0;
									X00.y=tym+(m+0.5)/25.0*dely[1]*0.5e0;
									X00.z=tzm+(n+0.5)/25.0*delz[1]*0.5e0;
									if( (distance_line_to_point(&X00, &X1, &X11))<radius_waterfilm) f_vol+=6.4e-5;
								}
					}
					f_f[IJK_f] += f_vol;	
					if(cnt1==8) p_vol=0.0;
					else if(cnt1==0) p_vol=1.0;
					else
					{	p_vol=0.0;
						for(int l=0;l<25;l++)
							for(int m=0;m<25;m++)
								for(int n=0;n<25;n++)
								{	X00.x=txm+(l+0.5)/25.0*delx[1]*0.5e0;
									X00.y=tym+(m+0.5)/25.0*dely[1]*0.5e0;
									X00.z=tzm+(n+0.5)/25.0*delz[1]*0.5e0;
									if( (distance_line_to_point(&X00, &X1, &X11))<radius) p_vol+=6.4e-5;
								}		
					}	
				psi_f[IJK_f] += p_vol;
			}
	
	st_point center;
	center.x = x_dim; center.y = y_dim; center.z = z_dim;
	
	if (last_bi == 0 || last_bi == 1)
	{
		if (last_bi == 1) {
			center.x -= 0.7e-3 * cos(thetax);
			center.z -= 0.7e-3 * sin(thetax);
		}
		init_cutting_plane_2(&center, angle);
	}
	for(i=0;i<=im1_f;i++)
		for(j=0;j<=jm1_f;j++) 
			for(k=0;k<=km1_f;k++)
			{
				if (psi_f[IJK_f] < em6) psi_f[IJK_f] = 0.0;
		
				if (psi_f[IJK_f] > em61) psi_f[IJK_f] = 1.0;
				
				if (f_f[IJK_f] < em6) f_f[IJK_f] = 0.0;
		
				if (f_f[IJK_f] > em61) f_f[IJK_f] = 1.0;
				
			}
	
	// Now lets right some code to taper the cylinders:
	// This code essentially just reconstructs the same cylinders
	// But tapers them starting at the under face, using smaller radius.
	// Should be done after the plane has been cut,
	// But then a new plane needs to be cut again after tapering.
	
	if (tapering == 1) {
	
	st_point norm;
	int checking_side = 0;
	
	if (ref_x == x_dim)
	{
		over_face = floor(2*((z_dim + (delx[1]/20))/delx[1]));
		under_face = floor(2*((z_dim - 1.4e-3 + (delx[1]/20))/delx[1]));
		
		norm.x = 0.0; //cos(angle);
		norm.y = 0.0;
		norm.z = 1.0; //sin(angle);
	}
	else if (x_dim < ref_x)
	{
		over_face = floor(2*((z_dim + (radius*sin(thetaz)) + (delx[1]/20))/delx[1]));
		under_face = floor(2*((z_dim - 1.4e-3 - radius*sin(thetaz) + (delx[1]/20))/delx[1]));
		
		norm.x = cos(thetax);
		norm.y = 0.0;
		norm.z = sin(thetaz);
		checking_side = 1;
	}
	else
	{
		over_face = floor(2*((z_dim + (radius*sin(thetaz)) + (delx[1]/20))/delx[1]));
		under_face = floor(2*((z_dim - 1.4e-3 - radius*sin(thetaz) + (delx[1]/20))/delx[1]));
		
		norm.x = cos(thetax);
		norm.y = 0.0;
		norm.z = sin(thetaz);
		checking_side = 2;
	}
	
	o_f = ((int)over_face) + 1;
	u_f = ((int)under_face) + 1;
	
	// Need to Check if the box is correct or if it should be the mpi boundary and make coordinates local not global
	if( o_f > (km1_f+2*mpi.OProc[2]) ) 
	{
		o_f = km1_f;
	}
	else 
	{
		o_f -= 2*mpi.OProc[2];
	}
	
	if( u_f < (1+2*mpi.OProc[2]) ) 
	{
		u_f = 1;
	}
	else
	{
		u_f -= 2*mpi.OProc[2];
	}

	double available_tcells; // # of avaiable tapering cells
	double radius_differnce;
	double tn_cells; // total number of needed cells
	
	double tapering_gradient;
	
	double new_radius = radius;
	double inside_radius = radius - 0.4e-3 - 0.5e-3; // radius - next_radius - additional_0.5e-3
	
	available_tcells = floor(2*((1.4e-3 + (delx[1]/20))/delx[1]));
	radius_differnce = radius - inside_radius; // Extra difference is needed hence the 0.5e-3
	
	tn_cells = (2*radius_differnce)/delx[1];
	
	tapering_gradient = (tn_cells / available_tcells)*0.5*delx[1];
	
	double result;
	st_point vector;
	
	double new_x_dim = x_dim;
	double new_z_dim = z_dim;
	
	while(new_radius > inside_radius) {
		
		new_radius -= tapering_gradient;
		radius_waterfilm = new_radius - 0.925*film_array;
	
		if (checking_side == 0) {
			new_x_dim = new_x_dim;
			new_z_dim = new_z_dim - delz[1];
		}
		else {
			new_x_dim = new_x_dim - delx[1]*cos(thetax);
			new_z_dim = new_z_dim - delz[1]*sin(thetax);
		}
	
		for(int i=l_f; i<r_f; i++)
			for(int j=b_f; j<t_f; j++)
				for(int k=u_f; k<o_f; k++)
				{
					tx = (i+2*mpi.OProc[0]) * (0.5*delx[1]);
					ty = (j+2*mpi.OProc[1]) * (0.5*dely[1]);
					tz = (k+2*mpi.OProc[2]) * (0.5*delz[1]);
					txm = tx - (0.5*delx[1]);
					tym = ty - (0.5*dely[1]);
					tzm = tz - (0.5*delz[1]);
					
					X1.x = x_dim;
					X1.y = y_dim;
					X1.z = z_dim;
					X11.x = x_dim + length*cos(thetax); // this needs to be changed
					X11.y = y_dim;
					X11.z = z_dim + length*sin(thetax); // this needs to be changed, just temporary
										
					X0.x = txm;
					X0.y = tym;
					X0.z = tzm;
					dist[0] = distance_line_to_point(&X0, &X1, &X11);
					X0.x = txm;
					X0.y = ty;
					X0.z = tzm;
					dist[1] = distance_line_to_point(&X0, &X1, &X11);
					X0.x = txm;
					X0.y = tym;
					X0.z = tz;
					dist[2] = distance_line_to_point(&X0, &X1, &X11);
					X0.x = txm;
					X0.y = ty;
					X0.z = tz;
					dist[3] = distance_line_to_point(&X0, &X1, &X11);
					X0.x = tx;
					X0.y = ty;
					X0.z = tzm;
					dist[4] = distance_line_to_point(&X0, &X1, &X11);
					X0.x = tx;
					X0.y = tym;
					X0.z = tzm;
					dist[5] = distance_line_to_point(&X0, &X1, &X11);
					X0.x = tx;
					X0.y = tym;
					X0.z = tz;
					dist[6] = distance_line_to_point(&X0, &X1, &X11);
					X0.x = tx;
					X0.y = ty;
					X0.z = tz;
					dist[7] = distance_line_to_point(&X0, &X1, &X11);
					
					cnt1=0; //outside of cylinder
					cnt2=0; //inside of hollow part
					
					for(int qq=0;qq<8;qq++)
					{
						if(dist[qq]>new_radius) cnt1++;
						if(dist[qq]>radius_waterfilm) cnt2++;
					}
					
					if(cnt2==8) f_vol=0.0;
					else if(cnt2==0) f_vol=1.0;
					else
					{	f_vol=0.0;
						for(int l=0;l<25;l++)
							for(int m=0;m<25;m++)
								for(int n=0;n<25;n++)
								{	X00.x=txm+(l+0.5)/25.0*delx[1]*0.5e0;
									X00.y=tym+(m+0.5)/25.0*dely[1]*0.5e0;
									X00.z=tzm+(n+0.5)/25.0*delz[1]*0.5e0;
									
									if( (distance_line_to_point(&X00, &X1, &X11)) < radius_waterfilm) {
										f_vol+=6.4e-5;
									}
								}
					}
						
					f_f[IJK_f] += f_vol;
						
					if(cnt1==8) p_vol=0.0;
					else if(cnt1==0) p_vol=1.0;
					else
					{
						p_vol=0.0;
						for(int l=0;l<25;l++)
							for(int m=0;m<25;m++)
								for(int n=0;n<25;n++)
								{	X00.x=txm+(l+0.5)/25.0*delx[1]*0.5e0;
									X00.y=tym+(m+0.5)/25.0*dely[1]*0.5e0;
									X00.z=tzm+(n+0.5)/25.0*delz[1]*0.5e0;
									
									if( (distance_line_to_point(&X00, &X1, &X11)) < new_radius) {
										p_vol+=6.4e-5;
									}
								}
					}
					psi_f[IJK_f] += p_vol;
				}
			
			center.x = new_x_dim; center.y = y_dim; center.z = new_z_dim;
			init_cutting_plane_2(&center, angle);
			for(i=0;i<=im1_f;i++)
				for(j=0;j<=jm1_f;j++) 
					for(k=0;k<=km1_f;k++)
					{
						if (psi_f[IJK_f] < em6) psi_f[IJK_f] = 0.0;
		
						if (psi_f[IJK_f] > em61) psi_f[IJK_f] = 1.0;
				
						if (f_f[IJK_f] < em6) f_f[IJK_f] = 0.0;
		
						if (f_f[IJK_f] > em61) f_f[IJK_f] = 1.0;
				
					}
		}
	}
}

void invert_field() {
	
	for(int i=1;i<im1_f;i++)
		for(int j=1;j<jm1_f;j++)
			for(int k=1;k<km1_f;k++)
			{
				if(psi_f[IJK_f] > em61) psi_f[IJK_f] = 1.0;
			}
	
	for(int i=1;i<im1_f;i++)
		for(int j=1;j<jm1_f;j++)
			for(int k=1;k<km1_f;k++)
			{
				psi_f[IJK_f] = 1 - psi_f[IJK_f];
			}
	
	for(int i=1;i<im1_f;i++)
		for(int j=1;j<jm1_f;j++)
			for(int k=1;k<km1_f;k++)		
			{
				if(f_f[IJK_f] > em61)
				{
					f_f[IJK_f] = 1;
				}
			}
	
	for(int i=1; i<im1_f; i++)
		for(int j=1; j<jm1_f; j++)
			for(int k=1; k<km1_f; k++)
			{
				f_f[IJK_f] = (1-f_f[IJK_f]);
			}
	
	for(int i=1;i<im1_f;i++)
		for(int j=1;j<jm1_f;j++)
			for(int k=1;k<km1_f;k++)		
			{
				if(f_f[IJK_f] < em6)
				{
					f_f[IJK_f] = 0;
				}
			}

	fine2stnd();
}

void init_ytube_geometry_node(int NA, int NB, double plane, double symmetry, double *radius_array, double *length_array, double *film_array, int sym_outflow)
{
	int i,j,k;
	double p_x, p_y, p_z, p_length, p_radius, p_film;
	double thetax, thetay, thetaz;
	st_point cent[1];
	st_point X0, X00, X1, X11;
	
	int treeKeys[] = {50, 25, 100, 16, 30, 75, 125};
	p_x = xe/2; 
	p_y = ye/2; 
	p_z = ze - length_array[0]; // Parent_Tube/Root_Node
	p_length = length_array[0];
	p_radius = radius_array[0];
	p_film = film_array[0];
	
	int plane_ar[] = {0, 0, 0, 0, 0, 0, 0};
	if (plane == 1.)
	{
		plane_ar[4] = 1;
		plane_ar[6] = 1;
		plane_ar[7] = 1;
		plane_ar[7] = 1;
	}
	
	int last_bi[] = {0, 0, 0, 1, 1, 1, 1};
	
	BST Ytube_tree(p_x, p_y, p_z, p_radius, p_length, p_film);
	
	for (i=0; i<3; ++i) 
	{
		int tapering = 1;
		Ytube_tree.addTube(treeKeys[i], radius_array[i], length_array[i], plane_ar[i], tapering, film_array[i], last_bi[i]);
	}
	
	for(i=0;i<=im1_f;i++)
		for(j=0;j<=jm1_f;j++) 
			for(k=0;k<=km1_f;k++)
			{
				if (psi_f[IJK_f] < em6) psi_f[IJK_f] = 0.0;
				
				if (psi_f[IJK_f] > 1) psi_f[IJK_f] = 1.0;
			}
	
	
	for (i=3; i<7; ++i) 
	{
		int tapering = 0;
		Ytube_tree.addTube(treeKeys[i], radius_array[i], length_array[i], plane_ar[i], tapering, film_array[i], last_bi[i]);
	}
	if (sym_outflow == 1)
	{
		for (i=3; i<7; ++i) 
		{
			int tapering = 0;
			last_bi[3] = 2;
			last_bi[4] = 2;
			last_bi[5] = 2;
			last_bi[6] = 2;
			Ytube_tree.addTube(treeKeys[i], radius_array[i], length_array[i], plane_ar[i], tapering, film_array[i], last_bi[i]);
		}
	}
	invert_field();
	
}

void initialize_ytube()
{
	int i,j,k;
	int NB, NA; // Number of bifurcations / number of airways
	int sym_outflow; // This determines if we need a an equal cross sectional area leaving the tubes at the outlet
	sym_outflow = 1;
	
	//read_airway_tree_input(); // Function which reads the airway_tree_input file
	//rval("NB", NB);
	NB = 2;
	if (mpi.MyRank == 0) printf("NB = %d\n",NB);
	NA = 0;
	for(i=0; i<=NB; ++i) NA += (int) pow(2,i);
	if (mpi.MyRank == 0) printf("NA = %d\n",NA);
	if (sym_outflow == 1) NA += (int) pow(2,NB); // Adds 1 for each airway in the last generation
	
	double plane, symmetry, N_plug_blockages;
	
	plane = 0;
	symmetry = 0;
	N_plug_blockages = 0;
	
	double plug_length, plug_center_z;
	
	double length_array[NA];
	double radius_array[NA];
	double film_array[NA];
	
	plug_frequency = 0; // distance between plugs divided by 2*average velocity

	radius_array[0] = 2e-3;
	radius_array[1] = 1.6e-3;
	radius_array[2] = 1.6e-3;
	
	radius_array[3] = 1.26e-3;
	radius_array[4] = 1.26e-3;
	radius_array[5] = 1.26e-3;
	radius_array[6] = 1.26e-3;

	length_array[0] = 15e-3;
	length_array[1] = 9.6e-3; // 14e-3;
	length_array[2] = 9.6e-3; // 14e-3;
	
	length_array[3] = 26e-3;
	length_array[4] = 26e-3;
	length_array[5] = 26e-3;
	length_array[6] = 26e-3;

	double initial_vel = 0.04;

	film_array[0] = 1.34 * pow(initial_vel*0.151/0.0307, 2./3.) / (1 + 1.34*2.5*pow(initial_vel*0.151/0.0307, 2./3.));
	
	film_array[1] = 1.34 * pow(initial_vel*0.151/0.0307, 2./3.) / (1 + 1.34*2.5*pow(0.78125*initial_vel*0.151/0.0307, 2./3.));
	film_array[2] = 1.34 * pow(initial_vel*0.151/0.0307, 2./3.) / (1 + 1.34*2.5*pow(0.78125*initial_vel*0.151/0.0307, 2./3.));
	
	film_array[3] = 1.34 * pow(initial_vel*0.151/0.0307, 2./3.) / (1 + 1.34*2.5*pow(0.62988*initial_vel*0.151/0.0307, 2./3.));
	film_array[4] = 1.34 * pow(initial_vel*0.151/0.0307, 2./3.) / (1 + 1.34*2.5*pow(0.62988*initial_vel*0.151/0.0307, 2./3.));
	film_array[5] = 1.34 * pow(initial_vel*0.151/0.0307, 2./3.) / (1 + 1.34*2.5*pow(0.62988*initial_vel*0.151/0.0307, 2./3.));
	film_array[6] = 1.34 * pow(initial_vel*0.151/0.0307, 2./3.) / (1 + 1.34*2.5*pow(0.62988*initial_vel*0.151/0.0307, 2./3.));

	/**
	double initial_vel = 0.041;	

	film_array[0] = 0.417*(1 - exp(-1.69*pow(initial_vel*0.151/0.0307,0.5025)) );

	film_array[1] = 0.417*(1 - exp(-1.69*pow(0.78125*initial_vel*0.151/0.0307,0.5025)) );
	film_array[2] = 0.417*(1 - exp(-1.69*pow(0.78125*initial_vel*0.151/0.0307,0.5025)) );

	film_array[3] = 0.417*(1 - exp(-1.69*pow(0.62988*initial_vel*0.151/0.0307,0.5025)) );
	film_array[4] = 0.417*(1 - exp(-1.69*pow(0.62988*initial_vel*0.151/0.0307,0.5025)) );
	film_array[5] = 0.417*(1 - exp(-1.69*pow(0.62988*initial_vel*0.151/0.0307,0.5025)) );
	film_array[6] = 0.417*(1 - exp(-1.69*pow(0.62988*initial_vel*0.151/0.0307,0.5025)) ); **/

	tube_angle = 60*pi/180;
	
	// Storing the F field of the plug so it is not over written with the following code:
	memcpy(plug_f, f_f, NX_f*NY_f*NZ_f*sizeof(double));
	
	memset(f, 0, NX*NY*NZ*sizeof(double));
	memset(f_f, 0, NX_f*NY_f*NZ_f*sizeof(double));
	
	// read_values(&plane, &symmetry, &N_plug_blockages, &plug_length, &plug_center_z, radius_array, length_array); // Reads values in the airway_tree_input file
	
	init_ytube_geometry_node(NA, NB, plane, symmetry, radius_array, length_array, film_array, sym_outflow); // Setup the geometry
	
	// Add back in the plug
	for(int i=1;i<im1_f;i++)
		for(int j=1;j<jm1_f;j++)
			for(int k=1;k<km1_f;k++)		
			{
				f_f[IJK_f] += plug_f[IJK_f];
			}
	fine2stnd();
}
