#include "ripple.h"

/******************************************************************************


Subroutine GLOBAL is called by:	PRTPLT

Subroutine GLOBAL calls:			

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

void global()
{
	//x,y,z momentum (xmv, ymv, zmv)
	//total kinetic energy (tke);
		
	int i,j,k;
	xmv=ymv=zmv=tke=0.0;

	for (i=1;i<im1;i++)
		for (j=1;j<jm1;j++)
//arg			for (k=MAX(1,kbot[IND(i,j,0)]); k<MIN(ktop[IND(i,j,0)],km1);k++)
			for (k=1;k<2;k++)
			{
				double umid=(u[IJK]+u[IMJK])/2.0;
				double vmid=(v[IJK]+v[IJMK])/2.0;
				double wmid=(w[IJK]+w[IJKM])/2.0;
				xmv += f[IJK]*umid;		
				ymv += f[IJK]*vmid;     
				zmv += f[IJK]*wmid;
				tke += f[IJK]*vol[IJK]*(SQUARE(umid)+SQUARE(vmid)+SQUARE(wmid));
			}
	tke /= pi/3*CUBE(radius)*(uf1*uf1 + vf1*vf1 + wf1*wf1);
}
