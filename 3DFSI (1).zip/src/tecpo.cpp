#include "ripple.h"
//#include "TECIO.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "rbd.h"
#include "testing.h"

#define RBD 1
#define TECP 2
#define NONE 0
#define FORMAT RBD

/******************************************************************************
This subrouitne is used to generate RBD files representing the obstacles in
the flow.  The RBD files can later be converted to tecplot binary data files
using RBD Convert.

Subroutine TECPO is called by:

Subroutine TECPO calls:

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

float dumy_var1;


void tecpo()
{
#if FORMAT==RBD
	//output in "rbd" (raw binary data) format. Use rbd2plt or RBD Convert(WIN32) to
	//convert rbd to TecPlot plt file.

	int i,j,k;
	char fname[256];

	//sprintf(fname,"obstacle.rbd");
	sprintf (fname, "o%03d-%03d.rbd", mpi.NProc, mpi.MyRank);

	FILE *out = fopen (fname, "wb");

	//initialize the RBD header
	struct rbd hdr;
	initrbd (&hdr);
	hdr.nproc = mpi.NProc;
	hdr.rank = mpi.MyRank;
	hdr.count = iplot;
	hdr.nx = dim.nx;
	hdr.ny = dim.ny;
	hdr.nz = dim.nz;
	hdr.time = t;
	memcpy (hdr.origin, mpi.OProc, 3*sizeof(int));

	hdr.nvar = 4;
	struct vname varnames[4];
	strcpy (varnames[0].name, "X");
	strcpy (varnames[1].name, "Y");
	strcpy (varnames[2].name, "Z");
	strcpy (varnames[3].name, "O");

	//write header to file
	if (sizeof(struct rbd) != 64)
	{
		printf ("sizeof rbd isn't 36\n");
		exit (1);
	}
	fwrite (&hdr, sizeof(struct rbd), 1, out);
	fwrite (varnames, sizeof(struct vname), hdr.nvar, out);

	//write data to file
	int n=1;
	for (k=0;k<kmax;k++)
		for (j=0;j<jmax;j++)
			for (i=0;i<imax;i++)
			{
				dumy_var1 = (float)xi[i];
				fwrite (&dumy_var1, sizeof(float), 1, out);
			}
	for (k=0;k<kmax;k++)
		for (j=0;j<jmax;j++)
			for (i=0;i<imax;i++)
			{
				dumy_var1 = (float)yj[j];
				fwrite (&dumy_var1, sizeof(float), 1, out);
			}
	for (k=0;k<kmax;k++)
		for (j=0;j<jmax;j++)
			for (i=0;i<imax;i++)
			{
				dumy_var1 = (float)zk[k];
				fwrite (&dumy_var1, sizeof(float), 1, out);
			}

	for (i=0; i < NX*NY*NZ; i++)
	{
		dumy_var1 = 1 - fabs ( (float)ac[i]);
		fwrite (&dumy_var1, sizeof(float), 1, out);
	}

	//close the output file.
	fclose (out);

    if (mpi.MyRank == 0)
        printf("Written obstacle.rbd\n");



//******TecPlot format
#elif FORMAT==TECP

	char fname[256];
	iplot++;
	sprintf (fname, "f%03d-%03d-%04d.plt",mpi.NProc, mpi.MyRank, iplot);

	int Debug=1;
	int VIsDouble=1;

	TECINI ("fname", "X Y Z U V W F", fname, ".", &Debug, &VIsDouble);
	TECZNE ("1", &dim.nx, &dim.ny, &dim.nz, "POINT", "");

	int i,j,k,n=1;
	for (k=0;k<kmax;k++)
		for (j=0;j<jmax;j++)
			for (i=0;i<imax;i++)
			{
				TECDAT (&n, &xi[i], &VIsDouble);
				TECDAT (&n, &yj[j], &VIsDouble);
				TECDAT (&n, &zk[k], &VIsDouble);
				TECDAT (&n, &u[IJK], &VIsDouble);
				TECDAT (&n, &v[IJK], &VIsDouble);
				TECDAT (&n, &w[IJK], &VIsDouble);
				TECDAT (&n, &f[IJK], &VIsDouble);
				//TECDAT (&n, &ac[IJK], &VIsDouble);
			}
	TECEND();
#endif
}
