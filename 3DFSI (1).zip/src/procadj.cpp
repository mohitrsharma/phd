#include "comm.h"
#include "ripple.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

/******************************************************************************
	Moves the processor boundary with a neighboring processor. Copies data 
	to/from the neighbor and reallocates local arrays and modifies nx,ny,nz 
	appropriately. Also ensures ghost cells are coherent with neighbor.

	dir = 0,1,2 = x,y,z.  Selects which boundary to move. 
	                      dir=0 moves a yz plane in the positive x direction by amount
						  dir=1 moves an xz plane in the positive y direction by amount
						  dir=2 moves an xy plane in the positive z direction by amount
	amount = integer      amount in cells to shift the processor boundary.
	index = < 0 | 1 >	  Selects the boundary to move. 0 moves boundary with lower coordinate.
					      1 moves boundary with higher coordinate.
	Every procadj call must be matched with a similar call with index switched and amount
	unchanged on the appropriate neighbor processor. A similar call must be made to all processors
	sharing the same boundary being moved, otherwise neighbors(6) becomes inaccurate.

	procadj acts only on the local processor.

Subroutine PROCADJ is called by:	LOADBALANCE

Subroutine PROCADJ calls:			

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

void BackupArrays(int nx, int ny, int nz);
void FreeArrays();
void RestoreArraysE (int nnx, int nny, int nnz, int nx, int ny, int nz, int xo, int yo, int zo);
void RestoreArraysS (int nnx, int nny, int nnz, int nx, int ny, int nz, int xo, int yo, int zo);

//temporary arrays to preserve data when resizing arrays.
double *tu, *tv, *tw, *tf, *tp;
double *tun, *tvn, *twn, *tfn, *tpn;


void procadj (int dir, int index, int amount)
{

int nnx,nny,nnz;	//new size.

	//programmer sanity check ;) Ensure processors aren't emptied.
	switch (dir)
	{
		case 0: if (dim.nx+(index?amount:-amount)-2 <1) {printf ("Tried to procadj too much.\n"); exit (1);} break;
		case 1: if (dim.ny+(index?amount:-amount)-2 <1) {printf ("Tried to procadj too much.\n"); exit (1);} break;
		case 2: if (dim.nz+(index?amount:-amount)-2 <1) {printf ("Tried to procadj too much.\n"); exit (1);} break;		
	}

	if (amount==0) return;			//requested to not move so. um.. ok.

	nnx = dim.nx;
	nny = dim.ny;
	nnz = dim.nz;
	switch (dir)
	{
		case 0:	nnx+=index?amount:-amount; break;
		case 1: nny+=index?amount:-amount; break;
		case 2: nnz+=index?amount:-amount; break;
	}
	
	//Allocate and backup temporary arrays
	BackupArrays(dim.nx, dim.ny, dim.nz);

	if ((index!=0) == (amount > 0))	//expansion of current processor space.
	{
		//Reallocate arrays.
		arraysfree();
		arraysalloc (nnx, nny, nnz);
		
		//Now that we have the new blank arrays, restore data.
		int xoff=0,yoff=0,zoff=0;

		//note: ((index-1)&(-amount)) = -amount if index=0 (amount < 0) or 0 if index=1.
		switch (dir)
		{
			case 0: xoff = ((index-1)&(-amount)); break;
			case 1: yoff = ((index-1)&(-amount)); break;
			case 2: zoff = ((index-1)&(-amount)); break;
		}

		RestoreArraysE (nnx, nny, nnz, dim.nx, dim.ny, dim.nz, xoff, yoff, zoff);

		//Get data from neighbors.
		//transfer both expanded and one extra row of ghost cells.
		switch (dir)
		{
			case 0:
				arecvspace<double> (u, nnx,nny,nnz, index?dim.nx:1 ,1,1,  index?nnx:-amount+1, nny,nnz, mpi.Neighbors[0+index], 21);
				arecvspace<double> (v, nnx,nny,nnz, index?dim.nx:1 ,1,1,  index?nnx:-amount+1, nny,nnz, mpi.Neighbors[0+index], 21);
				arecvspace<double> (w, nnx,nny,nnz, index?dim.nx:1 ,1,1,  index?nnx:-amount+1, nny,nnz, mpi.Neighbors[0+index], 21);
				arecvspace<double> (p, nnx,nny,nnz, index?dim.nx:1 ,1,1,  index?nnx:-amount+1, nny,nnz, mpi.Neighbors[0+index], 21);
				arecvspace<double> (f, nnx,nny,nnz, index?dim.nx:1 ,1,1,  index?nnx:-amount+1, nny,nnz, mpi.Neighbors[0+index], 21);
				break;
			case 1:
				arecvspace<double> (u, nnx,nny,nnz, 1, index?dim.ny:1 ,1,  nnx,index?nny:-amount+1,nnz, mpi.Neighbors[2+index], 22);
				arecvspace<double> (v, nnx,nny,nnz, 1, index?dim.ny:1 ,1,  nnx,index?nny:-amount+1,nnz, mpi.Neighbors[2+index], 22);
				arecvspace<double> (w, nnx,nny,nnz, 1, index?dim.ny:1 ,1,  nnx,index?nny:-amount+1,nnz, mpi.Neighbors[2+index], 22);
				arecvspace<double> (p, nnx,nny,nnz, 1, index?dim.ny:1 ,1,  nnx,index?nny:-amount+1,nnz, mpi.Neighbors[2+index], 22);
				arecvspace<double> (f, nnx,nny,nnz, 1, index?dim.ny:1 ,1,  nnx,index?nny:-amount+1,nnz, mpi.Neighbors[2+index], 22);
				break;
			case 2:
				arecvspace<double> (u, nnx,nny,nnz, 1,1,index?dim.nz:1 ,  nnx,nny,index?nnz:-amount+1, mpi.Neighbors[4+index], 23);
				arecvspace<double> (v, nnx,nny,nnz, 1,1,index?dim.nz:1 ,  nnx,nny,index?nnz:-amount+1, mpi.Neighbors[4+index], 23);
				arecvspace<double> (w, nnx,nny,nnz, 1,1,index?dim.nz:1 ,  nnx,nny,index?nnz:-amount+1, mpi.Neighbors[4+index], 23);
				arecvspace<double> (p, nnx,nny,nnz, 1,1,index?dim.nz:1 ,  nnx,nny,index?nnz:-amount+1, mpi.Neighbors[4+index], 23);
				arecvspace<double> (f, nnx,nny,nnz, 1,1,index?dim.nz:1 ,  nnx,nny,index?nnz:-amount+1, mpi.Neighbors[4+index], 23);
				break;
		}
			
	}
	else							//shrink current processor space.
	{
		//Send data to neighbor first.
		switch (dir)
		{
			case 0:
				sendspace<double>(u, dim.nx,dim.ny,dim.nz, index?dim.nx+amount-1:2,1,1, index?dim.nx-1:amount+2,dim.ny, dim.nz, mpi.Neighbors[0+index], 21);  
				sendspace<double>(v, dim.nx,dim.ny,dim.nz, index?dim.nx+amount-1:2,1,1, index?dim.nx-1:amount+2,dim.ny, dim.nz, mpi.Neighbors[0+index], 21);  
				sendspace<double>(w, dim.nx,dim.ny,dim.nz, index?dim.nx+amount-1:2,1,1, index?dim.nx-1:amount+2,dim.ny, dim.nz, mpi.Neighbors[0+index], 21);  
				sendspace<double>(p, dim.nx,dim.ny,dim.nz, index?dim.nx+amount-1:2,1,1, index?dim.nx-1:amount+2,dim.ny, dim.nz, mpi.Neighbors[0+index], 21);  
				sendspace<double>(f, dim.nx,dim.ny,dim.nz, index?dim.nx+amount-1:2,1,1, index?dim.nx-1:amount+2,dim.ny, dim.nz, mpi.Neighbors[0+index], 21);  
				break;
			case 1:
				sendspace<double>(u, dim.nx,dim.ny,dim.nz, 1,index?dim.ny+amount-1:2,1, dim.nx,index?dim.ny-1:amount+2,dim.nz, mpi.Neighbors[2+index], 22);  
				sendspace<double>(v, dim.nx,dim.ny,dim.nz, 1,index?dim.ny+amount-1:2,1, dim.nx,index?dim.ny-1:amount+2,dim.nz, mpi.Neighbors[2+index], 22);  
				sendspace<double>(w, dim.nx,dim.ny,dim.nz, 1,index?dim.ny+amount-1:2,1, dim.nx,index?dim.ny-1:amount+2,dim.nz, mpi.Neighbors[2+index], 22);  
				sendspace<double>(p, dim.nx,dim.ny,dim.nz, 1,index?dim.ny+amount-1:2,1, dim.nx,index?dim.ny-1:amount+2,dim.nz, mpi.Neighbors[2+index], 22);  
				sendspace<double>(f, dim.nx,dim.ny,dim.nz, 1,index?dim.ny+amount-1:2,1, dim.nx,index?dim.ny-1:amount+2,dim.nz, mpi.Neighbors[2+index], 22);  
				break;
			case 2:
				sendspace<double>(u, dim.nx,dim.ny,dim.nz, 1,1,index?dim.nz+amount-1:2, dim.nx,dim.ny,index?dim.nz-1:amount+2, mpi.Neighbors[4+index], 23);  
				sendspace<double>(v, dim.nx,dim.ny,dim.nz, 1,1,index?dim.nz+amount-1:2, dim.nx,dim.ny,index?dim.nz-1:amount+2, mpi.Neighbors[4+index], 23);  
				sendspace<double>(w, dim.nx,dim.ny,dim.nz, 1,1,index?dim.nz+amount-1:2, dim.nx,dim.ny,index?dim.nz-1:amount+2, mpi.Neighbors[4+index], 23);  
				sendspace<double>(p, dim.nx,dim.ny,dim.nz, 1,1,index?dim.nz+amount-1:2, dim.nx,dim.ny,index?dim.nz-1:amount+2, mpi.Neighbors[4+index], 23);  
				sendspace<double>(f, dim.nx,dim.ny,dim.nz, 1,1,index?dim.nz+amount-1:2, dim.nx,dim.ny,index?dim.nz-1:amount+2, mpi.Neighbors[4+index], 23);  
				break;
		}

		//wait for sends to complete.
		sendwait();

		//Reallocate arrays (i.e. shrink)
		arraysfree();
		arraysalloc (nnx, nny, nnz);

		int xoff=0,yoff=0,zoff=0;
		switch (dir)
		{
			case 0: xoff=((index-1)&amount); break;
			case 1: yoff=((index-1)&amount); break;
			case 2: zoff=((index-1)&amount); break;
		}
		//restore data.
		RestoreArraysS(nnx, nny, nnz, dim.nx, dim.ny, dim.nz, xoff, yoff, zoff);
	}

	//Free backup arrays
	FreeArrays();

	//Update nx,ny,nz.
	dim.nx = nnx;
	dim.ny = nny;
	dim.nz = nnz;

	//update OProc
	if (index==0)	//OProc changes only if index==0
		mpi.OProc[dir] += amount;

	arecvspacewait();
	sendwait();

	meshset();
	aset();
//ben	limit();
	voferr();
	dt();
	bcf();
	setproperties();
	normals();
	setnf();
	bc();
}
//*****************************************************************************

void BackupArrays(int nx, int ny, int nz)
{
	//allocate memory and save contents of global arrays.

	tu = (double*)memalloc (nx, ny, nz, sizeof(double));
	memcpy (tu, u, nx*ny*nz*sizeof(double));
	tv = (double*)memalloc (nx, ny, nz, sizeof(double));
	memcpy (tv, v, nx*ny*nz*sizeof(double));
	tw = (double*)memalloc (nx, ny, nz, sizeof(double));
	memcpy (tw, w, nx*ny*nz*sizeof(double));
	tf = (double*)memalloc (nx, ny, nz, sizeof(double));
	memcpy (tf, f, nx*ny*nz*sizeof(double));
	tp = (double*)memalloc (nx, ny, nz, sizeof(double));
	memcpy (tp, p, nx*ny*nz*sizeof(double));
	
	tun = (double*)memalloc (nx, ny, nz, sizeof(double));
	memcpy (tun, un, nx*ny*nz*sizeof(double));
	tvn = (double*)memalloc (nx, ny, nz, sizeof(double));
	memcpy (tvn, vn, nx*ny*nz*sizeof(double));
	twn = (double*)memalloc (nx, ny, nz, sizeof(double));
	memcpy (twn, wn, nx*ny*nz*sizeof(double));
	tfn = (double*)memalloc (nx, ny, nz, sizeof(double));
	memcpy (tfn, fn, nx*ny*nz*sizeof(double));
	tpn = (double*)memalloc (nx, ny, nz, sizeof(double));
	memcpy (tpn, pn, nx*ny*nz*sizeof(double));

}
void FreeArrays()
{
	//Free backup arrays
	memfree (tu);
	memfree (tv);
	memfree (tw);
	memfree (tf);
	memfree (tp);

	memfree (tun);
	memfree (tvn);
	memfree (twn);
	memfree (tfn);
	memfree (tpn);
		   
}
void RestoreArraysE (int nnx, int nny, int nnz, int nx, int ny, int nz, int xo, int yo, int zo)
{
	//Restore array contents after expanding.
	for (int k=0;k<nz;k++)
	 for (int j=0;j<ny;j++)
	  for (int i=0;i<nx;i++) 
	  {
		const int ind1 = i+xo + (j+yo)*nnx + (k+zo)*nnx*nny;
		const int ind2 = i + (j)*nx + (k)*nx*ny;
		u[ind1] = tu[ind2];
		v[ind1] = tv[ind2];
		w[ind1] = tw[ind2];
		f[ind1] = tf[ind2];
		p[ind1] = tp[ind2];

		un[ind1] = tun[ind2];
		vn[ind1] = tvn[ind2];
		wn[ind1] = twn[ind2];
		fn[ind1] = tfn[ind2];
		pn[ind1] = tpn[ind2];

	  }

}
void RestoreArraysS (int nnx, int nny, int nnz, int nx, int ny, int nz, int xo, int yo, int zo)
{
	//Restore array contents after shrinking
	for (int k=0;k<nnz;k++)
	 for (int j=0;j<nny;j++)
	  for (int i=0;i<nnx;i++) 
	  {
		const int ind1 = i + (j)*nnx + (k)*nnx*nny;
		const int ind2 = i+xo + (j+yo)*nx + (k+zo)*nx*ny;
		u[ind1] = tu[ind2];
		v[ind1] = tv[ind2];
		w[ind1] = tw[ind2];
		f[ind1] = tf[ind2];
		p[ind1] = tp[ind2];

		un[ind1] = tun[ind2];
		vn[ind1] = tvn[ind2];
		wn[ind1] = twn[ind2];
		fn[ind1] = tfn[ind2];
		pn[ind1] = tpn[ind2];
	  }	
}
