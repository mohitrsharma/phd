#include "ripple.h"
#include "comm.h"
#include <string.h>
#include "testing.h"


/******************************************************************************


Subroutine VELGRAD is called by:	CONVECT

Subroutine VELGRAD calls:

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE
-Implement boundary conditions on the tilde veloc.	Ben			April 21 2005
 just like its done in bc() for ghost cells

*******************************************************************************/
void velgrad()
{
	double *rgux=temp[0], *rguy=temp[1], *rguz=temp[2];
	double *rgvx=temp[3], *rgvy=temp[4], *rgvz=temp[5];
	double *rgwx=temp[6], *rgwy=temp[7], *rgwz=temp[8];
	double *ufc =temp[9], *ufy=temp[10], *ufz=temp[11];
	double *vfx=temp[12], *vfc=temp[13], *vfz=temp[14];
	double *wfx=temp[15], *wfy=temp[16], *wfc=temp[17];
	double *util=temp[18],*vtil=temp[19],*wtil=temp[20];

	int i,j,k;
	double utilimjk;
	double utilipjk;
	double vtilijmk;
	double vtilijpk;
	double wtilijkm;
	double wtilijkp;

	//calculate rg__ from util,vtil,wtil.

	//apply boundary conditions on the tilde velocities...(tilde velocities not modified.)

	for(i = 0; i < imax; i++)
		for(j = 0; j < jmax; j++)
			for(k = 0; k < kmax; k++)
			{
				const int ip = (i==im1)? i: i+1;
				const int im = (i==0) ? i: i-1;
				const int jp = (j==jm1)? j: j+1;
				const int jm = (j==0)? j: j-1;
				const int kp = (k==km1)? k: k+1;
				const int km = (k==0)? k: k-1;
				const int ipjk = (i==im1)? IJK: IPJK;
				const int ijpk = (j==jm1)? IJK: IJPK;
				const int ijkp = (k==km1)? IJK: IJKP;
				const int imjk = (i==0)? IJK: IMJK;
				const int ijmk = (j==0)? IJK: IJMK;
				const int ijkm = (k==0)? IJK: IJKM;
/*
				if(i == 0)//left face
				{
					if(kl == 1)//symmetry bc
					{
						//normal stress should be non-zero
						utilimjk = -util[ipjk];
						utilipjk = util[ipjk];
					}
					else// if(kl == 2 || kl == 3 || kl == 4)//wall, inflow, no-gradient
					{
						//normal stress should be zero
						utilimjk = util[ipjk];
						utilipjk = util[ipjk];
					}
				}
				else if(i == im2)//right face
				{
					if(kr == 1)//symmetry bc
					{
						//normal stress should be non-zero
						utilimjk = util[imjk];
						utilipjk = -util[imjk];
					}
					else// if(kr == 2 || kr == 3 || kr == 4)//wall, inflow, no-gradient
					{
						//normal stress should be zero
						utilimjk = util[imjk];
						utilipjk = util[imjk];
					}
				}
				else if(j == 0)//back face
				{
					if(kb == 1)//symmetry bc
					{
						//normal stress should be non-zero
						vtilijmk = -vtil[ijpk];
						vtilijpk = vtil[ijpk];
					}
					else// if(kb == 2 // kb == 3 // kb == 4)//wall, inflow, no-gradient
					{
						//normal stress should be zero
						vtilijmk = vtil[ijpk];
						vtilijpk = vtil[ijpk];
					}
				}
				else if(j == jm2)//front face
				{
					if(kf == 1)//symmetry bc
					{
						//normal stress should be non-zero
						vtilijmk = vtil[ijmk];
						vtilijpk = -vtil[ijmk];
					}
					else// if(kf ==2 // kf == 3 // kf == 4)//wall, inflow, no-gradient
					{
						//normal stress should be zero
						vtilijmk = vtil[ijmk];
						vtilijpk = vtil[ijmk];
					}
				}
				else if(k == 0)//under face
				{
					if(ku == 1)//symmetry bc
					{
						//normal stress should be non-zero
						wtilijkm = -wtil[ijkp];
						wtilijkp = wtil[ijkp];
					}
					else// if(ku == 2 // ku == 3 // ku == 4)
					{
						//normal stress should be zero
						wtilijkm = wtil[ijkp];
						wtilijkp = wtil[ijkp];
					}
				}
				else if(k == km2)//over face
				{
					if(ko == 1)//symmetry bc
					{
						wtilijkm = wtil[ijkm];
						wtilijkp = -wtil[ijkm];
					}
					else// if(ko == 2 // ko == 3 // ko == 4)
					{
						wtilijkm = wtil[ijkm];
						wtilijkp = wtil[ijkm];
					}
				}
*/
				const double utilimjk = (i==0 && kl==1)? -util[ipjk]:util[imjk];
				const double utilipjk = (i==im1-1 && kr==1)? -util[imjk]:util[ipjk];
				const double vtilijmk = (j==0 && kb==1)? -vtil[ijpk]:vtil[ijmk];
				const double vtilijpk = (j==jm1-1 && kf==1)? -vtil[ijmk]:vtil[ijpk];
				const double wtilijkm = (k==0 && ku==1)? -wtil[ijkp]:wtil[ijkm];
				const double wtilijkp = (k==km1-1 && ko==1)? -wtil[ijkm]:wtil[ijkp];
//my way above should be the same as this commented block


				double rdeltx=1.0/(delx[i]+0.5*(delx[ip]+delx[im]));
				double rdelty=1.0/(dely[j]+0.5*(dely[jp]+dely[jm]));
				double rdeltz=1.0/(delz[k]+0.5*(delz[kp]+delz[km]));



				rgux[IJK]=(utilipjk-utilimjk)/(delx[i]+delx[ip]);
				double unmin=MIN(utilimjk,utilipjk);
				double unmax=MAX(utilimjk,utilipjk);
				const double ugl=util[IJK]-0.5*delx[i]*rgux[IJK];
				const double ugr=util[IJK]+0.5*delx[ip]*rgux[IJK];
				double ugmin=MIN(ugl,ugr);
				double ugmax=MAX(ugl,ugr);
				double denom1=MAX(tiny,ugmax-util[IJK]);
				double denom2=MAX(tiny,util[IJK]-ugmin);
				double alph1=(unmax-MIN(util[IJK],unmax))/denom1;
				double alph2=(MAX(util[IJK],unmin)-unmin)/denom2;
				double alphvl=MAX(0.0,MIN(alph1,MIN(alph2,1.0)));
				rgux[IJK]=alphvl*rgux[IJK];

				rguy[IJK]=(util[ijpk]-util[ijmk])*rdelty;
				unmin=MIN(util[ijmk],util[ijpk]);
				unmax=MAX(util[ijmk],util[ijpk]);
				const double ugb=util[IJK]-0.5*dely[j]*rguy[IJK];
				const double ugt=util[IJK]+0.5*dely[j]*rguy[IJK];
				ugmin=MIN(ugb,ugt);
				ugmax=MAX(ugb,ugt);
				denom1=MAX(tiny,ugmax-util[IJK]);
				denom2=MAX(tiny,util[IJK]-ugmin);
				alph1=(unmax-MIN(util[IJK],unmax))/denom1;
				alph2=(MAX(util[IJK],unmin)-unmin)/denom2;
				alphvl=MAX(0.0,MIN(alph1,MIN(alph2,1.0)));
				rguy[IJK]=alphvl*rguy[IJK];

				rguz[IJK]=(util[ijkp]-util[ijkm])*rdeltz;
				unmin=MIN(util[ijkm],util[ijkp]);
				unmax=MAX(util[ijkm],util[ijkp]);
				const double ugu=util[IJK]-0.5*delz[k]*rguz[IJK];
				const double ugo=util[IJK]+0.5*delz[k]*rguz[IJK];
				ugmin=MIN(ugu,ugo);
				ugmax=MAX(ugu,ugo);
				denom1=MAX(tiny,ugmax-util[IJK]);
				denom2=MAX(tiny,util[IJK]-ugmin);
				alph1=(unmax-MIN(util[IJK],unmax))/denom1;
				alph2=(MAX(util[IJK],unmin)-unmin)/denom2;
				alphvl=MAX(0.0,MIN(alph1,MIN(alph2,1.0)));
				rguz[IJK]=alphvl*rguz[IJK];

				rgvx[IJK]=(vtil[ipjk]-vtil[imjk])*rdeltx;
				double vnmin=MIN(vtil[imjk],vtil[ipjk]);
				double vnmax=MAX(vtil[imjk],vtil[ipjk]);
				const double vgl=vtil[IJK]-0.5*delx[i]*rgvx[IJK];
				const double vgr=vtil[IJK]+0.5*delx[i]*rgvx[IJK];
				double vgmin=MIN(vgl,vgr);
				double vgmax=MAX(vgl,vgr);
				denom1=MAX(tiny,vgmax-vtil[IJK]);
				denom2=MAX(tiny,vtil[IJK]-vgmin);
				alph1=(vnmax-MIN(vtil[IJK],vnmax))/denom1;
				alph2=(MAX(vtil[IJK],vnmin)-vnmin)/denom2;
				alphvl=MAX(0.0,MIN(alph1,MIN(alph2,1.0)));
				rgvx[IJK]=alphvl*rgvx[IJK];

				rgvy[IJK]=(vtilijpk-vtilijmk)/(dely[j]+dely[jp]);
				vnmin=MIN(vtilijmk,vtilijpk);
				vnmax=MAX(vtilijmk,vtilijpk);
				const double vgb=vtil[IJK]-0.5*dely[j]*rgvy[IJK];
				const double vgt=vtil[IJK]+0.5*dely[jp]*rgvy[IJK];
				vgmin=MIN(vgb,vgt);
				vgmax=MAX(vgb,vgt);
				denom1=MAX(tiny,vgmax-vtil[IJK]);
				denom2=MAX(tiny,vtil[IJK]-vgmin);
				alph1=(vnmax-MIN(vtil[IJK],vnmax))/denom1;
				alph2=(MAX(vtil[IJK],vnmin)-vnmin)/denom2;
				alphvl=MAX(0.0,MIN(alph1,MIN(alph2,1.0)));
				rgvy[IJK]=alphvl*rgvy[IJK];

				rgvz[IJK]=(vtil[ijkp]-vtil[ijkm])*rdeltz;
				vnmin=MIN(vtil[ijkm],vtil[ijkp]);
				vnmax=MAX(vtil[ijkm],vtil[ijkp]);
				const double vgu=vtil[IJK]-0.5*delz[k]*rgvz[IJK];
				const double vgo=vtil[IJK]+0.5*delz[k]*rgvz[IJK];
				vgmin=MIN(vgu,vgo);
				vgmax=MAX(vgu,vgo);
				denom1=MAX(tiny,vgmax-vtil[IJK]);
				denom2=MAX(tiny,vtil[IJK]-vgmin);
				alph1=(vnmax-MIN(vtil[IJK],vnmax))/denom1;
				alph2=(MAX(vtil[IJK],vnmin)-vnmin)/denom2;
				alphvl=MAX(0.0,MIN(alph1,MIN(alph2,1.0)));
				rgvz[IJK]=alphvl*rgvz[IJK];

				rgwx[IJK]=(wtil[ipjk]-wtil[imjk])*rdeltx;
				double wnmin=MIN(wtil[imjk],wtil[ipjk]);
				double wnmax=MAX(wtil[imjk],wtil[ipjk]);
				const double wgl=wtil[IJK]-0.5*delx[i]*rgwx[IJK];
				const double wgr=wtil[IJK]+0.5*delx[i]*rgwx[IJK];
				double wgmin=MIN(wgl,wgr);
				double wgmax=MAX(wgl,wgr);
				denom1=MAX(tiny,wgmax-wtil[IJK]);
				denom2=MAX(tiny,wtil[IJK]-wgmin);
				alph1=(wnmax-MIN(wtil[IJK],wnmax))/denom1;
				alph2=(MAX(wtil[IJK],wnmin)-wnmin)/denom2;
				alphvl=MAX(0.0,MIN(alph1,MIN(alph2,1.0)));
				rgwx[IJK]=alphvl*rgwx[IJK];

				rgwy[IJK]=(wtil[ijpk]-wtil[ijmk])*rdelty;
				wnmin=MIN(wtil[ijmk],wtil[ijpk]);
				wnmax=MAX(wtil[ijmk],wtil[ijpk]);
				const double wgb=wtil[IJK]-0.5*dely[j]*rgwy[IJK];
				const double wgt=wtil[IJK]+0.5*dely[j]*rgwy[IJK];
				wgmin=MIN(wgb,wgt);
				wgmax=MAX(wgb,wgt);
				denom1=MAX(tiny,wgmax-wtil[IJK]);
				denom2=MAX(tiny,wtil[IJK]-wgmin);
				alph1=(wnmax-MIN(wtil[IJK],wnmax))/denom1;
				alph2=(MAX(wtil[IJK],wnmin)-wnmin)/denom2;
				alphvl=MAX(0.0,MIN(alph1,MIN(alph2,1.0)));
				rgwy[IJK]=alphvl*rgwy[IJK];

				rgwz[IJK]=(wtilijkp-wtilijkm)/(delz[k]+delz[kp]);
				wnmin=MIN(wtilijkm,wtilijkp);
				wnmax=MAX(wtilijkm,wtilijkp);
				const double wgu=wtil[IJK]-0.5*delz[k]*rgwz[IJK];
				const double wgo=wtil[IJK]+0.5*delz[kp]*rgwz[IJK];
				wgmin=MIN(wgu,wgo);
				wgmax=MAX(wgu,wgo);
				denom1=MAX(tiny,wgmax-wtil[IJK]);
				denom2=MAX(tiny,wtil[IJK]-wgmin);
				alph1=(wnmax-MIN(wtil[IJK],wnmax))/denom1;
				alph2=(MAX(wtil[IJK],wnmin)-wnmin)/denom2;
				alphvl=MAX(0.0,MIN(alph1,MIN(alph2,1.0)));
				rgwz[IJK]=alphvl*rgwz[IJK];
			}

			//only if in current processors imax,jmax,kmax domain there are

			if (mpi.obst_flag)
				velgradobs(util,vtil,wtil);//applying obstacle BCs to the TILDE velocities

	//exchange rg__ with neigboring processors
	xchg<double> (rgux);
	xchg<double> (rguy);
	xchg<double> (rguz);

	xchg<double> (rgvx);
	xchg<double> (rgvy);
	xchg<double> (rgvz);

	xchg<double> (rgwx);
	xchg<double> (rgwy);
	xchg<double> (rgwz);
}

#ifdef rudman_fine
double vanLeer_grad(double u1, double u2, double u3, double deli) {
	double interp_val;
	interp_val=(u3-u1)/(2.e0*deli);
	
	double unmin=MIN(u1,u3);
	double unmax=MAX(u1,u3);
	
	const double ugl=u2-0.5*deli*interp_val;
	const double ugr=u2+0.5*deli*interp_val;
	double ugmin=MIN(ugl,ugr);
	double ugmax=MAX(ugl,ugr);
	
	double denom1=MAX(tiny,ugmax-u2);
	double denom2=MAX(tiny,u2-ugmin);
	double alph1=(unmax-MIN(u2,unmax))/denom1;
	double alph2=(MAX(u2,unmin)-unmin)/denom2;
	double alphvl=MAX(0.0,MIN(alph1,MIN(alph2,1.0)));
	interp_val=alphvl*interp_val;
	
	return interp_val;
}

void velgrad_new() {
      
	double *util=u;
	double *vtil=v;
	double *wtil=w;
	
	double *rgux=temp[0],  *rguy=temp[1], *rguz=temp[2];
	double *rgvx=temp[3], *rgvy=temp[4], *rgvz=temp[5];
	double *rgwx=temp[6], *rgwy=temp[7], *rgwz=temp[8];
	
	int i,j,k;
	double u1, u2, u3;
	
	//rgux
	for(k=1;k<km1;k++)
	   for(j=1;j<jm1;j++)
		  for(i=1;i<im1;i++) {
			u1=util[IJK-1]; u2=util[IJK]; 
			if(i==im2 && mpi.Neighbors[1]==-1) 
			      u3=2.e0*u2-u1; //change it for open boundary condition
			else 
			      u3=util[IJK+1];
			      
			rgux[IJK]=vanLeer_grad(u1,u2,u3,delx[1]);
		  }
        
	if(mpi.Neighbors[0]==-1) {
	      i=0;
	      for(k=1;k<km1;k++)
		   for(j=1;j<jm1;j++) {
			u2=util[IJK]; u3=util[IJK+1];
			u1=2.e0*u2-u3;
			
			rgux[IJK]=vanLeer_grad(u1,u2,u3,delx[1]);
		  }
	}
	
	//rguy
	for(k=1;k<km1;k++)
		for(j=1;j<jm1;j++) 
		  for(i=1;i<im1;i++){
			u1=util[IJK-imax]; u2=util[IJK]; u3=util[IJK+imax];
			rguy[IJK]=vanLeer_grad(u1,u2,u3,dely[1]);
		  }
		  
      if(mpi.Neighbors[2]==-1) {
	      j=0;
		  for(k=1;k<km1;k++) 
		   for(i=1;i<im1;i++) {
			u2=util[IJK]; u3=util[IJK+imax];
			u1=2.e0*u2-u3;
			rguy[IJK]=vanLeer_grad(u1,u2,u3,dely[1]);
		  }
	}
	
	if(mpi.Neighbors[3]==-1) {
	      j=jm1;
	      for(k=1;k<km1;k++)
		   for(i=1;i<im1;i++) {
			u1=util[IJK-imax]; u2=util[IJK];
			u3=2.e0*u2-u1;
			rguy[IJK]=vanLeer_grad(u1,u2,u3,dely[1]);
		  }
	}
	
	//rguz
	for(k=1;k<km1;k++)
	    for(j=1;j<jm1;j++)
		  for(i=1;i<im1;i++) {
			u1=util[IJK-ijmax]; u2=util[IJK]; u3=util[IJK+ijmax];
			rguz[IJK]=vanLeer_grad(u1,u2,u3,delz[1]);
		  }
	
	if(mpi.Neighbors[4]==-1) {
	      k=0;
		  for(j=1;j<jm1;j++) 
		   for(i=1;i<im1;i++) {
			u2=util[IJK]; u3=util[IJK+ijmax];
			u1=2.e0*u2-u3;
			rguz[IJK]=vanLeer_grad(u1,u2,u3,delz[1]);
		  }
	}
	
	if(mpi.Neighbors[5]==-1) {
	      k=km1;
		  for(j=1;j<jm1;j++) 
		   for(i=1;i<im1;i++) {
			u1=util[IJK-ijmax]; u2=util[IJK];
			u3=2.e0*u2-u1;
			rguz[IJK]=vanLeer_grad(u1,u2,u3,delz[1]);
		  }
	}
	
	//rgvx
	for(k=1;k<km1;k++)
		for(j=1;j<jm1;j++) 
		  for(i=1;i<im1;i++){
			u1=vtil[IJK-1]; u2=vtil[IJK]; u3=vtil[IJK+1];
			rgvx[IJK]=vanLeer_grad(u1,u2,u3,delx[1]);
		  }
		  
        if(mpi.Neighbors[0]==-1) {
	      i=0;
	      for(k=1;k<km1;k++) 
		   for(j=1;j<jm1;j++){
			u2=vtil[IJK]; u3=vtil[IJK+1];
			u1=2.e0*u2-u3;
			rgvx[IJK]=vanLeer_grad(u1,u2,u3,delx[1]);
		  }
	}
	
	if(mpi.Neighbors[1]==-1) {
	      i=im1;	      
		  for(k=1;k<km1;k++) 
		   for(j=1;j<jm1;j++){
			u1=vtil[IJK-1]; u2=vtil[IJK];
			u3=2.e0*u2-u1;
			rgvx[IJK]=vanLeer_grad(u1,u2,u3,delx[1]);
		  }
	}
	
	//rgvy
	for(k=1;k<km1;k++)
	    for(j=1;j<jm1;j++) 
		  for(i=1;i<im1;i++) {
			u1=vtil[IJK-imax]; u2=vtil[IJK];
			if(j==jm2 && mpi.Neighbors[3]==-1)
			      u3=2.e0*u2-u1;
			else
			      u3=vtil[IJK+imax];
			rgvy[IJK]=vanLeer_grad(u1,u2,u3,dely[1]);
		  }
         
	 if(mpi.Neighbors[2]==-1) {
	       j=0; 
		  for(k=1;k<km1;k++) 
		   for(i=1;i<im1;i++){
			u2=vtil[IJK]; u3=vtil[IJK+imax];
			u1=2.e0*u2-u3;
			rgvy[IJK]=vanLeer_grad(u1,u2,u3,dely[1]);
		  }
	 }
	 
	 //rgvz
	 for(k=1;k<km1;k++)  
	    for(j=1;j<jm1;j++)		  
		  for(i=1;i<im1;i++) {
			u1=vtil[IJK-ijmax]; u2=vtil[IJK]; u3=vtil[IJK+ijmax];
			rgvz[IJK]=vanLeer_grad(u1,u2,u3,delz[1]);
		  }
        
	 if(mpi.Neighbors[4]==-1) {
	       k=0; 
		 for(j=1;j<jm1;j++) 
		  for(i=1;i<im1;i++) {
			u2=vtil[IJK]; u3=vtil[IJK+ijmax];
			u1=2.e0*u2-u3;
			rgvz[IJK]=vanLeer_grad(u1,u2,u3,delz[1]);
		  }
	 }
	 
	 if(mpi.Neighbors[5]==-1) {
	       k=km1;
		  for(j=1;j<jm1;j++) 
		   for(i=1;i<im1;i++)  {
			u1=vtil[IJK-ijmax]; u2=vtil[IJK];
			u3=2.e0*u2-u1;
			rgvz[IJK]=vanLeer_grad(u1,u2,u3,delz[1]);
		  }
	 }
	 
	 //rgwx
	 for(k=1;k<km1;k++) 
	    for(j=1;j<jm1;j++)  
		  for(i=1;i<im1;i++) {
			u1=wtil[IJK-1]; u2=wtil[IJK]; u3=wtil[IJK+1];
			rgwx[IJK]=vanLeer_grad(u1,u2,u3,delx[1]);
		  }
      
      if(mpi.Neighbors[0]==-1) {
	       i=0;	        
		  for(k=1;k<km1;k++) 
		   for(j=1;j<jm1;j++){
			u2=wtil[IJK]; u3=wtil[IJK+1];
			u1=2.e0*u2-u3;
			rgwx[IJK]=vanLeer_grad(u1,u2,u3,delx[1]);
		  }
	 }
	 
	 if(mpi.Neighbors[1]==-1) {
	       i=im1;	        
		  for(k=1;k<km1;k++) 
		   for(j=1;j<jm1;j++) {
			u1=wtil[IJK-1]; u2=wtil[IJK];
			u3=2.e0*u2-u1;
			rgwx[IJK]=vanLeer_grad(u1,u2,u3,delx[1]);
		  }
	 }
	 
	 //rgwy
	 for(k=1;k<km1;k++) 
	    for(j=1;j<jm1;j++)		  
		  for(i=1;i<im1;i++){
			u1=wtil[IJK-imax]; u2=wtil[IJK]; u3=wtil[IJK+imax];
			rgwy[IJK]=vanLeer_grad(u1,u2,u3,dely[1]);
		  }
		  
     if(mpi.Neighbors[2]==-1) {
		j=0;
		for(k=1;k<km1;k++) 
		  for(i=1;i<im1;i++) {
			u2=wtil[IJK]; u3=wtil[IJK+imax];
			u1=2.e0*u2-u3;
			rgwy[IJK]=vanLeer_grad(u1,u2,u3,dely[1]);
		  }
	  }
	  
	  if(mpi.Neighbors[3]==-1) {
		j=jm1;
		for(k=1;k<km1;k++) 
		  for(i=1;i<im1;i++) {
			u1=wtil[IJK-imax]; u2=wtil[IJK];
			u3=2.e0*u2-u1;
			rgwy[IJK]=vanLeer_grad(u1,u2,u3,dely[1]);
		  }
	  }
	  
	  //rgwz
	  for(k=1;k<km1;k++) 
	    for(j=1;j<jm1;j++)		  
		  for(i=1;i<im1;i++){
			u1=wtil[IJK-ijmax]; u2=wtil[IJK];
			if(k==km2 && mpi.Neighbors[5]==-1)
			      u3=2.e0*u2-u1;
			else
			      u3=wtil[IJK+ijmax];
			      
			rgwz[IJK]=vanLeer_grad(u1,u2,u3,delz[1]);
		  }
           
	   if(mpi.Neighbors[4]==-1) {
		 k=0;
		 for(j=1;j<jm1;j++) 
		  for(i=1;i<im1;i++) {
			u2=wtil[IJK]; u3=wtil[IJK+ijmax];
			u1=2.e0*u2-u3;
			rgwz[IJK]=vanLeer_grad(u1,u2,u3,delz[1]);
		  }
	   }
	
//obstacle implementation
#ifndef no_obs
	for(k = 1; k < km1; k++)
		for(j = 1; j < jm1; j++)
			for(i = 1; i < im1; i++)
			{
                		if (isobstsfc(IJK))             /*if current cell is the obstacle interface cell*/
				{

                    			if (obst[IJK].flag_r)      /*if obstacle cell is to the RIGHT of fluid cell*/
					{
						u1=util[IJK-2]; u2=util[IJK-1]; 
						u3=2*u2-u1;
						rgux[IMJK]=vanLeer_grad(u1,u2,u3,delx[1]);
					}

                    			if (obst[IJK].flag_l)      /*if obstacle cell is to the LEFT of fluid cell*/
					{
						u2=util[IJK]; u3=util[IJK+1];
						u1=2*u2-u3;
						rgux[IJK]=vanLeer_grad(u1,u2,u3,delx[1]);
					}

                    			if (obst[IJK].flag_f)      /*if obst. is in of the FRONT of fluid cell*/
					{
						u1=vtil[IJK-2*imax]; u2=vtil[IJK-imax]; 
						u3=2*u2-u1;
						rgvy[IJMK]=vanLeer_grad(u1,u2,u3,dely[1]);
					}

                    			if (obst[IJK].flag_b)      /*if obstacle cell is to the BACK of fluid cell*/
					{
						u2=vtil[IJK]; u3=vtil[IJK+imax];
						u1=2*u2-u3;
						rgvy[IJK]=vanLeer_grad(u1,u2,u3,dely[1]);
					}

                    			if (obst[IJK].flag_o)      /*if obstacle cell is OVER the fluid cell*/
					{
						u1=wtil[IJK-2*ijmax]; u2=wtil[IJK-ijmax]; 
						u3=2*u2-u1;
						rgwz[IJKM]=vanLeer_grad(u1,u2,u3,delz[1]);
					}

                    			if (obst[IJK].flag_u)      /*if obstacle cell is UNDER the fluid cell*/
					{
						u2=wtil[IJK]; u3=wtil[IJK+ijmax];
						u1=2*u2-u3;
						rgwz[IJK]=vanLeer_grad(u1,u2,u3,delz[1]);
					}
				}
			}
	
	//Right side
	for (k=1;k<km1;k++)
		for (j=1;j<jm1;j++)
		{
                	const int ijkr = IND(im1, j, k);
			if (ac[ijkr] == 0 && ac[ijkr - 1] == 1) //if (obst[ijkr].flag_r)
            	{     				
                  	u1=util[ijkr-2]; u2=util[ijkr-1]; 
				u3=2*u2-u1;
				rgux[ijkr-1]=vanLeer_grad(u1,u2,u3,delx[1]);
            	}
		}
	//Front Side
    for (k=1;k<km1;k++)
		for (i=1;i<im1;i++)
		{
                	const int ijkf = IND(i, jm1, k);
			if (ac[ijkf] == 0 && ac[ijkf - imax] == 1) //if (obst[ijkf].flag_f)
            	{
				u1=vtil[ijkf-2*imax]; u2=vtil[ijkf-imax]; 
				u3=2*u2-u1;
				rgvy[ijkf-imax]=vanLeer_grad(u1,u2,u3,dely[1]);
			}
		}	
	//Over Side
	for (j=1;j<jm1;j++)
		for (i=1;i<im1;i++)
		{		
			const int ijko = IND(i, j, km1);
			if (ac[ijko] == 0 && ac[ijko - ijmax] == 1) //if (obst[ijko].flag_o)			
			{
				u1=wtil[ijko-2*ijmax]; u2=wtil[ijko-ijmax]; 
				u3=2*u2-u1;
				rgwz[ijko-ijmax]=vanLeer_grad(u1,u2,u3,delz[1]);
			}
		}
#endif

	//exchange rg__ with neigboring processors
	xchg<double> (rgux);
	xchg<double> (rguy);
	xchg<double> (rguz);

	xchg<double> (rgvx);
	xchg<double> (rgvy);
	xchg<double> (rgvz);

	xchg<double> (rgwx);
	xchg<double> (rgwy);
	xchg<double> (rgwz);
}
#endif

