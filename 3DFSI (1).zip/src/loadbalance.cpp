#include "ripple.h"
#include "comm.h"			 
#define LBTHRESHOLD 25

/******************************************************************************


Subroutine LOADBALANCE is called by:	

Subroutine LOADBALANCE calls:			

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/
ltime_t LTime;		//Local time for one iteration.
void LoadBalance()
{
	/*
	Diffusive load balancing.
	Assumptions: LTime reflects the load on the processor. 
	Increasing nx,ny,nz of the processor should increase LTime. 
	LoadBalance attempts to lower maximum LTime by giving processors with 
	low LTime more work, and giving processors with high LTime less work.

	Processor boundaries are moved such that neighbors never change.
	(i.e. the same boundary on all processors on the boundary are
	moved simultaneously.)	 Uses procadj to move boundary.

	Local processing time is sent to a processor in the same plane as the 
	current	processor, for each direction.  That processor sums the running
	times for its plane, takes the difference with neighboring planes,
	then sends messages back notifying other processors in the same plane
	whether it needs to adjust its boundaries (via procadj).

	To avoid errors, when sending summed times to neighbors, a 
	'shrinkable' flag is sent. If 0, then no attempts are made
	to shrink that cell. A plane is shrinkable if after shrinking
	(by 1 cell), there is still at least 1 internal cell (or 3 including
	ghost cells).
	*/

	//Send local time off to three processors.
	int xm, ym, zm;		//ranks of nodes for x,y, and z planes.
	int lx,ly,lz;		//coordinates of this processor in processor array.
	
	//Get MY coordinates;
	coordat (mpi.MyRank, &lx, &ly, &lz);

	//Get ranks of x,y,z-plane nodes.
	xm = rankat (lx, 0, 0);
	ym = rankat (0, ly, 0);
	zm = rankat (0, 0, lz);

	//Assume LTime contains the correct run-time for an iteration.
	//(or some other standard unit of measurement, where large LTime
	//means high load, small LTime means low load, LTime >=0)

	//Send off LTime
	senddata(&LTime, sizeof(LTime), xm, 51);
	senddata(&LTime, sizeof(LTime), ym, 52);
	senddata(&LTime, sizeof(LTime), zm, 53);

	//Get Communicator size: used if MyRank == xm, ym, or zm
	int psx,psy,psz;	//processor-array size
	cartsize(&psx, &psy, &psz);

	if (mpi.MyRank==xm)
	{
		int rankp,rankm;		//ranks for neighboring xm's
		ltime_t temp;
		ltime_t sum[2]={0};		//the second element is a "shrinkable" flag. 1 means nx/ny/nz > 3
		ltime_t sump[2], summ[2];	//sums and shrinkable flag for neighbor planes.
		int replycmd[2]={0,0};		//instructions to move planes to be returned to processors on same plane..

		if (dim.nx > 3) sum[1]=1; else sum[1]=0;		//Set whether current plane is 'shrinkable'

		for (int c=0;c<psy*psz;c++)
		{
			recvdata (&temp, sizeof(LTime), ANY_SOURCE, 51);
			sum[0] += temp;
		}
		rankp = rankat (lx+1,0,0);
		rankm = rankat (lx-1,0,0);
		//exchange data with neighboring xm/ym/zm.
		senddata (&sum, 2*sizeof(sum[0]), rankp,54);
		senddata (&sum, 2*sizeof(sum[0]), rankm,54);
		recvdata (&sump, 2*sizeof(sump[0]), rankp,54);
		recvdata (&summ, 2*sizeof(summ[0]), rankm,54);
		if (rankm >= 0)
		{
			if (sum[0] + LBTHRESHOLD < summ[0] && summ[1])	//want to shrink and shrinkable.
				replycmd[0] = -1;
			if (sum[0] - LBTHRESHOLD > summ[0] && sum[1])		//want to shrink this plane and shrinkable.
				replycmd[0] = 1;
		}
		if (rankp >= 0)
		{
			if (sum[0] + LBTHRESHOLD < sump[0] && sump[1])
				replycmd[1] = 1;				//shrink the other processor.
			if (sum[0] - LBTHRESHOLD > sump[0] && sum[1])
				replycmd[1] = -1;
		}
		//Reply to processors in plane
		for (int j=0;j<psy;j++)
		for (int k=0;k<psz;k++)
			senddata (replycmd, sizeof(replycmd[0])*2, rankat (lx, j,k), 61);
	}
	if (mpi.MyRank==ym)
	{
		int rankp,rankm;		//ranks for neighboring xm's
		ltime_t temp;
		ltime_t sum[2]={0};		//the second element is a "shrinkable" flag. 1 means nx/ny/nz > 3
		ltime_t sump[2], summ[2];	//sums and shrinkable flag for neighbor planes.
		int replycmd[2]={0,0};		//instructions to move planes to be returned to processors on same plane..

		if (dim.ny > 3) sum[1]=1; else sum[1]=0;		//Set whether current plane is 'shrinkable'

		for (int c=0;c<psx*psz;c++)
		{
			recvdata (&temp, sizeof(temp), ANY_SOURCE, 52);
			sum[0] += temp;
		}
		rankp = rankat (0, ly+1,0);
		rankm = rankat (0, ly-1,0);
		//exchange data with neighboring xm/ym/zm.
		senddata (&sum, 2*sizeof(sum[0]), rankp,55);
		senddata (&sum, 2*sizeof(sum[0]), rankm,55);
		recvdata (&sump, 2*sizeof(sump[0]), rankp,55);
		recvdata (&summ, 2*sizeof(summ[0]), rankm,55);
		if (rankm >= 0)
		{
			if (sum[0] + LBTHRESHOLD < summ[0] && summ[1])	//want to shrink and shrinkable.
				replycmd[0] = -1;
			if (sum[0] - LBTHRESHOLD > summ[0] && sum[1])		//want to shrink this plane and shrinkable.
				replycmd[0] = 1;
		}
		if (rankp >= 0)
		{
			if (sum[0] + LBTHRESHOLD < sump[0] && sump[1])
				replycmd[1] = 1;				//shrink the other processor.
			if (sum[0] - LBTHRESHOLD > sump[0] && sum[1])
				replycmd[1] = -1;
		}
		//Reply to processors in plane
		for (int i=0;i<psx;i++)
		for (int k=0;k<psz;k++)
			senddata (replycmd, sizeof(replycmd[0])*2, rankat (i,ly,k), 62);
	}
	if (mpi.MyRank==zm)
	{
		int rankp,rankm;		//ranks for neighboring xm's
		ltime_t temp;
		ltime_t sum[2]={0};		//the second element is a "shrinkable" flag. 1 means nx/ny/nz > 3
		ltime_t sump[2], summ[2];	//sums and shrinkable flag for neighbor planes.
		int replycmd[2]={0,0};		//instructions to move planes to be returned to processors on same plane..

		if (dim.nz > 3) sum[1]=1; else sum[1]=0;		//Set whether current plane is 'shrinkable'

		for (int c=0;c<psx*psy;c++)
		{
			recvdata (&temp, sizeof(temp), ANY_SOURCE, 53);
			sum[0] += temp;
		}
		rankp = rankat (0,0,lz+1);
		rankm = rankat (0,0,lz-1);
		//exchange data with neighboring xm/ym/zm.
		senddata (&sum, 2*sizeof(sum[0]), rankp,56);
		senddata (&sum, 2*sizeof(sum[0]), rankm,56);
		recvdata (&sump, 2*sizeof(sump[0]), rankp,56);
		recvdata (&summ, 2*sizeof(summ[0]), rankm,56);
		if (rankm >= 0)
		{
			if (sum[0] + LBTHRESHOLD < summ[0] && summ[1])	//want to shrink and shrinkable.
				replycmd[0] = -1;
			if (sum[0] - LBTHRESHOLD > summ[0] && sum[1])		//want to shrink this plane and shrinkable.
				replycmd[0] = 1;
		}
		if (rankp >= 0)
		{
			if (sum[0] + LBTHRESHOLD < sump[0] && sump[1])
				replycmd[1] = 1;				//shrink the other processor.
			if (sum[0] - LBTHRESHOLD > sump[0] && sum[1])
				replycmd[1] = -1;
		}
		//Reply to processors in plane
		for (int i=0;i<psx;i++)
		for (int j=0;j<psy;j++)
			senddata (replycmd, sizeof(replycmd[0])*2, rankat (i,j,lz), 63);
	}

	//Get replies from xm/ym/zm and do procadj if appropriate
	int reply[2];		//reply from xm,ym,zm. Reply contains the amount to shift the processor plane by.
	recvdata (reply, 2*sizeof(reply[0]), xm, 61);
	if (reply[0]) procadj (0, 0, reply[0]);
	if (reply[1]) procadj (0, 1, reply[1]);
	recvdata (reply, 2*sizeof(reply[0]), ym, 62);
	if (reply[0]) procadj (1, 0, reply[0]);
	if (reply[1]) procadj (1, 1, reply[1]);
	recvdata (reply, 2*sizeof(reply[0]), zm, 63);
	if (reply[0]) procadj (2, 0, reply[0]);
	if (reply[1]) procadj (2, 1, reply[1]);
}
