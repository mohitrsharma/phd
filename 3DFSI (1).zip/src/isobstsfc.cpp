#include <stdio.h>
#include "ripple.h"
#include "testing.h"

/******************************************************************************
This subroutine ISOBSTSFC determines if a given cell is an obstacle interface
cell.  It returns true for obstacle interface cell and false for all other cells

Subroutine ISOBSTSFC is called by:	BCOBS, BCFOBS,

Subroutine ISOBSTSFC calls:	****

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

bool isobstsfc(int index)
{
	const int ijkl = index - 1;
	const int ijkr = index + 1;
	const int ijkb = index - imax;
	const int ijkf = index + imax;
	const int ijku = index - ijmax;
	const int ijko = index + ijmax;

	if (ac[index] == 0 &&
		 ( 	ac[ijkl] == 1 ||
		 	ac[ijkr] == 1 ||
			ac[ijkb] == 1 ||
			ac[ijkf] == 1 ||
			ac[ijku] == 1 ||
		 	ac[ijko] == 1 	)	)
		return true;
	else
		return false;
}
