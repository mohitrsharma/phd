#include "ripple.h"
#include <math.h>
#include <string.h>
#include <stdlib.h> //exit
#include "testing.h"

double distance_line_to_point(st_point *vec_c, st_point *vec_a, st_point *vec_b);
void gfine2stnd(double *S, double *s);

void ytube_under_bc()
{	
	// Set a band of cells at the under face to the original volume fractions.
	// ALso set the curvature of the cell equal to (kappa = 1/r)
	// Normals should be coppied from 2 to 1. 
	
	int i,j,k;
	
	if (mpi.Neighbors[4] == -1)
	{
		for (k=20; k>1; --k)
			for (j=1; j<jm1_f; ++j)
				for (i=1; i<im1_f; ++i)
				{
					f_f[IJK_f] = ytubef_field[IJK_f]; // reseting f to original initialized value at the under face.
					scal[IJK_f] = 0.0;
				}
	}
	gfine2stnd(crse_scal,scal);
}

void ytube_exact_curvature(double *kap_x, double *kap_y, double *kap_z)
{
	int i,j,k;
	int indx = 1;
	double rad3_o, rad3_i, rad2_o, rad2_i, rad1_o, rad1_i;
	double height3, height2, height1;
	st_point theta1, theta2, theta3;
	
	st_point dimen1, dimen2, dimen3;
	dimen3.x=xe/2, dimen3.y=ye/2, dimen3.z=  15.3e-3;
	rad3_o=2.0e-3, rad3_i=2.0e-3;
	height3= (15.0e-3);
	
	theta1.x=60*pi/180, theta1.y=90*pi/180, theta1.z=30*pi/180;
	rad1_o=1.9e-3, rad1_i=1.6e-3;
	height1= 15.6e-3; //(rad1_i * 3 * 2); Same length as the plug
	dimen1.x=dimen3.x - (height1*cos(theta1.x)) - (rad1_i*cos(theta1.z)), dimen1.y=ye/2, dimen1.z=0.0e-3;
	
	dimen2.x=dimen1.x + 2*((height1*cos(theta1.x)) + (rad1_i*cos(theta1.z))), dimen2.y=ye/2, dimen2.z=dimen1.z;
	theta2.x=120*pi/180, theta2.y=90*pi/180, theta2.z=30*pi/180;   
	rad2_o=1.9e-3, rad2_i=1.6e-3;
	height2= 15.6e-3; //(rad2_i * 3 * 2); Same length as the plug

	st_point point_B, point_C;
	
	point_B.x = dimen1.x + ((height1)*cos(theta1.x));
	point_B.y = dimen1.y + ((height1)*cos(theta1.y));
	point_B.z = dimen1.z + ((height1)*cos(theta1.z));
	
	point_C.x = dimen2.x + ((height2)*cos(theta2.x));
	point_C.y = dimen2.y + ((height2)*cos(theta2.y));
	point_C.z = dimen2.z + ((height2)*cos(theta2.z));
	
	if (mpi.MyRank < 14 && mpi.Neighbors[4] == -1)
	{
		for (k=1; k<5; k++)
			for (i=1; i<im1; i++)
				for (j=1; j<jm1; j++)
				{
					st_point vector_x, vector_y, vector_z;
					
					vector_x.x = (i+mpi.OProc[0])*delx[1]; //global coordinates in coarse-grid
					vector_x.y = (j+mpi.OProc[1])*dely[1] - 0.5*dely[1];
					vector_x.z = (k+mpi.OProc[2])*delz[1] - 0.5*delz[1];
					
					vector_y.x = (i+mpi.OProc[0])*delx[1] - 0.5*delx[1]; //global coordinates in coarse-grid
					vector_y.y = (j+mpi.OProc[1])*dely[1];
					vector_y.z = (k+mpi.OProc[2])*delz[1] - 0.5*delz[1];
										
					vector_z.x = (i+mpi.OProc[0])*delx[1] - 0.5*delx[1]; //global coordinates in coarse-grid
					vector_z.y = (j+mpi.OProc[1])*dely[1] - 0.5*dely[1];
					vector_z.z = (k+mpi.OProc[2])*delz[1];
					
					double result_x, result_y, result_z;
					
					result_x = distance_line_to_point(&vector_x, &dimen1, &point_B);
					result_y = distance_line_to_point(&vector_y, &dimen1, &point_B);
					result_z = distance_line_to_point(&vector_z, &dimen1, &point_B);
					
					kap_x[IJK] = -1.0/result_x;
					kap_y[IJK] = -1.0/result_y;
					kap_z[IJK] = -1.0/result_z;
					
				}
	}
	
	if (mpi.MyRank > 14 && mpi.Neighbors[4] == -1)
	{
		for (k=1; k<5; k++)
			for (i=1; i<im1; i++)
				for (j=1; j<jm1; j++)
				{
					st_point vector_x, vector_y, vector_z;
					
					vector_z.x = (i+mpi.OProc[0])*delx[1]; //global coordinates in coarse-grid
					vector_z.y = (j+mpi.OProc[1])*dely[1];
					vector_z.z = (k+mpi.OProc[2])*delz[1] + 0.5*delz[1];
					
					vector_x.x = (i+mpi.OProc[0])*delx[1] + 0.5*delx[1]; //global coordinates in coarse-grid
					vector_x.y = (j+mpi.OProc[1])*dely[1];
					vector_x.z = (k+mpi.OProc[2])*delz[1];
					
					vector_y.x = (i+mpi.OProc[0])*delx[1]; //global coordinates in coarse-grid
					vector_y.y = (j+mpi.OProc[1])*dely[1] + 0.5*dely[1];
					vector_y.z = (k+mpi.OProc[2])*delz[1];
					
					double result_x, result_y, result_z;
					
					result_x = distance_line_to_point(&vector_x, &dimen2, &point_C);
					result_y = distance_line_to_point(&vector_y, &dimen2, &point_C);
					result_z = distance_line_to_point(&vector_z, &dimen2, &point_C);
					
					kap_x[IJK] = -1.0/result_x;
					kap_y[IJK] = -1.0/result_y;
					kap_z[IJK] = -1.0/result_z;
				}
	}
}
