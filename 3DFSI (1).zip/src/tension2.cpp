#include "ripple.h"
#include <string.h> //memset
#include <math.h>//fabs for testing
#include "testing.h"
#include <stdio.h>//printf for debugging
#include <stdlib.h>//exit

#ifdef balanced_force
void bc_tens();
#endif
#define CSF 0

void normals_fvirt_curvature(double *fvirt);
void ytube_exact_curvature(double *kap_x, double *kap_y, double *kap_z);

void tension2( double *fvirt )
{
#ifndef balanced_force
	double kappa;
	double *tensx=temp[0], *tensy=temp[1], *tensz=temp[2];
	double *txtilde=temp[3], *tytilde=temp[4], *tztilde=temp[5];
	int i,j,k;

	double totarea = 0.0;
					  
	memset (tensx, 0, NX*NY*NZ*sizeof(double));
	memset (tensy, 0, NX*NY*NZ*sizeof(double));
	memset (tensz, 0, NX*NY*NZ*sizeof(double));
	
	double max_face=0.e0; double min_face=100.e0*delx[1]*dely[1];
	
	for (i=1;i<im1;i++)
		for (j=1;j<jm1;j++)
			for (k=1;k<km1;k++)
			{
				double face, xd, yd, zd;
				if (f[IJK]>em61) continue;/*skip if full*/
        		if (f[IJK]<em6) continue;/*skip if empty*/
        		if (ac[IJK]<em6) continue;/*skip if obstacle*/
				{
					/*calculate interfacial area and midpoint, evaluate kappa.*/
					area (IJK, &face, &xd, &yd, &zd);
					totarea += face;
					if(face>max_face) max_face=face;
					if(face<min_face) min_face=face;
					/*curvature via normalized grad at cell centre*/
 					kappa=-(gradrox[IPJPKP]-gradrox[IJPKP]
						+gradrox[IPJPK]-gradrox[IJPK]
						+gradrox[IPJKP]-gradrox[IJKP]
						+gradrox[IPJK]-gradrox[IJK])/delx[i]/4.0
						-(gradroy[IPJPKP]-gradroy[IPJKP]
						+gradroy[IJPKP]-gradroy[IJKP]
						+gradroy[IPJPK]-gradroy[IPJK]
						+gradroy[IJPK]-gradroy[IJK])/dely[j]/4.0
						-(gradroz[IPJPKP]-gradroz[IPJPK]
						+gradroz[IPJKP]-gradroz[IPJK]
						+gradroz[IJPKP]-gradroz[IJPK]
						+gradroz[IJKP]-gradroz[IJK])/delz[k]/4.0;
//                     kappa= 2.0 / radius;
					/*evaluate tension forces*/
					double ralph=sqrt(avnx[IJK]*avnx[IJK] + avny[IJK]*avny[IJK] + avnz[IJK]*avnz[IJK]) + tiny;
					double tensin=sigma[IJK]*kappa*face/vol[IJK]/ralph;
					
				tensx[IJK]=(tensin)*avnx[IJK];
    				tensy[IJK]=(tensin)*avny[IJK];
    				tensz[IJK]=(tensin)*avnz[IJK];
    				//if(mpi.MyRank==0 && IJK==IND(37,1,1)) printf("in tension bot: tensin = %.9e avnx=%.9e\n",tensin,avnx[IJK]);
				//if(mpi.MyRank==0 && IJK==IND(37,64,1)) printf("in tension top: tensin = %.9e avnx=%.9e\n",tensin,avnx[IJK]);
				//if(mpi.MyRank==0 && IJK==IND(37,1,1)) printf("in tension bot: %.9e %.9e %.9e %.9e %.9e %.9e %.9e %.9e\n",gradrox[IPJK],gradrox[IPJPK],gradrox[IJPK],gradrox[IJK],gradrox[IPJKP],gradrox[IPJPKP],gradrox[IJPKP],gradrox[IJKP]);
    				//if(mpi.MyRank==0 && IJK==IND(37,64,1)) printf("in tension top: %.9e %.9e %.9e %.9e %.9e %.9e %.9e %.9e\n",gradrox[IPJPK],gradrox[IPJK],gradrox[IJK],gradrox[IJPK],gradrox[IPJPKP],gradrox[IPJKP],gradrox[IJKP],gradrox[IJPKP]);
                }
			}
			
	//printf("proc %d: max_face=%e min_face=%e\n",mpi.MyRank,max_face,min_face);
	/*smooth the force*/
	/*writes to txtilde, tytilde, tztilde*/
	mollifyt();	
	int umax_ijk, umin_ijk;	
	double u_max=0.e0; double u_min=1000.e0; 
	double v_max=0.e0; double v_min=1000.e0;
	double w_max=0.e0; double w_min=1000.e0;
	for(i=1;i<im1;i++)
		for(j=1;j<jm1;j++)
			for(k=1;k<km1;k++)
			{
				/*skip near open boundaries*/
				if (kl==4 && i==1) 	 continue;
				if (kr==4 && i==im2) continue;
				if (kb==4 && j==1)   continue;
				if (kf==4 && j==jm2) continue;
				if (ku==4 && k==1)   continue;										
				if (mpi.Neighbors[5] == -1 && ko==4 && k==km2) continue;
				
				double fxrc = (delx[i]*txtilde[IPJK] + delx[i+1]*txtilde[IJK])/(delx[i]+delx[i+1]);
				fxrc = 2.0*rhorc[IJK] * fxrc/ rhof1;
				
				double fyfc = (dely[j]*tytilde[IJPK] + dely[j+1]*tytilde[IJK])/(dely[j]+dely[j+1]);
				fyfc = 2.0*rhofc[IJK] * fyfc/ rhof1;

				double fzoc = (delz[k]*tztilde[IJKP] + delz[k+1]*tztilde[IJK])/(delz[k]+delz[k+1]);
				fzoc = 2.0*rhooc[IJK] * fzoc/ rhof1;

				/*apply surface tension force*/
				if (ar[IJK] >= em6)
					u[IJK] += delt*fxrc/rhorc[IJK];
				if ( (rhorc[IJK]<frctn*rho[IJK]) || (ar[IJK] < em6) )
					u[IJK] = 0.0;
				if(u[IJK]>u_max) {
					u_max=u[IJK];
					umax_ijk=IJK;
				}
				if(u[IJK]<u_min) {
					u_min=u[IJK];
					umin_ijk=IJK;
				}
				
				if (af[IJK] >= em6)
					v[IJK] += delt*fyfc/rhofc[IJK];
				if ( (rhofc[IJK]<frctn*rho[IJK]) || (af[IJK] < em6) )
					v[IJK] = 0.0;
				if(v[IJK]>v_max) v_max=v[IJK];
				if(v[IJK]<v_min) v_min=v[IJK];
				
				if (ao[IJK] >= em6)
					w[IJK] += delt*fzoc/rhooc[IJK];
				if ( (rhooc[IJK]<frctn*rho[IJK]) || (ao[IJK] < em6) )
					w[IJK] = 0.0;
				if(w[IJK]>w_max) w_max=w[IJK];
				if(w[IJK]<w_min) w_min=w[IJK];
			}
	//printf("proc%d:u_max=%e u_min=%e v_max=%e v_min=%e w_max=%e w_min=%e umax_ijk=%d umin_ijk=%d\n",mpi.MyRank,u_max,u_min,v_max,v_min,w_max,w_min,umax_ijk,umin_ijk);
	/*apply boundary conditions*/
	bc();
#endif

	// move this line to setup.cpp
	for(int k=0;k<=kmax;k++)
	 for(int j=0;j<=jmax;j++)
	   for(int i=0;i<=imax;i++)
	   {
		   fvirt[IJK] = f[IJK] + psi[IJK];
	   }

	for(int k=0;k<=kmax;k++)
	 for(int j=0;j<=jmax;j++)
	   for(int i=0;i<=imax;i++) {
		  rho[IJK] = rhof1*fvirt[IJK] + 1.0*(1.e0 - fvirt[IJK]); //only for the purpose of calculating normals
	  }

normals_fvirt_curvature( fvirt ); // gradros are now based on fvirt

#ifdef Ytube
	// Cory Added this
	double *kap_x = (double*)memalloc (dim.nx, dim.ny, dim.nz, sizeof(double));
	double *kap_y = (double*)memalloc (dim.nx, dim.ny, 5, sizeof(double));
	double *kap_z = (double*)memalloc (dim.nx, dim.ny, 5, sizeof(double));
	
//	ytube_exact_curvature(kap_x, kap_y, kap_z);
#endif

#ifdef balanced_force
	double dfdx, dfdy, dfdz;
	double *kappa = temp[0];
	double *tensx=temp[9], *tensy=temp[10], *tensz=temp[11];
	double better_curv_est(int i, int j, int k);
	memset (tensx, 0, NX*NY*NZ*sizeof(double));
	memset (tensy, 0, NX*NY*NZ*sizeof(double));
	memset (tensz, 0, NX*NY*NZ*sizeof(double));
	
	memset(kappa, 0 , NX*NY*NZ*sizeof(double));
	
	int i,j,k; double w1,w2,kap;
	for(k=1;k<km1;k++)
	 for(j=1;j<jm1;j++)
	   for(i=1;i<im1;i++) {
		   
		  kappa[IJK]=-(gradrox[IPJPKP]-gradrox[IJPKP]
			  +gradrox[IPJPK]-gradrox[IJPK]
			  +gradrox[IPJKP]-gradrox[IJKP]
			  +gradrox[IPJK]-gradrox[IJK])/delx[i]/4.0
			  -(gradroy[IPJPKP]-gradroy[IPJKP]
			  +gradroy[IJPKP]-gradroy[IJKP]
			  +gradroy[IPJPK]-gradroy[IPJK]
			  +gradroy[IJPK]-gradroy[IJK])/dely[j]/4.0
			  -(gradroz[IPJPKP]-gradroz[IPJPK]
			  +gradroz[IPJKP]-gradroz[IPJK]
			  +gradroz[IJPKP]-gradroz[IJPK]
			  +gradroz[IJKP]-gradroz[IJK])/delz[k]/4.0;

		   if(fabs(kappa[IJK]) > 4.0/delx[1]) kappa[IJK] = 0.0; //turn off surface tension for subcell curvatures.
		  //kappa[IJK] = 2.0 / radius;
	  }
	  
	
	xchg<double>(kappa); 

#if CSF	
	if(mpi.MyRank==0) printf("entered the CSF region\n");
	for(k=1;k<km1;k++)
	 for(j=1;j<jm1;j++)
	   for(i=1;i<im1;i++) {
		  dfdx = (fvirt[IPJK]-fvirt[IJK]) / delx[1];
		  w1 = 1.0-fabs(pow(2.0*fvirt[IJK]-1,3));
		  w2 = 1.0-fabs(pow(2.0*fvirt[IPJK]-1,3));
		  kap = (w1*kappa[IJK]+w2*kappa[IPJK])/(w1+w2+tiny);
		  tensx[IJK] = sigma[IJK]*kap*dfdx;
/**
#ifdef Ytube			  
			  if (k<5 && mpi.Neighbors[4] == -1)
			  {
				tensx[IJK] = sigma[IJK]*kap_x[IJK]*dfdx;
			  }
#endif		  
**/
		  dfdy = (fvirt[IJPK]-fvirt[IJK]) / dely[1];
		  w1 = 1.0-fabs(pow(2.0*fvirt[IJK]-1,3));
		  w2 = 1.0-fabs(pow(2.0*fvirt[IJPK]-1,3));
		  kap = (w1*kappa[IJK]+w2*kappa[IJPK])/(w1+w2+tiny);
		  tensy[IJK] = sigma[IJK]*kap*dfdy;
/**
#ifdef Ytube			  
			  if (k<5 && mpi.Neighbors[4] == -1)
			  {
				tensy[IJK] = sigma[IJK]*kap_y[IJK]*dfdy;
			  }
#endif		  
**/
		  dfdz = (fvirt[IJKP]-fvirt[IJK]) / delz[1];
		  w1 = 1.0-fabs(pow(2.0*fvirt[IJK]-1,3));
		  w2 = 1.0-fabs(pow(2.0*fvirt[IJKP]-1,3));
		  kap = (w1*kappa[IJK]+w2*kappa[IJKP])/(w1+w2+tiny);
		  tensz[IJK] = sigma[IJK]*kap*dfdz;

/**
#ifdef Ytube			  
			  if (k<5 && mpi.Neighbors[4] == -1)
			  {
				tensz[IJK] = sigma[IJK]*kap_z[IJK]*dfdz;
			  }
#endif
**/

	  }
#else
	if(mpi.MyRank==0) printf("entered the SSF region\n");
	for(k=1;k<km1;k++)
	 for(j=1;j<jm1;j++)
	   for(i=1;i<im1;i++){
		  double phi1 = fvirt[IJK ] - 0.5;
		  double phi2 = fvirt[IPJK] - 0.5;
		  
		  if(phi1*phi2 <= 0.0) {
			  dfdx = (fvirt[IPJK]-fvirt[IJK]) / delx[1];
			  w1 = 1.0-fabs(pow(2.0*fvirt[IJK]-1,3));
			  w2 = 1.0-fabs(pow(2.0*fvirt[IPJK]-1,3));
		      kap = (w1*kappa[IJK]+w2*kappa[IPJK])/(w1+w2+tiny);
			  tensx[IJK] = sigma[IJK]*kap*SIGN(dfdx)/delx[1];
			  
#ifdef Ytube			  
			  if (k<5 && mpi.Neighbors[4] == -1)
			  {
				tensx[IJK] = sigma[IJK]*kap_x[IJK]*SIGN(dfdx)/delx[1];
			  }
#endif	
		  }
		  
		  phi2 = fvirt[IJPK] - 0.5;
		  if(phi1*phi2 <= 0.0) {
			  dfdy = (fvirt[IJPK]-fvirt[IJK]) / dely[1];
			  w1 = 1.0-fabs(pow(2.0*fvirt[IJK]-1,3));
			  w2 = 1.0-fabs(pow(2.0*fvirt[IJPK]-1,3));
		      kap = (w1*kappa[IJK]+w2*kappa[IJPK])/(w1+w2+tiny);
			  tensy[IJK] = sigma[IJK]*kap*SIGN(dfdy)/dely[1];
#ifdef Ytube			  
			  if (k<5 && mpi.Neighbors[4] == -1)
			  {
				tensy[IJK] = sigma[IJK]*kap_y[IJK]*SIGN(dfdy)/dely[1];
			  }
#endif	
		  }
		  
		  phi2 = fvirt[IJKP] - 0.5;
		  if(phi1*phi2 <= 0.0) {
			  dfdz = (fvirt[IJKP]-fvirt[IJK]) / delz[1];
			  w1 = 1.0-fabs(pow(2.0*fvirt[IJK]-1,3));
			  w2 = 1.0-fabs(pow(2.0*fvirt[IJKP]-1,3));
		      kap = (w1*kappa[IJK]+w2*kappa[IJKP])/(w1+w2+tiny);
			  tensz[IJK] = sigma[IJK]*kap*SIGN(dfdz)/delz[1];
#ifdef Ytube			  
			  if (k<5 && mpi.Neighbors[4] == -1)
			  {
				tensz[IJK] = sigma[IJK]*kap_z[IJK]*SIGN(dfdz)/delz[1];
			  }
#endif
		  }
	  }
#endif



	xchg<double>(tensx);
	xchg<double>(tensy);
	xchg<double>(tensz);
	//think of tens at domain boundaries later ...ashish
	//bc();
	bc_tens();
	
	//free(kap_x);
	//free(kap_y);
	//free(kap_z);
	
#endif
}
