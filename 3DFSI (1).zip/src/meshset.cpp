#include "ripple.h"

/******************************************************************************
This subroutine generates the computation mesh based on fx, fy and fz

Subroutine MESHSET is called by:	RIPPLE

Subroutine MESHSET calls:			

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-chagned the size of the inside array				Ben			July 29 2005
-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

void meshset()
{
	int i,j,k;
	//x mesh generation	(fixed)
	dxmn=xe/( (double)dim.fx );
	for (i=0;i<NX;i++)
		x[i]=dxmn*(double)(i+mpi.OProc[0]);
	
	//y mesh generation (fixed)
	dymn = ye / ( (double)dim.fy );
	for (j=0;j<NY;j++)
		y[j]=dymn*(double)(j+mpi.OProc[1]);

	//z mesh generation (fixed)
	dzmn = ze / ( (double)dim.fz );
	for (k=0;k<NZ;k++)
		z[k]=dzmn*(double)(k+mpi.OProc[2]);


	//calculate various mesh values

	for (i=1;i<NX;i++)
	{
		xi[i] = 0.5*(x[i-1]+x[i]);
		delx[i] = x[i]-x[i-1];
		rdx[i] = 1.0/delx[i];
	}
	xi[0]=xi[1]-delx[1];
	delx[0]=delx[1];
	rdx[0]=1/delx[0];
	for (i=1;i<NX;i++)
	{
		delxl[i]=0.5*(delx[i]+delx[i-1]);
		rdelxl[i]=1.0/delxl[i];
	}


	for (j=1;j<NY;j++)
	{
		yj[j]=0.5*(y[j-1]+y[j]);
		dely[j]=y[j]-y[j-1];
		rdy[j]=1.0/dely[j];
	}
	yj[0]=yj[1]-dely[1];
	dely[0]=dely[1];
	rdy[0]=1.0/dely[1];
	for (j=1;j<NY;j++)
	{
		delyb[j]=0.5*(dely[j]+dely[j-1]);
		rdelyb[j]=1.0/delyb[j];
	}

	for (k=1;k<NZ;k++)
	{
		zk[k]=0.5*(z[k-1]+z[k]);
		delz[k]=z[k]-z[k-1];
		rdz[k]=1.0/delz[k];
	}
	zk[0]=zk[1]-delz[1];
	delz[0]=delz[1];
	rdz[0]=1.0/delz[0];
	for (k=1;k<NZ;k++)
	{
		delzu[k]=0.5*(delz[k]+delz[k-1]);
		rdelzu[k]=1.0/delzu[k];
	}

	//calculate volumes for the mesh
	for (i=0;i<NX;i++)
		for (j=0;j<NY;j++)
			for (k=0;k<NZ;k++)
				vol[IND(i,j,k)]=delx[i]*dely[j]*delz[k];
				
#ifdef rudman_fine
	for (i=0;i<NX_f;i++)
		for (j=0;j<NY_f;j++)
			for (k=0;k<NZ_f;k++)
				vol_f[IND_f(i,j,k)]=0.125e0*delx[1]*dely[1]*delz[1];
#endif

	//initialize vector 'inside'
	inside[0]=0;//added this so that inside vector works like in serial code
	inside[1]=-1;
	inside[2]=1;
	inside[3]=-imax;
	inside[4]=imax;
	inside[5]=-ijmax;
	inside[6]=ijmax;

	 //too much data...
	//write out mesh information
	fprintf (files.summary, "\n");
	for (i=0;i<NX;i++)
		{
		fprintf (files.summary, "  x(%3d)=%11.4e  delx(%3d)=%11.4e  rdx(%3d)=%11.4e  xi(%3d)=%11.4e\n", i, x[i], i, delx[i], i, rdx[i], i, xi[i]);
		}
	fprintf(files.summary, "\n");
	for (j=0;j<NY;j++)
		{
		fprintf (files.summary, "  y(%3d)=%11.4e  dely(%3d)=%11.4e  rdy(%3d)=%11.4e  yj(%3d)=%11.4e\n", j, y[j], j, dely[j], j, rdy[j], j, yj[j]);
		}
	fprintf(files.summary, "\n");
	for (k=0;k<NZ;k++)
		{
		fprintf (files.summary, "  z(%3d)=%11.4e  delz(%3d)=%11.4e  rdz(%3d)=%11.4e  zk(%3d)=%11.4e\n", k, z[k], k, delz[k], k, rdz[k], k, zk[k]);
		}
	fprintf(files.out, "\n");
}
