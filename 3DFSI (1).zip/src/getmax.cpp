#include <math.h>
#include "ripple.h"
#include "testing.h"

/******************************************************************************
This subroutine returns the larges value of an array given by VAR.  It also
saves the location of the maximum value and stores them in ii, jj and kk.

Subroutine GETMAX is called by:	DT

Subroutine GETMAX calls:	

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION                                         NAME        DATE

-Created this subroutine                            Ben         Jan 24 2006
-Created this template for tracking changes         Ben         Apr 21 2005


_________________________________TO DO LIST____________________________________
DESCRIPTION                                         NAME        DATE


*******************************************************************************/

double getmax(double *var, int *ii, int *jj, int *kk)
{
	int i, j, k;
	double tmax = tiny;
	
	i = j = k = 0;
	for(k = 1; k < km1; k++)
		for(j = 1; j < jm1; j++)
			for(i = 1; i < im1; i++)
			{
				if(fabs(var[IJK]) > tmax)
				{
					tmax = fabs(var[IJK]);
					*ii = i;
					*jj = j;
					*kk = k;
				}
			}
	return tmax;
}
