#include <stdio.h>
#include <stdlib.h>
#include "ripple.h"
#include "testing.h"
#include <string.h>/*memcpy*/

/******************************************************************************

This subroutine is used to read the dump files into the computational nodes.

Subroutine READ_DUMP is called by:	SETUP

Subroutine READ_DUMP calls:		

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

- Added the f_copy routine from initf_jet to copy   S.Codyer    Apr 24.2012
  the f field into memory for testing.cpp jet_flow
  routines.

- Bugs in this subroutine are fixed. Now the dump   Babak       October 22 2008
  files can be read without problem. Each dump
  file must be renamed to dump-XXX prior to 
  running, with XXX standing for the process
  number.
  
- Created this template for tracking changes		Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

void read_dump(void)
{
	int i, j, k, c;
	int nfluid;
	double uin, vin, win, fin, pin, sin;
	
#ifdef rudman_fine
	double f_f1, f_f2, f_f3, f_f4, f_f5, f_f6, f_f7, f_f8;
#ifdef __solid
	double psi_f1, psi_f2, psi_f3, psi_f4, psi_f5, psi_f6, psi_f7, psi_f8;
	
	double s_f1, s_f2, s_f3, s_f4, s_f5, s_f6, s_f7, s_f8;
#endif
#endif

	char filename[16];
	sprintf(filename, "dump-%03d", mpi.MyRank);
	FILE *in = fopen(filename, "rt");

	if (!in)
	{
		printf ("Process %03d is unable to open input file\n", mpi.MyRank);
		exit (1);
	}

	/*read in time data and ncyc*/
	fscanf(in, "%lf %lf %lf %lf %lf %d\n", &delt, &deltold, &t, &twplt, &twdmp, &ncyc);
	
	//printf("proc%d: t=%e ncyc=%d\n",mpi.MyRank,t,ncyc);
	
	/*read in total number of cells*/
	fscanf(in, "%d %d %d\n", &nfluid, &iplot, &idump);

#ifndef rudman_fine
	for(c = 0; c < nfluid; c++)
	{
        /*read in u,v,w,f,p for each cell*/
		fscanf(in, "%4d %4d %4d %lf %lf %lf %lf %lf", &i, &j, &k, &uin, &vin, &win, &fin, &pin);
		u[IJK] = uin;
		v[IJK] = vin;
		w[IJK] = win;
		f[IJK] = fin;
		p[IJK] = pin;
	}
	
#endif

#ifdef rudman_fine

#ifndef __solid
	for(c=0; c < nfluid; c++)
	{
		fscanf(in, "%4d %4d %4d %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf", &i, &j, &k, &uin, &vin, &win, &fin, &pin, &f_f1, &f_f2, &f_f3, &f_f4, &f_f5, &f_f6, &f_f7, &f_f8);
		u[IJK] = uin;
		v[IJK] = vin;
		w[IJK] = win;
		f[IJK] = fin;
		p[IJK] = pin;
		
		f_f[IND_f(2*i,2*j,2*k)]=f_f1;
		f_f[IND_f(2*i-1,2*j,2*k)]=f_f2;
		f_f[IND_f(2*i-1,2*j-1,2*k)]=f_f3;
		f_f[IND_f(2*i,2*j-1,2*k)]=f_f4;
		f_f[IND_f(2*i,2*j,2*k-1)]=f_f5;
		f_f[IND_f(2*i-1,2*j,2*k-1)]=f_f6;
		f_f[IND_f(2*i-1,2*j-1,2*k-1)]=f_f7;
		f_f[IND_f(2*i,2*j-1,2*k-1)]=f_f8;
		
	}
#endif

#ifdef __solid
	for(c=0; c < nfluid; c++)
	{
		fscanf(in, "%4d %4d %4d %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf\n", &i, &j, &k, &uin, &vin, &win, &fin, &pin, &f_f1, &f_f2, &f_f3, &f_f4, &f_f5, &f_f6, &f_f7, &f_f8,
		&psi_f1, &psi_f2, &psi_f3, &psi_f4, &psi_f5, &psi_f6, &psi_f7, &psi_f8);
		u[IJK] = uin;
		v[IJK] = vin;
		w[IJK] = win;
		f[IJK] = fin;
		p[IJK] = pin;
		
		f_f[IND_f(2*i,2*j,2*k)]=f_f1;
		f_f[IND_f(2*i-1,2*j,2*k)]=f_f2;
		f_f[IND_f(2*i-1,2*j-1,2*k)]=f_f3;
		f_f[IND_f(2*i,2*j-1,2*k)]=f_f4;
		f_f[IND_f(2*i,2*j,2*k-1)]=f_f5;
		f_f[IND_f(2*i-1,2*j,2*k-1)]=f_f6;
		f_f[IND_f(2*i-1,2*j-1,2*k-1)]=f_f7;
		f_f[IND_f(2*i,2*j-1,2*k-1)]=f_f8;
		
		psi_f[IND_f(2*i,2*j,2*k)]=psi_f1;
		psi_f[IND_f(2*i-1,2*j,2*k)]=psi_f2;
		psi_f[IND_f(2*i-1,2*j-1,2*k)]=psi_f3;
		psi_f[IND_f(2*i,2*j-1,2*k)]=psi_f4;
		psi_f[IND_f(2*i,2*j,2*k-1)]=psi_f5;
		psi_f[IND_f(2*i-1,2*j,2*k-1)]=psi_f6;
		psi_f[IND_f(2*i-1,2*j-1,2*k-1)]=psi_f7;
		psi_f[IND_f(2*i,2*j-1,2*k-1)]=psi_f8;
		
	}
	
for(c=0; c < nfluid; c++)
	{
		fscanf(in, "%4d %4d %4d %lf %lf %lf %lf %lf %lf %lf %lf %lf", &i, &j, &k, &sin, &s_f1, &s_f2, &s_f3, &s_f4, &s_f5, &s_f6, &s_f7, &s_f8);

		crse_scal[IJK] = sin;
		
		scal[IND_f(2*i,2*j,2*k)]=s_f1;
		scal[IND_f(2*i-1,2*j,2*k)]=s_f2;
		scal[IND_f(2*i-1,2*j-1,2*k)]=s_f3;
		scal[IND_f(2*i,2*j-1,2*k)]=s_f4;
		scal[IND_f(2*i,2*j,2*k-1)]=s_f5;
		scal[IND_f(2*i-1,2*j,2*k-1)]=s_f6;
		scal[IND_f(2*i-1,2*j-1,2*k-1)]=s_f7;
		scal[IND_f(2*i,2*j-1,2*k-1)]=s_f8;
	}
#endif

#endif
	fclose(in);
	if (ko == 3)
	{
      	/*if OVER face on this processor is real, preserve the original circular
		profile of the jet by copying f from level km2 into ftemp.  This is 
		needed later when applying bc's
	*/
		if (mpi.Neighbors[5] == -1)
		{
			memcpy (&ftemp[IND(0,0,km2)], &f[IND(0,0,km2)], NX*NY*sizeof(double));
		}
	}
	else if (ku == 3)
	{
		if (mpi.Neighbors[4] == -1)		
		{
			memcpy (&ftemp[IND(0,0,0)], &f[IND(0,0,1)], NX*NY*sizeof(double));
			memcpy (&ftemp[IND(0,0,1)], &f[IND(0,0,1)], NX*NY*sizeof(double));
			memcpy (&ftemp[IND(0,0,2)], &f[IND(0,0,2)], NX*NY*sizeof(double));
			printf("Copied F field to temp!");
			printf("F[0] = %f\n",ftemp[IND(100,100,0)]);
			printf("F[1] = %f\n",ftemp[IND(100,100,1)]);
			printf("F[2] = %f\n",ftemp[IND(100,100,2)]);
		}
	}
	
/**
	if (mpi.MyRank == 0) {
		sprintf(filename, "cory_dump-%03d", mpi.MyRank);
		FILE *cory = fopen(filename, "rt");
		
		fscanf(cory,"%d %lf %lf\n", &plug_number, plug_frequency, plug_i_time);
		fclose(cory);
	}
	bcastdata(&plug_number, 1);
	bcastdata(&plug_frequency, 1);
	bcastdata(&plug_i_time, 1); **/
	
	
}
