#include "ripple.h"
#include "testing.h"
#define TOL 1e-6
/******************************************************************************
Resets velocities and check for surrounding fluid.  Adjusts velocities based on 
pressure field.

Subroutine ACCEL is called by:	IMPLCTP

Subroutine ACCEL calls:	BC

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Removed a call to bc() at end of accel because     Ben        July 01  2006
 bc() is called imediately after the call to accel
 in implctp
-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

void accel()
{
	int i,j,k;
	
#ifdef rudman_fine
	//double *rhorc=temp[18], *rhofc=temp[19], *rhooc=temp[20];
	rhorc=temp[18], rhofc=temp[19], rhooc=temp[20];
#ifdef __solid
	double *psimx=temp[21], *psimy=temp[22], *psimz=temp[23];
#endif
#endif

#ifdef balanced_force
	double *tensx=temp[9], *tensy=temp[10], *tensz=temp[11];
#endif

	for (i=1;i<im1;i++)
		for (j=1;j<jm1;j++)
			for (k=1;k<km1;k++)
	    	{
                if (BUBBLE && 
                   (bubble[IJK].current  ||
                    bubble[IPJK].current ||
                    bubble[IJPK].current ||
                    bubble[IJKP].current))
                    continue;/*skip bubble cells*/
				//reset x-velocity and check for surrounding fluid
				if (ar[IJK]>=em6) {
#ifndef balanced_force 
					u[IJK] += delt*(p[IJK]-p[IPJK])*2.0/(rhorc[IJK]*(delx[i+1]+delx[i]));
#endif
#ifdef balanced_force
					u[IJK] += (delt/rhorc[IJK])*((p[IJK]-p[IPJK])*2.0/(delx[i+1]+delx[i]) + tensx[IJK]);
#endif
				}
				else
					u[IJK]=0.0;

				//reset y-velocity and check for surrounding fluid
				if (af[IJK]>=em6) {
#ifndef balanced_force  
					v[IJK] += delt*(p[IJK]-p[IJPK])*2.0/(rhofc[IJK]*(dely[j+1]+dely[j]));
#endif
#ifdef balanced_force
					v[IJK] += (delt/rhofc[IJK])*((p[IJK]-p[IJPK])*2.0/(dely[j+1]+dely[j]) + tensy[IJK]);
#endif
				}
				else
					v[IJK]=0.0;

				//reset z-velocity and check for surrounding fluid
				
				if (ao[IJK]>=em6) {
#ifndef balanced_force
					w[IJK] += delt*(p[IJK]-p[IJKP])*2.0/(rhooc[IJK]*(delz[k+1]+delz[k]));
#endif
#ifdef balanced_force
					w[IJK] += (delt/rhooc[IJK])*((p[IJK]-p[IJKP])*2.0/(delz[k+1]+delz[k]) + tensz[IJK]);
#endif
				}
				else
					w[IJK]=0.0;
		}
		/*if(mpi.MyRank==5) {
			i=3,j=17,k=5;
			double rt,lt,ft,bt,ot,ut;
			rt = (p[IJK]-p[IPJK])/delx[1] + tensx[IJK];
			lt = (p[IMJK]-p[IJK])/delx[1] + tensx[IMJK];
			ft = (p[IJK]-p[IJPK])/dely[1] + tensy[IJK];
			bt = (p[IJMK]-p[IJK])/dely[1] + tensy[IJMK];
			ot = (p[IJK]-p[IJKP])/delz[1] + tensz[IJK];
			ut = (p[IJKM]-p[IJK])/delz[1] + tensz[IJKM];
			
			printf("rt = %e lt = %e ft = %e bt = %e ot = %e ut = %e TOL=%e\n", rt, lt, ft, bt, ot, ut, (rt-lt)+(ft-bt)+(ot-ut));
		}*/
}
