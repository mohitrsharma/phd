// include statements
#include "ripple.h"
#include <math.h>
#include <string.h>
#include <stdlib.h> //exit

// As a dummy example, initialize scal in the same way as you would initialize 
// the vof scalar.
	
	
void compute_concentration(double *c, double *s, double *fn) {
		
	int i,j,k;
		
	memset(c,0,NX_f*NY_f*NZ_f*sizeof(double));
		
	for(k=1;k<km1_f;k++)
		for(j=1;j<jm1_f;j++)
			for(i=1;i<im1_f;i++) {
					
				if(fn[IJK_f] > em6) c[IJK_f] = s[IJK_f] / fn[IJK_f];
			}
			
		
	// fill the virtual subdomain boundaries
	xchg_f <double> (c);
}
	
	
void rescale_scalar(double *s, double *vold_f, double *vnew_f) {
	
	int i,j,k;
		
	for(k=1;k<km1_f;k++)
		for(j=1;j<jm1_f;j++)
			for(i=1;i<im1_f;i++) {
				s[IJK_f] = s[IJK_f] * vold_f[IJK_f] / vnew_f[IJK_f];
			}
}
	
	
void update_scalar(int looper, double *u_f, double *s, double *flx, double *vnew_f, double *c) {
		
	int i,j,k;
	double conc;
	
	for(k=0;k<km1_f;k++)
		for(j=0;j<jm1_f;j++)
			for(i=0;i<im1_f;i++) {
				
			switch(looper) {
				case 1:
					if(j==0 || k==0) continue;
					if(u_f[IJK_f] == 0.0) continue;
						
					if(u_f[IJK_f] > 0.0) 
						conc = c[IJK_f];
					else
						conc = c[IPJK_f];
						
					s[IJK_f]  = s[IJK_f]  - flx[IJK_f] * conc / vnew_f[IJK_f];
					s[IPJK_f] = s[IPJK_f] + flx[IJK_f] * conc / vnew_f[IPJK_f];
					break;
					
				case 2:
					if(i==0 || k==0) continue;
					if(u_f[IJK_f] == 0.0) continue;
						
					if(u_f[IJK_f] > 0.0)
						conc = c[IJK_f];
					else
						conc = c[IJPK_f];
							
					s[IJK_f]  = s[IJK_f]  - flx[IJK_f] * conc / vnew_f[IJK_f];
					s[IJPK_f] = s[IJPK_f] + flx[IJK_f] * conc / vnew_f[IJPK_f];
					break;
					
				case 3:
					if(i==0 || j==0) continue;
					if(u_f[IJK_f] == 0.0) continue;
						
					if(u_f[IJK_f] > 0.0)
						conc = c[IJK_f];
					else
						conc = c[IJKP_f];
						
					s[IJK_f]  = s[IJK_f]  - flx[IJK_f] * conc / vnew_f[IJK_f];
					s[IJKP_f] = s[IJKP_f] + flx[IJK_f] * conc / vnew_f[IJKP_f];
					break;
				}
				
			}
			
			//debug
			//if(mpi.MyRank==4) {
			//	i=16, j=90, k=54;
			//int ii,jj,kk;
			//for(kk=-1;kk<1;kk++)
			// for(jj=-1;jj<1;jj++)
			 // for(ii=-1;ii<1;ii++) {
			//		
			//		printf("(%d %d %d) scal = %e f=%e\t",ii,jj,kk,s[IND_f(2*i+ii,2*j+jj,2*k+kk)],f_f[IND_f(2*i+ii,2*j+jj,2*k+kk)]);
			//		
			//	}
			//	printf("\n");
			//}
			
			
			// fill the virtual subdomain boundaries
			xchg_f <double> (s); 
}

void gfine2stnd(double *S, double *s) {
		
	int i,j,k;
	
	for(k=1;k<km1;k++)
		for(j=1;j<jm1;j++)
			for(i=1;i<im1;i++) {
				S[IJK] = 0.125e0 * ( s[IND_f(2*i-1,2*j-1,2*k-1)] 
				                   + s[IND_f(2*i  ,2*j-1,2*k-1)]
				                   + s[IND_f(2*i-1,2*j  ,2*k-1)]
				                   + s[IND_f(2*i  ,2*j  ,2*k-1)]
				                   
				                   + s[IND_f(2*i-1,2*j-1,2*k  )] 
				                   + s[IND_f(2*i  ,2*j-1,2*k  )]
				                   + s[IND_f(2*i-1,2*j  ,2*k  )]
				                   + s[IND_f(2*i  ,2*j  ,2*k  )] 
				                   );
			}
}
	
void clean_scal(double *s) {
		
	int i,j,k;
		
	for(k=1;k<km1_f;k++)
		for(j=1;j<jm1_f;j++)
			for(i=1;i<im1_f;i++) {
				
				if(s[IJK_f] < em6) s[IJK_f] = 0.0;
				if(s[IJK_f] > em61) s[IJK_f] = 1.0;
			}
			
	xchg_f<double>(s);	
}
	
void advect_scalar(int looper, double *s, double *S, double *c, double *fn, double *vold_f, 
	                   double *vnew_f, double *u_f, double *flx) {
	// s is a scalar just like vof, i.e. fraction of cell volume occupied by scalar
	// c is concentration of scalar within vof, i.e. fract of vof occupied by scalar
	// Idea has been borowed from Bothe & Fleckenstein (2013)
		
	compute_concentration(c,s,fn);
	rescale_scalar(s,vold_f, vnew_f);
	update_scalar(looper,u_f,s,flx,vnew_f,c);
		
	// for plotting map to the coarse grid
	gfine2stnd(S,s);
	xchg<double>(S); //xchg information at the virtual boundaries
}
