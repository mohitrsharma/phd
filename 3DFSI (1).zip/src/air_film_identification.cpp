#include "ripple.h"
#include "testing.h"
#include "comm.h"
#include <math.h>
#include <string.h> //memcpy

/******************************************************************************
____________________________NOTES ON CNAGES____________________________________


DESCRIPTION                                             NAME        DATE

-This routine determins if an air film has been         Cory        January 12 2017
identified, and calls the function to correct the
problem.

-The current routine determins the leading edge of      Cory        January 27 2017
the solid object. It does this by determining the 
largest component of velocity and using this as its
reference. After this is determined, the largest or
smallest index is found between mpi procs. This
index is then used for the density change.



_________________________________TO DO LIST____________________________________

DESCRIPTION                                             NAME        DATE

-Make leading edge detection more general               Cory        February 3 2017
The current method will only work for slow rotating
particles. If the particle is rotating, velocities
will have different directions in solid cells. The
proposed method is to detect the liquid when it is
close and to obtain its normal and use this as the
direction for density change.


*******************************************************************************/

int detect_air_film()
{
	int i,j,k;
	double *kappa = temp[9];
	double *alpharho_f = temp_f[1];
	
	double *alphagradrox = temp[3];
	double *alphagradroy = temp[4];
	double *alphagradroz = temp[5];
	double *alphagradrox_f = temp_f[3];
	double *alphagradroy_f = temp_f[4];
	double *alphagradroz_f = temp_f[5];
	
	for(k=0;k<kmax_f;k++)
		for(j=0;j<jmax_f;j++)
			for(i=0;i<imax_f;i++)  
				alpharho_f[IJK_f]=rhof2*(1-f_f[IJK_f]-psi_f[IJK_f]) + rhof2*(f_f[IJK_f]+psi_f[IJK_f])/1000;
	
	normals_alpha_f(); //Calculates cell centered and vertex centered normal vectors on the find grid for alpha

	normals_from_fine(alphagradrox,  alphagradroy,   alphagradroz,
				  alphagradrox_f,alphagradroy_f,alphagradroz_f);    //Interpolates coarse grid normals from fine grid
				  
	for (k=1;k<km1;k++)
		for (j=1;j<jm1;j++)
			for (i=1;i<im1;i++)
			{
				kappa[IJK]=-(alphagradrox[IPJPKP]-alphagradrox[IJPKP]
				+alphagradrox[IPJPK]-alphagradrox[IJPK]
				+alphagradrox[IPJKP]-alphagradrox[IJKP]
				+alphagradrox[IPJK]-alphagradrox[IJK])/delx[i]/4.0
				-(alphagradroy[IPJPKP]-alphagradroy[IPJKP]
				+alphagradroy[IJPKP]-alphagradroy[IJKP]
				+alphagradroy[IPJPK]-alphagradroy[IPJK]
				+alphagradroy[IJPK]-alphagradroy[IJK])/dely[j]/4.0
				-(alphagradroz[IPJPKP]-alphagradroz[IPJPK]
				+alphagradroz[IPJKP]-alphagradroz[IPJK]
				+alphagradroz[IJPKP]-alphagradroz[IJPK]
				+alphagradroz[IJKP]-alphagradroz[IJK])/delz[k]/4.0;    //Coarse Grid Curvature
			}
	
	double temporary_indicator =0;
	double new_indicator =0;
			
	for(k=1;k<km1;k++)
		for(j=1;j<jm1;j++)
			for(i=1;i<im1;i++)
			{
				if(kappa[IJK]*delx[1] > 2.3) //2.3 for wedge, 1.5 for sphere
				{
					temporary_indicator =1;
				}
			}
		
		dallreduce(&temporary_indicator,&new_indicator,1,OP_MAX);
			
		if(new_indicator ==1)
		{
			return 1;
		}
		else return 0;	
}

double largest_solid_velocity()
{
	int i,j,k;
	int velocity =0;
	
	for(k=1;k<km1;k++)
		for(j=1;j<jm1;j++)
			for(i=1;i<im1;i++)
			{
				if(psi[IJK] >=em6)
				{
					if( fabs(u[IJK]) > fabs(v[IJK]) && fabs(u[IJK]) > fabs(w[IJK])) 
					{
						if(u[IJK]>0) velocity = 1;
						else velocity = -1;
						goto end;
					}
					
					if( fabs(v[IJK]) > fabs(u[IJK]) && fabs(v[IJK]) > fabs(w[IJK])) 
					{
						if(v[IJK]>0) velocity = 2;
						else velocity = -2;
						goto end;
					}
					
					if( fabs(w[IJK]) > fabs(u[IJK]) && fabs(w[IJK]) > fabs(v[IJK]) ) 
					{
						if(w[IJK]>0) velocity = 3;
						else velocity = -3;
						goto end;
					}
				}
			}
			
	end:
	return velocity;
}

void density_correction(double velocity)
{
	int i,j,k;
	double index=0;
	double new_index=0;
	double tx,ty,tz;
	tx=ty=tz=0;
			
	double *vnew_stgx=temp[12]; //control volumes for x,y and z momentum
    double *vnew_stgy=temp[13];
    double *vnew_stgz=temp[14];
	double *vnew_f = temp_f[0];
		
	rhorc=temp[18], rhofc=temp[19], rhooc=temp[20];
	
	memcpy(vnew_f,vol_f,NX_f*NY_f*NZ_f*sizeof(double));
	
	stag_vol();
	
	double shared_velocity=0;
	
	dallreduce(&velocity,&shared_velocity,1,OP_MAX);
	if(shared_velocity==0) dallreduce(&velocity,&shared_velocity,1,OP_MIN);
	
	if(global_velocity==0 && shared_velocity != 0) global_velocity=shared_velocity;
	if(global_velocity != shared_velocity) goto no_change;
	
	if(shared_velocity==1) goto vel_1;
	if(shared_velocity==2) goto vel_2;
	if(shared_velocity==3) goto vel_3;
	if(shared_velocity==-1) goto vel_m1;
	if(shared_velocity==-2) goto vel_m2;
	if(shared_velocity==-3) goto vel_m3;
	if(shared_velocity==0) goto no_change;
	
	vel_1:
	if(velocity==1)
	{
		index=0;
		for(k=1;k<km1;k++)
			for(j=1;j<jm1;j++)
				for(i=1;i<im1;i++)
					if(psi[IJK]>em6 && i>index) index = i;
	}
	tx = (index+2*mpi.OProc[0]-0.5)*(0.5*delx[1]);
	dallreduce(&tx,&new_index,1,OP_MAX);
	if(tx==new_index) goto end_1;
	else goto no_change;
	
	vel_m1:
	if(velocity==-1)
	{
		index=im1;
		for(k=1;k<km1;k++)
			for(j=1;j<jm1;j++)
				for(i=1;i<im1;i++)
					if(psi[IJK]>em6 && i<index) index = i;
	}
	tx = (index+2*mpi.OProc[0]-0.5)*(0.5*delx[1]);
	dallreduce(&tx,&new_index,1,OP_MIN);
	if(tx==new_index) goto end_1;			
	else goto no_change;
	
	vel_2:
	if(velocity==2)
	{
		index=0;
		for(k=1;k<km1;k++)
			for(j=1;j<jm1;j++)
				for(i=1;i<im1;i++)
					if(psi[IJK]>em6 && j>index) index = j;
	}
	ty = (index+2*mpi.OProc[1]-0.5)*(0.5*dely[1]);
	dallreduce(&ty,&new_index,1,OP_MAX);	
	if(ty==new_index) goto end_2;				
	else goto no_change;

	vel_m2:
	if(velocity==-2)
	{
		index=jm1;
		for(k=1;k<km1;k++)
			for(j=1;j<jm1;j++)
				for(i=1;i<im1;i++)
					if(psi[IJK]>em6 && j<index) index = j;
	}
	ty = (index+2*mpi.OProc[1]-0.5)*(0.5*dely[1]);
	dallreduce(&ty,&new_index,1,OP_MIN);	
	if(ty==new_index) goto end_2;			
	else goto no_change;
	
	vel_3:
	if(velocity==3)
	{	
		index=0;
		for(k=1;k<km1;k++)
			for(j=1;j<jm1;j++)
				for(i=1;i<im1;i++)
					if(psi[IJK]>em6 && k>index) index = k;
	}	
	tz = (index+2*mpi.OProc[2]-0.5)*(0.5*delz[1]);
	dallreduce(&tz,&new_index,1,OP_MAX);
	if(tz==new_index) goto end_3;				
	else goto no_change;

	vel_m3:
	if(velocity==-3)
	{
		index=km1;
		for(k=1;k<km1;k++)
			for(j=1;j<jm1;j++)
				for(i=1;i<im1;i++)
					if(psi[IJK]>em6 && k<index) index = k;
	}
	tz = (index+2*mpi.OProc[1]-0.5)*(0.5*delz[1]);
	dallreduce(&tz,&new_index,1,OP_MIN);
	if(tz==new_index) goto end_3;
	else goto no_change;
	
	end_1:

	i=index;
	
	for(k=0;k<km1;k++)
		for(j=0;j<jm1;j++)
		{
			if( f[IJK] <em6 && psi[IJK]>em6)
			{	
					
				if(i>0 && k>0)
				{
					rhofc[IJK] = rhof2*(vnew_f[IND_f(2*i,2*j,2*k)] + vnew_f[IND_f(2*i-1,2*j,2*k)] + vnew_f[IND_f(2*i-1,2*j,2*k-1)] + vnew_f[IND_f(2*i,2*j,2*k-1)] + vnew_f[IND_f(2*i,2*j+1,2*k)] + vnew_f[IND_f(2*i-1,2*j+1,2*k)] + vnew_f[IND_f(2*i-1,2*j+1,2*k-1)] + vnew_f[IND_f(2*i,2*j+1,2*k-1)])/vnew_stgy[IJK];
					rhofc[IJMK]= rhof2*(vnew_f[IND_f(2*i,2*j-1,2*k)] + vnew_f[IND_f(2*i-1,2*j-1,2*k)] + vnew_f[IND_f(2*i-1,2*j-1,2*k-1)] + vnew_f[IND_f(2*i,2*j-1,2*k-1)] + vnew_f[IND_f(2*i,2*j+1-1,2*k)] + vnew_f[IND_f(2*i-1,2*j+1-1,2*k)] + vnew_f[IND_f(2*i-1,2*j+1-1,2*k-1)] + vnew_f[IND_f(2*i,2*j+1-1,2*k-1)])/vnew_stgy[IJMK];				

				}

				if(i>0 && j>0) 
				{
					rhooc[IJK] = rhof2*(vnew_f[IND_f(2*i,2*j,2*k)] + vnew_f[IND_f(2*i-1,2*j,2*k)] + vnew_f[IND_f(2*i-1,2*j-1,2*k)] + vnew_f[IND_f(2*i,2*j-1,2*k)] + vnew_f[IND_f(2*i,2*j,2*k+1)] + vnew_f[IND_f(2*i-1,2*j,2*k+1)] + vnew_f[IND_f(2*i-1,2*j-1,2*k+1)] + vnew_f[IND_f(2*i,2*j-1,2*k+1)])/vnew_stgz[IJK];
					rhooc[IJKM]= rhof2*(vnew_f[IND_f(2*i,2*j,2*k-1)] + vnew_f[IND_f(2*i-1,2*j,2*k-1)] + vnew_f[IND_f(2*i-1,2*j-1,2*k-1)] + vnew_f[IND_f(2*i,2*j-1,2*k-1)] + vnew_f[IND_f(2*i,2*j,2*k+1-1)] + vnew_f[IND_f(2*i-1,2*j,2*k+1-1)] + vnew_f[IND_f(2*i-1,2*j-1,2*k+1-1)] + vnew_f[IND_f(2*i,2*j-1,2*k+1-1)])/vnew_stgz[IJKM];

				}
			}
		}
		goto stop;
	
	end_2:

	j=index;
		
	for(k=0;k<km1;k++)
		for(i=0;i<im1;i++)
		{
			if( f[IJK] <em6 && psi[IJK]>em6)
			{	
				if(j>0 && k>0)
				{
					rhorc[IJK] = rhof2*(vnew_f[IND_f(2*i,2*j,2*k)] + vnew_f[IND_f(2*i,2*j-1,2*k)] + vnew_f[IND_f(2*i,2*j-1,2*k-1)] + vnew_f[IND_f(2*i,2*j,2*k-1)] + vnew_f[IND_f(2*i+1,2*j,2*k)] + vnew_f[IND_f(2*i+1,2*j-1,2*k)] + vnew_f[IND_f(2*i+1,2*j-1,2*k-1)] + vnew_f[IND_f(2*i+1,2*j,2*k-1)])/vnew_stgx[IJK];
					rhorc[IMJK]= rhof2*(vnew_f[IND_f(2*i-1,2*j,2*k)] + vnew_f[IND_f(2*i-1,2*j-1,2*k)] + vnew_f[IND_f(2*i-1,2*j-1,2*k-1)] + vnew_f[IND_f(2*i-1,2*j,2*k-1)] + vnew_f[IND_f(2*i-1+1,2*j,2*k)] + vnew_f[IND_f(2*i-1+1,2*j-1,2*k)] + vnew_f[IND_f(2*i-1+1,2*j-1,2*k-1)] + vnew_f[IND_f(2*i-1+1,2*j,2*k-1)])/vnew_stgx[IMJK];

				}

				if(i>0 && j>0) 
				{
					rhooc[IJK] = rhof2*(vnew_f[IND_f(2*i,2*j,2*k)] + vnew_f[IND_f(2*i-1,2*j,2*k)] + vnew_f[IND_f(2*i-1,2*j-1,2*k)] + vnew_f[IND_f(2*i,2*j-1,2*k)] + vnew_f[IND_f(2*i,2*j,2*k+1)] + vnew_f[IND_f(2*i-1,2*j,2*k+1)] + vnew_f[IND_f(2*i-1,2*j-1,2*k+1)] + vnew_f[IND_f(2*i,2*j-1,2*k+1)])/vnew_stgz[IJK];
					rhooc[IJKM]= rhof2*(vnew_f[IND_f(2*i,2*j,2*k-1)] + vnew_f[IND_f(2*i-1,2*j,2*k-1)] + vnew_f[IND_f(2*i-1,2*j-1,2*k-1)] + vnew_f[IND_f(2*i,2*j-1,2*k-1)] + vnew_f[IND_f(2*i,2*j,2*k+1-1)] + vnew_f[IND_f(2*i-1,2*j,2*k+1-1)] + vnew_f[IND_f(2*i-1,2*j-1,2*k+1-1)] + vnew_f[IND_f(2*i,2*j-1,2*k+1-1)])/vnew_stgz[IJKM];

				}
			}
		}
		goto stop;
		
	end_3:	

	k=index;	
		
	for(j=0;j<jm1;j++)
		for(i=0;i<im1;i++)
		{
			if( f[IJK] <em6 && psi[IJK]>em6)
			{	
				if(j>0 && k>0)
				{
					rhorc[IJK] = rhof2*(vnew_f[IND_f(2*i,2*j,2*k)] + vnew_f[IND_f(2*i,2*j-1,2*k)] + vnew_f[IND_f(2*i,2*j-1,2*k-1)] + vnew_f[IND_f(2*i,2*j,2*k-1)] + vnew_f[IND_f(2*i+1,2*j,2*k)] + vnew_f[IND_f(2*i+1,2*j-1,2*k)] + vnew_f[IND_f(2*i+1,2*j-1,2*k-1)] + vnew_f[IND_f(2*i+1,2*j,2*k-1)])/vnew_stgx[IJK];
					rhorc[IMJK]= rhof2*(vnew_f[IND_f(2*i-1,2*j,2*k)] + vnew_f[IND_f(2*i-1,2*j-1,2*k)] + vnew_f[IND_f(2*i-1,2*j-1,2*k-1)] + vnew_f[IND_f(2*i-1,2*j,2*k-1)] + vnew_f[IND_f(2*i-1+1,2*j,2*k)] + vnew_f[IND_f(2*i-1+1,2*j-1,2*k)] + vnew_f[IND_f(2*i-1+1,2*j-1,2*k-1)] + vnew_f[IND_f(2*i-1+1,2*j,2*k-1)])/vnew_stgx[IMJK];

				}
				
				if(i>0 && k>0)
				{
					rhofc[IJK] = rhof2*(vnew_f[IND_f(2*i,2*j,2*k)] + vnew_f[IND_f(2*i-1,2*j,2*k)] + vnew_f[IND_f(2*i-1,2*j,2*k-1)] + vnew_f[IND_f(2*i,2*j,2*k-1)] + vnew_f[IND_f(2*i,2*j+1,2*k)] + vnew_f[IND_f(2*i-1,2*j+1,2*k)] + vnew_f[IND_f(2*i-1,2*j+1,2*k-1)] + vnew_f[IND_f(2*i,2*j+1,2*k-1)])/vnew_stgy[IJK];
					rhofc[IJMK]= rhof2*(vnew_f[IND_f(2*i,2*j-1,2*k)] + vnew_f[IND_f(2*i-1,2*j-1,2*k)] + vnew_f[IND_f(2*i-1,2*j-1,2*k-1)] + vnew_f[IND_f(2*i,2*j-1,2*k-1)] + vnew_f[IND_f(2*i,2*j+1-1,2*k)] + vnew_f[IND_f(2*i-1,2*j+1-1,2*k)] + vnew_f[IND_f(2*i-1,2*j+1-1,2*k-1)] + vnew_f[IND_f(2*i,2*j+1-1,2*k-1)])/vnew_stgy[IJMK];				

				}
			}
		}
		
		stop:
		printf("Density was Changed: proc = %d\n",mpi.MyRank);
		return;
		
		no_change:
		return;
}
