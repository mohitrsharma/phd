#include "ripple.h"
#include "testing.h"

/******************************************************************************
This subroutine is used to measure the loss of spherity of spherical droplet
after a translation.  The ouput file sphere0000 is created.

Subroutine SPHERICITY is called by:	RIPPLE

Subroutine SPHERICITY calls:	SETF1, RESIDUAL			

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION                                         NAME        DATE

-Made this function work correctly in MPI mode. Now Ben         Sept 23 2005
 process 0 gets correct global maximum and minimum
 values for f_xmin,f_xmax etc.. Thus, only process 0
 writes to file spherity.
-Created this template for tracking changes         Ben         April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/
//determines the sphericity of a droplet given center(x,y,z) and radius

void sphericity(double x_cent, double y_cent, double z_cent)
{
	int i,j,k;
	double f_xmin, f_ymin, f_zmin, f1_xmin, f1_ymin, f1_zmin;
	double f_xmax, f_ymax, f_zmax, f1_xmax, f1_ymax, f1_zmax;
	double f_xcent, f_ycent, f_zcent, f1_xcent, f1_ycent, f1_zcent;
	double f_xdiam, f_ydiam, f_zdiam, f1_xdiam, f1_ydiam, f1_zdiam;
	double temp;
	
	f_xmin = f_ymin = f_zmin = f1_xmin = f1_ymin = f1_zmin = 1000.00;
	f_xmax = f_ymax = f_zmax = f1_xmax = f1_ymax = f1_zmax = 0.00;
	
	setf1( x_cent, y_cent, z_cent );
//x sweep 
	for (i=1; i<im1; i++)
		for(j=1; j<jm1; j++)
			for(k=1; k<km1; k++)
			{
				if ( f[IJK] >= em6 && ( xi[i] < f_xmin)  )
				{
					f_xmin = x[i-1];
				}
				
				if ( f[IJK] >= em6 && ( xi[i] > f_xmax ) )
				{
					f_xmax = x[i];
				}
				
				if ( f1[IJK] >= em6 && ( xi[i] < f1_xmin) )
				{
					f1_xmin = x[i-1];
				}
				
				if ( f1[IJK] >= em6 && ( xi[i] > f1_xmax ) )
				{
					f1_xmax = x[i];
				}
			}
 //y sweep
	for (j=1; j < jm1; j++)
		for (i=1; i < im1; i++)
			for (k=1; k < km1; k++)
			{
				if ( f[IJK] >= em6 && (yj[j] < f_ymin) )
				{
					f_ymin = y[j-1];
				}
				
				if ( f[IJK] >= em6 && ( yj[j] > f_ymax) )
				{
					f_ymax = y[j];
				}
				
				if ( f1[IJK] >= em6 && (yj[j] < f1_ymin) )
				{
					f1_ymin = y[j-1];
				}
				
				if ( f1[IJK] >= em6  && (yj[j] > f1_ymax) )
				{
					f1_ymax = y[j];
				}
			}
//z sweep
	for (k=1; k < km1; k++)
		for(i = 1; i < im1; i++)
			for(j=1; j < jm1; j++)
			{
				if ( f[IJK] >= em6 && (zk[k] < f_zmin) )
				{
					f_zmin = z[k-1];
				}
				
				if ( f[IJK] >= em6 && (zk[k] > f_zmax) )
				{
					f_zmax = z[k];
				}
				
				if ( f1[IJK] >= em6 && (zk[k] < f1_zmin) )
				{
					f1_zmin = z[k-1];
				}
				
				if ( f1[IJK] >= em6 && (zk[k] > f1_zmax) )
				{
					f1_zmax = z[k];
				}
			}
	//reduce f_=================================================================
	//get minimum and maximum values globaly for f_xmin,f_xmax,f_ymin etc.
	
	dreduce(&f_xmin,&temp,1,OP_MIN);
	//now temp variable on proces 0 is set to minimum global f_xmin
	if(mpi.MyRank == 0)
		f_xmin = temp;
	
	dreduce(&f_ymin,&temp,1,OP_MIN);
	//now temp variable on proces 0 is set to minimum global f_ymin
	if(mpi.MyRank == 0)
		f_ymin = temp;
	
	dreduce(&f_zmin,&temp,1,OP_MIN);
	//now temp variable on proces 0 is set to minimum global f_zmin
	if(mpi.MyRank == 0)
		f_zmin = temp;
	
	dreduce(&f_xmax,&temp,1,OP_MAX);
	//now temp variable on proces 0 is set to maximum global f_xmax
	if(mpi.MyRank == 0)
		f_xmax = temp;
	
	dreduce(&f_ymax,&temp,1,OP_MAX);
	//now temp variable on proces 0 is set to maximum global f_ymax
	if(mpi.MyRank == 0)
		f_ymax = temp;
	
	dreduce(&f_zmax,&temp,1,OP_MAX);
	//now temp variable on proces 0 is set to maximum global f_zmax
	if(mpi.MyRank == 0)
		f_zmax = temp;
	
	//reduce f1_================================================================
	//get minimum and maximum values globaly for f1_xmin,f_xmax,f1_ymin etc.
	
	dreduce(&f1_xmin,&temp,1,OP_MIN);
	//now temp variable on proces 0 is set to minimum global f_xmin
	if(mpi.MyRank == 0)
		f1_xmin = temp;
	
	dreduce(&f1_ymin,&temp,1,OP_MIN);
	//now temp variable on proces 0 is set to minimum global f_ymin
	if(mpi.MyRank == 0)
		f1_ymin = temp;
	
	dreduce(&f1_zmin,&temp,1,OP_MIN);
	//now temp variable on proces 0 is set to minimum global f_zmin
	if(mpi.MyRank == 0)
		f1_zmin = temp;
	
	dreduce(&f1_xmax,&temp,1,OP_MAX);
	//now temp variable on proces 0 is set to maximum global f_xmax
	if(mpi.MyRank == 0)
		f1_xmax = temp;
	
	dreduce(&f1_ymax,&temp,1,OP_MAX);
	//now temp variable on proces 0 is set to maximum global f_ymax
	if(mpi.MyRank == 0)
		f1_ymax = temp;
	
	dreduce(&f1_zmax,&temp,1,OP_MAX);
	//now temp variable on proces 0 is set to maximum global f_zmax
	if(mpi.MyRank == 0)
		f1_zmax = temp;
	
	//since now only process 0 has correct global max and min values
	//process 0 has to do the following	
	if (mpi.MyRank == 0)
	{
		f_xdiam = f_xmax - f_xmin;
		f_ydiam = f_ymax - f_ymin;
		f_zdiam = f_zmax - f_zmin;
	
		f1_xdiam = f1_xmax - f1_xmin;
		f1_ydiam = f1_ymax - f1_ymin;
		f1_zdiam = f1_zmax - f1_zmin;

		f_xcent = f_xmin + f_xdiam / 2;
		f_ycent = f_ymin + f_ydiam / 2;
		f_zcent = f_zmin + f_zdiam / 2;
	
		f1_xcent = f1_xmin + f1_xdiam / 2;
		f1_ycent = f1_ymin + f1_ydiam / 2;
		f1_zcent = f1_zmin + f1_zdiam / 2;
	
		fprintf(files.sphere, "\n");
		fprintf(files.sphere, "	EXPECTED VALUES							CALCULATED VALUES\n");
		fprintf(files.sphere, "	f1_xcent = %12.4e					f_xcent = %12.4e\n", f1_xcent, f_xcent );
		fprintf(files.sphere, "	f1_ycent = %12.4e					f_ycent = %12.4e\n", f1_ycent, f_ycent );
		fprintf(files.sphere, "	f1_zcent = %12.4e					f_zcent = %12.4e\n", f1_zcent, f_zcent );
		fprintf(files.sphere, "	\n");
		fprintf(files.sphere, "	f1_xmin = %12.4e					f_xmin = %12.4e\n", f1_xmin, f_xmin );
		fprintf(files.sphere, "	f1_ymin = %12.4e					f_ymin = %12.4e\n", f1_ymin, f_ymin );
		fprintf(files.sphere, "	f1_zmin = %12.4e					f_zmin = %12.4e\n", f1_zmin, f_zmin );
		fprintf(files.sphere, "	\n");
		fprintf(files.sphere, "	f1_xmax = %12.4e					f_xmax = %12.4e\n", f1_xmax, f_xmax );
		fprintf(files.sphere, "	f1_ymax = %12.4e					f_ymax = %12.4e\n", f1_ymax, f_ymax );
		fprintf(files.sphere, "	f1_zmax = %12.4e					f_zmax = %12.4e\n", f1_zmax, f_zmax );
		fprintf(files.sphere, "	\n");
		fprintf(files.sphere, "	f1_xdiam = %12.4e					f_xdiam = %12.4e\n", f1_xdiam, f_xdiam );
		fprintf(files.sphere, "	f1_ydiam = %12.4e					f_ydiam = %12.4e\n", f1_ydiam, f_ydiam );
		fprintf(files.sphere, "	f1_zdiam = %12.4e					f_zdiam = %12.4e\n", f1_zdiam, f_zdiam );
	}
	//every process needs to make this call
	residual();
	
}
