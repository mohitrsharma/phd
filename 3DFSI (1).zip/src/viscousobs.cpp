#include "ripple.h"
#include "comm.h"
#include "testing.h"

/******************************************************************************
This subroutine VISCOUSOBS sets the tau's in te obstacle cell sfc. cells according to
the no slip BC on the obstacle boundary

Subroutine VISCOUSOBS is called by:	VISCOUS

Subroutine VISCOUSOBS calls:	ISOBSTSFC

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Fixed how tauxy, tauxz and tauyz are found for     Ben         May 31 2006
 obstacles on the right, front and over cells.
 This correction is based on my debugging 2PHASE
 code.
-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

void viscousobs(double *tauxy, double *tauxz, double *tauyz)
{
	int i,j,k;

	for (k = 1; k < km1; k++)
		for (j = 1; j < jm1; j++)
			for (i = 1; i < im1; i++){
                if (isobstsfc(IJK)){     /*if cell IJK is the obstacle surface cell*/

                    if (obst[IJK].flag_r){      /*if obstacle cell is on the RIGHT of fluid*/

						tauxy[IJK] = v[IJMK]*rdx[i];
						tauxz[IJK] = w[IJKM]*rdx[i];
					}
                    if (obst[IJK].flag_l){      /*if obstacle cell is on the LEFT of fluid*/

						tauxy[IPJK] = v[IPJMK]*rdx[i+1];
						tauxz[IPJK] = w[IPJKM]*rdx[i+1];
					}
                    if (obst[IJK].flag_f){      /*if obstacle cell is in of the FRONT of fluid*/

						tauxy[IJK] = u[IMJK]*rdy[j];
						tauyz[IJK] = w[IJKM]*rdy[j];
					}
                    if (obst[IJK].flag_b){      /*if obstacle cell is on the BACK of fluid*/

						tauxy[IJPK] = u[IMJPK]*rdy[j+1];
						tauyz[IJPK] = w[IJPKM]*rdy[j+1];
					}
                    if (obst[IJK].flag_o){      /*if obstacle cell is OVER the fluid*/

						tauxz[IJK] = u[IMJK]*rdz[k];
						tauyz[IJK] = v[IJMK]*rdz[k];
					}
                    if (obst[IJK].flag_u){      /*if obstacle cell is UNDER the fluid*/

						tauxz[IND(i,j,k+1)]=u[IND(i-1,j,k+1)]*rdz[k+1];
						tauyz[IND(i,j,k+1)]=v[IND(i,j-1,k+1)]*rdz[k+1];
					}
				}
			}
	
	//obstacles in the ghost cells
	//Right and left side
    for (k=1;k<km1;k++)
		for (j=1;j<jm1;j++)	
		{
			i=im1;
			if (ac[IJK] == 0 && ac[IJK - 1] == 1) //if (obst[ijkr].flag_r)
            		{     				
						tauxy[IJK] = v[IJMK]*rdx[i];
						tauxz[IJK] = w[IJKM]*rdx[i];
            		}
            i=0;		
            if (ac[IJK] == 0 && ac[IJK + 1] == 1) //if (obst[ijkr].flag_l)
            		{     				
                    	tauxy[IPJK] = v[IPJMK]*rdx[i+1];
						tauxz[IPJK] = w[IPJKM]*rdx[i+1];
            		}
		}	
	//Front and back Side
    for (k=1;k<km1;k++)
     for (i=1;i<im1;i++)		
		{              
			j=jm1;
			if (ac[IJK] == 0 && ac[IJK - imax] == 1) //if (obst[ijkf].flag_f)
			{
                	    tauxy[IJK] = u[IMJK]*rdy[j];
						tauyz[IJK] = w[IJKM]*rdy[j];
			}
			j=0;
			if (ac[IJK] == 0 && ac[IJK + imax] == 1) {
						tauxy[IJPK] = u[IMJPK]*rdy[j+1];
						tauyz[IJPK] = w[IJPKM]*rdy[j+1];
			}
			
		}	
	//Over and under Side
	for (j=1;j<jm1;j++)
		for (i=1;i<im1;i++)	
		{		
			k=km1;
			if (ac[IJK] == 0 && ac[IJK - ijmax] == 1) //if (obst[ijko].flag_o)			
			{
				tauxz[IJK] = u[IMJK]*rdz[k];
				tauyz[IJK] = v[IJMK]*rdz[k];
			}
				
			k=0;
			if (ac[IJK] == 0 && ac[IJK + ijmax] == 1) //if (obst[ijko].flag_u)			
			{
				tauxz[IND(i,j,k+1)]=u[IND(i-1,j,k+1)]*rdz[k+1];
			    tauyz[IND(i,j,k+1)]=v[IND(i,j-1,k+1)]*rdz[k+1];
			}
		}
	
}
