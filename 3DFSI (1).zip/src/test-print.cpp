#include "ripple.h"
#include "testing.h"
#include <math.h>

/******************************************************************************


Subroutine TEST_PRINT is called by:	(can be called in any subroutine)

Subroutine TEST_PRINT calls:		

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

void test_print(void)
{
		int i,j,k;

		i= 4;
		fprintf(files.out, "***U***\n");
		for(k = km1; k > -1 ; k--)
		{
			for (j = 0; j < jmax ; j++)			
				fprintf(files.out, "%12.4e",u[IJK]);
			fprintf(files.out, "\n");	
		}

		fprintf(files.out, "\n***V***\n");
		for(k = km1; k > -1 ; k--)
		{
			for (j = 0; j < jmax ; j++)			
				fprintf(files.out, "%12.4e",v[IJK]);
			fprintf(files.out, "\n");	
		}

		fprintf(files.out, "\n***W***\n");
		for(k = km1; k > -1 ; k--)
		{
			for (j = 0; j < jmax ; j++)			
				fprintf(files.out, "%12.4e",w[IJK]);
			fprintf(files.out, "\n");	
		}				

		fprintf(files.out, "\n***P***\n");
		for(k = km1; k > -1 ; k--)
		{
			for (j = 0; j < jmax ; j++)			
				fprintf(files.out, "%12.4e",p[IJK]);
			fprintf(files.out, "\n");	
		}

		fprintf(files.out, "\n***AC***\n");
		for(k = km1; k > -1 ; k--)
		{
			for (j = 0; j < jmax ; j++)			
				fprintf(files.out, "%12.4e",ac[IJK]);
			fprintf(files.out, "\n");	
		}

		fprintf(files.out, "\n***F***\n");
		for(k = km1; k > -1 ; k--)
		{
			for (j = 0; j < jmax ; j++)			
				fprintf(files.out, "%12.4e",f[IJK]);
			fprintf(files.out, "\n");	
		}
//		fclose(files.out);

}
