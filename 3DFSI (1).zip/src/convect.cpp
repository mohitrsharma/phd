#include "ripple.h"
#include <string.h>
#include "testing.h"
/******************************************************************************

Finite volume approximations of convection terms of N-S eqs.


Subroutine CONVECT is called by:	RIPPLE

Subroutine CONVECT calls:	VELGRAD, BC

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/


void convect()
{
	double *rgux=temp[0], *rguy=temp[1], *rguz=temp[2];
	double *rgvx=temp[3], *rgvy=temp[4], *rgvz=temp[5];
	double *rgwx=temp[6], *rgwy=temp[7], *rgwz=temp[8];
	double *ufc =temp[9], *ufy=temp[10], *ufz=temp[11];
	double *vfx=temp[12], *vfc=temp[13], *vfz=temp[14];
	double *wfx=temp[15], *wfy=temp[16], *wfc=temp[17];
	double *util=temp[18],*vtil=temp[19],*wtil=temp[20];
	static double sd[12]={0,0,0,0,0,0,0,0,0,0,0,0};
	int looper[6][6]={{3,2,1,1,2,3},{3,1,2,2,1,3},{2,3,1,1,3,2},{2,1,3,3,1,2},{1,3,2,2,3,1},{1,2,3,3,2,1}};

	int i,j,k;
	double dtadv = delt*0.5;
	int isweep = ncyc%6;

	//initialize tilde-velocities (util/vtil/wtil)
	memcpy (util, u, NX*NY*NZ*sizeof(double));
	memcpy (vtil, v, NX*NY*NZ*sizeof(double));
	memcpy (wtil, w, NX*NY*NZ*sizeof(double));

	for(i = 1; i < imax; i++)
		for(j = 1; j < jmax; j++)
			for(k = 1; k < kmax; k++)
			{
				ufc[IJK]=0.5*(u[IMJK]+u[IJK]);
				ufy[IJK]=0.5*(dely[j]*u[IMJMK]+dely[j-1]*u[IMJK])*rdelyb[j];
				ufz[IJK]=0.5*(delz[k]*u[IMJKM]+delz[k-1]*u[IMJK])*rdelzu[k];

				vfc[IJK]=0.5*(v[IJMK]+v[IJK]);
				vfx[IJK]=0.5*(delx[i]*v[IMJMK]+delx[i-1]*v[IJMK])*rdelxl[i];
				vfz[IJK]=0.5*(delz[k]*v[IJMKM]+delz[k-1]*v[IJMK])*rdelzu[k];

				wfc[IJK]=0.5*(w[IJKM]+w[IJK]);
				wfx[IJK]=0.5*(delx[i]*w[IMJKM]+delx[i-1]*w[IJKM])*rdelxl[i];
				wfy[IJK]=0.5*(dely[j]*w[IJMKM]+dely[j-1]*w[IJKM])*rdelyb[j];
			}

	//identify surface cells.
	for(i = 0; i < im1; i++)
		for(j=0; j < jm1; j++)
			for(k=0; k < km1; k++)
			{
				double srfijk=(1.0-f[IJK])*f[IJK];
				double srfipjk=(1.0-f[IPJK])*f[IPJK];
				double srfijpk=(1.0-f[IJPK])*f[IJPK];
				double srfijkp=(1.0-f[IJKP])*f[IJKP];
				ijkfr[IJK]=0;
				if (srfijk+srfipjk > 1E-12) ijkfr[IJK] |= 4;
				if (srfijk+srfijpk > 1E-12) ijkfr[IJK] |= 2;
				if (srfijk+srfijkp > 1E-12) ijkfr[IJK] |= 1;
			}

	velgrad();
	int nsubcyc=0;

	for (nsubcyc=0;nsubcyc<6;nsubcyc++)
	{

		switch (looper[isweep][nsubcyc])
		{
			case 1:	//x sweep
				for (i=1;i<im1;i++)
				for (j=1;j<jm1;j++)
				for (k=1;k<km1;k++)
				{
					double volrf=delxl[i+1]*dely[j]*delz[k]+tiny;
					double voltf=delx[i]*delyb[j+1]*delz[k]+tiny;
					double volof=delx[i]*dely[j]*delzu[k+1]+tiny;

					//x-momentum
					if(ar[IJK] >= em6)
					{
						double ul,ur;
						if (ufc[IJK] >= 0.0)
							ul=util[IMJK]+0.5*delx[i]*rgux[IMJK]*(1.0-ufc[IJK]*dtadv*rdx[i]);
						else
							ul=util[IJK]-0.5*delx[i]*rgux[IJK]*(1.0+ufc[IJK]*dtadv*rdx[i]);
						if (ufc[IPJK] >= 0.0)
							ur=util[IJK]+0.5*delx[i+1]*rgux[IJK]*(1.0-ufc[IPJK]*dtadv*rdx[i+1]);
						else
							ur=util[IPJK]-0.5*delx[i+1]*rgux[IPJK]*(1.0+ufc[IPJK]*dtadv*rdx[i+1]);
						double fux=(ufc[IJK]*ul-ufc[IPJK]*ur)*dely[j]*delz[k];
						u[IJK] += dtadv*fux/volrf;
						sd[0] += dtadv*fux/volrf;
					}
					else
						u[IJK] = 0.0;

					//y-momentum
					if(af[IJK] >= em6)
					{
						double vl,vr;
						if (ufy[IJPK] >= 0.0)
							vl=vtil[IMJK]+0.5*delxl[i]*rgvx[IMJK]*(1.0-ufy[IJPK]*dtadv*rdelxl[i]);
						else
							vl=vtil[IJK]-0.5*delxl[i]*rgvx[IJK]*(1.0+ufy[IJPK]*dtadv*rdelxl[i]);
						if (ufy[IPJPK] >= 0.0)
							vr=vtil[IJK]+0.5*delxl[i+1]*rgvx[IJK]*(1.0-ufy[IPJPK]*dtadv*rdelxl[i+1]);
						else
							vr=vtil[IPJK]-0.5*delxl[i+1]*rgvx[IPJK]*(1.0+ufy[IPJPK]*dtadv*rdelxl[i+1]);
						double fvx=(ufy[IJPK]*vl-ufy[IPJPK]*vr)*delyb[j+1]*delz[k];
						v[IJK] += dtadv*fvx/voltf;
						sd[1] += dtadv*fvx/voltf;
					}
					else
						v[IJK]=0.0;

					//z-momentum
					if(ao[IJK] >= em6)
					{
						double wl,wr;
						if (ufz[IJKP] >= 0.0)
							wl=wtil[IMJK]+0.5*delxl[i]*rgwx[IMJK]*(1.0-ufz[IJKP]*dtadv*rdelxl[i]);
						else
							wl=wtil[IJK]-0.5*delxl[i]*rgwx[IJK]*(1.0+ufz[IJKP]*dtadv*rdelxl[i]);
						if (ufz[IPJKP] >= 0.0)
							wr=wtil[IJK]+0.5*delxl[i+1]*rgwx[IJK]*(1.0-ufz[IPJKP]*dtadv*rdelxl[i+1]);
						else
							wr=wtil[IPJK]-0.5*delxl[i+1]*rgwx[IPJK]*(1.0+ufz[IPJKP]*dtadv*rdelxl[i+1]);
						double fwx=(ufz[IJKP]*wl-ufz[IPJKP]*wr)*dely[j]*delzu[k+1];
						w[IJK] += dtadv*fwx/volof;
						sd[2] += dtadv*fwx/volof;
					}
					else
						w[IJK] = 0.0;
				}
				break;

			case 2: //y sweep
				for (i=1;i<im1;i++)
				for (j=1;j<jm1;j++)
				for (k=1;k<km1;k++)
				{
					double volrf=ar[IJK]*delxl[i+1]*dely[j]*delz[k]+tiny;
					double voltf=af[IJK]*delx[i]*delyb[j+1]*delz[k]+tiny;
					double volof=ao[IJK]*delx[i]*dely[j]*delzu[k+1]+tiny;

					//x-momentum
					if(ar[IJK] >= em6)
					{
						double ub,ut;
						if (vfx[IPJK] >= 0.0)
							ub=util[IJMK]+0.5*delyb[j]*rguy[IJMK]*(1.0-vfx[IPJK]*dtadv*rdelyb[j]);
						else
							ub=util[IJK]-0.5*delyb[j]*rguy[IJK]*(1.0+vfx[IPJK]*dtadv*rdelyb[j]);
						if (vfx[IPJPK] >= 0.0)
							ut=util[IJK]+0.5*delyb[j+1]*rguy[IJK]*(1.0-vfx[IPJPK]*dtadv*rdelyb[j+1]);
						else
							ut=util[IJPK]-0.5*delyb[j+1]*rguy[IJPK]*(1.0+vfx[IPJPK]*dtadv*rdelyb[j+1]);
						double fuy=(vfx[IPJK]*ub-vfx[IPJPK]*ut)*delxl[i+1]*delz[k];
						u[IJK] += dtadv*fuy/volrf;
						sd[3] += dtadv*fuy/volrf;
					}
					else
						u[IJK] = 0.0;

					//y-momentum
					if(af[IJK] >= em6)
					{
						double vb,vt;
						if (vfc[IJK] >= 0.0)
							vb=vtil[IJMK]+0.5*dely[j]*rgvy[IJMK]*(1.0-vfc[IJK]*dtadv*rdy[j]);
						else
							vb=vtil[IJK]-0.5*dely[j]*rgvy[IJK]*(1.0+vfc[IJK]*dtadv*rdy[j]);
						if (vfc[IJPK] >= 0.0)
							vt=vtil[IJK]+0.5*dely[j+1]*rgvy[IJK]*(1.0-vfc[IJPK]*dtadv*rdy[j+1]);
						else
							vt=vtil[IJPK]-0.5*dely[j+1]*rgvy[IJPK]*(1.0+vfc[IJPK]*dtadv*rdy[j+1]);
						double fvy=(vfc[IJK]*vb-vfc[IJPK]*vt)*delx[i]*delz[k];
						v[IJK] += dtadv*fvy/voltf;
						sd[4] += dtadv*fvy/voltf;
					}
					else
						v[IJK]=0.0;

					//z-momentum
					if(ao[IJK] >= em6)
					{
						double wb,wt;
						if (vfz[IJKP] >= 0.0)
							wb=wtil[IJMK]+0.5*delyb[j]*rgwy[IJMK]*(1.0-vfz[IJKP]*dtadv*rdelyb[j]);
						else
							wb=wtil[IJK]-0.5*delyb[j]*rgwy[IJK]*(1.0+vfz[IJKP]*dtadv*rdelyb[j]);
						if (vfz[IJPKP] >= 0.0)
							wt=wtil[IJK]+0.5*delyb[j+1]*rgwy[IJK]*(1.0-vfz[IJPKP]*dtadv*rdelyb[j+1]);
						else
							wt=wtil[IJPK]-0.5*delyb[j+1]*rgwy[IJPK]*(1.0+vfz[IJPKP]*dtadv*rdelyb[j+1]);
						double fwy=(vfz[IJKP]*wb-vfz[IJPKP]*wt)*delx[i]*delzu[k+1];
						w[IJK] += dtadv*fwy/volof;
						sd[5] += dtadv*fwy/volof;
					}
					else
						w[IJK] = 0.0;
				}
				break;
			case 3: //z sweep
				for (i=1;i<im1;i++)
				for (j=1;j<jm1;j++)
				for (k=1;k<km1;k++)
				{
					double volrf=ar[IJK]*delxl[i+1]*dely[j]*delz[k]+tiny;
					double voltf=af[IJK]*delx[i]*delyb[j+1]*delz[k]+tiny;
					double volof=ao[IJK]*delx[i]*dely[j]*delzu[k+1]+tiny;

					//x-momentum
					if(ar[IJK] >= em6)
					{
						double uu,uo;
						if (wfx[IPJK] >= 0.0)
							uu=util[IJKM]+0.5*delzu[k]*rguz[IJKM]*(1.0-wfx[IPJK]*dtadv*rdelzu[k]);
						else
							uu=util[IJK]-0.5*delzu[k]*rguz[IJK]*(1.0+wfx[IPJK]*dtadv*rdelzu[k]);
						if (wfx[IPJKP] >= 0.0)
							uo=util[IJK]+0.5*delzu[k+1]*rguz[IJK]*(1.0-wfx[IPJKP]*dtadv*rdelzu[k+1]);
						else
							uo=util[IJKP]-0.5*delzu[k+1]*rguz[IJKP]*(1.0+wfx[IPJKP]*dtadv*rdelzu[k+1]);
						double fuz=(wfx[IPJK]*uu-wfx[IPJKP]*uo)*delxl[i+1]*dely[j];
						u[IJK] += dtadv*fuz/volrf;
						sd[6] += dtadv*fuz/volrf;
					}
					else
						u[IJK] = 0.0;

					//y-momentum
					if(af[IJK] >= em6)
					{
						double vu,vo;
						if (wfy[IJPK] >= 0.0)
							vu=vtil[IJKM]+0.5*delzu[k]*rgvz[IJKM]*(1.0-wfy[IJPK]*dtadv*rdelzu[k]);
						else
							vu=vtil[IJK]-0.5*delzu[k]*rgvz[IJK]*(1.0+wfy[IJPK]*dtadv*rdelzu[k]);
						if (wfy[IJPKP] >= 0.0)
							vo=vtil[IJK]+0.5*delzu[k+1]*rgvz[IJK]*(1.0-wfy[IJPKP]*dtadv*rdelzu[k+1]);
						else
							vo=vtil[IJKP]-0.5*delzu[k+1]*rgvz[IJKP]*(1.0+wfy[IJPKP]*dtadv*rdelzu[k+1]);
						double fvz=(wfy[IJPK]*vu-wfy[IJPKP]*vo)*delx[i]*delyb[j+1];
						v[IJK] += dtadv*fvz/voltf;
						sd[7] += dtadv*fvz/voltf;
					}
					else
						v[IJK]=0.0;

					//z-momentum
					if(ao[IJK] >= em6)
					{
						double wu,wo;
						if (wfc[IJK] >= 0.0)
							wu=wtil[IJKM]+0.5*delz[k]*rgwz[IJKM]*(1.0-wfc[IJK]*dtadv*rdz[k]);
						else
							wu=wtil[IJK]-0.5*delz[k]*rgwz[IJK]*(1.0+wfc[IJK]*dtadv*rdz[k]);
						if (wfc[IJKP] >= 0.0)
							wo=wtil[IJK]+0.5*delz[k+1]*rgwz[IJK]*(1.0-wfc[IJKP]*dtadv*rdz[k+1]);
						else
							wo=wtil[IJKP]-0.5*delz[k+1]*rgwz[IJKP]*(1.0+wfc[IJKP]*dtadv*rdz[k+1]);
						double fwz=(wfc[IJK]*wu - wfc[IJKP]*wo)*delx[i]*dely[j];
						w[IJK] += dtadv*fwz/volof;
						sd[8] += dtadv*fwz/volof;
					}
					else
						w[IJK] = 0.0;
				}
				break;

		} //switch (looper)
		if (nsubcyc==2)/*update after half time step*/
		{
			bc();
			memcpy (util, u, NX*NY*NZ*sizeof(double));
			memcpy (vtil, v, NX*NY*NZ*sizeof(double));
			memcpy (wtil, w, NX*NY*NZ*sizeof(double));
			velgrad();
		}
	}
	//Upwind scheme for surface cells not necessary for 2 fluid code.

	//update the boundary conditions
	bc();
}

#undef SIGN

