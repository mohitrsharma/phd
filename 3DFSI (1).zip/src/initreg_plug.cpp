#include "ripple.h"
#include <stdlib.h>	 //rand
#include <string.h>
/******************************************************************************
This subroutine sets the initial velocity field into u, v, and w arrays given
an F field

Subroutine INITREG is called by:	SETUP	

Subroutine INITREG calls:			

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

void initreg_plug()
{
	// Set initial velocity field into u, v, and w arrays, given a scal field.
	// Since we only want the plug and the air to have a fully develoepd velocity profile
	// Although the film might have a velocity profile as well, lets not set its velocity atm
	
	int i,j,k;
	
	double w_avg = wf1 / 2;
	
	double tx, ty, txm, tym;
	double r2 = parent_radius*parent_radius;
	
	for (i=1;i<im1;i++)
		for (j=1;j<jm1;j++)
			for (k=1;k<km1;k++)
			{
				u[IJK]=uf2;
				if ( (ar[IJK] > em6) &&  
					((f[IJK] > emf) || (f[IPJK] > emf)))
					u[IJK] = uf1;
				v[IJK]=vf2;
				if ( (af[IJK] > em6) &&
					((f[IJK] > emf) || (f[IJPK] > emf)))
					v[IJK]=vf1;
				w[IJK]=wf2;
				
//				if ( ((f[IJK] > emf) || (f[IJKP] > emf)) && z[k] >= 20.5e-3 && z[k] <= 25.2e-3)
				if (z[k] >= 20.5e-3 && z[k] <= 29.6e-3)
				{
					tx = (i+mpi.OProc[0])*delx[1]; //global coordinates in coarse-grid
					ty = (j+mpi.OProc[1])*dely[1];
				
					txm = tx-delx[1];
					tym = ty-dely[1];
					
					if ( MAX(SQUARE(txm-xcent), SQUARE(tx-xcent)) + MAX(SQUARE(tym-ycent), SQUARE(ty-ycent)) <= r2)
					{
						w[IJK] = 2*w_avg*(1 - ( MAX(SQUARE(txm-xcent), SQUARE(tx-xcent)) + MAX(SQUARE(tym-ycent), SQUARE(ty-ycent))) / r2 );
					}
			//		if ( MIN(SQUARE(txm-xcent), SQUARE(tx-xcent)) + MIN(SQUARE(tym-ycent), SQUARE(ty-ycent)) >= r2)
			//		w[IJK] = 0;
			//
			//		else if ( MAX(SQUARE(txm-xcent), SQUARE(tx-xcent)) + MAX(SQUARE(tym-ycent), SQUARE(ty-ycent)) <= r2)
			//		w[IJK] = 2*w_avg*(1 - ( MAX(SQUARE(txm), SQUARE(tx)) + MAX(SQUARE(tym), SQUARE(ty))) / r2);
			//		
				}

#ifdef rudman_fine
#ifdef __solid	
				 //make following more sophisticated for initial solid 
				 //velocities-Omegas-multiple-bodies
				if ( (ar[IJK] > em6) &&  
					((psi[IJK] > emf) || (psi[IPJK] > emf)))
					u[IJK]=0.0;
				if ( (af[IJK] > em6) &&
					((psi[IJK] > emf) || (psi[IJPK] > emf)))
					v[IJK]=0.0;
				if ((ao[IJK] > em6) && 
					((psi[IJK] > emf) || (psi[IJKP] > emf)))
					w[IJK]=0.0;
#endif
#endif
				
				un[IJK]=u[IJK];
				vn[IJK]=v[IJK];
				wn[IJK]=w[IJK];
			}
	for(i=1;i<=NBODY;i++) {
		//initialize rigid-body-velocities
		memset(rig_U[i],0,4*sizeof(double));
		Omega[i].x=Omega[i].y=Omega[i].z=0.0;
	}
}

void Nfine2stnd(double *crse, double *fine);

void initreg_plug2()
{
	int i,j,k, m;
	double tx, ty, tz, txm, tym, tzm; //temporary x,y,z of ijk
	double xcent, ycent, zcent;

	double *fmz = temp[17];
#ifdef __solid
	double *psimx = temp[21];
	double *psimy = temp[22];
	double *psimz = temp[23];
#endif
	
	double r2 = (parent_radius)*(parent_radius); // Cylinder Radius
	double rl = (parent_radius - film_thickness)*(parent_radius - film_thickness); // Radius of Film
	
	double w_avg = -0.024;
	
	xcent = x_carina;
	ycent = ye/2;
	zcent = z_upper_bound; // Upper Bound on Y_tube - z3 + h3
	
	Nfine2stnd(plug_c,plug_f);
	
	for (k=1;k<km1;k++)
		for (j=1;j<jm1;j++)
			for (i=1;i<im1;i++)
			{	
				tx = (i+mpi.OProc[0])*delx[1] - 0.5*delx[1]; //global coordinates in coarse-grid
				ty = (j+mpi.OProc[1])*dely[1] - 0.5*dely[1];
				tz = (k+mpi.OProc[2])*delz[1];
				
				if ( plug_c[IJK] > em6)
				{
					u[IJK] = 0.0;
					v[IJK] = 0.0;
					w[IJK] = 2*w_avg*(1 - ( SQUARE(tx-xcent) + SQUARE(ty-ycent) ) / r2 );
				}
			}
}
