#include "ripple.h"
#include <string.h> //memset
#include <math.h>//fabs for testing
#include "testing.h"
#include <stdio.h>//printf for debugging
#include <stdlib.h>//exit

//#define DEBUG
/******************************************************************************


Subroutine TENSION is called by:	RIPPLE

Subroutine TENSION calls:	MOLLIFYT, BC

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-I removed anything related to the bubble from		Ben			Oct 13 2005
 tension.cpp.  This version of tension will work 
 with jets and bubbles.
-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/
#ifdef balanced_force
void bc_tens();
#endif
#define CSF 0

void bc_zero_tension();
void ytube_exact_curvature(double *kap_x, double *kap_y, double *kap_z);

void tension()
{
#ifndef balanced_force
	double kappa;
	double *tensx=temp[0], *tensy=temp[1], *tensz=temp[2];
	double *txtilde=temp[3], *tytilde=temp[4], *tztilde=temp[5];
	int i,j,k;

	double totarea = 0.0;
					  
	memset (tensx, 0, NX*NY*NZ*sizeof(double));
	memset (tensy, 0, NX*NY*NZ*sizeof(double));
	memset (tensz, 0, NX*NY*NZ*sizeof(double));
	
	double max_face=0.e0; double min_face=100.e0*delx[1]*dely[1];
	
	for (i=1;i<im1;i++)
		for (j=1;j<jm1;j++)
			for (k=1;k<km1;k++)
			{
				double face, xd, yd, zd;
				if (f[IJK]>em61) continue;/*skip if full*/
        		if (f[IJK]<em6) continue;/*skip if empty*/
        		if (ac[IJK]<em6) continue;/*skip if obstacle*/
				{
					/*calculate interfacial area and midpoint, evaluate kappa.*/
					area (IJK, &face, &xd, &yd, &zd);
					totarea += face;
					if(face>max_face) max_face=face;
					if(face<min_face) min_face=face;
					/*curvature via normalized grad at cell centre*/
 					kappa=-(gradrox[IPJPKP]-gradrox[IJPKP]
						+gradrox[IPJPK]-gradrox[IJPK]
						+gradrox[IPJKP]-gradrox[IJKP]
						+gradrox[IPJK]-gradrox[IJK])/delx[i]/4.0
						-(gradroy[IPJPKP]-gradroy[IPJKP]
						+gradroy[IJPKP]-gradroy[IJKP]
						+gradroy[IPJPK]-gradroy[IPJK]
						+gradroy[IJPK]-gradroy[IJK])/dely[j]/4.0
						-(gradroz[IPJPKP]-gradroz[IPJPK]
						+gradroz[IPJKP]-gradroz[IPJK]
						+gradroz[IJPKP]-gradroz[IJPK]
						+gradroz[IJKP]-gradroz[IJK])/delz[k]/4.0;
//                     kappa= 2.0 / radius;
					/*evaluate tension forces*/
					double ralph=sqrt(avnx[IJK]*avnx[IJK] + avny[IJK]*avny[IJK] + avnz[IJK]*avnz[IJK]) + tiny;
					double tensin=sigma[IJK]*kappa*face/vol[IJK]/ralph;
					
				tensx[IJK]=(tensin)*avnx[IJK];
    				tensy[IJK]=(tensin)*avny[IJK];
    				tensz[IJK]=(tensin)*avnz[IJK];
    				//if(mpi.MyRank==0 && IJK==IND(37,1,1)) printf("in tension bot: tensin = %.9e avnx=%.9e\n",tensin,avnx[IJK]);
				//if(mpi.MyRank==0 && IJK==IND(37,64,1)) printf("in tension top: tensin = %.9e avnx=%.9e\n",tensin,avnx[IJK]);
				//if(mpi.MyRank==0 && IJK==IND(37,1,1)) printf("in tension bot: %.9e %.9e %.9e %.9e %.9e %.9e %.9e %.9e\n",gradrox[IPJK],gradrox[IPJPK],gradrox[IJPK],gradrox[IJK],gradrox[IPJKP],gradrox[IPJPKP],gradrox[IJPKP],gradrox[IJKP]);
    				//if(mpi.MyRank==0 && IJK==IND(37,64,1)) printf("in tension top: %.9e %.9e %.9e %.9e %.9e %.9e %.9e %.9e\n",gradrox[IPJPK],gradrox[IPJK],gradrox[IJK],gradrox[IJPK],gradrox[IPJPKP],gradrox[IPJKP],gradrox[IJKP],gradrox[IJPKP]);
                }
			}
			
	//printf("proc %d: max_face=%e min_face=%e\n",mpi.MyRank,max_face,min_face);
	/*smooth the force*/
	/*writes to txtilde, tytilde, tztilde*/
	mollifyt();	
	int umax_ijk, umin_ijk;	
	double u_max=0.e0; double u_min=1000.e0; 
	double v_max=0.e0; double v_min=1000.e0;
	double w_max=0.e0; double w_min=1000.e0;
	for(i=1;i<im1;i++)
		for(j=1;j<jm1;j++)
			for(k=1;k<km1;k++)
			{
				/*skip near open boundaries*/
				if (kl==4 && i==1) 	 continue;
				if (kr==4 && i==im2) continue;
				if (kb==4 && j==1)   continue;
				if (kf==4 && j==jm2) continue;
				if (ku==4 && k==1)   continue;										
				if (mpi.Neighbors[5] == -1 && ko==4 && k==km2) continue;
				
				double fxrc = (delx[i]*txtilde[IPJK] + delx[i+1]*txtilde[IJK])/(delx[i]+delx[i+1]);
				fxrc = 2.0*rhorc[IJK] * fxrc/ rhof1;
				
				double fyfc = (dely[j]*tytilde[IJPK] + dely[j+1]*tytilde[IJK])/(dely[j]+dely[j+1]);
				fyfc = 2.0*rhofc[IJK] * fyfc/ rhof1;

				double fzoc = (delz[k]*tztilde[IJKP] + delz[k+1]*tztilde[IJK])/(delz[k]+delz[k+1]);
				fzoc = 2.0*rhooc[IJK] * fzoc/ rhof1;

				/*apply surface tension force*/
				if (ar[IJK] >= em6)
					u[IJK] += delt*fxrc/rhorc[IJK];
				if ( (rhorc[IJK]<frctn*rho[IJK]) || (ar[IJK] < em6) )
					u[IJK] = 0.0;
				if(u[IJK]>u_max) {
					u_max=u[IJK];
					umax_ijk=IJK;
				}
				if(u[IJK]<u_min) {
					u_min=u[IJK];
					umin_ijk=IJK;
				}
				
				if (af[IJK] >= em6)
					v[IJK] += delt*fyfc/rhofc[IJK];
				if ( (rhofc[IJK]<frctn*rho[IJK]) || (af[IJK] < em6) )
					v[IJK] = 0.0;
				if(v[IJK]>v_max) v_max=v[IJK];
				if(v[IJK]<v_min) v_min=v[IJK];
				
				if (ao[IJK] >= em6)
					w[IJK] += delt*fzoc/rhooc[IJK];
				if ( (rhooc[IJK]<frctn*rho[IJK]) || (ao[IJK] < em6) )
					w[IJK] = 0.0;
				if(w[IJK]>w_max) w_max=w[IJK];
				if(w[IJK]<w_min) w_min=w[IJK];
			}
	//printf("proc%d:u_max=%e u_min=%e v_max=%e v_min=%e w_max=%e w_min=%e umax_ijk=%d umin_ijk=%d\n",mpi.MyRank,u_max,u_min,v_max,v_min,w_max,w_min,umax_ijk,umin_ijk);
	/*apply boundary conditions*/
	bc();
#endif

#ifdef balanced_force
	double dfdx, dfdy, dfdz;
	double *kappa = temp[0];
	double *tensx=temp[9], *tensy=temp[10], *tensz=temp[11];
	double better_curv_est(int i, int j, int k);
	memset (tensx, 0, NX*NY*NZ*sizeof(double));
	memset (tensy, 0, NX*NY*NZ*sizeof(double));
	memset (tensz, 0, NX*NY*NZ*sizeof(double));
	
	memset(kappa, 0 , NX*NY*NZ*sizeof(double));
	
	int i,j,k; double w1,w2,kap;
	for(k=1;k<km1;k++)
	 for(j=1;j<jm1;j++)
	   for(i=1;i<im1;i++) {
		   
		  kappa[IJK]=-(gradrox[IPJPKP]-gradrox[IJPKP]
			  +gradrox[IPJPK]-gradrox[IJPK]
			  +gradrox[IPJKP]-gradrox[IJKP]
			  +gradrox[IPJK]-gradrox[IJK])/delx[i]/4.0
			  -(gradroy[IPJPKP]-gradroy[IPJKP]
			  +gradroy[IJPKP]-gradroy[IJKP]
			  +gradroy[IPJPK]-gradroy[IPJK]
			  +gradroy[IJPK]-gradroy[IJK])/dely[j]/4.0
			  -(gradroz[IPJPKP]-gradroz[IPJPK]
			  +gradroz[IPJKP]-gradroz[IPJK]
			  +gradroz[IJPKP]-gradroz[IJPK]
			  +gradroz[IJKP]-gradroz[IJK])/delz[k]/4.0;

		   if(fabs(kappa[IJK]) > 4.0/delx[1]) kappa[IJK] = 0.0; //turn off surface tension for subcell curvatures.
		  //kappa[IJK] = 2.0 / radius;
	  }
	  
//	bc_zero_tension();
	
	xchg<double>(kappa); 

#ifdef __solid
	double *kappa1 = temp[2];
	memcpy(kappa1,kappa,NX*NY*NZ*sizeof(double));
	
	for(k=1;k<km1;k++)
	 for(j=1;j<jm1;j++)
	   for(i=1;i<im1;i++) {
		   //only in physical cells
		   if(psi[IJK] >= em6) kappa[IJK] = better_curv_est(i,j,k);
	   }
	xchg<double>(kappa);
	//memcpy(kappa1,kappa,NX*NY*NZ*sizeof(double));
#endif
	
double *ftemp;

#ifndef __solid
	ftemp = f;
#endif
#ifdef __solid
	void Nfine2stnd(double *crse, double *fine);
	double *fvirt_l = temp[1];
	Nfine2stnd(fvirt_l,fvirt_f); //restricts(averages) fvirt_f to fvirt
	ftemp = fvirt_l;
#endif

#ifdef Ytube
	// Cory Added this
	double *kap_x = (double*)memalloc (dim.nx, dim.ny, dim.nz, sizeof(double));
	double *kap_y = (double*)memalloc (dim.nx, dim.ny, 5, sizeof(double));
	double *kap_z = (double*)memalloc (dim.nx, dim.ny, 5, sizeof(double));
	
	ytube_exact_curvature(kap_x, kap_y, kap_z);
#endif

#if CSF	
	if(mpi.MyRank==0) printf("entered the CSF region\n");
	for(k=1;k<km1;k++)
	 for(j=1;j<jm1;j++)
	   for(i=1;i<im1;i++) {
		  dfdx = (ftemp[IPJK]-ftemp[IJK]) / delx[1];
		  w1 = 1.0-fabs(pow(2.0*ftemp[IJK]-1,3));
		  w2 = 1.0-fabs(pow(2.0*ftemp[IPJK]-1,3));
		  kap = (w1*kappa[IJK]+w2*kappa[IPJK])/(w1+w2+tiny);
		  tensx[IJK] = sigma[IJK]*kap*dfdx;

		  dfdy = (ftemp[IJPK]-ftemp[IJK]) / dely[1];
		  w1 = 1.0-fabs(pow(2.0*ftemp[IJK]-1,3));
		  w2 = 1.0-fabs(pow(2.0*ftemp[IJPK]-1,3));
		  kap = (w1*kappa[IJK]+w2*kappa[IJPK])/(w1+w2+tiny);
		  tensy[IJK] = sigma[IJK]*kap*dfdy;
		  
		  dfdz = (ftemp[IJKP]-ftemp[IJK]) / delz[1];
		  w1 = 1.0-fabs(pow(2.0*ftemp[IJK]-1,3));
		  w2 = 1.0-fabs(pow(2.0*ftemp[IJKP]-1,3));
		  kap = (w1*kappa[IJK]+w2*kappa[IJKP])/(w1+w2+tiny);
		  tensz[IJK] = sigma[IJK]*kap*dfdz;
		 
	  }
#else
	if(mpi.MyRank==0) printf("entered the SSF region\n");
	for(k=1;k<km1;k++)
	 for(j=1;j<jm1;j++)
	   for(i=1;i<im1;i++){
		  double phi1 = ftemp[IJK ] - 0.5;
		  double phi2 = ftemp[IPJK] - 0.5;
		  
		  if(phi1*phi2 <= 0.0) {
			  dfdx = (ftemp[IPJK]-ftemp[IJK]) / delx[1];
			  w1 = 1.0-fabs(pow(2.0*ftemp[IJK]-1,3));
			  w2 = 1.0-fabs(pow(2.0*ftemp[IPJK]-1,3));
		      kap = (w1*kappa[IJK]+w2*kappa[IPJK])/(w1+w2+tiny);
			  tensx[IJK] = sigma[IJK]*kap*SIGN(dfdx)/delx[1];

#ifdef Ytube			  
			  if (k<5 && (mpi.MyRank == 0 || mpi.MyRank == 12))
			  {
				tensx[IJK] = sigma[IJK]*kap_x[IJK]*dfdx;
			  }
#endif
		  }
		  
		  phi2 = ftemp[IJPK] - 0.5;
		  if(phi1*phi2 <= 0.0) {
			  dfdy = (ftemp[IJPK]-ftemp[IJK]) / dely[1];
			  w1 = 1.0-fabs(pow(2.0*ftemp[IJK]-1,3));
			  w2 = 1.0-fabs(pow(2.0*ftemp[IJPK]-1,3));
		      kap = (w1*kappa[IJK]+w2*kappa[IJPK])/(w1+w2+tiny);
			  tensy[IJK] = sigma[IJK]*kap*SIGN(dfdy)/dely[1];

#ifdef Ytube			  
			  if (k<5 && (mpi.MyRank == 0 || mpi.MyRank == 12))
			  {
				tensy[IJK] = sigma[IJK]*kap_y[IJK]*dfdy;
			  }
#endif
		  }
		  
		  phi2 = ftemp[IJKP] - 0.5;
		  if(phi1*phi2 <= 0.0) {
			  dfdz = (ftemp[IJKP]-ftemp[IJK]) / delz[1];
			  w1 = 1.0-fabs(pow(2.0*ftemp[IJK]-1,3));
			  w2 = 1.0-fabs(pow(2.0*ftemp[IJKP]-1,3));
		      kap = (w1*kappa[IJK]+w2*kappa[IJKP])/(w1+w2+tiny);
			  tensz[IJK] = sigma[IJK]*kap*SIGN(dfdz)/delz[1];

#ifdef Ytube			  
			  if (k<5 && (mpi.MyRank == 0 || mpi.MyRank == 12))
			  {
				tensz[IJK] = sigma[IJK]*kap_z[IJK]*dfdz;
			  }
#endif
		  }
	  }
#endif

#ifdef __solid
	double *psimx = temp[21], *psimy = temp[22], *psimz = temp[23];
	double *fmx = temp[15], *fmy = temp[16], *fmz = temp[17];
	
	for(k=1;k<km1;k++)
	 for(j=1;j<jm1;j++)
	   for(i=1;i<im1;i++) {
		  if(psimx[IJK] >= em6 && psimx[IJK]+fmx[IJK]>em61 ) tensx[IJK] = 0.0;
		  if(psimx[IJK] >= em6 && psimx[IJK]+fmx[IJK]<=em61) {
			  double phi1 = ftemp[IJK ]-0.5;
			  double phi2 = ftemp[IPJK]-0.5;
			  
			  if(phi1*phi2<=0.0) {
				  dfdx = (ftemp[IPJK]-ftemp[IJK]) / delx[1];
				  if(psi[IJK] > psi[IPJK]) kap = kappa[IPJK];
				  else kap = kappa[IJK];
				  tensx[IJK] = sigma[IJK]*kap*SIGN(dfdx)/delx[1];
			  }
		  }
		  
		  if(psimy[IJK] >= em6 && psimy[IJK]+fmy[IJK]>em61 ) tensy[IJK] = 0.0;
		  if(psimy[IJK] >= em6 && psimy[IJK]+fmy[IJK]<=em61) {
			  double phi1 = ftemp[IJK ]-0.5;
			  double phi2 = ftemp[IJPK]-0.5;
			  
			  if(phi1*phi2<=0.0) {
				  dfdy = (ftemp[IJPK]-ftemp[IJK]) / dely[1];
				  if(psi[IJK] > psi[IJPK]) kap = kappa[IJPK];
				  else kap = kappa[IJK];
				  tensy[IJK] = sigma[IJK]*kap*SIGN(dfdy)/dely[1];
			  }
		  }
		  
		  if(psimz[IJK] >= em6 && psimz[IJK]+fmz[IJK]>em61 ) tensz[IJK] = 0.0;
		  if(psimz[IJK] >= em6 && psimz[IJK]+fmz[IJK]<=em61) {
			  double phi1 = ftemp[IJK ]-0.5;
			  double phi2 = ftemp[IJKP]-0.5;
			  
			  if(phi1*phi2<=0.0) {
				  dfdz = (ftemp[IJKP]-ftemp[IJK]) / delz[1];
				  if(psi[IJK] > psi[IJKP]) kap = kappa[IJKP];
				  else kap = kappa[IJK];
				  tensz[IJK] = sigma[IJK]*kap*SIGN(dfdz)/delz[1];
				  
			  }
		  }
	  }
#endif

	xchg<double>(tensx);
	xchg<double>(tensy);
	xchg<double>(tensz);
	//think of tens at domain boundaries later ...ashish
	//bc();
	bc_tens();

#ifdef print_norm

	memcpy(global_kappa, kappa, NX*NY*NZ*sizeof(double));

	for(k=1;k<5;k++)
	 for(j=1;j<jm1;j++)
	   for(i=1;i<im1;i++){
		   
		   global_kappa[IJK] = kap_x[IJK];
	   }
	   
	memcpy(g_normx, gradrox, NX*NY*NZ*sizeof(double));
	memcpy(g_normy, gradroy, NX*NY*NZ*sizeof(double));
	memcpy(g_normz, gradroz, NX*NY*NZ*sizeof(double));
#endif
#endif
	
	//memfree(kap_x);
	//memfree(kap_y);
	//memfree(kap_z);

}

void vec_dot(double *d, st_point *vec_a, st_point *vec_b);
void bc_zero_tension()
{
	int i,j,k;
	double tx, ty, tz;
	double txm, tym, tzm;
	double *kappa = temp[0];
	
	for (k=1;k<km1;k++)
		for (j=1;j<jm1;j++)
			for (i=1;i<im1;i++)
			{
				tz = (k+mpi.OProc[2])*delz[1];
				
				if(fabs(tz - z_upper_bound) <= 5*delz[1]) kappa[IJK] = 0.0;
			}
	
	st_point cent, norm[2];
	
	cent.x = xe/2; cent.y = ye/2; cent.z = 6.5e-3; // Point on the plane
	norm[0].x = sin((90*pi/180) - tube_angle); norm[0].y = 0.0; norm[0].z = cos((90*pi/180) - tube_angle); // Normal to my Plane
	
	norm[1].x = sin((90*pi/180) - tube_angle); norm[1].y = 0.0; norm[1].z = -cos((90*pi/180) - tube_angle); // Normal to my Plane but on the other side of the domain
	
	for (k=1;k<km1;k++)
		for (j=1;j<jm1;j++)
			for (i=1;i<im1;i++)
			{
				double result;
				st_point vector; // vector between center and current point
				
				tx = (i+mpi.OProc[0])*delx[1]; //global coordinates in coarse-grid
				ty = (j+mpi.OProc[1])*dely[1];
				tz = (k+mpi.OProc[2])*delz[1];
				
				txm = tx-delx[1];
				tym = ty-dely[1];
				tzm = tz-delz[1];
				
				vector.x = MAX(tx,txm) - cent.x;
				vector.y = MAX(ty,tym) - cent.y;
				vector.z = MAX(tz,tzm) - cent.z;

				vec_dot(&result, &norm[0], &vector);
				
				if(result < 0) kappa[IJK] = 0.0;
				
				vec_dot(&result, &norm[1], &vector);
				
				if(result > 0) kappa[IJK] = 0.0;
				
			}
}

#ifdef balanced_force
void bc_tens() {
	
	int i,j,k;
	double *tensx=temp[9], *tensy=temp[10], *tensz=temp[11];
	
	//left face
	if (mpi.Neighbors[0] == -1) {
		for(j=1;j<jm1;j++)
		 for(k=1;k<km1;k++) {
			 tensx[IND(0,j,k)] = 0.e0;
		 }
	}
	
	//right face
	if (mpi.Neighbors[1] == -1) {
		for(j=1;j<jm1;j++)
		 for(k=1;k<km1;k++) {
			 tensx[IND(im2,j,k)] = 0.e0;
		 }
	}
	
	//bottom face
	if (mpi.Neighbors[2] == -1) {
		for(i=1;i<im1;i++)
		 for(k=1;k<km1;k++) {
			 tensy[IND(i,0,k)] = 0.e0;
		 }
	}
	
	//top face
	if (mpi.Neighbors[3] == -1) {
		for(i=1;i<im1;i++)
		 for(k=1;k<km1;k++) {
			 tensy[IND(i,jm2,k)] = 0.e0;
		 }
	}
	
	//under face
	if (mpi.Neighbors[4] == -1) {
		for(i=1;i<im1;i++)
		 for(j=1;j<jm1;j++) {
			 tensz[IND(i,j,0)] = 0.e0;
		 }
	}
	
	//over face
	if (mpi.Neighbors[5] == -1) {
		for(i=1;i<im1;i++)
		 for(j=1;j<jm1;j++) {
			 tensz[IND(i,j,km2)] = 0.e0;
		 }
	}
	
}

void Nfine2stnd(double *crse, double *fine) {
	for(int k=1;k<km1;k++)
	 for(int j=1;j<jm1;j++)
	  for(int i=1;i<im1;i++) {
		crse[IND(i,j,k)] = 0.125*(fine[IND_f(2*i-1,2*j-1,2*k-1)]
								 +fine[IND_f(2*i  ,2*j-1,2*k-1)]
								 +fine[IND_f(2*i-1,2*j  ,2*k-1)]
								 +fine[IND_f(2*i  ,2*j  ,2*k-1)]
								 
								 +fine[IND_f(2*i-1,2*j-1,2*k  )]
								 +fine[IND_f(2*i  ,2*j-1,2*k  )]
								 +fine[IND_f(2*i-1,2*j  ,2*k  )]
								 +fine[IND_f(2*i  ,2*j  ,2*k  )]);
	  }
	xchg<double>(crse);
}

#ifdef __solid
double better_curv_est(int i, int j, int k) {
	double *kappa1 = temp[2];
	double open = 0.0;
	double rout = 0.0;
	int tIJK;
	for(int kk=-1;kk<2;kk++) 
	 for(int jj=-1;jj<2;jj++)
	  for(int ii=-1;ii<2;ii++) {
		  double alpha = 1.0-psi[IND(i+ii,j+jj,k+kk)]-f[IND(i+ii,j+jj,k+kk)];
		  double tmpvar=f[IND(i+ii,j+jj,k+kk)]*alpha;
		  if(tmpvar > open && psi[IND(i+ii,j+jj,k+kk)]<em6) {
			  open = tmpvar;
			  tIJK = IND(i+ii,j+jj,k+kk);
			  rout = kappa1[tIJK];
		  }
	  }

	return (rout);
}
#endif
#endif
