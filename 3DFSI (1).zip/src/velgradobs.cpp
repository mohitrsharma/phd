#include "ripple.h"
#include "comm.h"
#include <stdlib.h>
#include <string.h>
#include "testing.h"

/******************************************************************************
This subroutine sets the boundary conditions on the obstacle ghost cells

Subroutine BCOBS is called by:	BC

Subroutine BCOBS calls:	****

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-made the big loop only execute if the current cell	Ben			May 14 2005
 is obstacle interface cell
-wrote the big loop which sets the velocities on 	Ben			May 03 2005
 the ghost cells of the obstacles according to no
 slip boundary conditions

-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

void velgradobs(double *util, double *vtil, double *wtil)
{
    /*This subroutine applies WALL bc onto tilde velocities just like it is
    done in velgrad subroutine.
    */
	int i, j, k;

	for (k = 0; k < kmax; k++ )
		for (j = 0; j < jmax; j++ )
			for (i = 0; i < imax; i++ )
			{
                if (isobstsfc(IJK))         /*if cell IJK is the obstacle surface cell*/
				{
					if (obst[IJK].flag_r)  /*if obstacle cell is on the RIGHT of fluid*/
					{
						util[IMJK] = 0.0;
						vtil[IJK] = -vtil[IMJK];
						wtil[IJK] = -wtil[IMJK];
					}
					if (obst[IJK].flag_l)  /*if obstacle cell is on the LEFT of fluid*/
					{
						util[IJK] = 0.0;
						vtil[IJK] = -vtil[IPJK];
						wtil[IJK] = -wtil[IPJK];
					}
					if (obst[IJK].flag_f)  /*if obstacle cell is in of the FRONT of fluid*/
					{
						util[IJK] = -util[IJMK];
						vtil[IJMK] = 0.0;
						wtil[IJK] = -wtil[IJMK];
					}
					if (obst[IJK].flag_b)  /*if obstacle cell is on the BACK of fluid*/
					{
					    util[IJK] = -util[IJPK];
						vtil[IJK] = 0.0;
						wtil[IJK] = -wtil[IJPK];
					}
					if (obst[IJK].flag_o)  /*if obstacle cell is OVER the fluid*/
					{
						util[IJK] = -util[IJKM];
						vtil[IJK] = -vtil[IJKM];
						wtil[IJKM] = 0.0;
					}
					if (obst[IJK].flag_u) /*if obstacle cell is UNDER the fluid*/
					{
						util[IJK] = -util[IJKP];
						vtil[IJK] = -vtil[IJKP];
						wtil[IJK] = 0.0;
					}
				}
			}
}
