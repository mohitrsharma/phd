#include "ripple.h"
#include <math.h>
#include <stdlib.h>	//exit

/******************************************************************************



Subroutine CANGLE is called by:	NORMALS	

Subroutine CANGLE calls:		

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/


double cangle (int iside, int ii, int jj, int kk)
{
	//(this routine not thoroughly tested...)
	//this version implements CA model as a function of contact 
	//line velocity.

	if (iside==1)
		return canglel;
	if (iside==2)
		return cangler;
	if (iside==3)
		return cangleb;
	if (iside==4)
		return canglet;
	if (iside==5)
	{
		//routine to evaluate contact angles based on contact line velocity
		int ijk=IND(ii,jj,kk);
		int iu=0;
		int iv=0;
		double umid=0.0;
		double vmid=0.0;
		if ((f[ijk] > em6 || f[ijk-1] > em6) && ar[ijk-1] > em6)
		{
			iu=1;
			umid = u[ijk-1];
		}
		if ((f[ijk-imax] > em6 || f[ijk-imax-1] > em6) && ar[ijk-imax-1] > em6)
		{
			iu++;
			umid+=u[ijk-imax-1];
		}
		if ((f[ijk]>em6 || f[ijk-imax] > em6) && af[ijk-imax] > em6)
		{
			iv=1;
			vmid=v[ijk-imax];
		}
		if ((f[ijk-1] > em6 || f[ijk-imax-1] > em6) && af[ijk-imax-1] > em6)
		{
			iv++;
			vmid+=v[ijk-imax-1];
		}
		if (iu > 0) umid/=(double)iu;
		if (iv > 0) vmid/=(double)iv;
		double vel= -(umid*gradrox[ijk]+vmid*gradroy[ijk]) / sqrt(SQUARE(gradrox[ijk])+SQUARE(gradroy[ijk]));
		double vmax = 0.1;
		double ve=0.05;
		double thetaa=110.0;
		double thetae=90.0;
		double thetar=40.0;	  
		if (vel > vmax)
			return thetaa/180.0*pi;
		else if(vel > ve)
			return (thetae+(vel-ve)/(vmax-ve)*(thetaa-thetae))*pi/180.0;
		else if(vel > -ve)
			return thetae*pi/180.0;
		else if (vel > -vmax)
			return (thetar+(vel+vmax)/(vmax-ve)*(thetae-thetar))*pi/180.0;
		else
			return thetar/180.0*pi;
	}
	if (iside==6)
		return cangleo;

	fprintf (files.error, "Invalid iside in cangle.\n");
	exit(1);
}
