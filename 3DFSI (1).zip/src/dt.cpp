#include "ripple.h"
#include "comm.h"
#include <math.h>
#include "testing.h"

/******************************************************************************


Subroutine DT is called by:	SETUP

Subroutine DT calls:			

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

- Subroutine modified for variable properties		Babak		Sep 15 2009
  
- Time step restriction for energy diffusion		Babak		May 15 2009
  added.
  
- Surface tension time step divided by 3 for		Babak		November 25 2008
  better accuracy. (Not sure, but results are 
  more symmetric with smaller time step. Also
  VOFERR errors are avoided).

- Bugs fixed in the implementation of viscosity		Babak		November 25 2008
  time step.										


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/
void dt()
{
	/* 
	 * This subroutine calculates dtvis and dtsft, which are delt restrictions
	 * due to viscosity and surface tension. These are 2D criteria applied to the
	 * 3D problem.
	 */

	double alfaf1,alfaf2,alfa;
	int i,j,k;
	dtvist=1.0e+10;
	dtsftt=1.0e+10;
	dtdift=1.0e+10;
	int isft=0,jsft=0,ksft=0;
	int ivis=0,jvis=0,kvis=0;
	int idif=0,jdif=0,kdif=0;
	int ii, jj, kk;//for getmax()


	/* VISCOSITY AND DIFFUSION TIME STEP */

	for (i=1;i<im1;i++)
		for (j=1;j<jm1;j++)
			for (k=1;k<km1;k++)
			{
				const double delxsq=delx[i]*delx[i];
				const double delysq=dely[j]*dely[j];
				const double delzsq=delz[k]*delz[k];
				//x-y criteria
				double rdsq=delxsq*delysq/(delxsq+delysq);
				if (rdsq < dtvist)
				{
					ivis=i+mpi.OProc[0];	//OProc gives global coordinates.
					jvis=j+mpi.OProc[1];
					kvis=k+mpi.OProc[2];
					idif=i+mpi.OProc[0];
					jdif=j+mpi.OProc[1];
					kdif=k+mpi.OProc[2];
					dtvist=rdsq;
					dtdift=rdsq;
				}
				//x-z criteria
				rdsq=delxsq*delzsq/(delxsq+delzsq);
				if (rdsq < dtvist)
				{
					ivis=i+mpi.OProc[0];
					jvis=j+mpi.OProc[1];
					kvis=k+mpi.OProc[2];
					idif=i+mpi.OProc[0];
					jdif=j+mpi.OProc[1];
					kdif=k+mpi.OProc[2];
					dtvist=rdsq;
					dtdift=rdsq;
				}
				//y-z criteria
				rdsq=delysq*delzsq/(delysq+delzsq);
				if (rdsq < dtvist)
				{
					ivis=i+mpi.OProc[0];
					jvis=j+mpi.OProc[1];
					kvis=k+mpi.OProc[2];
					idif=i+mpi.OProc[0];
					jdif=j+mpi.OProc[1];
					kdif=k+mpi.OProc[2];
					dtvist=rdsq;
					dtdift=rdsq;
				}
			}
	double temp;	//recv buffer for reduce operation.
	dallreduceloc(&dtvist,&temp,ivis,jvis,kvis,OP_MIN);
	dtvist = temp;

	dallreduceloc(&dtdift,&temp,idif,jdif,kdif,OP_MIN);
	dtdift = temp;

   /* SURFCE TENSION TIME STEP */	
	
	for (i=1;i<im1;i++)
		if (delx[i]<dtsftt)
		{
			isft=i+mpi.OProc[0];
			jsft=mpi.OProc[1];
			ksft=mpi.OProc[2];
			dtsftt = delx[i];
		}
	for (j=1;j<jm1;j++)
		if (dely[j]<dtsftt)
		{
			isft=mpi.OProc[0];
			jsft=j+mpi.OProc[1];
			ksft=mpi.OProc[2];
			dtsftt = dely[j];
		}
	for (k=1;k<km1;k++)
		if (delz[k]<dtsftt)
		{
			isft=mpi.OProc[0];
			jsft=mpi.OProc[1];
			ksft=k+mpi.OProc[2];
			dtsftt = delz[k];
		}
	dallreduceloc(&dtsftt, &temp, isft, jsft, ksft, OP_MIN);
	dtsftt = temp;

	if (!VARPROP)
	{

	    dtsft = sqrt(((rhof1+rhof2)/2.0)*CUBE(dtsftt)/(18.0*pi*stf1+tiny));

		xmumin = MIN(rhof1/xmuf1,rhof2/xmuf2);
		dtvis = dtvist*xmumin/3.0;

	    alfaf1 = condf1/(cpf1*rhof1);
	    alfaf2 = condf2/(cpf2*rhof2);
		alfa = 2.0*MAX(alfaf1,alfaf2);
		dtdif = dtdift/alfa;

		if(mpi.MyRank == 0)
		{
			printf("*** Surface tension time step = %12.5e\n", dtsft);
			printf("*** Viscosity time step       = %12.5e\n", dtvis);
			if (ENERGY)
			printf("*** Diffusion time step       = %12.5e\n", dtdif);
		}
	}
}
