#include "ripple.h"
#include "comm.h"
#include "testing.h"//equal()

#define TOL 1e-8
/******************************************************************************
This subroutine sets the nf array.
NF	CELL TYPE	NEIGHBOURING CELL TYPES
0	fluid		fluid in all directions
1	surface		fluid on the left
2	surface		fluid on the right
3	surface		fluid in the back
4	surface		fluid in the front
5	surface		fluid under 
6	surface 	fluid over
7	surface		void in all direction (isolated)
8	void		no restrictions

Subroutine SETNF is called by:	SETUP, VOFDLY

Subroutine SETNF calls:			

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-reorganized the nf so that it corresponds to serialBen			July 29 2005
 code and ripple manual
-removed the "continue" statement added previously	Ben			July 28 2005
 and fixed nf to be more like serial version of nf
-added a "continue" call on line 50					Ben			May 18 2005
-Fixed up comparison signs on lines 61-66.  Now it 	Ben			May 18 2005
 corresponds to the serial code.
-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/
void setnf()
{
	//Sets nf.
	//psat constant void pressure = 0. It is set once in rinput and never changed..BEN
	int i,j,k;
	for (i=1;i<im1;i++)
	for (j=1;j<jm1;j++)
	for (k=MAX(1,kbot[IND(i,j,0)]); k<MIN(ktop[IND(i,j,0)],km1);k++)
	{
		
		nf[IJK]=0;

		//if cell is obstacle cell, skip.
		if (ac[IJK] == 0.0) continue;//changed from "ac[ijk] < em6"

		//declare empty cell to be a void cell
		if (f[IJK] < emf)	
			nf[IJK]=8;
					
		//if cell is empty (or full but psat = 0) skip: cell will have default values
		//if (f[IJK] < emf) continue; //emf = 1e-6  This line is repeat of the one above
		if (f[IJK] < emf || (f[IJK] > emf1 && psat == 0) ) continue;//emf1 = 1-emf

		//six tests to see whether one of the six neighboring 
		//cells is both empty and open to flow from (i,j,k)
		//cell; if so, enter main do loops.
		if (f[IPJK] < emf && ar[IJK] > em6) goto continue_from_here;
		if (f[IMJK] < emf && ar[IMJK] > em6) goto continue_from_here;
		if (f[IJPK] < emf && af[IJK] > em6)	goto continue_from_here;
		if (f[IJMK] < emf && af[IJMK] > em6) goto continue_from_here;
		if (f[IJKP] < emf && ao[IJK] > em6)	goto continue_from_here;
		if (f[IJKM] < emf && ao[IJKM] > em6) goto continue_from_here;
		{
			//cell is not a surface cell, obstacle cell, empty cell,
			//or particular type of full cell. If it satisfies
			//pressure test, set nf=7 for isolated cell and skip
			//to end of loops. Otherwise, cell is fluid cell and
			//we skip to end of loops with default values.

			if (p[IJK] <= psat*em6p1 && psat > 0)
			{
				nf[IJK]=7;//this does not correspond to serial but
						  //i think its more correct: BEN
				continue;
			}
			else
				continue;//I adde this because in the above comment it says
						 //Otherwise cell is fluid cell and we skip to the end
						 //of loops with default values
		}
	//added this so it corresponds to the serial code
	continue_from_here:
				
		//if the total volume of fluid in cell ijk plus 18
		//neighbors is less than .1, ijk is isolated.
        if (f[IJK]+f[IMJK]+f[IJMK]+f[IJKM]+f[IPJK]+f[IJPK]+f[IJKP]
			+f[IMJMK]+f[IMJPK]+f[IPJMK]+f[IPJPK]
			+f[IJMKM]+f[IJMKP]+f[IJPKM]+f[IJPKP]
			+f[IMJKM]+f[IPJKM]+f[IMJKP]+f[IPJKP] < 0.1)
		{
			nf[IJK]=7;	//isolated.
			continue;
		}
		
		//now I know it's a true surface cell; find nf
		double gradmax = 0.0;
		double grad=-avnx[IJK]*rdx[i];
		if (ar[IJK-1] > em6 && !equal(grad,gradmax, TOL) && grad>gradmax) 
		{
			nf[IJK]=1; //fluid is to LEFT of cel IJK
			gradmax = grad;
		}
		grad = avnx[IJK]*rdx[i];
		if (ar[IJK] > em6 && !equal(grad,gradmax, TOL) && grad>gradmax)
		{
			nf[IJK]=2;//fluid is to the RIGHT of cell IJK
			gradmax = grad;
		}
		grad = -avny[IJK]*rdy[j];
		if (af[IJK-imax] > em6 && !equal(grad,gradmax, TOL) && grad>gradmax)
		{
			nf[IJK]=3;//fluid is to the BACK of cell IJK
			gradmax = grad;
		}
		grad = avny[IJK]*rdy[j];
		if (af[IJK] > em6 && !equal(grad,gradmax, TOL) && grad>gradmax)
		{
			nf[IJK]=4;//fluid is to the FRONT of cell IJK
			gradmax = grad;
		}
		grad = -avnz[IJK]*rdz[k];
		if (ao[IJK-ijmax] > em6 && !equal(grad,gradmax, TOL) && grad>gradmax)
		{
			nf[IJK]=5;//fluid is UNDER cell IJK
			gradmax = grad;
		}
		grad = avnz[IJK]*rdz[k];
		if (ao[IJK] > em6 && !equal(grad,gradmax, TOL) && grad>gradmax)
		{
			nf[IJK]=6;//fluid is OVER cell IJK
			gradmax = grad;
		}
	}	
	//exchange nf
	xchg<int> (nf);
}
