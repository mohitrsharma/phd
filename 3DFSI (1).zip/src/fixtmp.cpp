#include "ripple.h"
#include "testing.h"

/******************************************************************************
This subroutine checks if temperature in the domain is higher or lower than the
initial values, and fixes the values.

Subroutine FIXTMP is called by:	ENTHTMP

Subroutine FIXTMP calls:			

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME			DATE

- Subroutine created								Babak			Sep 30 2009

_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

void fixtmp()
{

	int i,j,k,OBC = 21;
	double ff1,ff2;
	double xmuTf1,xmuTf2,cpTf1,cpTf2,condTf1,condTf2,sigmaTf1;

	for(i=1;i<im1;i++)
		for(j=1;j<jm1;j++)
			for(k=1;k<km1;k++)
			{
				if (tmp[IJK] < MIN(tif1,tif2))
				{
					tmp[IJK] = MIN(tif1,tif2);
					ff1 = f[IJK]*rhof1/rho[IJK];
					ff2 = (1.0-f[IJK])*rhof2/rho[IJK];

					if (VARPROP)
					{
						xmuTf1=interp(FLUID1_T,FLUID1_xmu,tmp[IJK]);
						xmuTf2=interp(FLUID2_T,FLUID2_xmu,tmp[IJK]);
						cpTf1=interp(FLUID1_T,FLUID1_Cp,tmp[IJK]);
						cpTf2=interp(FLUID2_T,FLUID2_Cp,tmp[IJK]);
						condTf1=interp(FLUID1_T,FLUID1_K,tmp[IJK]);
						condTf2=interp(FLUID2_T,FLUID2_K,tmp[IJK]);
						sigmaTf1=interp(FLUID1_T,FLUID1_st,tmp[IJK]);
					}
					else
					{
						xmuTf1=xmuf1;
						xmuTf2=xmuf2;
						cpTf1=cpf1;
						cpTf2=cpf2;
						condTf1=condf1;
						condTf2=condf2;
						sigmaTf1=stf1;
					}
					
					h[IJK] = cpTf1*ff1*tmp[IJK]+(h0f2+cpTf2*tmp[IJK])*ff2;
					xmu[IJK] = xmuTf1*f[IJK]+xmuTf2*(1.0-f[IJK]);
					cp[IJK] = cpTf1*ff1+cpTf2*ff2;
					cond[IJK] = 1.0/(ff1/condTf1+ff2/condTf2);
					sigma[IJK] = sigmaTf1;
					if (ku == 5 && k+mpi.OProc[2] < OBC) sigma[IJK] = 0.001;
				}

				if (tmp[IJK] > MAX(tif1,tif2))
				{
					tmp[IJK] = MAX(tif1,tif2);
					ff1 = f[IJK]*rhof1/rho[IJK];
					ff2 = (1.0-f[IJK])*rhof2/rho[IJK];

					if (VARPROP)
					{
						xmuTf1=interp(FLUID1_T,FLUID1_xmu,tmp[IJK]);
						xmuTf2=interp(FLUID2_T,FLUID2_xmu,tmp[IJK]);
						cpTf1=interp(FLUID1_T,FLUID1_Cp,tmp[IJK]);
						cpTf2=interp(FLUID2_T,FLUID2_Cp,tmp[IJK]);
						condTf1=interp(FLUID1_T,FLUID1_K,tmp[IJK]);
						condTf2=interp(FLUID2_T,FLUID2_K,tmp[IJK]);
						sigmaTf1=interp(FLUID1_T,FLUID1_st,tmp[IJK]);
					}
					else
					{
						xmuTf1=xmuf1;
						xmuTf2=xmuf2;
						cpTf1=cpf1;
						cpTf2=cpf2;
						condTf1=condf1;
						condTf2=condf2;
						sigmaTf1=stf1;
					}
					
					h[IJK] = cpTf1*ff1*tmp[IJK]+(h0f2+cpTf2*tmp[IJK])*ff2;
					xmu[IJK] = xmuTf1*f[IJK]+xmuTf2*(1.0-f[IJK]);
					cp[IJK] = cpTf1*ff1+cpTf2*ff2;
					cond[IJK] = 1.0/(ff1/condTf1+ff2/condTf2);
					sigma[IJK] = sigmaTf1;
					if (ku == 5 && k+mpi.OProc[2] < OBC) sigma[IJK] = 0.001;
				}
			}
}
