#include "comm.h"
#include "ripple.h"
#include <stdio.h>
#include <float.h>
#include <stdlib.h>
#include "testing.h"
#include <string.h>
#include <time.h>
#include <mpi.h>
#include "timing.h"

/******************************************************************************
This is the main program which is basically a parallel version of 3D ripple
code, developed by professor Marcus Bussmann as a part of his doctoral thesis

Subroutine RIPPLE calls:	SETUP, NEWCYC, CONVECT, VISCOUS, TENSION, IMPLCTP,
							VOFDLY, DIFUSSION, SPHERICITY

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION                                               NAME     DATE

- Energy equation added.								  Babak	   May 16 2009

- Made some changes on how spherity is calculated.        Ben      Sept
  These changes go together with changes I did in
  sphericity and residual.cpp subroutines.


_________________________________TO DO LIST____________________________________

DESCRIPTION                                               NAME     DATE
-ashish
* Include Omega and U_rig, V_rig etc. in the dump file

*******************************************************************************/
void test_module();
template <class T> void fetch_mom(int i, int j, int k, T &val, T *array, T *gArray);
void tension2(double *fvirt);

#ifdef __solid
void printSolVel();
#endif

void calc_div();
void printMaxVel();

void ytube_bc();
void ytube_bc2();
void ytube_bc3();

void Velocity_Symmetry();
void velocity_sym2();

int velocity_magnitude();

void mpi_velocity_sym();

int main (int argc, char *argv[]){
	/*
	 * Main program
	 */
char command[15];
sprintf(command, "ulimit -s hard");
system(command);
	initmpi(argc, argv);   					/* initialize MPI environment */
	rinput();              					/* read the INPUT file */
    OpenFiles();           					/* open input and output files */
	
    if(ICEM){
		ReadBC();							/* read BC.DAT file generated with ICEM */
		adjustdims();						/* adjust local and global dimensions */
		arraysalloc(dim.nx,dim.ny,dim.nz);	/* allocate dynamica memory */
		meshset();							/* create a numerical */
		ReadSOLID();						/* read SOLID.DAT file and set a_ arrays */
		ReadLIQUID();						/* read LIQUID.DAT file and set f array */
    	}
    else{
	   adjustdims();          				/* dim.nx,ny,nz not valid until after adjustdims */
	   arraysalloc(dim.nx,dim.ny,dim.nz);	/* allocate dynamica memory */
    	}
	
	setup();           						/* initialize F,U,V,W and BCs */
	
	bool quit=false;
	unsigned int Ltp;
#ifdef rudman_fine
	double *vnew_f=temp_f[0];
#endif

	init_timing();  // Initialize timing counters

	for(int tc = 0; true; tc++){       		/* start the big loop */
		LTime = wtime();

		if(quit = newcyc()) break;
		if(mpi.MyRank == 0) printf("______________________________NCYC=%d______________________________\n",ncyc);
		//bar(); if(mpi.MyRank==0) printf("exiting now after initial setup\n"); bar(); exit(1);
/*		
#ifdef rudman_fine
		//pseudo time-step: //use only with some initial fluid velocity
		if((!(uf1==0.0 && uf2==0.0 && vf1==0.0 && vf2==0.0 && wf1==0.0 && wf2==0.0))&& ncyc==1) {
			memcpy(vnew_f,vol_f,NX_f*NY_f*NZ_f*sizeof(double));
			stag_vol();
			stag_den(); //to be used in implctp
			double delt_in=delt;
			delt = delt*1.e-3;
			
			implctp();
			delt=delt_in;
			memset(p,0,NX*NY*NZ*sizeof(double));
			
		}
#endif
*/
		
// 		if(BUBBLE) apply_bubble_pressure(); /* apply bubble pressure */

#ifndef rudman_fine
#ifndef pres_v
		convect();        					/* calculate convective effects */
		viscous();        					/* calculate viscous effects */
		tension();        					/* calculate surface tension effect */
		implctp();        					/* solve Pressure Poison Equation */
		if(ENERGY) diffusion();				/* solve diffusion part of the energy equation */
#endif
		vofdly();         					/* advect the VOF function f */
#endif

		
#ifdef rudman_fine
#ifdef __solid
		calc_solid_mass(); //chaser
#endif

#ifdef air_film
		int gate =0;
		gate = detect_air_film(); 
		if(gate==1 && mpi.MyRank==0) printf("Air film Detected\n");
#endif			
		vofdly_f();
		
#ifndef pres_v
		viscous();
		tension();
//		tension2(g_fvirt);
#ifdef bl_mg
	    Ltp = wtime(); 
#ifdef air_film
		if(gate==1) 
		{
			double velocity = largest_solid_velocity();
			density_correction(velocity);
		}
#endif
	    bl_mg_main();
	    Ltp = wtime() - Ltp; 
#endif
#ifndef bl_mg  
		Ltp = wtime(); implctp();  Ltp = wtime() - Ltp; 
#endif
		if(mpi.MyRank==0) printf("time taken by implctp: %d (ms)\n",Ltp);
#ifdef __solid
		int i;
		for(i=1;i<=NBODY;i++) Nrigid_body_vel3(i); //implement FSI.. and set rigid-body-vel 		
		bcvel();
#endif
		calc_div();
#endif
#endif
		//printMaxVel();

        if(BUBBLE) update_bubble();     	/* update new bubble cells */
		LTime = wtime() - LTime;  			/* get time for an iteration */

		PrintCycleInfo();					/* print and record iteration info */
		
		/*if (!(tc&15) || t<5)
		LoadBalance();*/					/* not implemented load balance yet */

        // Print timing results every 100 cycles
        if (ncyc % 100 == 0) {
            print_timing_results();
            reset_timing();
        }
	}/* end of big loop */

	// Print final timing results
	print_timing_results();

	cleanupmpi();  							/* cannot have any MPI calls after this point*/
	CloseFiles();							/* close all files */

	return 0;
}

void Velocity_Symmetry() // Compare all symmetric cells
{
  int i,j,k;
  int ii, jj, kk;
  int iii, jjj, kkk;
  int count, count2;
  int sym_i;
  
  double temp_diff, max_diff, total_diff;
  
  double tempw_diff, w_diff_max, total_diff_w;
  
  w_diff_max = 0.0;
  tempw_diff = 0.0;
  total_diff_w = 0.0;
  
  temp_diff = 0.0;
  max_diff = 0.0;
  total_diff = 0.0;
  count = 0;
  count2 = 0;
  
  sym_i = (int)((xe/2)/delx[1]);
	
  for(i=52; i<sym_i; i++)
    for(j=33; j<34; j++)
	  for(k=168; k<175; k++)
	  {
		  if(psi[IJK] > em6 ) continue;
		  
		  tempw_diff = fabs(w[IND(im1 - i, j, k)]) - fabs(w[IJK]);
		  
		  count += 1;
			
		  total_diff_w += tempw_diff;
		  
		  if(tempw_diff > w_diff_max) 
		  {
			  w_diff_max = tempw_diff;
			  
			  iii = i;
			  jjj = j;
			  kkk = k;
		  }
	  }
  total_diff_w /= count;

  for(i=52; i<sym_i; i++)
    for(j=33; j<34; j++)
	  for(k=168; k<175; k++)
	  {
		  if(psi[IJK] > em6 ) continue;
		  
		  double vm1, vm2;
		  
		  vm1 = sqrt(u[IJK]*u[IJK] + v[IJK]*v[IJK] + w[IJK]*w[IJK]);
		  
		  vm2 = sqrt(u[IND(im1 - i, j, k)]*u[IND(im1 - i, j, k)] + v[IND(im1 - i, j, k)]*v[IND(im1 - i, j, k)] + w[IND(im1 - i, j, k)]*w[IND(im1 - i, j, k)]);
		  
		  temp_diff = fabs(vm2) - fabs(vm1);
		  
		  total_diff += temp_diff;
		  count2 += 1;
		  
		  if(temp_diff > max_diff) 
		  {
			  max_diff = temp_diff;
			  
			  ii = i;
			  jj = j;
			  kk = k;
		  }
	  }
	total_diff /= count2;
	
	// Now perform mpi allreduce to find out the max velocity and the average
	// Compare the local max with the reduced max, and if they are the same
	// have that processor print.
	
	double average_diff, average_diff_w;
	double max, max_w;
	
	dallreduce(&total_diff, &average_diff, 1, OP_SUM);
	dallreduce(&total_diff_w, &average_diff_w, 1, OP_SUM);
	
	dallreduce(&max_diff, &max, 1, OP_MAX);
	dallreduce(&w_diff_max, &max_w, 1, OP_MAX);
	
	if(w_diff_max == max_w)
	{
	  FILE *fp;
	  fp = fopen("W_before_bifurcation","a+");
	
	  if(ncyc == 0) fprintf(fp,"Max Diff         Average Diff\n");
	
	  fprintf(fp,"%e     %e     ",max_w, average_diff_w);
	  fprintf(fp,"i = %d    j = %d    k = %d\n",iii, jjj, kkk);
	  fclose(fp);
	}
	
	if(max_diff == max)
	{
	  FILE *gp;
	  gp = fopen("Velocity_symmetry","a+");
	
	  if(ncyc == 0) fprintf(gp,"Max Diff         Average Diff\n");
	
	  fprintf(gp,"%e     %e     ",max, average_diff);
	  fprintf(gp,"i = %d    j = %d    k = %d\n",ii, jj, kk);
	  fclose(gp);
	}
	
	i = 55;
	j = 28;
	k = 170;
	
	double vm1, vm2;
	
	vm1 = sqrt(u[IJK]*u[IJK] + v[IJK]*v[IJK] + w[IJK]*w[IJK]);
		  
	vm2 = sqrt(u[IND(im1 - i, j, k)]*u[IND(im1 - i, j, k)] + v[IND(im1 - i, j, k)]*v[IND(im1 - i, j, k)] + w[IND(im1 - i, j, k)]*w[IND(im1 - i, j, k)]);
	
}

void velocity_sym2()
{
  int i, j, k;
  int ii, jj, kk;
  int iii, jjj, kkk;
  int count, count2;
  int sym_i;
  
  double temp_diff, max_diff, total_diff;
  
  double tempw_diff, w_diff_max, total_diff_w;
  
  double tempv_diff, tempu_diff;
  
  double v_diff_max, u_diff_max;
  
  double total_diff_v, total_diff_u;
  
  double psi_diff = 0;
  
  v_diff_max = 0.0;
  u_diff_max = 0.0;
  
  tempv_diff = 0.0;
  tempu_diff = 0.0;
  
  w_diff_max = 0.0;
  tempw_diff = 0.0;
  total_diff_w = 0.0;
  
  temp_diff = 0.0;
  max_diff = 0.0;
  total_diff = 0.0;
  count = 0;
  count2 = 0;
  
  sym_i = (int)((xe/2)/delx[1]);
	
  for(int i=52; i<sym_i; i++)
    for(int j=20; j<45; j++)
	  for(int k=120; k<175; k++)
	  {  
		  if(psi[IJK] > em6 ) continue;
		  
		  tempw_diff = (fabs(w[IND(im1 - i, j, k)]) - fabs(w[IJK]));
		  
		  tempv_diff = (fabs(v[IND(im1 - i, j, k)]) - fabs(v[IJK]));
		  
		  tempu_diff = (fabs(u[IND(im1 - i - 1, j, k)]) - fabs(u[IJK]));
		  
		  count += 1;
			
		  total_diff_w += tempw_diff;
		  total_diff_v += tempv_diff;
		  total_diff_u += tempu_diff;
		  
		  if(tempw_diff > w_diff_max) 
		  {
			  w_diff_max = tempw_diff;
			  
			  iii = i;
			  jjj = j;
			  kkk = k;
		  }
		  
		  if(tempv_diff > v_diff_max) 
		  {
			  v_diff_max = tempv_diff;
		  }
		  
		  if(tempu_diff > u_diff_max) 
		  {
			  u_diff_max = tempu_diff;
		  }
	  }
	  
	double *const rh  = temp[12];
	double div, div_max_diff;
	
	div = 0.0;
	div_max_diff = 0.0;;
  
  	for(int k=1;k<km1;k++)
	 for(int j=1;j<jm1;j++)
	  for(int i=1;i<im1;i++) {
			const double div =((u[IJK]-u[IMJK])/delx[1])
						+((v[IJK]-v[IJMK])/dely[1])
						+((w[IJK]-w[IJKM])/delz[1]);
						
			
			rh[IJK] = -div;
	}
	
	double max_div = 0.0;

	for(int i=52; i<sym_i; i++)
		for(int j=20; j<45; j++)
			for(int k=120; k<175; k++)
			{  
				if(psi[IJK] > em6 ) continue;
		  
				div = (fabs(rh[IND(im1 - i, j, k)]) - fabs(rh[IJK]));
				
				if(div > div_max_diff) 
				{
					div_max_diff = div;
				}
				
				if(rh[IJK] > max_div) max_div = rh[IJK];
			}
	
	double pressure_diff, p_diff_max;
	
	pressure_diff = 0.0;
	p_diff_max = 0.0;
	
	int pi, pj, pk;
	
	for(int i=52; i<sym_i; i++)
		for(int j=20; j<45; j++)
			for(int k=120; k<175; k++)
			{  
				if(psi[IJK] > em6 ) continue;
		  
				pressure_diff = (fabs(p[IND(im1 - i, j, k)]) - fabs(p[IJK]));
				
				if(pressure_diff > p_diff_max)
				{
					p_diff_max = pressure_diff;
				
					pi = i;
					pj = j;
					pk = k;
				}
			}
			
	FILE *fp;
	fp = fopen("Symmetry_diff_parent","a+");
	
	if(ncyc == 1) fprintf(fp,"W            V            U             avg_W       avg_V     avg_u     div_diff         p_diff_max   \n");
	
	fprintf(fp,"%d %3e %3e %3e %3e %3e %3e %3e %3e\n",ncyc, w_diff_max, v_diff_max, u_diff_max,total_diff_w/count,total_diff_v/count,total_diff_u/count,div_max_diff,p_diff_max);
	fclose(fp);
	
	count =0;
	w_diff_max = 0.0;
	v_diff_max = 0.0;
	u_diff_max = 0.0;
	
	for(int i=26; i<sym_i; i++)
     for(int j=20; j<45; j++)
	  for(int k=73; k<120; k++)
	  {  
		  if(psi[IJK] > em6 ) continue;
		  
		  tempw_diff = (fabs(w[IND(im1 - i, j, k)]) - fabs(w[IJK]));
		  
		  tempv_diff = (fabs(v[IND(im1 - i, j, k)]) - fabs(v[IJK]));
		  
		  tempu_diff = (fabs(u[IND(im1 - i - 1, j, k)]) - fabs(u[IJK]));
		  
		  count += 1;
			
		  total_diff_w += tempw_diff;
		  total_diff_v += tempv_diff;
		  total_diff_u += tempu_diff;
		  
		  if(tempw_diff > w_diff_max) 
		  {
			  w_diff_max = tempw_diff;
			  
			  iii = i;
			  jjj = j;
			  kkk = k;
		  }
		  
		  if(tempv_diff > v_diff_max) 
		  {
			  v_diff_max = tempv_diff;
		  }
		  
		  if(tempu_diff > u_diff_max) 
		  {
			  u_diff_max = tempu_diff;
		  }
	  }
	
	FILE *gp;
	gp = fopen("Symmetry_diff_daughter","a+");
	if(ncyc == 1) fprintf(gp,"W            V            U             avg_W       avg_V     avg_u\n");
	fprintf(gp,"%d %3e %3e %3e %3e %3e %3e\n",ncyc, w_diff_max, v_diff_max, u_diff_max,total_diff_w/count,total_diff_v/count,total_diff_u/count);
	fclose(gp);
	
}

void mpi_velocity_sym()
{
  int i, j, k;

  int count;
  
  double total_diff_w, total_diff_v, total_diff_u;
  
  double w_diff_max, v_diff_max, u_diff_max;
  
  double tempw_diff, tempv_diff, tempu_diff;
  
  w_diff_max = 0.0;
  v_diff_max = 0.0;
  u_diff_max = 0.0;

  tempw_diff = 0.0;
  tempv_diff = 0.0;
  tempu_diff = 0.0;
  
  total_diff_w = 0.0;
  total_diff_v =0.0;
  total_diff_u =0.0;
  
  count = 0;
  
  double r_u, r_v, r_w;
  
  double over_face;
  double under_face;
	
  over_face = floor(((z_upper_bound + (delx[1]/20))/delx[1]));
  under_face = floor(((z_bifurcation + (delx[1]/20))/delx[1]));
	
  int o_f = ((int)over_face) +1;
  int u_f = ((int)under_face) +1;
  
  // Need to Check if the box is correct or if it should be the mpi boundary
  if( o_f > (km1+mpi.OProc[2]) ) 
  {
    o_f = km1;
  }
  else 
  {
	o_f -= mpi.OProc[2];
  }
	
  if( u_f < (1+mpi.OProc[2]) ) 
  {
	u_f = 1;
  }
  else
  {
	u_f -= mpi.OProc[2];
  }
	
  for(int i=1; i<im1; i++)
    for(int j=44; j<85; j++)
	  for(int k=u_f; k<o_f; k++)
	  {
		  if(mpi.MyRank == 17 || mpi.MyRank == 16 || mpi.MyRank == 15)
		  {
		    MPI_Send(&w[IND(i,j,k)], 1, MPI_DOUBLE, mpi.MyRank - 6, 0, (MPI_Comm)mpi.COMM_CART);
		    MPI_Send(&v[IND(i,j,k)], 1, MPI_DOUBLE, mpi.MyRank - 6, 1, (MPI_Comm)mpi.COMM_CART);
		    MPI_Send(&u[IND(i,j,k)], 1, MPI_DOUBLE, mpi.MyRank - 6, 2, (MPI_Comm)mpi.COMM_CART);
		    
		  }
		  else if(mpi.MyRank == 11 || mpi.MyRank == 10 || mpi.MyRank == 9)
		  {
			MPI_Recv(&r_w, 1, MPI_DOUBLE, mpi.MyRank + 6, 0, (MPI_Comm)mpi.COMM_CART, MPI_STATUS_IGNORE);
			MPI_Recv(&r_v, 1, MPI_DOUBLE, mpi.MyRank + 6, 1, (MPI_Comm)mpi.COMM_CART, MPI_STATUS_IGNORE);
		    MPI_Recv(&r_u, 1, MPI_DOUBLE, mpi.MyRank + 6, 2, (MPI_Comm)mpi.COMM_CART, MPI_STATUS_IGNORE); 
		  }
		  else continue;
		  		  
		  if(psi[IND(im1-i,j,k)] > em6 ) continue;
		  
		  if(mpi.MyRank == 11 || mpi.MyRank == 10 || mpi.MyRank == 9)
		  {
			count += 1;
			  
		    tempw_diff = (fabs(w[IND(im1 - i, j, k)]) - fabs(r_w));
		  
		    tempv_diff = (fabs(v[IND(im1 - i, j, k)]) - fabs(r_v));
		  
		    tempu_diff = (fabs(u[IND(im1 - i - 1, j, k)]) - fabs(r_u));
			
		    total_diff_w += tempw_diff;
		    total_diff_v += tempv_diff;
		    total_diff_u += tempu_diff;
		  
		    if(tempw_diff > w_diff_max) 
		    {
			  w_diff_max = tempw_diff;
		    }
		  
		    if(tempv_diff > v_diff_max) 
		    {
			  v_diff_max = tempv_diff;
		    }
		  
		    if(tempu_diff > u_diff_max) 
		    {
			  u_diff_max = tempu_diff;
		    }
	      }
	  }
	  
	  if(mpi.MyRank == 11 || mpi.MyRank == 10 || mpi.MyRank == 9) printf("rank = %d w_diff_max = %e\n",mpi.MyRank, w_diff_max);
	  
	  double mpi_w_max, mpi_v_max, mpi_u_max;
	  
	  MPI_Allreduce (&w_diff_max, &mpi_w_max, 1, MPI_DOUBLE, MPI_MAX, (MPI_Comm)mpi.COMM_CART);
	  MPI_Allreduce (&v_diff_max, &mpi_v_max, 1, MPI_DOUBLE, MPI_MAX, (MPI_Comm)mpi.COMM_CART);
	  MPI_Allreduce (&u_diff_max, &mpi_u_max, 1, MPI_DOUBLE, MPI_MAX, (MPI_Comm)mpi.COMM_CART);
	  
	  double mpi_w_avg, mpi_v_avg, mpi_u_avg; 
	  int mpi_count;
	  
	  MPI_Allreduce (&count, &mpi_count, 1, MPI_INT, MPI_SUM, (MPI_Comm)mpi.COMM_CART);
	  
	  MPI_Allreduce (&total_diff_w, &mpi_w_avg, 1, MPI_DOUBLE, MPI_SUM, (MPI_Comm)mpi.COMM_CART);
	  MPI_Allreduce (&total_diff_v, &mpi_v_avg, 1, MPI_DOUBLE, MPI_SUM, (MPI_Comm)mpi.COMM_CART);
	  MPI_Allreduce (&total_diff_u, &mpi_u_avg, 1, MPI_DOUBLE, MPI_SUM, (MPI_Comm)mpi.COMM_CART);
	  	  
	  if(mpi_w_max == w_diff_max)
	  {
		FILE *fp;
		fp = fopen("Symmetry_diff","a+");
	
		if(ncyc == 1) fprintf(fp,"ncyc          W             V             U          Avg_W             Avg_V           Avg_U\n");
	
		fprintf(fp,"%d %e %e %e %e %e %e\n",ncyc, mpi_w_max, mpi_v_max, mpi_u_max, mpi_w_avg/mpi_count, mpi_v_avg/mpi_count, mpi_u_avg/mpi_count);
		fclose(fp);
	  }
}

void printMaxVel() {
	int i,j,k;
	double tmp_vel, err_Linf, terr_Linf;
	err_Linf = terr_Linf = 0.0;
	int indx_i, indx_j, indx_k;
	indx_i = indx_j = indx_k = 0;
	for(i=1;i<im1;i++)
	 for(j=1;j<jm1;j++)
	  for(k=1;k<km1;k++) {
		  tmp_vel = sqrt(u[IJK]*u[IJK] + v[IJK]*v[IJK] + w[IJK]*w[IJK]);
		  if(tmp_vel > err_Linf) {
			  err_Linf = tmp_vel;
			  indx_i = i, indx_j = j, indx_k = k;  
		  }
	  }
	dallreduce(&err_Linf,&terr_Linf,1,OP_MAX);
	if(err_Linf == terr_Linf) err_Linf += mpi.MyRank;
	dallreduce(&err_Linf,&terr_Linf,1,OP_MAX);
	FILE *fp;
	fp = fopen("max_vel","a+");
	if(err_Linf == terr_Linf) {
		fprintf(fp,"%d %d %e %d %d %d %e %e %e\n",ncyc,mpi.MyRank,(err_Linf-mpi.MyRank),indx_i,indx_j,indx_k,u[IND(indx_i,indx_j,indx_k)],v[IND(indx_i,indx_j,indx_k)],w[IND(indx_i,indx_j,indx_k)]);
	}
	fclose(fp);
}

void test_module() {
//stub function for time being. use it for prompt tests in ripple
}

int velocity_magnitude() {
	
	int i,j,k;
	int ii,jj,kk;
	
	double max_magnitude, temp_magnitude;
	
	max_magnitude = 0.0;
	temp_magnitude = 0.0;
	
	for(i=1; i<im1; i++)
		for(j=1; j<jm1; j++)
			for(k=1; k<km1; k++)
			{
				temp_magnitude = sqrt(u[IJK]*u[IJK] + v[IJK]*v[IJK] + w[IJK]*w[IJK]);
				
				if(temp_magnitude > max_magnitude)
				{
					max_magnitude = temp_magnitude;
					
					ii = i;
					jj = j;
					kk = k;
				}
			}
			
	double mpi_rec;		
			
	MPI_Allreduce (&max_magnitude, &mpi_rec, 1, MPI_DOUBLE, MPI_MAX, (MPI_Comm)mpi.COMM_CART);
	
	FILE *fp;
	fp = fopen("Tracking","a+");
	
	if(mpi_rec == max_magnitude)
	{
		fprintf(fp,"%d %d %e       ijk = %d %d %d\n",ncyc, mpi.MyRank, max_magnitude, ii, jj, kk);
	}
	fclose(fp);
	
	if(mpi_rec > 1) return 1;
	else return 0;
	
}


void calc_div() {
	int i,j,k;
	double *t_div = temp[13];
	memset(t_div,0,NX*NY*NZ*sizeof(double));
	
	for(i=1;i<im1;i++)
	 for(j=1;j<jm1;j++)
	  for(k=1;k<km1;k++) {
		  t_div[IJK] = (u[IJK] - u[IMJK])/delx[1]
				 + (v[IJK] - v[IJMK])/dely[1]
				 + (w[IJK] - w[IJKM])/delz[1];
	  }
	xchg<double>(t_div);
}
