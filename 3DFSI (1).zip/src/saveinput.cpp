#include "ripple.h"
#include <stdio.h>
#include "testing.h"

/******************************************************************************
The subroutine SAVEINPUT copies the INPUT file into the SUMMARY file so that
all the information relevant to a simulaiton are kept in one place.

Subroutine SAVEINPUT is called by:	SETUP

Subroutine SAVEINPUT calls:			

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION													NAME	DATE

-implemented 1st version of SAVEINPUT 						Ben		Sept 8 2005
-Created this template for tracking changes					Ben		April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION													NAME	DATE


*******************************************************************************/

void saveinput()
{
	char line[256]="";
	
	while (fgets(line,255,files.input))
	{
		fputs(line,files.summary);
	}
	
}
