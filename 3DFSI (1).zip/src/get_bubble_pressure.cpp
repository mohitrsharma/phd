#include <stdlib.h>
#include <math.h>
#include "testing.h"
#include "ripple.h"
#include <stdio.h>

//#define DEBUG
//#define P_INIT 7.0928e+08 //7000 atmospheres
#define PI 3.14159265
#define R 8.314 //universal gas constant in J/mol/K
/******************************************************************************
This subroutine GET_BUBBLE_PRESSURE returns a pressure inside the bubble at 
each time step.  The pressure is calculated from energy input profile. Bubble
expansion is considered to be isentropic process: PV^gamma = Const.  

Subroutine GET_BUBBLE_PRESSURE is called by:	TENSION

Subroutine GET_BUBBLE_PRESSURE calls:	****

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION                                         NAME        DATE

-Made some changes to bubble_volume function to     Ben         Mar 17 2006
 ensure that only process 0 worries if the simu-
 -lation is for full, half, or qtr. bubble.
-Added a function vel_centline at the bottom of     Ben         Feb 20 2006
 this subroutine.
-Removed the +101325 Pa term from Max_Pb() because
 I think that calculated Pb value should be a 
 gauge pressure value.  
-I added the ability to input energy ad a pre       Ben         Jan 27 2006
 defined rate.  Parameter Td is time of discharge
 and Eff is the efficiency of the process.
-changed how bubble volume is caculated. added a    Ben         Jan 16 2006
 check for obstacle cells so that its more selective
-Crated this subroutine for calculating pressure    Ben         Sept 29 2005
 variation inside a bubble
-Created this template for tracking changes.        Ben         April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION                                         NAME        DATE


*******************************************************************************/
void get_bubble_pressure(void)
{
    if(ncyc == 0) 
	{
		init_Pb();//set initial Pb, before energy input
		Erate = Eff * ENRG / Td;
	}
	else if(t < Td) 
	{
		ENRG = delt * Erate;
		Esum += ENRG;
		max_Pb();//set Pb during energy input
	}
	else
	{
		if(ncyc == 1)
		{
			ENRG = ENRG * Eff;
			Esum = ENRG;
			max_Pb();//set Pb for instanteneous energy input
		}
		else
			isentropic_Pb();//set Pb, after enrgy input
}
}
void init_Pb(void)
{
	/*This function returns initial absolute bubble pressure.
	  h2o = 18 kg/kmol
	*/
	double mol_h2o;
	bubble_volume();

    if(mpi.MyRank == 0)
	{
		mol_h2o = 1000.0 * (((4.0 / 3.0) * PI * pow(R_NUCL, 3) * rhof1) / 18.0);
		Pb = mol_h2o * R * T_INIT / Vb;
		init_pressure = Pb;
	}
	/*Share Pb with all processes here*/
	bcastdata(&Pb, sizeof(double));

	/*======================PRINT TO OUTPUT==============================*/
	double vel_cl = vel_centline();
	fprintf(files.out,"\n%10.4e\t%10.4e\t%10.4e\t%10.4e\t%10.4e\t%10.4e\n"
		,t, Pb, T_INIT, Vb, vel_cl, 0.0);//energy balance at ncyc = 0 is 0.0!
	
	
}
void max_Pb(void)
{
	/*This funciton returns bubble pressure during discharge.
	
	The maximum bubble pressure is calculated by assuming bubble volume stays
	constant while energy is instanteniously dumped into it.  The main equation
	used is P1*V1/T1 = P2*V2/T2, where V1 = V2.  T1 is room temp and T2 is know
	from dU = m*Cv*dT
	*/
	bubble_volume();//set Vb, all processes must call bubble_volume()

	if(mpi.MyRank == 0)
	{
		double T1 = (ncyc == 1)? T_INIT: T2;
		//in tension.cpp Pb was made to be a gauge-value by subtracting 101325
		//Here its necessary to add it again.  
		double P1 = (ncyc == 1)? Pb: Pb + 101325;
		//double V2 = (4.0 / 3.0) * PI * pow(radius, 3);
		//double P2;
		init_volume = (4.0 / 3.0) * PI * pow(radius, 3);
		double Mb = (4.0 / 3.0) * PI * pow(R_NUCL, 3) * rhof1;//Mass of bubble should be constant!
        		
		T2 = ENRG / (Mb * Cv) + T1;
		Pb = P1 * (T2 / T1);//remember, Pb needs to be converted into gauge pressure in tension.cpp
		c1 = Pb * pow(Vb, GAMMA);//isentropic expansion constant
		
		printf("VOLUME CHANGE = (%10.4e, %10.4e, %6f)\n\n", init_volume, Vb, 
								(Vb / init_volume) );
		/*printf("TEMPERATURE CHANGE = (%10.4e, %10.4e, %6f)\n\n", T_INIT, T2, 
        (T2 / T_INIT) );*/
		printf("PRESSURE CHANGE = (%10.4e, %10.4e, %6f)\n\n", init_pressure, Pb, 
								(Pb / init_pressure) );
		printf("ENERGY DELIVERED TOTAL [J]: %10.4e\n\n", Esum);
		fprintf(files.summary, "VOLUME CHANGE = (%10.4e, %10.4e, %6f)\n", init_volume, Vb, 
								(Vb / init_volume) );
		fprintf(files.summary, "TEMPERATURE CHANGE = (%10.4e, %10.4e, %6f)\n", T_INIT, T2, 
								(T2 / T_INIT) );
		fprintf(files.summary, "PRESSURE CHANGE = (%10.4e, %10.4e, %6f)\n", init_pressure, Pb, 
								(Pb / init_pressure) );
		fprintf(files.summary, "ENERGY DELIVERED TOTAL [J]: %10.4e\n", Esum);
		if(ncyc > 1) printmax();
	}//if(mpi.MyRank == 0)
	
	//share Pb here
	bcastdata(&Pb, sizeof(double));

	/*======================PRINT TO OUTPUT==============================*/
	double vel_cl = vel_centline();	
	fprintf(files.out,"\n%10.4e\t%10.4e\t%10.4e\t%10.4e\t%10.4e\t%10.4e\n"
		,t, Pb, T_INIT, Vb, vel_cl, jet_energy / Esum);
}
void isentropic_Pb(void)
{
	/*This function returns bubble pressure during isentropic expansion
	
	PV^(GAMMA) = CONST is assumed true
	
	*/
	
	bubble_volume();//set Vb, all processes must do this 
	
	if(mpi.MyRank == 0)
	{
		Pb = c1 / pow(Vb, GAMMA);
		
		if(ncyc > 1)
		{
			printf("VOLUME CHANGE = (%10.4e, %10.4e, %6f)\n\n", init_volume, Vb, 
									(Vb / init_volume) );
			/*printf("TEMPERATURE CHANGE = (%10.4e, %10.4e, %6f)\n\n", T_INIT, T2, (T2 / T_INIT) );*/
			printf("PRESSURE CHANGE = (%10.4e, %10.4e, %6f)\n\n", init_pressure, Pb, 
									(Pb / init_pressure) );
			printf("ENERGY DELIVERED TOTAL [J]: %10.4e\n\n", Esum);
			fprintf(files.summary, "VOLUME CHANGE = (%10.4e, %10.4e, %6f)\n", init_volume, Vb, 
									(Vb / init_volume) );
			fprintf(files.summary, "TEMPERATURE CHANGE = (%10.4e, %10.4e, %6f)\n", T_INIT, T2, 
								(T2 / T_INIT) );
			fprintf(files.summary, "PRESSURE CHANGE = (%10.4e, %10.4e, %6f)\n", init_pressure, Pb, 
									(Pb / init_pressure) );
			fprintf(files.summary, "ENERGY DELIVERED TOTAL [J]: %10.4e\n", Esum);
			printmax();
		}
	}//if(mpi.MyRank == 0)
	
	//share Pb here
	bcastdata(&Pb, sizeof(double));

	/*======================PRINT TO OUTPUT==============================*/
	double vel_cl = vel_centline();	
	fprintf(files.out,"\n%10.4e\t%10.4e\t%10.4e\t%10.4e\t%10.4e\t%10.4e\n"
		,t, Pb, T_INIT, Vb, vel_cl, jet_energy / Esum);
}

void bubble_volume(void)
{
	/*This function calculates the volume of the bubble at every time step.
	  It should be called by all processes, not just process 0.
	*/
	int i,j,k;
	Vb = 0.0;
	double part_Vb = 0.0;

	for(k = 1; k < km1; k++)
		for(j = 1; j < jm1; j++)
			for(i = 1; i < im1; i++)
			{
				if(z[k] >= BUBBLE_Z_LIM) continue; //region above where bubble can be
				else
				{   //region where bubble can exist
					
					if(ac[IJK] == 1.0 && f[IJK] < em6) 
					{
						part_Vb += pow(delx[i],3);//cell IJK is empty
					}
					else if(ac[IJK] == 1.0  && f[IJK] >= em6 && f[IJK] <= em61)
					{
						part_Vb += (1 - f[IJK]) * vol[IJK];//cell IJK part. full
					}

				}
			}
	/*Reduce all the bubble_vol from all processors onto processor 0*/
    dreduce(&part_Vb, &Vb, 1, OP_SUM);

	if(mpi.MyRank == 0)
	{
		/*Determine if this is a full-bubble, half-bubble or quarter-bubble
		  simulation.  This should only be done by process 0, after all of
		  the partial components of Volume (part_Vb) have been summed and
		  stored onto process 0
		*/
		if(xcent == 0.0 && ycent == 0.0)
		{
			//this is quartet-bubble simulation
			Vb = 4 * Vb;
		}
		else if(xcent == 0.0 || ycent == 0.0)
		{
		//this is half-bubble simulation
			Vb = 2 * Vb;
		}
		else
		{
			//this is full-bubble simulaiton
			Vb = 1 * Vb;
		}
	}

}

double vel_centline(void)
{
	/*This function returns centerline velocity at a point specified by ICL,
	  JCL and KCL in INPUT file
	*/
	int index = ICL + (JCL + KCL * dim.ny) * dim.nx;

	return w[index];
}

