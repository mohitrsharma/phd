#include <stdlib.h>
#include <math.h>
#include "testing.h"
#include "ripple.h"
#include "vector.h"
#include <string.h>/*memcpy*/

void solid_bc_entry () {
	
	// this function sets the solid volume fraction in the ghost cell for entry
	
	if (mpi.Neighbors[5] == -1) {
		
		for (int i=1; i<im1_f; i++)
			for (int j=1; j<jm1_f; j++) {
				
				int k = km1_f - 21;
				
				psi_f[IJK_f] = psin_f[IJKM_f];
			}
	}
	psifine2stnd();
}

void solid_bc_rigid () {
	
	// this function enforces rigid body velocity for the solid
	
	if (mpi.Neighbors[5] == -1) {
		
		for (int i=1; i<im1; i++)
			for (int j=1; j<jm1; j++) {
				
				int k = km1 - 10;
				
				w[IJK] = w[IJKM];
			}
	}
}

void init_sol_weight_quater (st_point *cent, double R) { 
	
	// this function intializes a solid object in a quater domain
	// center of cylinder, radius of cylinder, radius of sphere, concavity
	
	double tx, ty, tz, txm, tym, tzm; 
	double Xcent, Ycent, Zcent,p_vol;
	
	Xcent = cent->x; Ycent = cent->y; Zcent = cent->z;
	double r2 = R*R;
	
	//double sol_length = 144.62e-3;
	double sol_length = 3.0e-3;
	
	for(int i=1;i<im1_f;i++)
		for(int j=1;j<jm1_f;j++)
			for(int k=1;k<km1_f;k++) {
				
				tx = (i+2*mpi.OProc[0]) * (0.5*delx[1]);
				ty = (j+2*mpi.OProc[1]) * (0.5*dely[1]);
				tz = (k+2*mpi.OProc[2]) * (0.5*delz[1]);
				
				txm = tx - (0.5*delx[1]);
				tym = ty - (0.5*dely[1]);
				tzm = tz - (0.5*delz[1]);
				
				if ( MIN(SQUARE(txm-Xcent), SQUARE(tx-Xcent)) + MIN(SQUARE(tym-Ycent), SQUARE(ty-Ycent))>= r2) {
					p_vol=0.0; 
				}
				else if ( MAX(SQUARE(txm-Xcent), SQUARE(tx-Xcent)) + MAX(SQUARE(tym-Ycent), SQUARE(ty-Ycent)) <= r2) {
					p_vol=1.0;
				}
				else {
					p_vol=0.0;
					for (int l=0;l<25;l++)
						for (int m=0;m<25;m++)
							for (int n=0;n<25;n++)
							{	
								if (SQUARE(txm+(l+0.5)/25.0*delx[1]*0.5e0-Xcent) + SQUARE(tym+(m+0.5)/25.0*dely[1]*0.5e0-Ycent) < r2)
								p_vol += 6.4e-5;
							}
				}
				if (tz < Zcent + sol_length && tz > Zcent) psi_f[IJK_f] += p_vol;
	}
	
	double r3 = R*R;
	
	R += 0.5*delx[1];
	r2 = R*R;
	
	for(int i=1;i<im1_f;i++)
		for(int j=1;j<jm1_f;j++)
			for(int k=1;k<km1_f;k++) {
				
				tx = (i+2*mpi.OProc[0]) * (0.5*delx[1]);
				ty = (j+2*mpi.OProc[1]) * (0.5*dely[1]);
				tz = (k+2*mpi.OProc[2]) * (0.5*delz[1]);
				
				txm = tx - (0.5*delx[1]);
				tym = ty - (0.5*dely[1]);
				tzm = tz - (0.5*delz[1]);
				
				if ( MIN(SQUARE(txm-Xcent), SQUARE(tx-Xcent)) + MIN(SQUARE(tym-Ycent), SQUARE(ty-Ycent)) >= r2) {
					p_vol=0.0; 
				}
				else if ( MAX(SQUARE(txm-Xcent), SQUARE(tx-Xcent)) + MAX(SQUARE(tym-Ycent), SQUARE(ty-Ycent)) <= r2 && MAX(SQUARE(txm-Xcent), SQUARE(tx-Xcent)) + MAX(SQUARE(tym-Ycent), SQUARE(ty-Ycent)) >= r3) {
					p_vol=1.0;
				}
				else {
					p_vol=0.0;
					for (int l=0;l<25;l++)
						for (int m=0;m<25;m++)
							for (int n=0;n<25;n++)
							{	
								if (SQUARE(txm+(l+0.5)/25.0*delx[1]*0.5e0-Xcent) + SQUARE(tym+(m+0.5)/25.0*dely[1]*0.5e0-Ycent) < r2 && SQUARE(txm+(l+0.5)/25.0*delx[1]*0.5e0-Xcent) + SQUARE(tym+(m+0.5)/25.0*dely[1]*0.5e0-Ycent) > r3)
								p_vol += 6.4e-5;
							}
				}
				//if (tz < Zcent + 30.0e-3 && tz > Zcent) f_f[IJK_f] += p_vol;
				
				if ( MIN(SQUARE(txm-Xcent), SQUARE(tx-Xcent)) + MIN(SQUARE(tym-Ycent), SQUARE(ty-Ycent)) >= r2) {
					p_vol=0.0; 
				}
				else if ( MAX(SQUARE(txm-Xcent), SQUARE(tx-Xcent)) + MAX(SQUARE(tym-Ycent), SQUARE(ty-Ycent)) <= r2) {
					p_vol=1.0;
				}
				else {
					p_vol=0.0;
					for (int l=0;l<25;l++)
						for (int m=0;m<25;m++)
							for (int n=0;n<25;n++)
							{	
								if (SQUARE(txm+(l+0.5)/25.0*delx[1]*0.5e0-Xcent) + SQUARE(tym+(m+0.5)/25.0*dely[1]*0.5e0-Ycent) < r2)
								p_vol += 6.4e-5;
							}
				}
				if (tz < Zcent + sol_length && tz > Zcent - 0.5*delx[1]) f_f[IJK_f] += p_vol;
	}
	
	R = 44.5e-3;
	r2 = R*R;
	Zcent = Zcent - sol_length - delx[1];
	
	// Remove sphere		
	for(int i=1;i<im1_f;i++)
		for(int j=1;j<jm1_f;j++)
			for(int k=1;k<km1_f;k++) {
				
				tx = (i+2*mpi.OProc[0]) * (0.5*delx[1]);
				ty = (j+2*mpi.OProc[1]) * (0.5*dely[1]);
				tz = (k+2*mpi.OProc[2]) * (0.5*delz[1]);
				
				txm = tx - (0.5*delx[1]);
				tym = ty - (0.5*dely[1]);
				tzm = tz - (0.5*delz[1]);
				
				if ( MIN(SQUARE(txm-Xcent), SQUARE(tx-Xcent)) + MIN(SQUARE(tym-Ycent), SQUARE(ty-Ycent)) + MIN(SQUARE(tzm-Zcent), SQUARE(tz-Zcent)) >= r2) {
					p_vol=0.0; 
				}
				else if ( MAX(SQUARE(txm-Xcent), SQUARE(tx-Xcent)) + MAX(SQUARE(tym-Ycent), SQUARE(ty-Ycent)) + MAX(SQUARE(tzm-Zcent), SQUARE(tz-Zcent)) <= r2) {
					p_vol=1.0;
				}
				else {
					p_vol=0.0;
					for (int l=0;l<25;l++)
						for (int m=0;m<25;m++)
							for (int n=0;n<25;n++)
							{	
								if (SQUARE(txm+(l+0.5)/25.0*delx[1]*0.5e0-Xcent) + SQUARE(tym+(m+0.5)/25.0*dely[1]*0.5e0-Ycent) + SQUARE(tzm+(n+0.5)/25.0*delz[1]*0.5e0-Zcent)< r2)
								p_vol += 6.4e-5;
							}
				}
				//if (tx*tx + ty*ty < 12.7e-3*12.7e-3 && tz < 16e-2) psi_f[IJK_f] += p_vol;
				//psi_f[IJK_f] -= p_vol;
	}
	
	R -= 0.5*delx[1];
	r3 = R*R;
	
	// Now create a film thickness around the solid-sphere-part
	for(int i=1;i<im1_f;i++)
		for(int j=1;j<jm1_f;j++)
			for(int k=1;k<km1_f;k++) {
				
				tx = (i+2*mpi.OProc[0]) * (0.5*delx[1]);
				ty = (j+2*mpi.OProc[1]) * (0.5*dely[1]);
				tz = (k+2*mpi.OProc[2]) * (0.5*delz[1]);
				
				txm = tx - (0.5*delx[1]);
				tym = ty - (0.5*dely[1]);
				tzm = tz - (0.5*delz[1]);
				
				if ( MIN(SQUARE(txm-Xcent), SQUARE(tx-Xcent)) + MIN(SQUARE(tym-Ycent), SQUARE(ty-Ycent)) + MIN(SQUARE(tzm-Zcent), SQUARE(tz-Zcent)) >= r2) {
					p_vol=0.0; 
				}
				else if ( MAX(SQUARE(txm-Xcent), SQUARE(tx-Xcent)) + MAX(SQUARE(tym-Ycent), SQUARE(ty-Ycent)) + MAX(SQUARE(tzm-Zcent), SQUARE(tz-Zcent)) <= r2 && MAX(SQUARE(txm-Xcent), SQUARE(tx-Xcent)) + MAX(SQUARE(tym-Ycent), SQUARE(ty-Ycent)) + MAX(SQUARE(tzm-Zcent), SQUARE(tz-Zcent)) >= r3) {
					p_vol=1.0;
				}
				else {
					p_vol=0.0;
					for (int l=0;l<25;l++)
						for (int m=0;m<25;m++)
							for (int n=0;n<25;n++)
							{	
								if (SQUARE(txm+(l+0.5)/25.0*delx[1]*0.5e0-Xcent) + SQUARE(tym+(m+0.5)/25.0*dely[1]*0.5e0-Ycent) + SQUARE(tzm+(n+0.5)/25.0*delz[1]*0.5e0-Zcent)< r2 && SQUARE(txm+(l+0.5)/25.0*delx[1]*0.5e0-Xcent) + SQUARE(tym+(m+0.5)/25.0*dely[1]*0.5e0-Ycent) + SQUARE(tzm+(n+0.5)/25.0*delz[1]*0.5e0-Zcent)> r3)
								p_vol += 6.4e-5;
							}
				}
				//if (tx*tx + ty*ty < r3 && tx*tx + ty*ty < r2 && tz > Zcent + 21.997e-3) f_f[IJK_f] += p_vol;
	}

	fine2stnd();
}
