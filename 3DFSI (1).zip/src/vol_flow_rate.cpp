#include "ripple.h"
#include "testing.h"
#include <string.h>
#include <math.h>
#include "rtc.h"
#include "itersolv.h"
#include <stdio.h>
#include <stdlib.h>

#include "comm.h"

double vol_flow_rate() {
	double vfr = 0.0;
	int i,j,k;
	double r2 = radius * radius;

	k = 3;
	for(i = 0; i < im1; i++) {
		for(j = 0; j < jm1; j++) {
			if ((SQUARE(xcent - x[i]) + SQUARE(ycent - y[j])) <= r2) {
				vfr += w[IJK]*delx[i]*dely[j];
			}
		}
	}
	return vfr;
}
