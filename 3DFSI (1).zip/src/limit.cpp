#include "ripple.h"

/******************************************************************************
This subroutine initializes kbot and ktop arrays

Subroutine LIMIT is called by:	SETUP, VOFDLY

Subroutine LIMIT calls:			

____________________________NOTES ON CHANGES___________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Commented out a block of code definining kbot. now	Ben			May 19 2005
 kbot should be defined correctly
-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/
void limit()
{
	int i,j,k;
	//initialize kbot and ktop
	for (j=0;j<jmax;j++)
		for (i=0;i<imax;i++)
		{
			kbot[IND(i,j,0)]=km1-1;
			ktop[IND(i,j,0)]=2;
			//kbot[IND(i,j,0)]=-1;	//limits disabled.
			//ktop[IND(i,j,0)]=kmax;	//limits disabled.
		}


	//define all kbot(i,j,0)
	for (i = 1; i < im1; i++)
		for (j = 1; j < jm1; j++)
			for (k = 0; k < km1; k++)
			{
				if (f[IJK] > em6 && ac[IJK] > em6)
				{
					kbot[IND(i-1,j-1,0)]=MIN(k-1,kbot[IND(i-1,j-1,0)]);
					kbot[IND(i-1,j,0)]	=MIN(k-1,kbot[IND(i-1,j,0)]);
					kbot[IND(i-1,j+1,0)]=MIN(k-1,kbot[IND(i-1,j+1,0)]);
					kbot[IND(i,j-1,0)]	=MIN(k-1,kbot[IND(i,j-1,0)]);
					kbot[IND(i,j,0)]	=MIN(k-1,kbot[IND(i,j,0)]);
					kbot[IND(i,j+1,0)]	=MIN(k-1,kbot[IND(i,j+1,0)]);
					kbot[IND(i+1,j-1,0)]=MIN(k-1,kbot[IND(i+1,j-1,0)]);
					kbot[IND(i+1,j,0)]	=MIN(k-1,kbot[IND(i+1,j,0)]);
					kbot[IND(i+1,j+1,0)]=MIN(k-1,kbot[IND(i+1,j+1,0)]);
					break;
				}
			}
	//define all ktop(i,j)
	for (i = 1; i < im1; i++)
		for (j = 1; j < jm1; j++)
			for (k = km1; k >= 1; k--)
			{			
				if (f[IJK] > em6 && ac[IJK] > em6)
				{
					ktop[IND(i-1,j-1,0)]=MAX(k+2,ktop[IND(i-1,j-1,0)]);
					ktop[IND(i-1,j,0)]	=MAX(k+2,ktop[IND(i-1,j,0)]);
					ktop[IND(i-1,j+1,0)]=MAX(k+2,ktop[IND(i-1,j+1,0)]);
					ktop[IND(i,j-1,0)]	=MAX(k+2,ktop[IND(i,j-1,0)]);
					ktop[IND(i,j,0)]	=MAX(k+2,ktop[IND(i,j,0)]);
					ktop[IND(i,j+1,0)]	=MAX(k+2,ktop[IND(i,j+1,0)]);
					ktop[IND(i+1,j-1,0)]=MAX(k+2,ktop[IND(i+1,j-1,0)]);
					ktop[IND(i+1,j,0)]	=MAX(k+2,ktop[IND(i+1,j,0)]);
					ktop[IND(i+1,j+1,0)]=MAX(k+2,ktop[IND(i+1,j+1,0)]);
					break;
				}
			}

	int *kt1,*kt2,*kt3,*kt4,*kb1,*kb2,*kb3,*kb4;
	kt1 = new int[4*NY+4*NX];
	kt2 = kt1+NY;
	kt3 = kt2+NY;
	kt4 = kt3+NX;
	kb1 = kt4+NX;
	kb2 = kb1+NY;
	kb3 = kb2+NY;
	kb4 = kb3+NX;

	for (i=0;i<((NX+NY)<<1) ; i++)
	{
		//set defaults so if no neighbor, limits won't change.
		kt1[i]=0;
		kb1[i]=kmax;
	}
	
	arecvspace<int> (kt2, 1,NY,1, 1,1,1, 1,NY,1, mpi.Neighbors[1], 71);
	arecvspace<int> (kt1, 1,NY,1, 1,1,1, 1,NY,1, mpi.Neighbors[0], 72);
	arecvspace<int> (kb2, 1,NY,1, 1,1,1, 1,NY,1, mpi.Neighbors[1], 75);
	arecvspace<int> (kb1, 1,NY,1, 1,1,1, 1,NY,1, mpi.Neighbors[0], 76);
	sendspace<int> (ktop, NX,NY,1, 2,1,1, 2,NY,1, mpi.Neighbors[0], 71);
	sendspace<int> (ktop, NX,NY,1, NX-1,1,1, NX-1,NY,1, mpi.Neighbors[1], 72);
	sendspace<int> (kbot, NX,NY,1, 2,1,1, 2,NY,1, mpi.Neighbors[0], 75);
	sendspace<int> (kbot, NX,NY,1, NX-1,1,1, NX-1,NY,1, mpi.Neighbors[1], 76);

	arecvspace<int> (kt4, NX,1,1, 1,1,1, NX,1,1, mpi.Neighbors[3], 73);
	arecvspace<int> (kt3, NX,1,1, 1,1,1, NX,1,1, mpi.Neighbors[2], 74);
	arecvspace<int> (kb4, NX,1,1, 1,1,1, NX,1,1, mpi.Neighbors[3], 77);
	arecvspace<int> (kb3, NX,1,1, 1,1,1, NX,1,1, mpi.Neighbors[2], 78);
	sendspace<int> (ktop, NX,NY,1, 1,2,1, NX,2,1, mpi.Neighbors[2], 73);
	sendspace<int> (ktop, NX,NY,1, 1,NY-1,1, NX,NY-1,1, mpi.Neighbors[3], 74);
	sendspace<int> (kbot, NX,NY,1, 1,2,1, NX,2,1, mpi.Neighbors[2], 77);
	sendspace<int> (kbot, NX,NY,1, 1,NY-1,1, NX,NY-1,1, mpi.Neighbors[3], 78);
	arecvspacewait();

	for (j=0;j<NY;j++)
	{
		ktop[IND(0,j,0)] = MAX (ktop[IND(0,j,0)], kt1[j]);
		ktop[IND(1,j,0)] = MAX (ktop[IND(1,j,0)], kt1[j]);
		ktop[IND(im1-1,j,0)] = MAX (ktop[IND(im1-1,j,0)], kt2[j]);
		ktop[IND(im1,j,0)] = MAX (ktop[IND(im1,j,0)], kt2[j]);
		kbot[IND(0,j,0)] = MIN (kbot[IND(0,j,0)], kb1[j]);
		kbot[IND(1,j,0)] = MIN (kbot[IND(1,j,0)], kb1[j]);
		kbot[IND(im1-1,j,0)] = MIN (kbot[IND(im1-1,j,0)], kb2[j]);
		kbot[IND(im1,j,0)] = MIN (kbot[IND(im1,j,0)], kb2[j]);
	}
	for (i=0;i<NX;i++)
	{
		ktop[IND(i,0,0)] = MAX (ktop[IND(i,0,0)], kt3[i]);
		ktop[IND(i,1,0)] = MAX (ktop[IND(i,1,0)], kt3[i]);
		ktop[IND(i,jm1-1,0)] = MAX (ktop[IND(i,jm1-1,0)], kt4[i]);
		ktop[IND(i,jm1,0)] = MAX (ktop[IND(i,jm1,0)], kt4[i]);
		kbot[IND(i,0,0)] = MIN (kbot[IND(i,0,0)], kb3[i]);
		kbot[IND(i,1,0)] = MIN (kbot[IND(i,1,0)], kb3[i]);
		kbot[IND(i,jm1-1,0)] = MIN (kbot[IND(i,jm1-1,0)], kb4[i]);
		kbot[IND(i,jm1,0)] = MIN (kbot[IND(i,jm1,0)], kb4[i]);
	}

	delete [] kt1;

}
