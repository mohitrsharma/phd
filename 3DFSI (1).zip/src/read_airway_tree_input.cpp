#include <stdlib.h>
#include <math.h>
#include "testing.h"
#include "ripple.h"
#include "vector.h"
#include <string.h>/*memcpy*/

char* strlower(char* str);	//not available on UNIX, so reimplemented.

struct entry
{
	char value[56];
	double data;	//integers should be ok sitting in a double variable.
} *entries_airway=0;
int nentries_a=0;

template <class T> void rval(const char *value, T &data)
{
	//if value is defined in the input file, then modify data to its value
	//otherwise, nothing is done.
	//T should be a numeric type: data read from the input file is
	//stored as a double precision number, which is then converted here
	//to type T.

	char temp[56]="";
	strncpy (temp, value, 55);
	temp[55]=0;

	for (int i=0;i<nentries_a;i++)
	{
		if (strcmp (strlower(temp), entries_airway[i].value)==0)
		{
			data = (T)entries_airway[i].data;
			break;
		}
	}
}

void read_airway_tree_input()
{
	char line[256] = "";
	entries_airway = new struct entry[256];	//read at most 256 entries from input file.


	if (mpi.MyRank==0)
	{
		FILE *in = fopen ("airway_tree_input", "rt");

		if (!in)
		{
			printf ("Unable to open input file (airway_tree_input)\n");
			exit (1);
		}

		while (fgets (line, 255, in))
		{
			unsigned int i;
			char value[256]="";
			char *equalindex,*equalindex2;
			char *beginindex=line;
			if (!(equalindex=strchr (line, '='))) continue;	//invalid line.
			equalindex2=equalindex;	//save value for later.
			for (i=0;i<strlen(line);i++)
			{
				if (*beginindex == ' ' || *beginindex == '\t') beginindex++;
				else break;
			}
			if (beginindex == equalindex) continue;	//begin of line is the equal sign...
			for (i=0;i<=(unsigned int)(equalindex-beginindex);i++)
			{
				if (*equalindex == ' ' || *equalindex == '\t' || *equalindex=='=') equalindex--;
				else break;
			}
			if (equalindex-beginindex < 0) continue;	//no value?!
			strncpy (value, beginindex, equalindex-beginindex+1);
			value[equalindex-beginindex+1]=0;

			if (value[0] == '#') continue;	//this is a comment.

			double temp;
			if (sscanf (equalindex2+1, " %lg", &temp) <= 0) continue;	//no data.
			entries_airway[nentries_a].data = temp;
			strncpy (entries_airway[nentries_a].value, value, 55);
			entries_airway[nentries_a].value[55]=0;	//just in case.
			strlower (entries_airway[nentries_a].value);	//lower case for later comparison.
			nentries_a++;
		}

		fclose (in);
	}

	bcastdata (&nentries_a, sizeof(nentries_a));
	if (mpi.MyRank != 0)
		entries_airway = new struct entry[nentries_a+1];
	if (nentries_a > 0)
		bcastdata (entries_airway, sizeof(struct entry)*nentries_a);
}

void read_values(double *plane, double *symmetry, double *N_plug_blockages, double *plug_length, double *plug_center_z, double  *radius_array, double *length_array)
{
	rval("plane", *plane);
	rval("symmetry", *symmetry);
	rval("N_plug_blockages", *N_plug_blockages);
	
	rval("r0", radius_array[0]);
	rval("r1_a", radius_array[1]);
	rval("r1_b", radius_array[2]);
	rval("r2_a", radius_array[3]);
	rval("r2_b", radius_array[4]);
	rval("r2_c", radius_array[5]);
	rval("r2_d", radius_array[6]);
	
	rval("L0", length_array[0]);
	
	rval("L1_a", length_array[1]);
	rval("L1_b", length_array[2]);
	
	rval("L2_a", length_array[3]);
	rval("L2_b", length_array[4]);
	rval("L2_c", length_array[5]);
	rval("L2_d", length_array[6]);
	
	rval("tube_angle", tube_angle); // global
	tube_angle *= pi/180;
	
	rval("film_thickness", film_thickness); // global
	rval("length", *plug_length);
	rval("z_position", *plug_center_z);
}

