#include "ripple.h"
#include <stdlib.h>
#include <time.h>
#include "testing.h"
/************************************************************************
*This subroutine initializes the f-field for dam-break problem
* 
*************************************************************************/
void gfine2stnd(double *S, double *s) ;

#ifdef rudman_fine

void init_scal() {
	int i,j,k,ti,tj,tk;
	
	double tx,ty,tz,txm,tym,tzm;
	double xl,xr,yb,yf,zu,zo,p_vol;
	
	double ftotal=0.0;
	double f_total=0.0;
	  
	radius = 2.5e-6;
	xcent = 3.2e-6;
	ycent = 3.2e-6;
	zcent = 9.0e-6;
	
	double r2=radius*radius;
	double vof;
	
	//loop that initialized the scalar field of a droplet
	for (i=1;i<im1_f;i++) //loop through REAL cells
		for (j=1;j<jm1_f;j++)
			for (k=1;k<km1_f;k++)
			{	
				
				//cell is empty?
				tx = (i+2*mpi.OProc[0])*0.5e0*delx[1]; //global coordinates in fine-grid
				ty = (j+2*mpi.OProc[1])*0.5e0*dely[1];
				tz = (k+2*mpi.OProc[2])*0.5e0*delz[1];
				
				txm = tx-0.5e0*delx[1];
				tym = ty-0.5e0*dely[1];
				tzm = tz-0.5e0*delz[1];
				
				//if(i==1 && j==1 && k==1) printf("processor %d: txm=%.6e tym=%.6e tzm=%.6e\n",mpi.MyRank,txm,tym,tzm);
				
				//goto cube;
				if ( (MIN(SQUARE(txm-xcent), SQUARE(tx-xcent))
					+MIN(SQUARE(tym-ycent), SQUARE(ty-ycent))
					+MIN(SQUARE(tzm-zcent), SQUARE(tz-zcent))
					>= r2))
					vof = 0;
					//f_f[IJK_f]=0;
				//cell is full?
				else if ( MAX(SQUARE(txm-xcent), SQUARE(tx-xcent))
					+MAX(SQUARE(tym-ycent), SQUARE(ty-ycent))
					+MAX(SQUARE(tzm-zcent), SQUARE(tz-zcent))
					<= r2)
					vof = 1.0;
					//f_f[IJK_f]=1.0;
	
				//cell neither empty nor full
				else
				{
					vof = 0.0;
					//f_f[IJK_f]=0.0;
					for (int l=0;l<25;l++)
						for (int m=0;m<25;m++)
							for (int n=0;n<25;n++)
							{	
								
								if (SQUARE(txm+(l+0.5)/25.0*delx[1]*0.5e0-xcent)+
									SQUARE(tym+(m+0.5)/25.0*dely[1]*0.5e0-ycent)+
									SQUARE(tzm+(n+0.5)/25.0*delz[1]*0.5e0-zcent)
									< r2)
									vof += 6.4e-5;
									//f_f[IJK_f]+= 6.4e-5;
							}
				}
				
				scal[IJK_f] += vof;
				//ftotal += f_f[IJK_f]*vol_f[IJK_f];
				//f_total += f_f[IJK_f];
			}
	//For Ytube plug
	double over_face = floor(2*((28.5e-3 + (delx[1]/20))/delx[1]));
	double under_face = floor(2*((23.5e-3)/delx[1]));
	
	int o_f = ((int)over_face) +1;
	int u_f = ((int)under_face) +1;
	
	if( o_f > (km1_f+2*mpi.OProc[2]) ) 
	{
		o_f = km1_f;
	}
	else 
	{
		o_f -= 2*mpi.OProc[2];
	}
	
	if( u_f < (1+2*mpi.OProc[2]) ) 
	{
		u_f = 1;
	}
	else
	{
		u_f -= 2*mpi.OProc[2];
	}
	
	//loop thta initialized f-field for a cylinder
	for(i=1;i<im1_f;i++)
		for(j=1;j<jm1_f;j++)
			for(k=u_f;k<o_f;k++) {
				//cell is empty?
				tx = (i+2*mpi.OProc[0])*0.5e0*delx[1]; //global coordinates in fine-grid
				ty = (j+2*mpi.OProc[1])*0.5e0*dely[1];
				
				txm = tx-0.5e0*delx[1];
				tym = ty-0.5e0*dely[1];
				
				//goto cube;
				if ( MIN(SQUARE(txm-xcent), SQUARE(tx-xcent))
					+MIN(SQUARE(tym-ycent), SQUARE(ty-ycent))
					>= r2)
					f_f[IJK_f]=0;
				//cell is full?
				else if ( MAX(SQUARE(txm-xcent), SQUARE(tx-xcent))
					+MAX(SQUARE(tym-ycent), SQUARE(ty-ycent))
					<= r2)
					f_f[IJK_f]=1.0;
					
				//cell neither empty nor full
				else
				{
					f_f[IJK_f]=0.0;
					for (int l=0;l<25;l++)
						for (int m=0;m<25;m++)
							for (int n=0;n<25;n++)
							{	
								
								if (SQUARE(txm+(l+0.5)/25.0*delx[1]*0.5e0-xcent)+
									SQUARE(tym+(m+0.5)/25.0*dely[1]*0.5e0-ycent)
									< r2)
									f_f[IJK_f]+= 6.4e-5;
							}
				}
			}
	
	// Now I need to take away two spheres to form the plug since we only have a cylinder
	
	zcent = 23.5e-3;
			
	for (i=1;i<im1_f;i++) //loop through REAL cells
		for (j=1;j<jm1_f;j++)
			for (k=1;k<km1_f;k++)
			{	
				
				//cell is empty?
				tx = (i+2*mpi.OProc[0])*0.5e0*delx[1]; //global coordinates in fine-grid
				ty = (j+2*mpi.OProc[1])*0.5e0*dely[1];
				tz = (k+2*mpi.OProc[2])*0.5e0*delz[1];
				
				txm = tx-0.5e0*delx[1];
				tym = ty-0.5e0*dely[1];
				tzm = tz-0.5e0*delz[1];
				
				//if(i==1 && j==1 && k==1) printf("processor %d: txm=%.6e tym=%.6e tzm=%.6e\n",mpi.MyRank,txm,tym,tzm);
				
				//goto cube;
				if ( MIN(SQUARE(txm-xcent), SQUARE(tx-xcent))
					+MIN(SQUARE(tym-ycent), SQUARE(ty-ycent))
					+MIN(SQUARE(tzm-zcent), SQUARE(tz-zcent))
					>= r2)
					f_f[IJK_f] -= 0;
				//cell is full?
				else if ( MAX(SQUARE(txm-xcent), SQUARE(tx-xcent))
					+MAX(SQUARE(tym-ycent), SQUARE(ty-ycent))
					+MAX(SQUARE(tzm-zcent), SQUARE(tz-zcent))
					<= r2)
					f_f[IJK_f] -= f_f[IJK_f];
	
				//cell neither empty nor full
				else
				{
					f_f[IJK_f]=0.0;
					for (int l=0;l<25;l++)
						for (int m=0;m<25;m++)
							for (int n=0;n<25;n++)
							{	
								
								if (SQUARE(txm+(l+0.5)/25.0*delx[1]*0.5e0-xcent)+
									SQUARE(tym+(m+0.5)/25.0*dely[1]*0.5e0-ycent)+
									SQUARE(tzm+(n+0.5)/25.0*delz[1]*0.5e0-zcent)
									< r2)
									f_f[IJK_f] -= f_f[IJK_f];
							}
				}
			}
			
	zcent = 28.5e-3;
			
	for (i=1;i<im1_f;i++) //loop through REAL cells
		for (j=1;j<jm1_f;j++)
			for (k=1;k<km1_f;k++)
			{	
				
				//cell is empty?
				tx = (i+2*mpi.OProc[0])*0.5e0*delx[1]; //global coordinates in fine-grid
				ty = (j+2*mpi.OProc[1])*0.5e0*dely[1];
				tz = (k+2*mpi.OProc[2])*0.5e0*delz[1];
				
				txm = tx-0.5e0*delx[1];
				tym = ty-0.5e0*dely[1];
				tzm = tz-0.5e0*delz[1];
				
				//if(i==1 && j==1 && k==1) printf("processor %d: txm=%.6e tym=%.6e tzm=%.6e\n",mpi.MyRank,txm,tym,tzm);
				
				//goto cube;
				if ( MIN(SQUARE(txm-xcent), SQUARE(tx-xcent))
					+MIN(SQUARE(tym-ycent), SQUARE(ty-ycent))
					+MIN(SQUARE(tzm-zcent), SQUARE(tz-zcent))
					>= r2)
					f_f[IJK_f] -= 0;
				//cell is full?
				else if ( MAX(SQUARE(txm-xcent), SQUARE(tx-xcent))
					+MAX(SQUARE(tym-ycent), SQUARE(ty-ycent))
					+MAX(SQUARE(tzm-zcent), SQUARE(tz-zcent))
					<= r2)
					f_f[IJK_f] -= f_f[IJK_f];
	
				//cell neither empty nor full
				else
				{
					f_f[IJK_f]=0.0;
					for (int l=0;l<25;l++)
						for (int m=0;m<25;m++)
							for (int n=0;n<25;n++)
							{	
								
								if (SQUARE(txm+(l+0.5)/25.0*delx[1]*0.5e0-xcent)+
									SQUARE(tym+(m+0.5)/25.0*dely[1]*0.5e0-ycent)+
									SQUARE(tzm+(n+0.5)/25.0*delz[1]*0.5e0-zcent)
									< r2)
									f_f[IJK_f] -= f_f[IJK_f];
							}
				}
			}
			
		// for plotting map to the coarse grid
		
		xchg_f<double>(scal);
		//physical boundary conditions may be handled later.
		
		
		gfine2stnd(crse_scal,scal);
		xchg<double>(crse_scal); //xchg information at the virtual boundaries
		
	//fprintf (files.sphere, "f_volume = %12.8e, and ftotal = %12.8e\n", ftotal, f_total);
}

#endif
