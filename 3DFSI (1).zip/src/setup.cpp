#include "ripple.h"
#include <stdlib.h>
#include "testing.h"
#include "comm.h"
#include <string.h>
#include <mpi.h>

/******************************************************************************
This subroutine initializes the obstacles, f field, velocity, pressure, density,
viscosity and other relevant arrays.

RINPUT was assumed called earlier

Subroutine SETUP is called by:	RIPPLE

Subroutine SETUP calls:	ASET, RINPUT, MESHSET, INITF, LIMIT, BCF, SETproperties,
						INITREG, NORMALS, BC, SETNF, DT, VOFERR, INITENRG,
						BCE

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

- Subroutine modified to accomodate jet input		Babak		Sep 18 2009
  
- Subroutine modified for the energy equation.      Babak       May 16 2009
  
- meshset(), aset() and saveinput() are set to		Babak		October 21 2008
  be called for both istart=0 and 1. This ensures
  correct startup from dump files.
  
- To ensure agreement between volume fraction,      Babak       October 20 2008
  density and viscosity fields, bc() and bcf()
  are set to be called before setproperties().

- Sub. setrho by setproperties.				   	    Amirreza	December 2 2005
  

_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/
void initreg_plug2();
void gfine2stnd(double *S, double *s);

void setup()
{
	int i,j,k;
#ifdef __solid
	double *psirho_f = temp_f[1];
#endif
	/*
	 * This subroutine initializes all arrays before the big loop starts
	 */

	saveinput();							/* store input file into SUMMARY file */
	meshset();								/* initialize mesh variables, delx, dely, delz, x, y, z, etc... */
	aset();									/* initialize internal obstacles, a_ arrays */
		
	//remove after the rotation test ..ashish
	//delt = (M_PI * (0.5*delx[1])) / (25.0 * 0.15625);
	//delt = (M_PI * (0.5*delx[1])) / (37.5 * 0.15625);
	//twfin = 502 * delt;
	//twfin = 20*delt;
	//dmpdt = 100.0 * delt;
	
	/*t_cent.x = 0.265625; t_cent.y = 0.234375;
	t_cent.z = 0.369691469341;
	
	t_cent.x = t_cent.x / (0.5*delx[1]); 
	t_cent.y = t_cent.y / (0.5*dely[1]);
	t_cent.z = t_cent.z / (0.5*delz[1]);  */
	
	if (istart == 0)						/* if starting from t=0 */
	{
		//if(!ICEM)
#ifndef rudman_fine		 							/* if ICEM is NOT used to generate fluid and obstacles */
	        initf();						/* initialize VOF field, f array for a drop */
	        bcf();
#endif

#ifdef rudman_fine
		  initf_f(); // Also initializes passive scalar
		  fine2stnd(); //use this function whenever we change f_f on the fine grids
		  bcf(); //done for initreg
#ifdef __solid
		setup_rigid_body();
		corr_initf(); // Moved this inside init_ytube which is called inside setup rigid body for ease of use.

#ifdef Ytube		
		memcpy(ytubef_field, f_f, NX_f*NY_f*NZ_f*sizeof(double));
#endif			
		multi_solid_ancillary();
		psifine2stnd(); 
		bcpsi();//done for initreg
		//mirrorArray(f_f);
		fine2stnd(); //because f_f field has been changed again
		bcf(); //for initreg
#endif
#endif	
		initreg();	/* initialize velocity, u, v and w arrays */ //including solid ...AP
//		initreg_plug2();
        }
	else if (istart == 1) {					/* if starting from a dump file */ 
        read_dump();
        //include theta and omega in the dump file later
//-------------------------------------------------------------------------------
#ifdef rudman_fine
#ifdef __solid
	  //some of the following will become a part of the dump file ... but later
	  bcf_f();
	  bcpsi_f();
	  multi_solid_ancillary();
	  psifine2stnd(); 
	  bcpsi(); //for plotting purposes
	  recons_contact_line();
#ifdef Ytube		
	  memcpy(ytubef_field, f_f, NX_f*NY_f*NZ_f*sizeof(double));
	  fine2stnd();
#endif	
	  gfine2stnd(crse_scal,scal);
	  xchg<double>(crse_scal);
	  
	  for(i=1;i<=NBODY;i++) {
		  Omega[i].x = Omega[i].y = Omega[i].z = 0.0;
		  rig_U[i][1]=0.0, rig_U[i][2]=0.0, rig_U[i][3]=0.0;
		  Theta[i].x =0.0, Theta[i].y = 0.0, Theta[i].z = 0.0;
/**
		  if(i==1) {
			double stroke,Ti;
			stroke=0.14; Ti=2.0;
			rig_U[i][1]=(stroke/2.0)*(2.0*M_PI/Ti)*sin(2.0*M_PI*t/Ti);
		  }
		  else if(i==2) {
			  Omega[i].y=1.3762758132718185336008e-03;
			  Theta[i].y=-1.6650290867385071635898e-02;
		  }
		  * **/
	  }

	  //consider all rigid bodies.. because the velocities are not carried in the
	  // dump files
#endif
#endif
//----------------------------------------------------------------------------------	
		idump--;
		twdmp=t;
	}
/*	
#ifndef rudman_fine	//cleaning routines
	voferr();
#endif
	
#ifdef rudman_fine
	voferr_f();
#ifdef __solid
	psierr_f();
#endif
#endif
*/
	bc();
#ifdef rudman_fine
	bcf_f();
#ifdef __solid
	bcpsi_f();
#endif
#endif

	for (i=0;i<imax;i++)					/* setting up density field before proceeding */
		for (j=0;j<jmax;j++)
			for (k=0;k<kmax;k++)
			{
				rho[IJK]=rhof1*f[IJK]+rhof2*(1.0-f[IJK]);
			}

	if (ENERGY)
	{
		initenrg();							/* initialize enthalpy and temperature*/
		bce();								/* apply energy boundary conditions*/
	}
	setproperties();						/* initialize density, viscosity, surface tension, Cp and K */
	dt();									/* initialize time restrictions */
#ifndef rudman_fine
	normals();								/* initialize normals */
	setnf();								/* initialize nf array */
#endif
}
