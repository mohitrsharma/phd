#include "ripple.h"
//#include "TECIO.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "rbd.h"
#include "testing.h"

#define RBD 1
#define TECP 2
#define NONE 0
#define FORMAT RBD
//#define CELLCENTER

/******************************************************************************
This subroutine is used to generate RBD files which can later be converted
using RBD Convert to tecplot binary data files.  

Subroutine TECPF is called by:	NEWCYC

Subroutine TECPF calls:			

____________________________NOTES ON CHANGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

- Subroutine modified to add enthalpy and			Babak		May 16 2009
  temperature to output files
  
- Density and viscosity added to the tecplot        Babak       October 20 2008
  output files         

- Fixed tecpf so that pressure is printed as well	Ben			Oct. 11 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/
float dumy_var;

void tecpf()
{
#if FORMAT==RBD
	//output in "rbd" (raw binary data) format. Use rbd2plt or RBD Convert(WIN32) to
	//convert rbd to TecPlot plt file.

	int i,j,k;
	char fname[256];
	iplot++;
	sprintf (fname, "f%03d-%03d-%04d.rbd", mpi.NProc, mpi.MyRank, iplot);
	
	FILE *out = fopen (fname, "wb");
	double *mat_flgx = temp[0];
	double *mat_flgy = temp[1];
	double *mat_flgz = temp[2];
	double *t_div = temp[13];
	//initialize the RBD header
	struct rbd hdr;
	initrbd (&hdr);
	hdr.nproc = mpi.NProc;
	hdr.rank = mpi.MyRank;
	hdr.count = iplot;
	hdr.nx = dim.nx;
	hdr.ny = dim.ny;
	hdr.nz = dim.nz; 
	hdr.time = t;
	memcpy (hdr.origin, mpi.OProc, 3*sizeof(int));	
	int anz = 11+1; //div-test
	
#ifdef rudman_fine
#ifdef __solid
	anz=anz+1;
#endif

#ifdef print_norm
	anz=anz+5;
#endif

#endif
	hdr.nvar = anz; 
	if (ENERGY) hdr.nvar = anz+5;
	struct vname varnames[18]; 
	strcpy (varnames[0].name, "X              ");
	strcpy (varnames[1].name, "Y              ");
	strcpy (varnames[2].name, "Z              ");
	strcpy (varnames[3].name, "F              ");
	strcpy (varnames[4].name, "U              ");
	strcpy (varnames[5].name, "V              ");
	strcpy (varnames[6].name, "W              ");
	strcpy (varnames[7].name, "P              ");
	strcpy (varnames[8].name, "RHO            ");
	strcpy (varnames[9].name, "XMU            ");
	strcpy (varnames[10].name, "DIV            ");
#ifdef rudman_fine
#ifdef __solid
	strcpy (varnames[11].name, "PSI            ");
	strcpy (varnames[12].name, "SCAL           ");
#endif

#ifdef print_norm
	strcpy (varnames[13].name, "Kappa          ");
	strcpy (varnames[14].name, "X_norm         ");
	strcpy (varnames[15].name, "Y_norm         ");
	strcpy (varnames[16].name, "Z_norm         ");
	strcpy (varnames[17].name, "FVIRT          ");
	

#endif

#endif
	if (ENERGY)
	{
		strcpy (varnames[anz].name, "H");
		strcpy (varnames[anz+1].name, "T");
		strcpy (varnames[anz+2].name, "Cp");
		strcpy (varnames[anz+3].name, "K");
		strcpy (varnames[anz+4].name, "ST");
	}

	//write header to file	  
	if (sizeof(struct rbd) != 64)
	{
		printf ("sizeof rbd isn't 36\n");
		exit (1);
	}
	fwrite (&hdr, sizeof(struct rbd), 1, out);
	fwrite (varnames, sizeof(struct vname), hdr.nvar, out);

	//write data to file
	int n=1;
    //write X
	for (k=0;k<kmax;k++)
		for (j=0;j<jmax;j++)
			for (i=0;i<imax;i++)
			{
				dumy_var = (float)xi[i];
				fwrite (&dumy_var, sizeof(float), 1, out);
			}
	//write Y
	for (k=0;k<kmax;k++)
		for (j=0;j<jmax;j++)
			for (i=0;i<imax;i++)
			{
				dumy_var = (float)yj[j];
				fwrite (&dumy_var, sizeof(float), 1, out);
			}
	//write Z
	for (k=0;k<kmax;k++)
		for (j=0;j<jmax;j++)
			for (i=0;i<imax;i++)
			{
				dumy_var = (float)zk[k];
				fwrite (&dumy_var, sizeof(float), 1, out);
			}
	//write F
	for (i=0; i < NX*NY*NZ; i++)
	{
		dumy_var = (float)f[i];
		fwrite (&dumy_var, sizeof(float), 1, out);
	}
#ifdef CELLCENTER
	//write U
	for (k=0;k<kmax;k++)
		for (j=0;j<jmax;j++)
			for (i=0;i<imax;i++)
			{
				if(i==0)
					dumy_var = (float)u[IJK];
				else if(i==im1)
					dumy_var = (float)u[IMJK];
				else
					dumy_var = (float)((u[IJK]+u[IMJK])/2.0);
				
				fwrite (&dumy_var, sizeof(float), 1, out);
			}
	//write V
	for (k=0;k<kmax;k++)
		for (j=0;j<jmax;j++)
			for (i=0;i<imax;i++)
			{
				if(j==0)
					dumy_var = (float)v[IJK];
				else if(j==jm1)
					dumy_var = (float)v[IJMK];
				else
					dumy_var = (float)((v[IJK]+v[IJMK])/2.0);
				
				fwrite (&dumy_var, sizeof(float), 1, out);
			}
	//write W
	for (k=0;k<kmax;k++)
		for (j=0;j<jmax;j++)
			for (i=0;i<imax;i++)
			{
				if(k==0)
					dumy_var = (float)w[IJK];
				else if(k==km1)
					dumy_var = (float)w[IJKM];
				else
					dumy_var = (float)((w[IJK]+w[IJKM])/2.0);
				
				fwrite (&dumy_var, sizeof(float), 1, out);
			}							
#else
	//write U
	for (i=0; i < NX*NY*NZ; i++)
	{
		dumy_var = (float)u[i];
		fwrite (&dumy_var, sizeof(float), 1, out);
	}
	//write V
	for (i=0; i < NX*NY*NZ; i++)
	{
		dumy_var = (float)v[i];
		fwrite (&dumy_var, sizeof(float), 1, out);
	}
	//write W
	for (i=0; i < NX*NY*NZ; i++)
	{
		dumy_var = (float)w[i];
		fwrite (&dumy_var, sizeof(float), 1, out);
	}
#endif
	//write P
	for (i=0; i < NX*NY*NZ; i++)
	{
		dumy_var = (float)p[i];
		fwrite(&dumy_var, sizeof(float), 1, out);
	}
	//write RHO
	for (i=0; i < NX*NY*NZ; i++)
	{
		dumy_var = (float)rho[i];
		fwrite(&dumy_var, sizeof(float), 1, out);
	}
	//write XMU
	for (i=0; i < NX*NY*NZ; i++)
	{
		dumy_var = (float)xmu[i];
		fwrite(&dumy_var, sizeof(float), 1, out);
	}
	//write DIV
	for (i=0; i < NX*NY*NZ; i++)
	{
		dumy_var = (float)t_div[i];
		fwrite(&dumy_var, sizeof(float), 1, out);
	}
#ifdef rudman_fine
#ifdef __solid
	//write PSI
	for (i=0; i< NX*NY*NZ; i++)
	{
		dumy_var = (float)psi[i];
		fwrite(&dumy_var, sizeof(float), 1, out);
	}
	//write passive SCAL
	for (i=0; i < NX*NY*NZ; i++)
	{
		dumy_var = (float)crse_scal[i];
		fwrite(&dumy_var, sizeof(float), 1, out);
	}
#endif

#ifdef print_norm
	//write kappa
	for (i=0; i< NX*NY*NZ; i++)
	{
		dumy_var = (float)global_kappa[i];
		fwrite(&dumy_var, sizeof(float), 1, out);
	}
	//write x norm
	for (i=0; i < NX*NY*NZ; i++)
	{
		dumy_var = (float)g_normx[i];
		fwrite(&dumy_var, sizeof(float), 1, out);
	}
	//write y norm
	for (i=0; i< NX*NY*NZ; i++)
	{
		dumy_var = (float)g_normy[i];
		fwrite(&dumy_var, sizeof(float), 1, out);
	}
	//write z norm
	for (i=0; i < NX*NY*NZ; i++)
	{
		dumy_var = (float)g_normz[i];
		fwrite(&dumy_var, sizeof(float), 1, out);
	}
	//write fvirt norm
	for (i=0; i < NX*NY*NZ; i++)
	{
		dumy_var = (float)g_fvirt[i];
		fwrite(&dumy_var, sizeof(float), 1, out);
	}

#endif
#endif
	if (ENERGY)
	{
		//write H
		for (i=0; i < NX*NY*NZ; i++)
		{
			dumy_var = (float)h[i];
			fwrite(&dumy_var, sizeof(float), 1, out);
		}
		//write T
		for (i=0; i < NX*NY*NZ; i++)
		{
			dumy_var = (float)tmp[i];
			fwrite(&dumy_var, sizeof(float), 1, out);
		}
		//write Cp
		for (i=0; i < NX*NY*NZ; i++)
		{
			dumy_var = (float)cp[i];
			fwrite(&dumy_var, sizeof(float), 1, out);
		}
		//write K
		for (i=0; i < NX*NY*NZ; i++)
		{
			dumy_var = (float)cond[i];
			fwrite(&dumy_var, sizeof(float), 1, out);
		}
		//write Sigma
		for (i=0; i < NX*NY*NZ; i++)
		{
			dumy_var = (float)sigma[i];
			fwrite(&dumy_var, sizeof(float), 1, out);
		}
	}

	
	//close the output file.
	fclose (out);			 
	fprintf (files.summary,"Written frame %d\n", iplot);
	if (mpi.MyRank ==0)
		printf("Written frame %d\n", iplot);



//******TecPlot format
#elif FORMAT==TECP	

	char fname[256];
	iplot++;
	sprintf (fname, "f%03d-%03d-%04d.plt",mpi.NProc, mpi.MyRank, iplot);

	int Debug=1;
	int VIsDouble=1;

	TECINI ("fname", "X Y Z U V W F", fname, ".", &Debug, &VIsDouble);
	TECZNE ("1", &dim.nx, &dim.ny, &dim.nz, "POINT", "");
	
	int i,j,k,n=1;
	for (k=0;k<kmax;k++)
		for (j=0;j<jmax;j++)
			for (i=0;i<imax;i++)
			{
				TECDAT (&n, &xi[i], &VIsDouble);
				TECDAT (&n, &yj[j], &VIsDouble);
				TECDAT (&n, &zk[k], &VIsDouble);
				TECDAT (&n, &u[IJK], &VIsDouble);
				TECDAT (&n, &v[IJK], &VIsDouble);
				TECDAT (&n, &w[IJK], &VIsDouble);
				TECDAT (&n, &f[IJK], &VIsDouble);
			}
	TECEND();
#endif	
}

#ifdef rudman_fine //function for exporting fine-grid (select) variables
void tecpf_f()
{
#if FORMAT==RBD
	//output in "rbd" (raw binary data) format. Use rbd2plt or RBD Convert(WIN32) to
	//convert rbd to TecPlot plt file.

	int i,j,k;
	char fname[256];
	iplot++;
	sprintf (fname, "f%03d-%03d-%04d.rbd", mpi.NProc, mpi.MyRank, iplot);
	
	FILE *out = fopen (fname, "wb");

	//initialize the RBD header
	struct rbd hdr;
	initrbd (&hdr);
	hdr.nproc = mpi.NProc;
	hdr.rank = mpi.MyRank;
	hdr.count = iplot;
	hdr.nx = (2*dim.nx-2);
	hdr.ny = (2*dim.ny-2);
	hdr.nz = (2*dim.nz-2); 
	hdr.time = t;
	//memcpy (hdr.origin, mpi.OProc, 3*sizeof(int));
	hdr.origin[0] = 2*mpi.OProc[0];
	hdr.origin[1] = 2*mpi.OProc[1];
	hdr.origin[2] = 2*mpi.OProc[2];
	
	int anz = 4;
#ifdef __solid
	anz = 6;
#endif
	hdr.nvar = anz; 
	struct vname varnames[6]; //use # of variables exported
	strcpy (varnames[0].name, "X");
	strcpy (varnames[1].name, "Y");
	strcpy (varnames[2].name, "Z");
	strcpy (varnames[3].name, "F");
#ifdef __solid
	strcpy (varnames[4].name, "VIRTF");
	strcpy (varnames[5].name, "PSI");
#endif
	//write header to file	  
	if (sizeof(struct rbd) != 64)
	{
		printf ("sizeof rbd isn't 36\n");
		exit (1);
	}
	fwrite (&hdr, sizeof(struct rbd), 1, out);
	fwrite (varnames, sizeof(struct vname), hdr.nvar, out);

	//write data to file
	int n=1;
    //write X
	for (k=0;k<kmax_f;k++)
		for (j=0;j<jmax_f;j++)
			for (i=0;i<imax_f;i++)
			{
				dumy_var = (float)((2.0*mpi.OProc[0]+i-0.5)*(0.5*delx[1]));
				fwrite (&dumy_var, sizeof(float), 1, out);
			}
	//write Y
	for (k=0;k<kmax_f;k++)
		for (j=0;j<jmax_f;j++)
			for (i=0;i<imax_f;i++)
			{
				dumy_var = (float)((2.0*mpi.OProc[1]+j-0.5)*(0.5*dely[1]));
				fwrite (&dumy_var, sizeof(float), 1, out);
			}
	//write Z
	for (k=0;k<kmax_f;k++)
		for (j=0;j<jmax_f;j++)
			for (i=0;i<imax_f;i++)
			{
				dumy_var = (float)((2.0*mpi.OProc[2]+k-0.5)*(0.5*delz[1]));
				fwrite (&dumy_var, sizeof(float), 1, out);
			}
	//write F
	for (i=0; i < NX_f*NY_f*NZ_f; i++)
	{
		dumy_var = (float)f_f[i];
		fwrite (&dumy_var, sizeof(float), 1, out);
	}
#ifdef __solid
	//write VIRTF
	for (i=0; i < NX_f*NY_f*NZ_f; i++)
	{
		dumy_var = (float)fvirt_f[i];
		fwrite(&dumy_var, sizeof(float), 1, out);
	}
	//write PSI
	for (i=0; i< NX_f*NY_f*NZ_f; i++)
	{
		dumy_var = (float)psi_f[i];
		fwrite(&dumy_var, sizeof(float), 1, out);
	}
#endif
	//close the output file.
	fclose (out);			 
	fprintf (files.summary,"Written frame %d\n", iplot);
	if (mpi.MyRank ==0)
		printf("Written frame %d\n", iplot);

#endif	
}
#endif
