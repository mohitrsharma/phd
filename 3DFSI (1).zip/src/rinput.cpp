#include "ripple.h"
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>	//exit
#include "testing.h"
/******************************************************************************
This subroutine reads the input from the file called input and stores it in
the appropriate arrays

Subroutine RINPUT is called by:	SETUP

Subroutine RINPUT calls:

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											 NAME		DATE

- New modification for variable properties added.	 Babak		Sep 13 2009
  STILL UNDER CONSTRUCTION
  
- New variables for energy calculations added        Babak		May 15 2009

- Changed OBST_FLAG to simply OBSTACLE               Ben        July 14 2005

- Added OBST_FLAG variable to be read by readfile()	 Ben		Sept 12 2005

- Deleting xmu=xmuf1*rhof1; at the end of Subrotine				Dec.5, 2005

_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

char* strlower(char* str)	//not available on UNIX, so reimplemented.
{
	const int len = strlen(str);
	for (int i=0;i<len;i++)
		if (str[i]>='A' && str[i]<='Z')
			str[i] |= 32;
	return str;
}

struct entry
{
	char value[56];
	double data;	//integers should be ok sitting in a double variable.
} *entries=0;
int nentries=0;

void readfile()
{
	char line[256] = "";
	entries = new struct entry[256];	//read at most 256 entries from input file.


	if (mpi.MyRank==0)
	{
		FILE *in = fopen ("input", "rt");

		if (!in)
		{
			printf ("Unable to open input file (input)\n");
			exit (1);
		}

		while (fgets (line, 255, in))
		{
			unsigned int i;
			char value[256]="";
			char *equalindex,*equalindex2;
			char *beginindex=line;
			if (!(equalindex=strchr (line, '='))) continue;	//invalid line.
			equalindex2=equalindex;	//save value for later.
			for (i=0;i<strlen(line);i++)
			{
				if (*beginindex == ' ' || *beginindex == '\t') beginindex++;
				else break;
			}
			if (beginindex == equalindex) continue;	//begin of line is the equal sign...
			for (i=0;i<=(unsigned int)(equalindex-beginindex);i++)
			{
				if (*equalindex == ' ' || *equalindex == '\t' || *equalindex=='=') equalindex--;
				else break;
			}
			if (equalindex-beginindex < 0) continue;	//no value?!
			strncpy (value, beginindex, equalindex-beginindex+1);
			value[equalindex-beginindex+1]=0;

			if (value[0] == '#') continue;	//this is a comment.

			double temp;
			if (sscanf (equalindex2+1, " %lg", &temp) <= 0) continue;	//no data.
			entries[nentries].data = temp;
			strncpy (entries[nentries].value, value, 55);
			entries[nentries].value[55]=0;	//just in case.
			strlower (entries[nentries].value);	//lower case for later comparison.
			nentries++;
		}

		fclose (in);
	}

	bcastdata (&nentries, sizeof(nentries));
	if (mpi.MyRank != 0)
		entries = new struct entry[nentries+1];
	if (nentries > 0)
		bcastdata (entries, sizeof(struct entry)*nentries);
}
void cleanup()
{
	if (entries && nentries) delete [] entries;
	nentries=0;
}
template <class T> void rval(const char *value, T &data)
{
	//if value is defined in the input file, then modify data to its value
	//otherwise, nothing is done.
	//T should be a numeric type: data read from the input file is
	//stored as a double precision number, which is then converted here
	//to type T.

	char temp[56]="";
	strncpy (temp, value, 55);
	temp[55]=0;

	for (int i=0;i<nentries;i++)
	{
		if (strcmp (strlower(temp), entries[i].value)==0)
		{
			data = (T)entries[i].data;
			break;
		}
	}
}
void rinput()
{

	/*set default values*/

	CGITER = 1;
    BUBBLE = 0;
    DELTADJ = true;
    ICEM = false;
	ENERGY = false;
	VARPROP = false;

	//multigrid
	npre = 5;
	npost = 5;
	ntop = 15;
	mgcycles = 5;
	omega = 1.15;
	maxres=1e-9;

	//numparam
	con=0.3;
	frctn=5e-7;

	//fldparam
	psat=0.0;

	//mesh
	dim.nx=10;
	dim.ny=10;
	dim.nz=10;

	//constants...
	emf = 1e-6;
	emf1 = 1.0-emf;
	em10 = 1.0e-10;
	ep10 = 1.0e+10;
	em6p1 = 1.0+1e-6;
	em61 = 1.0-1e-6;
	pi=acos (-1.0);
	pi2 = pi/2.0;
	rpd = pi/180.0;

	/*initialize selected variables*/
	t=0.0;
	flgc=0.0;
	deltold=0.0;
	twplt=0.0;
	twprt=0.0;
	twdata=0.0;
	twdmp=0.0;
	vchgt=0.0;
#ifdef rudman_fine
	t_prob=0, t_prob2=0; //for debuggin' .. reset to 1 (0) just before (after) using it
	p_flg = 0;
#ifdef __solid
	pvchgt = 0.0;
	rhof0 = 7700; // 1053.0;//335.53;//629.92; //for RME test WEC
#endif
#endif
	iter=0;
	ncyc=0;
	nflgc=0;
	nocon=0;
	iplot=0;
	idump=0;
	islice=0;
	ica=0;
	strcpy (idt, "g");

	/*read initial input data*/
	readfile ();

	rval("CGITER",CGITER);
	rval("DELTADJ",DELTADJ);
	rval("ICEM",ICEM);
	rval("ENERGY",ENERGY);
	rval("VARPROP",VARPROP);

	if (!ENERGY && VARPROP)
	{
		printf ("ERROR: To use variable properties ENERGY equation must be solved\n");
		exit (1);
	}

    /*numparam*/
	rval("delt", delt);
	rval("twfin", twfin);
	rval("prtdt",prtdt);
	rval("pltdt",pltdt);
	rval("datadt",datadt);
	rval("dmpdt",dmpdt);
   	rval("kr",kr);
	rval("kl",kl);
	rval("kf",kf);
	rval("kb",kb);
	rval("ko",ko);
	rval("ku",ku);
   	rval("ker",ker);
	rval("kel",kel);
	rval("kef",kef);
	rval("keb",keb);
	rval("keo",keo);
	rval("keu",keu);
	rval("con",con);
	rval("frctn",frctn);
   	rval("istart",istart);

	/*fldparam*/
	rval("rhof1",rhof1);
	rval("rhof2",rhof2);
	rval("xmuf1",xmuf1);
	rval("xmuf2",xmuf2);
	rval("stf1",stf1);
	rval("uf1",uf1);
	rval("vf1",vf1);
	rval("wf1",wf1);
	rval("uf2",uf2);
	rval("vf2",vf2);
	rval("wf2",wf2);
	rval("gx",gx);
	rval("gy",gy);
	rval("gz",gz);
	rval("psat",psat);
	rval("cangler",cangler);
	rval("canglel",canglel);
	rval("canglet",canglet);
	rval("cangleb",cangleb);
	rval("cangleo",cangleo);
	rval("cangleu",cangleu);
	rval("bcvl",bcvl);
	rval("bcvr",bcvr);
	rval("bcvb",bcvb);
	rval("bcvf",bcvf);
	rval("bcvu",bcvu);
	rval("bcvo",bcvo);
	rval("radius",radius);
	rval("xcent",xcent);
	rval("ycent",ycent);
	rval("zcent",zcent);
    rval("condf1",condf1);
	rval("condf2",condf2);
	rval("cpf1",cpf1);
	rval("cpf2",cpf2);
	rval("h0f2",h0f2);
	rval("tif1",tif1);
	rval("tif2",tif2);

	/*mesh*/
	rval("fx",dim.fx);
	rval("fy",dim.fy);
	rval("fz",dim.fz);
	rval("xe",xe);
	rval("dxmn",dxmn);
	rval("xmn",xmn);
	rval("nxmn",nxmn);
	rval("ye",ye);
	rval("dymn",dymn);
	rval("ymn",ymn);
	rval("nymn",nymn);
	rval("ze",ze);
	rval("dzmn",dzmn);
	rval("zmn",zmn);
	rval("nzmn",nzmn);

	/*multigrid*/
	rval("npre",npre);
	rval("npost",npost);
	rval("ntop",ntop);
	rval("mgcycles",mgcycles);
	rval("omega",omega);
	rval("maxres",maxres);
	minmgcycles = mgcycles;

	cleanup();

	//convert degrees to radians, other stuff.
	cangler *= rpd;
	canglel *= rpd;
	canglet *= rpd;
	cangleb *= rpd;
	cangleo *= rpd;
	cangleu *= rpd;
	//frsurf=frctn*rhof1;

	//minimum timestep
	dtend = 0.002*delt;

	if (VARPROP)
	{
		int i;
		
		FILE *inf1 = fopen ("f1prop", "rt");
		FILE *inf2 = fopen ("f2prop", "rt");

		if (!inf1 || !inf2)
		{
			printf ("Unable to open properties input file (f1prop or f2prop)\n");
			exit (1);
		}

		fscanf(inf1,"%d",&nFLUID1);
		for (i = 0; i < nFLUID1; i++)
			fscanf(inf1,"%lf%lf%lf%lf%lf",&FLUID1_T[i], &FLUID1_xmu[i], &FLUID1_st[i], &FLUID1_Cp[i], &FLUID1_K[i]);

		fscanf(inf2,"%d",&nFLUID2);
		for (i = 0; i < nFLUID2; i++)
			fscanf(inf2,"%lf%lf%lf%lf%lf",&FLUID2_T[i], &FLUID2_xmu[i], &FLUID2_st[i], &FLUID2_Cp[i], &FLUID2_K[i]);
		
		fclose(inf1);
		fclose(inf2);
	}
}
