#include <math.h>
#include "ripple.h"
#include "comm.h"
#include "testing.h"

/******************************************************************************
This subroutine NORMALSOBS

Subroutine NORMALSOBS is called by:	NORMALS

Subroutine NORMALSOBS calls:	ISOBSTSFC

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

void normalsobs(double *ftildeobs)
{
	int i, j, k, tk, tj, ti;

	if(ftildeobs != NULL)      /* If first time calling normalsobs from normals */
	{
		/*
        ** first copy ftilde velocities in obstacle surface cells
        */
		for(k=1;k<km1;k++)
			for(j=1;j<jm1;j++)
				for(i=1;i<im1;i++)
				{
					/*if current cell is obstacle interface cell*/
					if (isobstsfc(IJK))
					{
						/*if obst. is on the RIGHT of fluid*/
						if (obst[IJK].flag_r)
							ftildeobs[IJK] = ftildeobs[IMJK];
						/*if obst. is on the LEFT of fluid*/
						if (obst[IJK].flag_l)
							ftildeobs[IJK] = ftildeobs[IPJK];
						/*if obst. is in of the FRONT of fluid*/
						if (obst[IJK].flag_f)
							ftildeobs[IJK] = ftildeobs[IJMK];
						/*if obst. is on the BACK of fluid*/
						if (obst[IJK].flag_b)
							ftildeobs[IJK] = ftildeobs[IJPK];
						/*if obst. is OVER the fluid*/
						if (obst[IJK].flag_o)
							ftildeobs[IJK] = ftildeobs[IJKM];
						/*if obst. is UNDER the fluid*/
						if (obst[IJK].flag_u)
							ftildeobs[IJK] = ftildeobs[IJKP];
					}
			}

    }
    else
    {
        /*apply contact angles to obstacles*/
        //copy gradro_ form 2 cells left/right, front/back over/under the
        //obstacle to 1 cell left/right, front/back over/under the obst.
        //just like copying form k=2 to k=1 is done in normals. This is
        //more general.  it will be valid for any direction.
        for(k = 1; k < km1; k++)
            for(j = 1; j < jm1; j++)
                for(i = 1; i < im1; i++)
                {
                    if(isobstsfc(IJK))
                    {
                        if(obst[IJK].flag_r)       /*if obstacle cell is to the RIGHT of fluid	cell*/
                        {
                            gradrox[IMJK] = gradrox[IMJK - 1];
                            gradroy[IMJK] = gradroy[IMJK - 1];
                            gradroz[IMJK] = gradroz[IMJK - 1];
                        }

                        if(obst[IJK].flag_l)        /*if obstacle cell is to the LEFT of fluid	cell*/
                        {
                            gradrox[IPJK] = gradrox[IPJK + 1];
                            gradroy[IPJK] = gradroy[IPJK + 1];
                            gradroz[IPJK] = gradroz[IPJK + 1];
                        }

                        if(obst[IJK].flag_f)        /*if obstacle cell is to the FRONT of fluid	cell*/
                        {
                            gradrox[IJMK] = gradrox[IJMK - imax];
                            gradroy[IJMK] = gradroy[IJMK - imax];
                            gradroz[IJMK] = gradroz[IJMK - imax];
                        }

                        if(obst[IJK].flag_b)        /*if obstacle cell is to the BACK of fluid	cell*/
                        {
                            gradrox[IJPK] = gradrox[IJPK + imax];
                            gradroy[IJPK] = gradroy[IJPK + imax];
                            gradroz[IJPK] = gradroz[IJPK + imax];
                        }

                        if(obst[IJK].flag_o)        /*if obstacle cell is to the OVER of fluid	cell*/
                        {
                            gradrox[IJKM] = gradrox[IJKM - ijmax];
                            gradroy[IJKM] = gradroy[IJKM - ijmax];
                            gradroz[IJKM] = gradroz[IJKM - ijmax];
                        }

                        if(obst[IJK].flag_u)      /*if obstacle cell is to the UNDER of fluid	cell*/
                        {
                            gradrox[IND(i,j,k+1)] = gradrox[IND(i,j,k+2)];
                            gradroy[IND(i,j,k+1)] = gradroy[IND(i,j,k+2)];
                            gradroz[IND(i,j,k+1)] = gradroz[IND(i,j,k+2)];
                        }

                    }/*if osbstacle*/
                }/*for IJK*/

        /*use CA_4x4*/
        if (ncyc != 0)
        {
            double rca=0.0;	 //used for 'contact angle as function of velocity'
            int nca=0;

            for (tk=1;tk<km1;tk++)
                for (tj=1;tj<jm1;tj++)
                    for (ti=1;ti<im1;ti++)
                    {
                        if (isobstsfc(IND(ti,tj,tk)))
                        {
                            if (obst[IND(ti,tj,tk)].flag_l)      /*obstacle cell to the LEFT of fluid cell*/
                            {
                                i = ti + 1;
                                j = tj;
                                k = tk;
                                //if the 2x2 stencil about the ndoe is either completely
                                //full or completely empty, forget about a contact angle.
                                const double f4=f[IJK]+f[IJKM]+f[IJMK]+f[IJMKM];

                                if (f4==0.0 || f4==4.0) continue;

                                //so there's fluid within the 2x2 stencil; now can I find
                                //an empty cell in the 4x4 stencil?
                                const int ijmkm2 	= (k==1)? IJMKM	: IJMKM - ijmax;
                                const int ijkm2 	= (k==1)? IJKM 	: IJKM 	- ijmax;
                                const int ijpkm2	= (k==1)? IJPKM	: IJPKM	- ijmax;
                                const int ijm2kp 	= (j==1)? IJMKP	: IJMKP - imax;
                                const int ijm2k 	= (j==1)? IJMK	: IJMK 	- imax;
                                const int ijm2km 	= (j==1)? IJMKM	: IJMKM - imax;
                                int ijm2km2 = IJMKM-imax-ijmax;
                                if (k==1) ijm2km2+=ijmax;
                                if (j==1) ijm2km2+=imax;

                                if (f[IJPKM]!=0.0)
                                if (f[IJPK]!=0.0)
                                if (f[IJPKP]!=0.0)
                                if (f[IJKP]!=0.0)
                                if (f[IJMKP]!=0.0)
                                if (f[ijmkm2]!=0.0)
                                if (f[ijkm2]!=0.0)
                                if (f[ijpkm2]!=0.0)
                                if (f[ijm2kp]!=0.0)
                                if (f[ijm2k]!=0.0)
                                if (f[ijm2km]!=0.0)
                                if (f[ijm2km2]!=0.0)
                                    continue;	//can't find a nearby empty cell.

                                //apply a contact angle to node (i,j,k)
                                const double gradro1=sqrt(SQUARE(gradrox[IJK])+SQUARE(gradroy[IJK])+SQUARE(gradroz[IJK]));
                                const double gradroyz=sqrt(SQUARE(gradroy[IJK])+SQUARE(gradroz[IJK]));
                                //constant contact angle
                                gradrox[IJK] = gradroyz * tan(canglel - pi2);

                                const double gradro2=sqrt(SQUARE(gradrox[IJK])+SQUARE(gradroy[IJK])+SQUARE(gradroz[IJK])+em6);
                                gradrox[IJK]*=gradro1/gradro2;
                                gradroy[IJK]*=gradro1/gradro2;
                                gradroz[IJK]*=gradro1/gradro2;;
                            }

                            if (obst[IND(ti,tj,tk)].flag_r)      /*obstacle cell to the RIGHT of fluid cell*/
                            {
                                i = ti - 1;
                                j = tj;
                                k = tk;
                                //if the 2x2 stencil about the ndoe is either completely
                                //full or completely empty, forget about a contact angle.
                                const double f4=f[IJK]+f[IJKM]+f[IJMK]+f[IJMKM];

                                if (f4==0.0 || f4==4.0) continue;

                                //so there's fluid within the 2x2 stencil; now can I find
                                //an empty cell in the 4x4 stencil?
                                const int ijmkm2 	= (k==1)? IJMKM	: IJMKM - ijmax;
                                const int ijkm2 	= (k==1)? IJKM 	: IJKM 	- ijmax;
                                const int ijpkm2	= (k==1)? IJPKM	: IJPKM	- ijmax;
                                const int ijm2kp 	= (j==1)? IJMKP	: IJMKP - imax;
                                const int ijm2k 	= (j==1)? IJMK	: IJMK 	- imax;
                                const int ijm2km 	= (j==1)? IJMKM	: IJMKM - imax;
                                int ijm2km2 = IJMKM-imax-ijmax;
                                if (k==1) ijm2km2+=ijmax;
                                if (j==1) ijm2km2+=imax;

                                if (f[IJPKM]!=0.0)
                                if (f[IJPK]!=0.0)
                                if (f[IJPKP]!=0.0)
                                if (f[IJKP]!=0.0)
                                if (f[IJMKP]!=0.0)
                                if (f[ijmkm2]!=0.0)
                                if (f[ijkm2]!=0.0)
                                if (f[ijpkm2]!=0.0)
                                if (f[ijm2kp]!=0.0)
                                if (f[ijm2k]!=0.0)
                                if (f[ijm2km]!=0.0)
                                if (f[ijm2km2]!=0.0)
                                    continue;	//can't find a nearby empty cell.

                                //apply a contact angle to node (i,j,k)
                                const double gradro1=sqrt(SQUARE(gradrox[IJK])+SQUARE(gradroy[IJK])+SQUARE(gradroz[IJK]));
                                const double gradroyz=sqrt(SQUARE(gradroy[IJK])+SQUARE(gradroz[IJK]));
                                //constant contact angle
                                gradrox[IJK] = gradroyz * tan(cangler - pi2);

                                const double gradro2=sqrt(SQUARE(gradrox[IJK])+SQUARE(gradroy[IJK])+SQUARE(gradroz[IJK])+em6);
                                gradrox[IJK]*=gradro1/gradro2;
                                gradroy[IJK]*=gradro1/gradro2;
                                gradroz[IJK]*=gradro1/gradro2;;
                            }

                            if (obst[IND(ti,tj,tk)].flag_b)    /*obstacle cell to the BACK of fluid cell*/
                            {
                                i = ti;
                                j = tj + 1;
                                k = tk;
                                //if the 2x2 stencil about the ndoe is either completely
                                //full or completely empty, forget about a contact angle.
                                const double f4=f[IJK]+f[IJKM]+f[IMJK]+f[IMJKM];

                                if (f4==0.0 || f4==4.0) continue;

                                //so there's fluid within the 2x2 stencil; now can I find
                                //an empty cell in the 4x4 stencil?
                                const int im2jkm	= (i==1)? IMJKM	: IMJKM - 1;
                                const int im2jk 	= (i==1)? IMJK 	: IMJK 	- 1;
                                const int im2jkp	= (i==1)? IMJKP	: IMJKP - 1;
                                const int ipjkm2	= (k==1)? IPJKM	: IPJKM - ijmax;
                                const int ijkm2 	= (k==1)? IJKM	: IJKM 	- ijmax;
                                const int imjkm2 	= (k==1)? IMJKM	: IMJKM - ijmax;
                                int im2jkm2 = IMJKM-ijmax-1;
                                if (i==1) im2jkm2++;
                                if (k==1) im2jkm2+=ijmax;

                                if (f[IMJKP]!=0.0)
                                if (f[IJKP]!=0.0)
                                if (f[IPJKP]!=0.0)
                                if (f[IPJK]!=0.0)
                                if (f[IPJKM]!=0.0)
                                if (f[im2jkm]!=0.0)
                                if (f[im2jk]!=0.0)
                                if (f[im2jkp]!=0.0)
                                if (f[ipjkm2]!=0.0)
                                if (f[ijkm2]!=0.0)
                                if (f[imjkm2]!=0.0)
                                if (f[im2jkm2]!=0.0)
                                continue;	//can't find a nearby empty cell.

                                //apply a contact angle to node (i,j,k)
                                const double gradro1=sqrt(SQUARE(gradrox[IJK])+SQUARE(gradroy[IJK])+SQUARE(gradroz[IJK]));
                                const double gradroxz=sqrt(SQUARE(gradrox[IJK])+SQUARE(gradroz[IJK]));
                                //constant contact angle
                                gradroy[IJK] = gradroxz * tan(cangleb - pi2);

                                const double gradro2=sqrt(SQUARE(gradrox[IJK])+SQUARE(gradroy[IJK])+SQUARE(gradroz[IJK])+em6);
                                gradrox[IJK]*=gradro1/gradro2;
                                gradroy[IJK]*=gradro1/gradro2;
                                gradroz[IJK]*=gradro1/gradro2;;
                            }

                            if (obst[IND(ti,tj,tk)].flag_f)    /*obstacle cell to the FRONT of fluid cell*/
                            {
                                i = ti;
                                j = tj - 1;
                                k = tk;
                                //if the 2x2 stencil about the ndoe is either completely
                                //full or completely empty, forget about a contact angle.
                                const double f4=f[IJK]+f[IJKM]+f[IMJK]+f[IMJKM];

                                if (f4==0.0 || f4==4.0) continue;

                                //so there's fluid within the 2x2 stencil; now can I find
                                //an empty cell in the 4x4 stencil?
                                const int im2jkm	= (i==1)? IMJKM	: IMJKM - 1;
                                const int im2jk 	= (i==1)? IMJK 	: IMJK 	- 1;
                                const int im2jkp	= (i==1)? IMJKP	: IMJKP - 1;
                                const int ipjkm2	= (k==1)? IPJKM	: IPJKM - ijmax;
                                const int ijkm2 	= (k==1)? IJKM	: IJKM 	- ijmax;
                                const int imjkm2 	= (k==1)? IMJKM	: IMJKM - ijmax;
                                int im2jkm2 = IMJKM-ijmax-1;
                                if (i==1) im2jkm2++;
                                if (k==1) im2jkm2+=ijmax;

                                if (f[IMJKP]!=0.0)
                                if (f[IJKP]!=0.0)
                                if (f[IPJKP]!=0.0)
                                if (f[IPJK]!=0.0)
                                if (f[IPJKM]!=0.0)
                                if (f[im2jkm]!=0.0)
                                if (f[im2jk]!=0.0)
                                if (f[im2jkp]!=0.0)
                                if (f[ipjkm2]!=0.0)
                                if (f[ijkm2]!=0.0)
                                if (f[imjkm2]!=0.0)
                                if (f[im2jkm2]!=0.0)
                                continue;	//can't find a nearby empty cell.

                                //apply a contact angle to node (i,j,k)
                                const double gradro1=sqrt(SQUARE(gradrox[IJK])+SQUARE(gradroy[IJK])+SQUARE(gradroz[IJK]));
                                const double gradroxz=sqrt(SQUARE(gradrox[IJK])+SQUARE(gradroz[IJK]));
                                //constant contact angle
                                gradroy[IJK] = gradroxz * tan(canglet - pi2);

                                const double gradro2=sqrt(SQUARE(gradrox[IJK])+SQUARE(gradroy[IJK])+SQUARE(gradroz[IJK])+em6);
                                gradrox[IJK]*=gradro1/gradro2;
                                gradroy[IJK]*=gradro1/gradro2;
                                gradroz[IJK]*=gradro1/gradro2;;
                            }

                            if (obst[IND(ti,tj,tk)].flag_u)    /*obstacle cell UNDER fluid cell*/
                            {
                                i = ti;
                                j = tj;
                                k = tk + 1;
                                //if the 2x2 stencil about the ndoe is either completely
                                //full or completely empty, forget about a contact angle.
                                const double f4=f[IJK]+f[IMJK]+f[IJMK]+f[IMJMK];
                                //if (f4<1.0 || f4 > 3.0) continue;
                                if (f4==0.0 || f4==4.0) continue;

                                //so there's fluid within the 2x2 stencil; now can I find
                                //an empty cell in the 4x4 stencil?
                                const int im2jmk    = (i==1)? IMJMK : IMJMK - 1;
                                const int im2jk     = (i==1)? IMJK  : IMJK  - 1;
                                const int im2jpk	= (i==1)? IMJPK : IMJPK - 1;
                                const int ipjm2k    = (j==1)? IPJMK : IPJMK - imax;
                                const int ijm2k     = (j==1)? IJMK  : IJMK  - imax;
                                const int imjm2k    = (j==1)? IMJMK : IMJMK - imax;
                                int im2jm2k = IMJMK-imax-1;
                                if (i==1) im2jm2k++;
                                if (j==1) im2jm2k+=imax;

                                if (f[IMJPK]!=0.0)
                                if (f[IJPK]!=0.0)
                                if (f[IPJPK]!=0.0)
                                if (f[IPJK]!=0.0)
                                if (f[IPJMK]!=0.0)
                                if (f[im2jmk]!=0.0)
                                if (f[im2jk]!=0.0)
                                if (f[im2jpk]!=0.0)
                                if (f[ipjm2k]!=0.0)
                                if (f[ijm2k]!=0.0)
                                if (f[imjm2k]!=0.0)
                                if (f[im2jm2k]!=0.0)
                                continue;	//can't find a nearby empty cell.

                                /*apply a contact angle to node (i,j,k)*/
                                const double gradro1=sqrt(SQUARE(gradrox[IJK])+SQUARE(gradroy[IJK])+SQUARE(gradroz[IJK]));
                                const double gradroxy=sqrt(SQUARE(gradrox[IJK])+SQUARE(gradroy[IJK]));
                                /*constant contact angle*/
                                //gradroz[IJK]=gradroxy*tan(cangleu-pi2);
                                /*contact angle as function of line velocity*/
                                double varca=cangle(5,i,j,1);
                                rca += varca;
                                nca ++;
                                gradroz[IJK]=gradroxy*tan(varca-pi2);
                                const double gradro2=sqrt(SQUARE(gradrox[IJK])+SQUARE(gradroy[IJK])+SQUARE(gradroz[IJK])+em6);
                                gradrox[IJK]*=gradro1/gradro2;
                                gradroy[IJK]*=gradro1/gradro2;
                                gradroz[IJK]*=gradro1/gradro2;
                            }

                            if (obst[IND(ti,tj,tk)].flag_o)    /*obstacle cell OVER fluid cell*/
                            {
                                i = ti;
                                j = tj;
                                k = tk - 1;
                                //if the 2x2 stencil about the ndoe is either completely
                                //full or completely empty, forget about a contact angle.
                                const double f4=f[IJK]+f[IMJK]+f[IJMK]+f[IMJMK];
                                //if (f4<1.0 || f4 > 3.0) continue;
                                if (f4==0.0 || f4==4.0) continue;

                                //so there's fluid within the 2x2 stencil; now can I find
                                //an empty cell in the 4x4 stencil?
                                const int im2jmk    = (i==1)? IMJMK : IMJMK - 1;
                                const int im2jk     = (i==1)? IMJK  : IMJK  - 1;
                                const int im2jpk    = (i==1)? IMJPK : IMJPK - 1;
                                const int ipjm2k    = (j==1)? IPJMK : IPJMK - imax;
                                const int ijm2k     = (j==1)? IJMK  : IJMK  - imax;
                                const int imjm2k    = (j==1)? IMJMK : IMJMK - imax;
                                int im2jm2k = IMJMK-imax-1;
                                if (i==1) im2jm2k++;
                                if (j==1) im2jm2k+=imax;

                                if (f[IMJPK]!=0.0)
                                if (f[IJPK]!=0.0)
                                if (f[IPJPK]!=0.0)
                                if (f[IPJK]!=0.0)
                                if (f[IPJMK]!=0.0)
                                if (f[im2jmk]!=0.0)
                                if (f[im2jk]!=0.0)
                                if (f[im2jpk]!=0.0)
                                if (f[ipjm2k]!=0.0)
                                if (f[ijm2k]!=0.0)
                                if (f[imjm2k]!=0.0)
                                if (f[im2jm2k]!=0.0)
                                continue;   //can't find a nearby empty cell.

                                //apply a contact angle to node (i,j,k)
                                const double gradro1=sqrt(SQUARE(gradrox[IJK])+SQUARE(gradroy[IJK])+SQUARE(gradroz[IJK]));
                                const double gradroxy=sqrt(SQUARE(gradrox[IJK])+SQUARE(gradroy[IJK]));
                                //constant contact angle
                                gradroz[IJK]=gradroxy*tan(cangleo-pi2);

                                const double gradro2=sqrt(SQUARE(gradrox[IJK])+SQUARE(gradroy[IJK])+SQUARE(gradroz[IJK])+em6);
                                gradrox[IJK]*=gradro1/gradro2;
                                gradroy[IJK]*=gradro1/gradro2;
                                gradroz[IJK]*=gradro1/gradro2;
                            }
                        }/*if(isobstacle(IJK))*/
                    }
            }//if (ncyc !=0)
	}//else

}

#ifdef rudman_fine
void normalsobs_f(double *ftildeobs_f)
{
	int i, j, k;
	
	if(ftildeobs_f != NULL)      /* If first time calling normalsobs from normals */
	{
		/*
        ** first copy ftilde velocities in obstacle surface cells
        */
		for(k=1;k<km1;k++)
			for(j=1;j<jm1;j++)
				for(i=1;i<im1;i++)
				{
					/*if current cell is obstacle interface cell*/
					if (isobstsfc(IJK))
				        {
					    if (obst[IJK].flag_r)  /*if obstacle cell is to the RIGHT of fluid cell*/
						  {
							ftildeobs_f[IND_f(2*i-1,2*j,2*k)]=ftildeobs_f[IND_f(2*i-2,2*j,2*k)];
							ftildeobs_f[IND_f(2*i-1,2*j-1,2*k)]=ftildeobs_f[IND_f(2*i-2,2*j-1,2*k)];
							ftildeobs_f[IND_f(2*i-1,2*j-1,2*k-1)]=ftildeobs_f[IND_f(2*i-2,2*j-1,2*k-1)];
							ftildeobs_f[IND_f(2*i-1,2*j,2*k-1)]=ftildeobs_f[IND_f(2*i-2,2*j,2*k-1)];
						  }

					    if (obst[IJK].flag_l)  /*if obstacle cell is to the LEFT of fluid cell*/
					    {
							ftildeobs_f[IND_f(2*i,2*j,2*k)]=ftildeobs_f[IND_f(2*i+1,2*j,2*k)];
							ftildeobs_f[IND_f(2*i,2*j-1,2*k)]=ftildeobs_f[IND_f(2*i+1,2*j-1,2*k)];
							ftildeobs_f[IND_f(2*i,2*j-1,2*k-1)]=ftildeobs_f[IND_f(2*i+1,2*j-1,2*k-1)];
							ftildeobs_f[IND_f(2*i,2*j,2*k-1)]=ftildeobs_f[IND_f(2*i+1,2*j,2*k-1)];	
						  }

					    if (obst[IJK].flag_f)  /*if obst. is in of the FRONT of fluid cell*/
					    {
							ftildeobs_f[IND_f(2*i,2*j-1,2*k)]=ftildeobs_f[IND_f(2*i,2*j-2,2*k)];
							ftildeobs_f[IND_f(2*i-1,2*j-1,2*k)]=ftildeobs_f[IND_f(2*i-1,2*j-2,2*k)]; 
							ftildeobs_f[IND_f(2*i-1,2*j-1,2*k-1)]=ftildeobs_f[IND_f(2*i-1,2*j-2,2*k-1)];
							ftildeobs_f[IND_f(2*i,2*j-1,2*k-1)]=ftildeobs_f[IND_f(2*i,2*j-2,2*k-1)];
						  }

					    if (obst[IJK].flag_b)  /*if obstacle cell is to the BACK of fluid cell*/
					    {
							  ftildeobs_f[IND_f(2*i,2*j,2*k)]=ftildeobs_f[IND_f(2*i,2*j+1,2*k)];
							  ftildeobs_f[IND_f(2*i-1,2*j,2*k)]=ftildeobs_f[IND_f(2*i-1,2*j+1,2*k)];
							  ftildeobs_f[IND_f(2*i-1,2*j,2*k-1)]=ftildeobs_f[IND_f(2*i-1,2*j+1,2*k-1)];
							  ftildeobs_f[IND_f(2*i,2*j,2*k-1)]=ftildeobs_f[IND_f(2*i,2*j+1,2*k-1)];
						  }

					    if (obst[IJK].flag_o)  /*if obstacle cell is OVER the fluid cell*/
					    {
							  ftildeobs_f[IND_f(2*i,2*j,2*k-1)]=ftildeobs_f[IND_f(2*i,2*j,2*k-2)];
							  ftildeobs_f[IND_f(2*i-1,2*j,2*k-1)]=ftildeobs_f[IND_f(2*i-1,2*j,2*k-2)];
							  ftildeobs_f[IND_f(2*i-1,2*j-1,2*k-1)]=ftildeobs_f[IND_f(2*i-1,2*j-1,2*k-2)];
							  ftildeobs_f[IND_f(2*i,2*j-1,2*k-1)]=ftildeobs_f[IND_f(2*i,2*j-1,2*k-2)];
						  }

					    if (obst[IJK].flag_u)  /*if obstacle cell is UNDER the fluid cell*/
					    {
							  ftildeobs_f[IND_f(2*i,2*j,2*k)]=ftildeobs_f[IND_f(2*i,2*j,2*k+1)];
							  ftildeobs_f[IND_f(2*i-1,2*j,2*k)]=ftildeobs_f[IND_f(2*i-1,2*j,2*k+1)];
							  ftildeobs_f[IND_f(2*i-1,2*j-1,2*k)]=ftildeobs_f[IND_f(2*i-1,2*j-1,2*k+1)];
							  ftildeobs_f[IND_f(2*i,2*j-1,2*k)]=ftildeobs_f[IND_f(2*i,2*j-1,2*k+1)];
						  }
				        }/*if(isobstsfc(IJK))*/
			}

    }
    //impose contact angle at obstacle cells later
}

void normalspsiobs_f(double *psiavnx_f, double *psiavny_f, double *psiavnz_f)
{
	int i, j, k;
	
		for(k=1;k<km1;k++)
			for(j=1;j<jm1;j++)
				for(i=1;i<im1;i++)
				{
					/*if current cell is obstacle interface cell*/
					if (isobstsfc(IJK))
				        {
					    if (obst[IJK].flag_r)  /*if obstacle cell is to the RIGHT of fluid cell*/
						  {
							psiavnx_f[IND_f(2*i-1,2*j,2*k)]=psiavnx_f[IND_f(2*i-2,2*j,2*k)];
							psiavnx_f[IND_f(2*i-1,2*j-1,2*k)]=psiavnx_f[IND_f(2*i-2,2*j-1,2*k)];
							psiavnx_f[IND_f(2*i-1,2*j-1,2*k-1)]=psiavnx_f[IND_f(2*i-2,2*j-1,2*k-1)];
							psiavnx_f[IND_f(2*i-1,2*j,2*k-1)]=psiavnx_f[IND_f(2*i-2,2*j,2*k-1)];
							
							psiavny_f[IND_f(2*i-1,2*j,2*k)]=psiavny_f[IND_f(2*i-2,2*j,2*k)];
							psiavny_f[IND_f(2*i-1,2*j-1,2*k)]=psiavny_f[IND_f(2*i-2,2*j-1,2*k)];
							psiavny_f[IND_f(2*i-1,2*j-1,2*k-1)]=psiavny_f[IND_f(2*i-2,2*j-1,2*k-1)];
							psiavny_f[IND_f(2*i-1,2*j,2*k-1)]=psiavny_f[IND_f(2*i-2,2*j,2*k-1)];
							
							psiavnz_f[IND_f(2*i-1,2*j,2*k)]=psiavnz_f[IND_f(2*i-2,2*j,2*k)];
							psiavnz_f[IND_f(2*i-1,2*j-1,2*k)]=psiavnz_f[IND_f(2*i-2,2*j-1,2*k)];
							psiavnz_f[IND_f(2*i-1,2*j-1,2*k-1)]=psiavnz_f[IND_f(2*i-2,2*j-1,2*k-1)];
							psiavnz_f[IND_f(2*i-1,2*j,2*k-1)]=psiavnz_f[IND_f(2*i-2,2*j,2*k-1)];
						  }

					    if (obst[IJK].flag_l)  /*if obstacle cell is to the LEFT of fluid cell*/
					    {
							psiavnx_f[IND_f(2*i,2*j,2*k)]=psiavnx_f[IND_f(2*i+1,2*j,2*k)];
							psiavnx_f[IND_f(2*i,2*j-1,2*k)]=psiavnx_f[IND_f(2*i+1,2*j-1,2*k)];
							psiavnx_f[IND_f(2*i,2*j-1,2*k-1)]=psiavnx_f[IND_f(2*i+1,2*j-1,2*k-1)];
							psiavnx_f[IND_f(2*i,2*j,2*k-1)]=psiavnx_f[IND_f(2*i+1,2*j,2*k-1)];
							
							psiavny_f[IND_f(2*i,2*j,2*k)]=psiavny_f[IND_f(2*i+1,2*j,2*k)];
							psiavny_f[IND_f(2*i,2*j-1,2*k)]=psiavny_f[IND_f(2*i+1,2*j-1,2*k)];
							psiavny_f[IND_f(2*i,2*j-1,2*k-1)]=psiavny_f[IND_f(2*i+1,2*j-1,2*k-1)];
							psiavny_f[IND_f(2*i,2*j,2*k-1)]=psiavny_f[IND_f(2*i+1,2*j,2*k-1)];
							
							psiavnz_f[IND_f(2*i,2*j,2*k)]=psiavnz_f[IND_f(2*i+1,2*j,2*k)];
							psiavnz_f[IND_f(2*i,2*j-1,2*k)]=psiavnz_f[IND_f(2*i+1,2*j-1,2*k)];
							psiavnz_f[IND_f(2*i,2*j-1,2*k-1)]=psiavnz_f[IND_f(2*i+1,2*j-1,2*k-1)];
							psiavnz_f[IND_f(2*i,2*j,2*k-1)]=psiavnz_f[IND_f(2*i+1,2*j,2*k-1)];	
						  }

					    if (obst[IJK].flag_f)  /*if obst. is in of the FRONT of fluid cell*/
					    {
							psiavnx_f[IND_f(2*i,2*j-1,2*k)]=psiavnx_f[IND_f(2*i,2*j-2,2*k)];
							psiavnx_f[IND_f(2*i-1,2*j-1,2*k)]=psiavnx_f[IND_f(2*i-1,2*j-2,2*k)]; 
							psiavnx_f[IND_f(2*i-1,2*j-1,2*k-1)]=psiavnx_f[IND_f(2*i-1,2*j-2,2*k-1)];
							psiavnx_f[IND_f(2*i,2*j-1,2*k-1)]=psiavnx_f[IND_f(2*i,2*j-2,2*k-1)];
							
							psiavny_f[IND_f(2*i,2*j-1,2*k)]=psiavny_f[IND_f(2*i,2*j-2,2*k)];
							psiavny_f[IND_f(2*i-1,2*j-1,2*k)]=psiavny_f[IND_f(2*i-1,2*j-2,2*k)]; 
							psiavny_f[IND_f(2*i-1,2*j-1,2*k-1)]=psiavny_f[IND_f(2*i-1,2*j-2,2*k-1)];
							psiavny_f[IND_f(2*i,2*j-1,2*k-1)]=psiavny_f[IND_f(2*i,2*j-2,2*k-1)];
							
							psiavnz_f[IND_f(2*i,2*j-1,2*k)]=psiavnz_f[IND_f(2*i,2*j-2,2*k)];
							psiavnz_f[IND_f(2*i-1,2*j-1,2*k)]=psiavnz_f[IND_f(2*i-1,2*j-2,2*k)]; 
							psiavnz_f[IND_f(2*i-1,2*j-1,2*k-1)]=psiavnz_f[IND_f(2*i-1,2*j-2,2*k-1)];
							psiavnz_f[IND_f(2*i,2*j-1,2*k-1)]=psiavnz_f[IND_f(2*i,2*j-2,2*k-1)];
						  }

					    if (obst[IJK].flag_b)  /*if obstacle cell is to the BACK of fluid cell*/
					    {
							  psiavnx_f[IND_f(2*i,2*j,2*k)]=psiavnx_f[IND_f(2*i,2*j+1,2*k)];
							  psiavnx_f[IND_f(2*i-1,2*j,2*k)]=psiavnx_f[IND_f(2*i-1,2*j+1,2*k)];
							  psiavnx_f[IND_f(2*i-1,2*j,2*k-1)]=psiavnx_f[IND_f(2*i-1,2*j+1,2*k-1)];
							  psiavnx_f[IND_f(2*i,2*j,2*k-1)]=psiavnx_f[IND_f(2*i,2*j+1,2*k-1)];
							  
							  psiavny_f[IND_f(2*i,2*j,2*k)]=psiavny_f[IND_f(2*i,2*j+1,2*k)];
							  psiavny_f[IND_f(2*i-1,2*j,2*k)]=psiavny_f[IND_f(2*i-1,2*j+1,2*k)];
							  psiavny_f[IND_f(2*i-1,2*j,2*k-1)]=psiavny_f[IND_f(2*i-1,2*j+1,2*k-1)];
							  psiavny_f[IND_f(2*i,2*j,2*k-1)]=psiavny_f[IND_f(2*i,2*j+1,2*k-1)];
							  
							  psiavnz_f[IND_f(2*i,2*j,2*k)]=psiavnz_f[IND_f(2*i,2*j+1,2*k)];
							  psiavnz_f[IND_f(2*i-1,2*j,2*k)]=psiavnz_f[IND_f(2*i-1,2*j+1,2*k)];
							  psiavnz_f[IND_f(2*i-1,2*j,2*k-1)]=psiavnz_f[IND_f(2*i-1,2*j+1,2*k-1)];
							  psiavnz_f[IND_f(2*i,2*j,2*k-1)]=psiavnz_f[IND_f(2*i,2*j+1,2*k-1)];
						  }

					    if (obst[IJK].flag_o)  /*if obstacle cell is OVER the fluid cell*/
					    {
							  psiavnx_f[IND_f(2*i,2*j,2*k-1)]=psiavnx_f[IND_f(2*i,2*j,2*k-2)];
							  psiavnx_f[IND_f(2*i-1,2*j,2*k-1)]=psiavnx_f[IND_f(2*i-1,2*j,2*k-2)];
							  psiavnx_f[IND_f(2*i-1,2*j-1,2*k-1)]=psiavnx_f[IND_f(2*i-1,2*j-1,2*k-2)];
							  psiavnx_f[IND_f(2*i,2*j-1,2*k-1)]=psiavnx_f[IND_f(2*i,2*j-1,2*k-2)];
							  
							  psiavny_f[IND_f(2*i,2*j,2*k-1)]=psiavny_f[IND_f(2*i,2*j,2*k-2)];
							  psiavny_f[IND_f(2*i-1,2*j,2*k-1)]=psiavny_f[IND_f(2*i-1,2*j,2*k-2)];
							  psiavny_f[IND_f(2*i-1,2*j-1,2*k-1)]=psiavny_f[IND_f(2*i-1,2*j-1,2*k-2)];
							  psiavny_f[IND_f(2*i,2*j-1,2*k-1)]=psiavny_f[IND_f(2*i,2*j-1,2*k-2)];
							  
							  psiavnz_f[IND_f(2*i,2*j,2*k-1)]=psiavnz_f[IND_f(2*i,2*j,2*k-2)];
							  psiavnz_f[IND_f(2*i-1,2*j,2*k-1)]=psiavnz_f[IND_f(2*i-1,2*j,2*k-2)];
							  psiavnz_f[IND_f(2*i-1,2*j-1,2*k-1)]=psiavnz_f[IND_f(2*i-1,2*j-1,2*k-2)];
							  psiavnz_f[IND_f(2*i,2*j-1,2*k-1)]=psiavnz_f[IND_f(2*i,2*j-1,2*k-2)];
						  }

					    if (obst[IJK].flag_u)  /*if obstacle cell is UNDER the fluid cell*/
					    {
							  psiavnx_f[IND_f(2*i,2*j,2*k)]=psiavnx_f[IND_f(2*i,2*j,2*k+1)];
							  psiavnx_f[IND_f(2*i-1,2*j,2*k)]=psiavnx_f[IND_f(2*i-1,2*j,2*k+1)];
							  psiavnx_f[IND_f(2*i-1,2*j-1,2*k)]=psiavnx_f[IND_f(2*i-1,2*j-1,2*k+1)];
							  psiavnx_f[IND_f(2*i,2*j-1,2*k)]=psiavnx_f[IND_f(2*i,2*j-1,2*k+1)];
							  
							  psiavny_f[IND_f(2*i,2*j,2*k)]=psiavny_f[IND_f(2*i,2*j,2*k+1)];
							  psiavny_f[IND_f(2*i-1,2*j,2*k)]=psiavny_f[IND_f(2*i-1,2*j,2*k+1)];
							  psiavny_f[IND_f(2*i-1,2*j-1,2*k)]=psiavny_f[IND_f(2*i-1,2*j-1,2*k+1)];
							  psiavny_f[IND_f(2*i,2*j-1,2*k)]=psiavny_f[IND_f(2*i,2*j-1,2*k+1)];
							  
							  psiavnz_f[IND_f(2*i,2*j,2*k)]=psiavnz_f[IND_f(2*i,2*j,2*k+1)];
							  psiavnz_f[IND_f(2*i-1,2*j,2*k)]=psiavnz_f[IND_f(2*i-1,2*j,2*k+1)];
							  psiavnz_f[IND_f(2*i-1,2*j-1,2*k)]=psiavnz_f[IND_f(2*i-1,2*j-1,2*k+1)];
							  psiavnz_f[IND_f(2*i,2*j-1,2*k)]=psiavnz_f[IND_f(2*i,2*j-1,2*k+1)];
						  }
				        }/*if(isobstsfc(IJK))*/
			}

}
#endif
