#include "ripple.h"
#include <math.h>

/******************************************************************************


Subroutine VOFERR is called by:	SETUP, VOFDLY

Subroutine VOFERR calls:	BC	

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/
void voferr()
{
	int i,j,k;
	double ofvol = fvol;
	fvol = 0.0;
	for(k=1;k<km1;k++)	
		for(j=1;j<jm1;j++)
			for(i=1;i<im1;i++)
			{
				if (ac[IJK] < em6) continue;//skip obstacle cells
				if (f[IJK]!=0.0 && f[IJK]!=1.0)//skip empty and full cells
				if ((f[IJK]<0.1) || (f[IJK] >= emf1))
				{
					/*if (fn[IJK]+fn[IMJK]+fn[IJMK]+fn[IJKM]+fn[IPJK]+fn[IJPK]
					   +fn[IJKP]+fn[IMJMK]+fn[IMJPK]+fn[IPJMK]+fn[IPJPK]+fn[IJMKM]
					   +fn[IJMKP]+fn[IJPKM]+fn[IJPKP]+fn[IMJKM]+fn[IPJKM]+fn[IMJKP]
					   +fn[IPJKP] < 0.1)
					{
						fprintf (files.error, " VOF isolated on cycle %5d, time %13.5e : F(%2d,%2d,%2d) = %14.7e\n", ncyc, t, i,j,k, f[IJK]);
						printf("voferr proc %d : VOF isolated on cycle %5d, time %13.5e : F(%2d,%2d,%2d) = %14.7e w ijk=%e\n", mpi.MyRank,ncyc,t,i,j,k,f[IJK],w[IJK]);
#ifdef rudman_fine	
						f_f[IND_f(2*i,2*j,2*k)]=0.e0; f_f[IND_f(2*i-1,2*j,2*k)]=0.e0; f_f[IND_f(2*i-1,2*j-1,2*k)]=0.e0; f_f[IND_f(2*i,2*j-1,2*k)]=0.e0;
						f_f[IND_f(2*i,2*j,2*k-1)]=0.e0; f_f[IND_f(2*i-1,2*j,2*k-1)]=0.e0; f_f[IND_f(2*i-1,2*j-1,2*k-1)]=0.e0; f_f[IND_f(2*i,2*j-1,2*k-1)]=0.e0;
#endif
						f[IJK]=0.0;
						u[IJK]=v[IJK]=w[IJK]=u[IMJK]=v[IJMK]=w[IJKM]=p[IJK]=0.0;
					}*/
					if (f[IJK] >= emf1)
					{
						//f above one or emf1 < f < 1
						if (1.0-fabs(f[IJK]) > 100.0*emf)
							fprintf (files.error, " VOF too large on cycle %5d, time %13.5e : F(%2d,%2d,%2d) = %14.7e\n", ncyc, t, i,j,k, f[IJK]);
						f[IJK]=1.0;
					}
					if (f[IJK] < emf)
					{
						//f below zero or 0 < f < emf
						if (fabs(f[IJK])>100.0*emf)
							fprintf (files.error, " VOF too small on cycle %5d, time %13.5e : F(%2d,%2d,%2d) = %14.7e\n", ncyc, t, i,j,k, f[IJK]);
						f[IJK]=0;
					}					
				}
				fvol=fvol+f[IJK]*ac[IJK]*vol[IJK];
			}
	vchgt=fvol - ofvol;
	if (ncyc==0) vchgt=0;
}

#ifdef rudman_fine
	void voferr_f()
	{
		int i,j,k, ti,tj,tk;
		double ofvol = fvol; double f_t;
		fvol = 0.e0;
		
		for(k=1;k<km1_f;k++)
			for(j=1;j<jm1_f;j++)
				for(i=1;i<im1_f;i++)
				{	
					ti = (i+1)/2; tj = (j+1)/2; tk = (k+1)/2;
					if(ac[IND(ti,tj,tk)]<em6) continue;
					if(f_f[IJK_f]!=0.0 && f_f[IJK_f]!=1.0) 
					if(f_f[IJK_f]<0.1 || f_f[IJK_f]>emf1)
					{
						//don't worry about isolated cells for now ...ashish
						if(f_f[IJK_f] >= emf1) 
						{
							//f above one or emf1 < f < 1
							if(fabs(f_f[IJK_f])-1.0 > 100.0*emf)
								fprintf (files.error, " VOF too large on cycle %5d, time %13.5e : F(%2d,%2d,%2d) = %14.7e\n", ncyc, t, i,j,k, f_f[IJK_f]);
							f_f[IJK_f]=1.0;
						}
						else if (f_f[IJK_f] < emf) 
						{
							//f below zero or 0<f<emf
							if(fabs(f_f[IJK_f])>100.0*emf)
								fprintf(files.error, " VOF too small on cycle %5d, time %13.5e : F(%2d,%2d,%2d) = %14.7e\n", ncyc, t, i,j,k, f_f[IJK_f]);
							f_f[IJK_f]=0.0;
						}
						
						//remove isolated liq. cells
						if(f_f[IJK_f] >= em6 && f_f[IJK_f] < 0.1) {
							f_t = fn_f[IJK_f] + fn_f[IMJK_f] + fn_f[IJMK_f] + fn_f[IJKM_f] + fn_f[IPJK_f] + fn_f[IJPK_f] + fn_f[IJKP_f] + fn_f[IMJMK_f]
								+ fn_f[IMJPK_f] + fn_f[IPJMK_f] + fn_f[IPJPK_f] + fn_f[IJMKM_f] + fn_f[IJMKP_f] + fn_f[IJPKM_f] + fn_f[IJPKP_f] + fn_f[IMJKM_f]
								+ fn_f[IPJKM_f] + fn_f[IMJKP_f] + fn_f[IPJKP_f];
			  
							if(f_t < 0.1) {
								fprintf (files.error, " water isolated on cycle %5d, time %13.5e : f_f(%2d,%2d,%2d) = %14.7e\n", ncyc, t, i,j,k, f_f[IJK_f]);
								printf (" water isolated on cycle %5d, time %13.5e : f_f(%2d,%2d,%2d) = %14.7e\n", ncyc, t, i,j,k, f_f[IJK_f]);
								f_f[IJK_f] = 0.0;
							}
						}
					}
			
					fvol=fvol+f_f[IJK_f]*vol_f[IJK_f];
				}
		
		vchgt=fvol-ofvol;
		if(ncyc==0) vchgt=0;
	}
	
#ifdef __solid
	void psierr_f()
	{
		int i,j,k, ti,tj,tk;
		double opsivol = psivol;
		psivol = 0.e0;
		
		for(k=1;k<km1_f;k++)
			for(j=1;j<jm1_f;j++)
				for(i=1;i<im1_f;i++)
				{
					ti = (i+1)/2; tj = (j+1)/2; tk = (k+1)/2;
					if(ac[IND(ti,tj,tk)]<em6) continue;
					if(psi_f[IJK_f]!=0.0 && psi_f[IJK_f]!=1.0) 
					if(psi_f[IJK_f]<0.1 || psi_f[IJK_f]>emf1)
					{
						//don't worry about isolated cells for now ...ashish
						if(psi_f[IJK_f] >= emf1) 
						{
							//f above one or emf1 < f < 1
							if(fabs(psi_f[IJK_f])-1.0 > 100.0*emf)
								fprintf (files.error, " PSI too large on cycle %5d, time %13.5e : F(%2d,%2d,%2d) = %14.7e\n", ncyc, t, i,j,k, psi_f[IJK_f]);
							psi_f[IJK_f]=1.0;
						}
						else if (psi_f[IJK_f] < emf) 
						{
							//f below zero or 0<f<emf
							if(fabs(psi_f[IJK_f])>100.0*emf)
								fprintf(files.error, " PSI too small on cycle %5d, time %13.5e : F(%2d,%2d,%2d) = %14.7e\n", ncyc, t, i,j,k, psi_f[IJK_f]);
							psi_f[IJK_f]=0.0;
						}
					}
					psivol=psivol+psi_f[IJK_f]*vol_f[IJK_f];
				}
		
		pvchgt=psivol-opsivol;
		if(ncyc==0) pvchgt=0;
	}
#endif

#endif

#undef fabs

