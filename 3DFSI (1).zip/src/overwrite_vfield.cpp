#include "ripple.h"
#include "testing.h"


void overwrite_vfield()
{
	int i, j, k;
	
		k = 1;
		for( i = 1; i < im1; i++ )
		for( j = 1; j < jm1; j++)
//			for( k = 1; k < km1; k++)
			{
				if( f[IJK] < em6
//					&& f[IJKM] < em6
					&& f[IPJK] < em6
					&& f[IJPK] < em6 
					&& f[IMJK] < em6
					&& f[IJMK] < em6 
//					&& f[IJKP] < em6
//					&& f[IMJKM] < em6 
//					&& f[IPJKM] < em6
//					&& f[IJMKM] < em6
//					&& f[IJPKM] < em6
					&& f[IPJPK] < em6
					&& f[IMJMK] < em6
					&& f[IMJPK] < em6
					&& f[IPJMK] < em6
//					&& f[IMJKP] < em6
//					&& f[IPJKP] < em6
//					&& f[IJMKP] < em6
//					&& f[IJPKP] < em6
//					&& f[IMJMKM] < em6
//					&& f[IPJMKM] < em6
//					&& f[IMJPKM] < em6
//					&& f[IPJPKM] < em6
//					&& f[IMJMKP] < em6
//					&& f[IPJMKP] < em6
//					&& f[IMJPKP] < em6
//					&& f[IPJPKP] < em6
										)
				{
					u[IJK]=0;
					v[IJK]=0;
					w[IJK]=0;
				}
				else
				;
			}
}
