#include <stdio.h>
#include <stdlib.h>
#include "testing.h"
#include "ripple.h"

void velocityCopy() { // This function copies w at k=1 to k=0, and is to be called after vofdly and viscous
	
	if (ku == 4 && mpi.Neighbors[4] == -1) {
		
		int k = 0;
		
		for (int i = 1; i < im1; ++i)
			for (int j = 1; j < jm1; ++j) {
				w[IJK] = w[IJKP];
			}
	}
}

void referencePressure() { // This function sets the reference pressure in partial solid/liquid cells equal to the pressure jump condition
	
	double tx, ty, tz;
	
	if (ku == 4 && mpi.Neighbors[4] == -1) {
		
		int k = 0;
		
		for (int i = 1; i < im1; ++i)
			for (int j = 1; j < jm1; ++j) {
				
				tx = (i + mpi.OProc[0])*delx[1];
				ty = (j + mpi.OProc[1])*dely[1];
				
				if ((tx>0.026 && tx<0.0289) || (tx>0.0384 && tx<0.0412)) {
					p[IJK] = 0.1525; // 5*0.026066 - gx*(xe - tx);
				}
				else if ((tx>0.003 && tx<0.0058) || (tx>0.0610 && tx<0.0638)) {
					p[IJK] = 0.0; // -gx*(xe - tx);
				}
				else {
					p[IJK] = 0.0; // -gx*(xe - tx);
				}
			}
	}
}

void singleTubeExtension() { // essentially the same function which creates the single tube, but on the course grid. for only k = 0 cells.
	
	// Can actually just copy the volume fraction from above, since the values will be the same.
	// Actually this isnt necessary. Since it occurs in bcf() and bcpsi()
	
	if (ku == 4 && mpi.Neighbors[4] == -1) {
		
		int k = 0;
		
		for (int i = 1; i < im1; ++i)
			for (int j = 1; j < jm1; ++j) {
				
				f[IJK] = f[IJKP];
				psi[IJK] = psi[IJKP];
			}
	}
}

void yTubeExtension() {
	
	
	
}

void tensionCopy(double *fvirt) {
	
	double *tensz = temp[11];
	double radius = 2.0e-3 - 3.0e-4;
	
	if (ku == 4 && mpi.Neighbors[4] == -1) {
		
		int k = 0;
		
		for (int i = 1; i < im1; ++i)
			for (int j = 1; j < jm1; ++j) {
				
				// tensz[IJK] = tensz[IJKP];
			
				tensz[IJK] = sigma[IJK]/radius*SIGN(fvirt[IJKP]-fvirt[IJK])/delz[1];
			}
	}
}
