#include "ripple.h"
#include "testing.h"
#include <string.h>

/******************************************************************************
This subroutine initializes the density and viscosity arrays given 2 fluid
properties in the input file.

Subroutine SETPROPERTIES is called by:	SETUP, VOFDLY

Subroutine SETPROPERTIES calls:			

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME			DATE

- Subroutine modified to op SIGMA at a certain Z	Babak			Sep 24 2009
  level if under boundary condition is open_jet
  
- Variable properties added							Babak			Sep 15 2009
  
- Subroutine modified to update thermal properties	Babak			Sep 2 2009
  
- Defining density and viscosity based on gas and   Amirreza		Dec 8 2005
  liquid properties

- Defing rho as a vector variable					Amirreza		Dec 7 2005

- Defing xmu as a vector variable					Amirreza		Dec 5 2005

- Created this template for tracking changes		Ben				April 21 2005

_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

void setproperties()
{

	int i,j,k,OBC = 21;
	double ff1,ff2;
	double xmuTf1,xmuTf2,cpTf1,cpTf2,condTf1,condTf2,sigmaTf1;

	// Updating Density

	for (k=0;k<kmax;k++)
		for (j=0;j<jmax;j++)
			for (i=0;i<imax;i++)
			{
				rho[IJK]=rhof1*f[IJK]+rhof2*(1.0-f[IJK]);
			}

#ifndef rudman_fine
	for (i=0;i<NX*NY*NZ;i++)
		rhorc[i]=rhofc[i]=rhooc[i]=1e-25;
		
	for (k=0;k<kmax;k++)
		for (j=0;j<jmax;j++)
			for (i=0;i<imax;i++)
			{	
				if (i < im1)
					rhorc[IJK]=tiny+0.5*(delx[i+1]*rho[IJK]+delx[i]*rho[IPJK])*rdelxl[i+1];
				if (i > 0)
					rhorc[IMJK]=MAX(tiny, rhorc[IMJK]);

				if (j < jm1)
					rhofc[IJK]=tiny+0.5*(dely[j+1]*rho[IJK]+dely[j]*rho[IJPK])*rdelyb[j+1];
				if (j > 0)
					rhofc[IJMK]=MAX(tiny, rhofc[IJMK]);

				if (k < km1)
					rhooc[IJK]=tiny+0.5*(delz[k+1]*rho[IJK]+delz[k]*rho[IJKP])*rdelzu[k+1];
				if (k > 0)
					rhooc[IJKM]=MAX(tiny, rhooc[IJKM]);
			}
#endif

#ifdef rudman_fine
	double *rho_stgx = temp[18];
	double *rho_stgy = temp[19];
	double *rho_stgz = temp[20];
	rhorc=temp[18], rhofc=temp[19], rhooc=temp[20]; //rememeber that the rhooc etc. are global variables
	
	double *vnew_f = temp_f[0];
	memcpy(vnew_f,vol_f,NX_f*NY_f*NZ_f*sizeof(double));
	stag_vol();
	stag_den();

#endif

	//Updating viscosity and surface tension
	for (k=0;k<kmax;k++)		
		for (j=0;j<jmax;j++)
			for (i=0;i<imax;i++)
			{
				if (VARPROP)
				{
					xmuTf1=interp(FLUID1_T,FLUID1_xmu,tmp[IJK]);
					xmuTf2=interp(FLUID2_T,FLUID2_xmu,tmp[IJK]);
					sigmaTf1=interp(FLUID1_T,FLUID1_st,tmp[IJK]);
				}
				else
				{
					xmuTf1=xmuf1;
					xmuTf2=xmuf2;
					sigmaTf1=stf1;
				}

				//xmu[IJK]=xmuTf1*f[IJK]+xmuTf2*(1.0-f[IJK]);
				xmu[IJK]=xmuTf1*xmuTf2/(f[IJK]*xmuTf2+(1.0-f[IJK])*xmuTf1+tiny); //calculate the harmonic average.
				sigma[IJK]=sigmaTf1;

				if (ku == 5 && k+mpi.OProc[2] < OBC)
					sigma[IJK] = 0.001;
			}
	
	
#ifdef rudman_fine
	//here we adopt the scheme of Rudman 1998 to compute viscous coefficients
	double *mu_f=temp_f[0]; //don't let vnew_f change it ...ashish
	for(k=0;k<=km1_f;k++)
	 for(j=0;j<=jm1_f;j++)
	   for(i=0;i<=im1_f;i++) {
#ifndef __solid
		mu_f[IJK_f]=f_f[IJK_f]*xmuf1 + (1.e0-f_f[IJK_f])*xmuf2;
#endif

#ifdef __solid
		mu_f[IJK_f]=fvirt_f[IJK_f]*xmuf1 + (1.0-fvirt_f[IJK_f])*xmuf2;
#endif
	  }
#endif
		
	//Updating cp and K
			
	if (ENERGY)
	{
		for (k=0;k<kmax;k++)
			for (j=0;j<jmax;j++)
				for (i=0;i<imax;i++)
				{

					if (VARPROP)
					{
						cpTf1=interp(FLUID1_T,FLUID1_Cp,tmp[IJK]);
						cpTf2=interp(FLUID2_T,FLUID2_Cp,tmp[IJK]);
						condTf1=interp(FLUID1_T,FLUID1_K,tmp[IJK]);
						condTf2=interp(FLUID2_T,FLUID2_K,tmp[IJK]);
					}
					else
					{
						cpTf1=cpf1;
						cpTf2=cpf2;
						condTf1=condf1;
						condTf2=condf2;
					}
				
					if (f[IJK] < em6)
					{
						cp[IJK] = cpTf2;
						cond[IJK] = condTf2;
					}					
					else if (f[IJK] > em61)
					{
						cp[IJK] = cpTf1;
						cond[IJK] = condTf1;
					}
					else
					{
						ff1 = f[IJK]*rhof1/rho[IJK];
						ff2 = (1.0-f[IJK])*rhof2/rho[IJK];
						cp[IJK] = cpTf1*ff1+cpTf2*ff2;
						cond[IJK] = 1.0/(ff1/condTf1+ff2/condTf2);
					}
				}
				
	}
						
	//exchange variables
	xchg<double>(rhorc);
	xchg<double>(rhofc);
	xchg<double>(rhooc);
	xchg<double>(xmu);
	xchg<double>(rho);
	xchg<double>(sigma);

	if (ENERGY)
	{
		xchg<double>(cp);
		xchg<double>(cond);
	}
}
