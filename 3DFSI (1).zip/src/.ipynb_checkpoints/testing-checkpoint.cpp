#include <math.h>
#include "testing.h"
#include "ripple.h"
#include "vector.h"
#include <string.h>/*memcpy*/
#include "setup_airway_tree.h"
#include "timing.h"

#define TOL 1e-8
#define ONE	1.0
#define ZERO	0.0

#define RBAIR 	1.15e-3
#define RBOC    2.250e-3
// #define R3		94.485e-6
#define R3		69.51e-6
#define RDIHEN	41.0e-6
#define ROUT 	194.485e-6

/* For working with ICEM */
#define IN_MY_XDOM (txi >= xi[1] && txi <= xi[im2])
#define IN_MY_YDOM (tyj >= yj[1] && tyj <= yj[jm2])
#define IN_MY_ZDOM (tzk >= zk[1] && tzk <= zk[km2])
//VARIABLE DEFINITIONS

//obstacle
_obst *obst;

//bubble
_bubble *bubble;
double c1,c2;
//struct Profile energy[500];
double init_pressure, init_volume;
bool BUBBLE;
double BUBBLE_Z_LIM;
double SLOPE;
double ZSTR;
double ZCONE;
double ZOUT;
double NOZZLE_RAD;
double ENRG, Erate, Esum;
double Cv;
double T_INIT,P_INIT, T2;
double GAMMA;
double R_NUCL;
int METHOD;
double Pb;//bubble pressure
double Vb;//bubble volume
double Pb_max;
double Td;//time of discharge
double Eff;//efficiency of discharge
int ICL, JCL, KCL;
double jet_energy;
double delta_jet_energy;
//sphericity
double *f1,*difference, spherity, x_cent, y_cent, z_cent;
double umax, vmax, wmax, rhomax, xmumin;
double umin, vmin, wmin;

/*CGITER*/
int CGITER;

/*DELTADJ*/
bool DELTADJ;
bool ICEM;
bool ENERGY;
bool VARPROP;

bool equal(double A, double B, double tol){

	if(A == 0.0 && fabs(B) < tol)//A=0 case
		return true;
	else if(B == 0.0 && fabs(A) < tol)//B=0 case
		return true;
	else if(fabs((A - B) / B) < tol)
		return true;
	else
		return false;
}
void print_27(double *var, int indx){
	int i, j, k;

	for(k = 0; k < kmax; k++)
		for(j = 0; j < jmax; j++)
			for(i =0; i < imax; i++)
			{
				if(IND(i, j, k) == indx)
				{
					fprintf(files.out, "CELL[%d]\n",indx);
					fprintf(files.out, " 1 IJK = %10.4e\n", var[IJK]);

					fprintf(files.out, " 2 IPJK = %10.4e\n", var[IPJK]);
					fprintf(files.out, " 3 IMJK = %10.4e\n", var[IMJK]);
					fprintf(files.out, " 4 IJPK = %10.4e\n", var[IJPK]);
					fprintf(files.out, " 5 IJMK = %10.4e\n", var[IJMK]);
					fprintf(files.out, " 6 IJKP = %10.4e\n", var[IJKP]);
					fprintf(files.out, " 7 IJKM = %10.4e\n", var[IJKM]);

					fprintf(files.out, " 8 IPJKP = %10.4e\n", var[IPJKP]);
					fprintf(files.out, " 9 IPJKM = %10.4e\n", var[IPJKM]);
					fprintf(files.out, "10 IPJPK = %10.4e\n", var[IPJPK]);
					fprintf(files.out, "11 IPJMK = %10.4e\n", var[IPJMK]);
					fprintf(files.out, "12 IMJKM = %10.4e\n", var[IMJKM]);
					fprintf(files.out, "13 IMJKP = %10.4e\n", var[IMJKP]);
					fprintf(files.out, "14 IMJPK = %10.4e\n", var[IMJPK]);
					fprintf(files.out, "15 IMJMK = %10.4e\n", var[IMJMK]);
					fprintf(files.out, "16 IJPKP = %10.4e\n", var[IJPKP]);
					fprintf(files.out, "17 IJPKM = %10.4e\n", var[IJPKM]);
					fprintf(files.out, "18 IJMKP = %10.4e\n", var[IJMKP]);
					fprintf(files.out, "19 IJMKM = %10.4e\n", var[IJMKM]);

					fprintf(files.out, "20 IPJPKP = %10.4e\n", var[IPJPKP]);
					fprintf(files.out, "21 IPJPKM = %10.4e\n", var[IPJPKM]);
					fprintf(files.out, "22 IPJMKP = %10.4e\n", var[IPJMKP]);
					fprintf(files.out, "23 IPJMKM = %10.4e\n", var[IPJMKM]);
					fprintf(files.out, "24 IMJPKP = %10.4e\n", var[IMJPKP]);
					fprintf(files.out, "25 IMJPKM = %10.4e\n", var[IMJPKM]);
					fprintf(files.out, "26 IMJMKP = %10.4e\n", var[IMJMKP]);
					fprintf(files.out, "27 IMJMKM = %10.4e\n", var[IMJMKM]);

					exit(1);

				}
			}
}
void make_pressure_symmetric(void){
	/*This function is used to force pressure to be symmetric.

	Pressure is first copied from the front side into the back side
	of the domain.  Then it is coppied from the right to left side.

	*/
	int i,j,k, ijksym;
	for(k=1;k<km1;k++)
		for(j=1;j<jmax/2;j++)
			for(i=1;i<im1;i++)
			{
				ijksym = IND(i, jm1 - j, k);
				p[IJK] = p[ijksym];//copy front to back
			}

	for(k=1;k<km1;k++)
		for(j=1;j<jm1;j++)
			for(i=1;i<imax/2;i++)
			{
				ijksym = IND(im1 - i, j, k);
				p[IJK] = p[ijksym];//copy right to left
			}

}
void printmax (void){
	int ii, jj, kk;
	double max;

	ii = jj = kk = 0;
	max = getmax(u, &ii, &jj, &kk);

//	printf("%4d\t%10.4e at [%d,%d,%d]\n",ncyc,max,ii,jj,kk);
//	fprintf(files.out, "%4d\t%10.4e\n",ncyc,max);
	printf("UMAX = %10.4e at (%d, %d, %d) or (%d)\n", max, ii, jj, kk,
			IND(ii,jj,kk));
	fprintf(files.summary, "UMAX = %10.4e at (%d, %d, %d) or (%d)\n", max, ii, jj, kk,
			IND(ii,jj,kk));

	max = getmax(v, &ii, &jj, &kk);

	printf("VMAX = %10.4e at (%d, %d, %d) or (%d)\n", max, ii, jj, kk,
			IND(ii,jj,kk));
	fprintf(files.summary, "VMAX = %10.4e at (%d, %d, %d) or (%d)\n", max, ii, jj, kk,
			IND(ii,jj,kk));

	max = getmax(w, &ii, &jj, &kk);

	printf("WMAX = %10.4e at (%d, %d, %d) or (%d)\n", max, ii, jj, kk,
			IND(ii,jj,kk));
	fprintf(files.summary, "WMAX = %10.4e at (%d, %d, %d) or (%d)\n", max, ii, jj, kk,
			IND(ii,jj,kk));

}
void printmin (void){
	int ii, jj, kk;
	double min;

	min = getmin(u, &ii, &jj, &kk);

	printf("UMIN = %10.4e at (%d, %d, %d)\n", min, ii, jj, kk);
	fprintf(files.out, "UMIN = %10.4e at (%d, %d, %d)\n", min, ii, jj, kk);

	min = getmin(v, &ii, &jj, &kk);

	printf("VMIN = %10.4e at (%d, %d, %d)\n", min, ii, jj, kk);
	fprintf(files.out, "VMIN = %10.4e at (%d, %d, %d)\n", min, ii, jj, kk);

	min = getmin(w, &ii, &jj, &kk);

	printf("WMIN = %10.4e at (%d, %d, %d)\n", min, ii, jj, kk);
	fprintf(files.out, "WMIN = %10.4e at (%d, %d, %d)\n", min, ii, jj, kk);

}
void inflow_L_face(void){
	/*This function sets entire left face to be inflow BC
	*/
	int i,j,k;
	i = 0;
	for (k = 1; k < km1; k++)
		for (j = 1; j < jm1; j++)
		{
			u[IJK] = uf1;
			v[IJK] = vf1;
			w[IJK] = wf1;
			f[IJK] = 1.0;
			p[IJK] = p[IPJK];
		}
}
void inflow_L_jet(void){
	/*This sets left face to be wall everywhere but where the
	  jet is define.  There, it is set to be inflow.
	*/
	printf("Inflow_L_jet not implemented!\n");
	exit(0);
}
void open_L(void){
	/*This sets the entire left face to be open boundary
	*/
	int i,j,k;
	i=1;
	for(k = 1; k < km1; k++)
		for(j = 1; j < jm1; j++)
		{
			u[IMJK] = u[IJK];
			v[IMJK] = v[IJK];
			w[IMJK] = w[IJK];
			f[IMJK]	= ZERO;
			p[IMJK]	= p[IJK];
		}
}
void inflow_R_face(void){
	/*This function sets entire right face to be inflow BC
	*/
	printf("Inflow_R_face not implemented!\n");
	exit(0);
}
void inflow_R_jet(void){
	/*This sets right face to be wall everywhere but where the
	  jet is define.  There, it is set to be inflow.
	*/
	printf("Inflow_L_jet not implemented!\n");
	exit(0);
}
void open_R(void){
	/*This sets the entire right face to be open boundary
	*/
	int i,j,k;
	i=im2;
	for(k=1;k<km1;k++)
		for(j=1;j<jm1;j++)
		{
			u[IJK]=u[IMJK];
			v[IPJK]=v[IJK];
			w[IPJK] =w[IJK];
			f[IPJK]=ZERO;
			p[IPJK]=p[IJK];
		}
}
void inflow_B_face(void){
	/*This function sets entire back face to be inflow BC
	*/
	int i,j,k;
	j = 0;
	for (k = 1; k < km1; k++)
		for (i = 1; i < im1; i++)
		{
			if (f[IJPK] > em6 && ac[IJPK] > em6)
			{
				u[IJK] = uf1;
				v[IJK] = vf1;
				w[IJK] = wf1;
				f[IJK] = f[IJPK] = 1.0;
				p[IJK] = p[IJPK];
			}
		}
}
void inflow_B_jet(void){
	/*This sets back face to be wall everywhere but where the
	  jet is define.  There, it is set to be inflow.
	*/
	printf("Inflow_B_jet not implemented!\n");
	exit(0);
}
void open_B(void){
	/*This sets the entire front face to be open boundary
    */
    int i,j,k;
    j=1;
    for(k=1;k<km1;k++)
        for(i=1;i<im1;i++)
    {
        u[IJMK]=u[IJK];
        v[IJMK]=v[IJK];
        w[IJMK]=w[IJK];
		f[IJMK]=ZERO;
        p[IJMK]=p[IJK];
    }
}
void inflow_F_face(void){
	/*This function sets entire front face to be inflow BC
	*/
	printf("Inflow_F_face not implemented!\n");
	exit(0);
}
void inflow_F_jet(void){
	/*This sets front face to be wall everywhere but where the
	  jet is define.  There, it is set to be inflow.
	*/
	printf("Inflow_F_jet not implemented!\n");
	exit(0);
}
void open_F(void){
	/*
	** This sets the entire front face to be open boundary
	*/
	int i,j,k;
	j = jm2;
	for(k=1;k<km1;k++)
		for(i=1;i<im1;i++)
		{
			u[IJPK]=u[IJK];
			v[IJK]=v[IJMK];
			w[IJPK] =w[IJK];
			f[IJPK]=ZERO;
			p[IJPK]=p[IJK];
		}
}
void inflow_U_face(void){
	/*This sets entire under face to be inflow BC
	*/
	int i,j,k;
	k = 0;
	for (i = 1; i < im1; i++)
		for (j = 1; j < jm1; j++)
		{
			u[IJK] = uf1;
			v[IJK] = vf1;
			w[IJK] = wf1;
			f[IJK] = 1.0;
			p[IJK] = p[IJKP];
		}

}
void inflow_U_jet_Laminar(void){
	/*This sets under face to no-slip everywhere but where the
	  jet is define.  There, it is set to be inflow
	*/
	int i,j,k;
	double r2_local,r2_max;
	/*copy f profile from ftemp*/
	memcpy (&f[IND(0,0,0)], &ftemp[IND(0,0,0)], NX*NY*sizeof(double));
	memcpy (&f[IND(0,0,1)], &ftemp[IND(0,0,1)], NX*NY*sizeof(double));
	memcpy (&f[IND(0,0,2)], &ftemp[IND(0,0,2)], NX*NY*sizeof(double));
	k = 0;

	for (i=1;i<im1;i++)
		for (j=1;j<jm1;j++)
		{
			f[IJKP] = f[IJKP+ijmax] = f[IJK];
			if (f[IJK] >= em6)
			{
				r2_local = SQUARE(x[i]-xcent) + SQUARE(y[j]-ycent);
				u[IJK] = u[IJKP] = u[IJKP + ijmax] = uf1;
				v[IJK] = v[IJKP] = v[IJKP + ijmax] = vf1;
				w[IJK] = w[IJKP] = w[IJKP + ijmax] = 2 * wf1 * pow((1 - r2_local/radius),2.0);
			}
			else
			{
				u[IJK] = u[IJKP] = uf2;
				v[IJK] = v[IJKP] = vf2;
				w[IJK] = w[IJKP] = w[IJKP + ijmax] = wf2;
			}	
			p[IJK] = p[IJKP];
		}
}
void inflow_U_jet_Turbulent(void){
	/*This sets under face to no-slip everywhere but where the
	  jet is define.  There, it is set to be inflow
	*/
	int i,j,k;
	double r2_local,r2_max;
	/*copy f profile from ftemp*/
	memcpy (&f[IND(0,0,0)], &ftemp[IND(0,0,0)], NX*NY*sizeof(double));
	memcpy (&f[IND(0,0,1)], &ftemp[IND(0,0,1)], NX*NY*sizeof(double));
	memcpy (&f[IND(0,0,2)], &ftemp[IND(0,0,2)], NX*NY*sizeof(double));
	k = 0;
	double onesev = 1.0 / 7.0;

	for (i=1;i<im1;i++)
		for (j=1;j<jm1;j++)
		{
			f[IJKP] = f[IJKP+ijmax] = f[IJK];
			if (f[IJK] >= em6)
			{
				r2_local = SQUARE(x[i]-xcent) + SQUARE(y[j]-ycent);
				u[IJK] = u[IJKP] = u[IJKP + ijmax] = uf1;
				v[IJK] = v[IJKP] = v[IJKP + ijmax] = vf1;
				w[IJK] = w[IJKP] = w[IJKP + ijmax] = w[IJKP + 2*ijmax] = wf1 * pow((1 - r2_local/radius),onesev);
			}
			else
			{
				u[IJK] = u[IJKP] = uf2;
				v[IJK] = v[IJKP] = vf2;
				w[IJK] = w[IJKP] = w[IJKP + ijmax] = wf2;
			}	
			p[IJK] = p[IJKP];
		}
}
void open_U(void){
	/*This sets the entire under face to be open BC
	*/
	int i,j,k;
	k=1;
	for(i=1; i < im1; i++)
		for(j =1; j < jm1; j++)
		{
			u[IJKM] = u[IJK];
			v[IJKM] = v[IJK];
			w[IJKM] = w[IJK];
			f[IJKM]	= ZERO;
			p[IJKM]	= p[IJK];
		}
}
void open_U_jet(void){
	/*This sets the entire under face to be open BC
	  but chops the jet at a certain Z level defined
	  by OBC
	*/
	int i,j,k,OBC;
	k=0;
	for(i = 1; i < im1; i++)
		for(j = 1; j < jm1; j++)
		{
			u[IJK] = u[IJKP];
			v[IJK] = v[IJKP];
			w[IJK] = w[IJKP];
			p[IJK] = p[IJKP];
			for(OBC = 0; OBC < 14; OBC++)
				f[IJK+OBC*ijmax] = ZERO;
		}
}
void inflow_O_face(void){
	/*This function sets entire over face to be inflow BC
	*/
	int i,j,k;
	k = km1;
	for (i = 1; i < im1; i++)
		for (j = 1; j < jm1; j++)
		{
			if(f[IJKM] >= em6 && ac[IJKM] > em6)
			{
				u[IJK] 	= uf1;
				v[IJK] 	= vf1;
				w[IJKM] = wf1;
				f[IJK]	= f[IJKM] = 1.0;
				p[IJK] 	= p[IJKM];
			}
			else
			{
				u[IJK] 	= uf2;
				v[IJK] 	= vf2;
				w[IJKM] = wf2;
				f[IJK] 	= f[IJKM] = 0.0;
				p[IJK] 	= p[IJKM];
			}
		}
}
void inflow_O_jet(void){
	/*
	 * This sets over face to be wall everywhere but where the
	 * jet is define.  There, it is set to be inflow.
	 */
	int i,j,k;

	/*copy f profile from ftemp*/
	memcpy (&f[IND(0,0,kmax)], &ftemp[IND(0,0,km2)], NX*NY*sizeof(double));
	k = kmax;
	for (i=1;i<im1;i++)
		for (j=1;j<jm1;j++)
		{
			f[IJKM] = f[IJKM-ijmax] = f[IJK];

			if (f[IJK] >= em6)
			{
				u[IJK] = u[IJKM] = uf1;
				v[IJK] = v[IJKM] = vf1;
				w[IJK] = w[IJKM] = w[IJKM-ijmax] = wf1;
			}
			else
			{
				u[IJK] = u[IJKM] = uf2;
				v[IJK] = v[IJKM] = vf2;
				w[IJK] = w[IJKM] = w[IJKM-ijmax] = wf2;
			}				
		}
	/*
	 * Calling SETPROPERTIES in order to correctly set rho_c arrays after overwriting
	 * the f field with the call to memcpy.
	*/
//	setproperties();
}
void inflow_pratt_nozzle(void){

	int i,j,k;
	double tx,ty,txm,tym;
	double R1, R2;
	R1 = RBAIR * RBAIR;
	R2 = (RBOC + 5.0*delx[1]) * (RBOC + 5.0*delx[1]);
	initf();

	k = km1;
	/* R1 */
	for (j=1;j<jm1;j++)
		for (i=1;i<im1;i++){

		tx = x[i];
		ty = y[j];
		txm = x[i-1];
		tym = y[j-1];

		if ((MIN(SQUARE(txm-xcent), SQUARE(tx-xcent))
				   +MIN(SQUARE(tym-ycent), SQUARE(ty-ycent))
				   < R1) ){
			if (t > 10.0e-3){
				u[IJK] = -u[IJKM];
				v[IJK] = -v[IJKM];
				w[IJKM] = -5.0;
			}
			else{
				u[IJK] = -u[IJKM];
				v[IJK] = -v[IJKM];
				w[IJKM] = -(490.0 * t + 0.1);
			}

		}
		if ((MAX(SQUARE(txm-xcent), SQUARE(tx-xcent))
				   +MAX(SQUARE(tym-ycent), SQUARE(ty-ycent))
				   > R2)){
			u[IJK] = -u[IJKM];
			v[IJK] = -v[IJKM];
			w[IJKM] = -0.5;
		}

	}	/* for IJ */

	/*
	* Calling SETPROPERTIES in order to correctly set rho_c arrays after overwriting
	* the f field with the call to memcpy.
	*/
	setproperties();
}
void outflow_pratt_nozzle(void){
	int i,j,k;

	k = 0;

	for (i=1; i < im1; i++)
		for (j = 1; j < jm1; j++){
			u[IJK] = u[IJKP];
			v[IJK] = v[IJKP];
			w[IJK] = -fabs(w[IJKP]); /* force outflow */
			f[IJK] = f[IJKP];
		}
}
void inflow_DIHEN(void){
	int i,j,k;
	double tx, ty, tz, txm, tym;
	k = km2;
	for (j=1;j<jm1;j++)
		for (i=1;i<im1;i++){

			tx = x[i];
			ty = y[j];
			txm = x[i-1];
			tym = y[j-1];

// 		if ((MIN(SQUARE(txm-xcent), SQUARE(tx-xcent))
// 				+MIN(SQUARE(tym-ycent), SQUARE(ty-ycent))
// 				< R3*R3) ){

			/* set gas inflow velocity*/
			if (ac[IJK] > em6){
				u[IJK] = ZERO;
				v[IJK] = ZERO;

// 				w[IJK] = -115.7 * t + wf2;
				w[IJK] = -0.1;
			}
// 		}
		if ((MIN(SQUARE(txm-xcent), SQUARE(tx-xcent))
				   +MIN(SQUARE(tym-ycent), SQUARE(ty-ycent))
				   < RDIHEN*RDIHEN) ){

			/* set solution inflow velocity*/
			if (ac[IJK] > em6){
				u[IJK] = ZERO;
				v[IJK] = ZERO;
				w[IJK] = wf1;
			}
		}
// 			if ((MIN(SQUARE(txm-xcent), SQUARE(tx-xcent))
// 						  +MIN(SQUARE(tym-ycent), SQUARE(ty-ycent))
// 						  > R3*R3) ){
//
// 				/* set wall BC outside of DIHEN tip */
// // 				u[IJK] = -u[IJKM];
// // 				v[IJK] = -v[IJKM];
// // 				w[IJK] = ZERO;
//
// 				/* force inflow outside of DIHEN tip */
// 				u[IJK] = u[IJKM];
// 				v[IJK] = v[IJKM];
// 				w[IJK] = wf1;
// 			}
		}
	/*
	* Calling SETPROPERTIES in order to correctly set rho_c arrays after overwriting
	* the f field with the call to memcpy.
	*/
	initf();	/* set solution inflow  velocity */
	setproperties();
}
void open_O(void){
	/*This sets the entire over face to be open boundary
	*/
	/*
	int i,j,k;
	k=km2;
	for(i=1;i<im1;i++)
		for(j=1;j<jm1;j++)
		{
			f[IJKP]=ZERO;
			u[IJKP]=u[IJK];
			v[IJKP]=v[IJK];
			w[IJK] =w[IJKM];
			p[IJKP]=p[IJK];
		}
	*/
	int i,j,k;
	k=km2;
	for(i=1;i<im1;i++)
		for(j=1;j<jm1;j++)
		{
			f[IJKP]=f[IJK];
			u[IJK]=u[IJKM];
			v[IJK]=v[IJKM];
			w[IJK]=w[IJKM];
			p[IJKP]=p[IJK];
		}
}
void lid_O(void){
	/*This sets the entire over face to be a moving lid
	  in the +y direction
	*/
	int i,j,k;
	double vlid = 1.0;//Lid velocity
	k=km1;
	for(i = 1; i < im1; i++)
		for(j = 1; j < jm1; j++)
		{
			u[IJK] = u[IJKM];
			v[IJK] = 2 * vlid - v[IJKM];
			w[IJKM] = 0.0;//no penetration
			f[IJK] = f[IJKM];
			p[IJK] = p[IJKM];
		}
}
void NoGhostInfo(Vector *V){
	/*This function removes ghost cell information from vector v. Used in CGIter.
	*/
	int i,j,k;
	int	el=0;
	for (k=0;k<kmax;k++)
		for (j=0;j<jmax;j++)
			for (i=0;i<imax;i++)
			{
				el++;
				if(i==0 || i==im1 || j==0 || j==jm1 || k==0 || k==km1)
					V_SetCmp(V,el,0.0);
			}
	//return(V);
}
void apply_bubble_pressure(void){
    int i,j,k;
    //find pressure force
    get_bubble_pressure();//set bubble pressure Pb
    Pb -= 101325;//make Pb a gauge value to be consistent with the code
    /*assign new Pb to bubble cells*/
    if (ncyc == 1)
        for (k=1;k<km1;k++)
            for (j=1;j<jm1;j++)
                for (i=1;i<im1;i++)
                    if (bubble[IJK].current)
                        p[IJK] = p[IJK]*f[IJK] + (1 - f[IJK]) * Pb;

    for (i=1;i<im1;i++)
        for (j=1;j<jm1;j++)
            for (k=1;k<km1;k++)
            {
                if (bubble[IJK].current  ||
                    bubble[IPJK].current ||
                    bubble[IJPK].current ||
                    bubble[IJKP].current)
                {
                        //reset x-velocity and check for surrounding fluid
                    if (ar[IJK]>=em6)
                        u[IJK] += delt*(p[IJK]-p[IPJK])*2.0/(rhorc[IJK]*(delx[i+1]+delx[i]));
                    else
                        u[IJK]=0.0;

                        //reset y-velocity and check for surrounding fluid
                    if (af[IJK]>=em6)
                        v[IJK] += delt*(p[IJK]-p[IJPK])*2.0/(rhofc[IJK]*(dely[j+1]+dely[j]));
                    else
                        v[IJK]=0.0;

                        //reset z-velocity and check for surrounding fluid
                    if (ao[IJK]>=em6)
                        w[IJK] += delt*(p[IJK]-p[IJKP])*2.0/(rhooc[IJK]*(delz[k+1]+delz[k]));
                    else
                        w[IJK]=0.0;
                }
            }
}
void update_bubble(void){
    /*this subroutine updates the flag that keeps track of
      bubble cells in the domain, bubble.current.
    */
    int i,j,k;

    for (k=1;k<km1;k++)
        for (j=1;j<jm1;j++)
            for (i=1;i<im1;i++)
            {
                if (ac[IJK] > em6 &&        /*cell IJK is fluid cell and*/
                    z[k] < BUBBLE_Z_LIM &&  /*below certain Z and*/
                    f[IJK] < em61)          /*fully or partially empty*/
                {
                    bubble[IJK].current = true;
                    p[IJK] = p[IJK]*f[IJK] + (1 - f[IJK]) * Pb;
                }
                else
                    bubble[IJK].current = false;
            }
}
void ReadBC(void){
    if(mpi.MyRank == 0)
    {
        int tfx, tfy, tfz;
        char str[8];
        FILE *in = fopen("BC.DAT", "r");

        if (!in)    /*exit if can't open BC.DAT file*/
        {
            printf ("Process %d is unable to open BC.DAT file\n", mpi.MyRank);
            exit (1);
        }

        fscanf(in, "%lf %lf %lf\n", &xe, &ye, &ze);

        fscanf(in, "%d %d %d\n", &tfx, &tfy, &tfz);

        fscanf(in, "%s %d", &str, &kl);
        fscanf(in, "%s %d", &str, &kr);
        fscanf(in, "%s %d", &str, &kb);
        fscanf(in, "%s %d", &str, &kf);
        fscanf(in, "%s %d", &str, &ku);
        fscanf(in, "%s %d", &str, &ko);

        dim.fx = tfx - 1;
        dim.fy = tfy - 1;
        dim.fz = tfz - 1;
    }/*if(mpi.MyRank == 0)*/

    /*broadcast read-in data to all processors*/
    bcastdata(&xe, sizeof(double));
    bcastdata(&ye, sizeof(double));
    bcastdata(&ze, sizeof(int));
    bcastdata(&dim.fx, sizeof(int));
    bcastdata(&dim.fy, sizeof(int));
    bcastdata(&dim.fz, sizeof(int));
    bcastdata(&kl, sizeof(int));
    bcastdata(&kr, sizeof(int));
    bcastdata(&kb, sizeof(int));
    bcastdata(&kf, sizeof(int));
    bcastdata(&ku, sizeof(int));
    bcastdata(&ko, sizeof(int));
}
void ReadLIQUID(void){
    /*This subroutine opens a file LIQUID.DAT generated by ICEM software
    at SIMULENT INC. LIQUID.DAT contains information on the position and
    initial velocity of a liquid defined inside the numerical domain.
    */

    int n, i, j, k;
    double txi, tyj, tzk, tf;

    FILE *in = fopen("LIQUID.DAT", "r");

    if (!in)    /*exit if can't open LIQUID.DAT file*/
    {
        printf ("Process %d is unable to open LIQUID.DAT file\n", mpi.MyRank);
        exit (1);
    }

    fscanf(in,"%lf %lf %lf\n", &uf1, &vf1, &wf1);
    while(fgetc(in) != EOF)
    {
        fscanf(in, "%lf %lf %lf %lf\n", &txi, &tyj, &tzk, &tf);

        if(IN_MY_XDOM && IN_MY_YDOM && IN_MY_ZDOM)
        {
            for(n = 1; n < im1; n++)
                if(equal(txi, xi[n], TOL))
                {
                    i = n;
                    break;
                }
            for(n = 1; n < jm1; n++)
				if(equal(tyj, yj[n], TOL))
                {
                    j = n;
                    break;
                }
            for(n = 1; n < km1; n++)
				if(equal(tzk, zk[n], TOL))
                {
                    k = n;
                    break;
                }
            f[IJK] = tf;
            u[IJK] = uf1;
            v[IJK] = vf1;
            w[IJK] = wf1;
        }/*if(IN_MY_XDOM && IN_MY_YDOM && IN_MY_ZDOM)*/
    }/*while(fgetc(in) != EOF)*/
}
void ReadSOLID(void){
    /*
	 * This subroutine read SOLID.DAT file created by ICEM software
     * at SIMULENT. The information in SOLID.DAT is used to generate
     * obstacles in the numerical domain of p3pple.
     */
    int i, j, k, n;
    double txi, tyj, tzk, tac;
    FILE *in = fopen("SOLID.DAT", "r");

    if (!in)    /*exit if can't open SOLID.DAT file*/
    {
        printf ("Process _%d_ is unable to open SOLID.DAT file\n", mpi.MyRank);
        exit (1);
    }

    /* initialize everything as fluid first */
    for (n = 0; n < NX * NY * NZ; n++)
    {
        ac[n]=1.0;
        ar[n]=1.0;
        af[n]=1.0;
        ao[n]=1.0;
    }

    while(fgetc(in) != EOF)
    {
        fscanf(in, "%lf %lf %lf %lf\n", &txi, &tyj, &tzk, &tac);

        if(IN_MY_XDOM && IN_MY_YDOM && IN_MY_ZDOM)
        {
            for(n = 1; n < im1; n++)
				if(equal(txi,xi[n], TOL))
            {
                i = n;
                break;
            }
            for(n = 1; n < jm1; n++)
				if(equal(tyj, yj[n], TOL))
            {
                j = n;
                break;
            }
            for(n = 1; n < km1; n++)
				if(equal(tzk, zk[n], TOL))
            {
                k = n;
                break;
            }
             if(tac >= 0.5)
             {
                ac[IJK] = 0;
                ar[IJK] = 0;
                af[IJK] = 0;
                ao[IJK] = 0;
             }

        }/*if(IN_MY_XDOM && IN_MY_YDOM && IN_MY_ZDOM)*/
    }/*while(fgetc(in) != EOF)*/

	/* Flag processors having obstacle surface cells.
	 * Used to optimize applying BCs on obstacle faces
	 */
	if (mpi.NProc < 2) tecpo();		/* print obstacle.rbd file */

	flagproc();         			/* flag processors which have obstacle surface cells in
									* their local domain */
	if (mpi.obst_flag)
		flagobs();	    			/* flag obtacle surface cells according
									* to their orientation to the fluid cells */
}
void OpenFiles(void){
    /*
	 * This subroutine open input and output files
     */
    char temp[20];

    files.input = fopen ("input", "rt");

    sprintf (temp, "error%04d", mpi.MyRank);
    files.error = fopen (temp, "wt");

    sprintf (temp, "out%04d", mpi.MyRank);
    files.out = fopen(temp, "wt");

    sprintf (temp, "spherity");
    files.sphere = fopen (temp,"wt");

    sprintf (temp, "summary%02d.txt", mpi.MyRank);
    files.summary = fopen (temp,"wt");
}
void CloseFiles(void){
	for (int i=0;i<sizeof(files);i+=sizeof(FILE*))
		fclose (((FILE**)&files)[i/sizeof(FILE*)]);
}
void CA_Under(void){
    /*
     * This subroutine applies contact angles Kmin face of the numerical domain
     * as well as to the obstacles located under the fluid.
     */

    int i, j, k;

	/*
     * first copy gradrox,gradroy,gradroz from k=2 to k=1
     */
	if (mpi.Neighbors[4]==-1)
	{
		/*fortran-style arrays...gradro_ (i,j,1) = gradro_ (i,j,2);*/
		memcpy (&gradrox[IND(0,0,1)], &gradrox[IND(0,0,2)], NX*NY*sizeof(double));
		memcpy (&gradroy[IND(0,0,1)], &gradroy[IND(0,0,2)], NX*NY*sizeof(double));
		memcpy (&gradroz[IND(0,0,1)], &gradroz[IND(0,0,2)], NX*NY*sizeof(double));
	}

////#define CA_Everywhere
//#define CA_4x4
////sanity checks
//#if defined CA_Everywhere && defined CA_4x4
//#	error Both CA_Everywhere and CA_4x4 #defined.
//#endif
//#if !defined CA_Everywhere && !defined CA_4x4
//#	error Neither CA_Everywhere nor CA_4x4 #defined.
//#endif

	///*
     //* Processor must have global k=1
     //*/
	//if (ncyc != 0 && mpi.Neighbors[4]==-1)
	//{

//#ifdef CA_Everywhere
		////apply contact angles everywhere
		//k=1;
		//for (i=1;i<imax;i++)
			//for (j=1;j<jmax;j++)
			//{
				//const double f4=f[IJK]+f[IMJK]+f[IJMK]+f[IMJMK];
				//if (f4 < 1.0 || f4 > 3.0) continue;
				//const double gradro1=sqrt(SQUARE(gradrox[IJK])+SQUARE(gradroy[IJK])+SQUARE(gradroz[IJK]));
				//const double gradroxy=sqrt(SQUARE(gradrox[IJK]+SQUARE(gradroy[IJK]);
				//gradroz[IJK]=gradroxy*tan(cangleu-pi2);
				//const double gradro2=sqrt(SQUARE(gradrox[IJK])+SQUARE(gradroy[IJK])+SQUARE(gradrox[IJK])+em6);
				//gradrox[IJK] *= gradro1/gradro2;
				//gradroy[IJK] *= gradro1/gradro2;
				//gradroz[IJK] *= gradro1/gradro2;
			//}
//#endif	//CA_Everywhere
//#ifdef CA_4x4

		////let's try this ... having copied normals from k=2 to k=1,
		////only apply contact angles at those nodes which have
		////both (partial) fluid cells and empty cells within a
		////4x4 stencil of the k=2 node

		////note that if i=2 or j=2, my 4x4 stencil extends beyond the
		////ghost cells, and I correct for that; I don't bother to
		////do the same at the i=im1 and j=jm1 boundaries



		//double rca=0.0;	 //used for 'contact angle as function of velocity'
		//int nca=0;

	        
		////printf("ca_under:gradrox_top = %.9e gradrox_bot=%.9e\n",gradrox[IND(37,65,1)],gradrox[IND(37,1,1)]);
		  
		//k=1;
		//for (i=1;i<=im1;i++)
			//for (j=1;j<=jm1;j++)
			//{
				////if the 2x2 stencil about the ndoe is either completely
				////full or completely empty, forget about a contact angle.
				//const double f4=f[IJK]+f[IMJK]+f[IJMK]+f[IMJMK];
				////if (f4<1.0 || f4 > 3.0) continue;
				//if (f4==0.0 || f4==4.0) continue;
			        ////if(IJK==IND(37,65,1) || IJK==IND(37,1,1)) printf("j=%d : entered till first\n",j);
				////so there's fluid within the 2x2 stencil; now can I find
				////an empty cell in the 4x4 stencil?
				//const int imjpk = (j==jm1)? IMJK : IMJK + imax;
				//const int ijpk = (j==jm1)? IJK : IJK + imax;
				//const int ipjk = (i==im1)? IJK : IJK + 1;
				//const int ipjmk = (i==im1)? IJMK : IJMK + 1;
				//const int im2jmk    = (i==1)? IMJMK : IMJMK - 1;
				//const int im2jk     = (i==1)? IMJK  : IMJK  - 1;
				//int im2jpk	= (i==1)? IMJPK : IMJPK - 1;
				//int ipjm2k    = (j==1)? IPJMK : IPJMK - imax;
				//const int ijm2k     = (j==1)? IJMK  : IJMK  - imax;
				//const int imjm2k    = (j==1)? IMJMK : IMJMK - imax;
				//int im2jm2k = IMJMK-imax-1;
				//int ipjpk = IJK+1+imax;
				
				//if (i==1) im2jm2k++;
				//if (j==1) im2jm2k+=imax;
				//if (i==im1) ipjpk--;
				//if (j==jm1) ipjpk-=imax;
				//if (j==jm1) im2jpk-=imax;
				//if (i==im1) ipjm2k--;
			        
				
				//if (f[imjpk]!=0.0)
				//if (f[ijpk]!=0.0)
				//if (f[ipjpk]!=0.0)
				//if (f[ipjk]!=0.0)
				//if (f[ipjmk]!=0.0)
				//if (f[im2jmk]!=0.0)
				//if (f[im2jk]!=0.0)
				//if (f[im2jpk]!=0.0)
				//if (f[ipjm2k]!=0.0)
				//if (f[ijm2k]!=0.0)
				//if (f[imjm2k]!=0.0)
				//if (f[im2jm2k]!=0.0)
					//continue;	//can't find a nearby empty cell.
			        ////if(mpi.MyRank==0) {
			        ////if(IJK==IND(37,65,1) || IJK==IND(37,1,1)) printf("j=%d : entered till second\n",j);
				////}
				///*
                 //* apply a contact angle to node (i,j,k)
                 //*/
				//const double gradro1=sqrt(SQUARE(gradrox[IJK])+SQUARE(gradroy[IJK])+SQUARE(gradroz[IJK]));
				//const double gradroxy=sqrt(SQUARE(gradrox[IJK])+SQUARE(gradroy[IJK]));

				///*************** constant contact angle modle **********************************************/
				///*******************************************************************************************/
//// 				gradroz[IJK]=gradroxy*tan(cangleu-pi2);		/* constant contact angle model */
				///*******************************************************************************************/
				///*******************************************************************************************/


				///*************** contact angle as function of line velocity model **************************/
				///*******************************************************************************************/
				//double varca=cangle(5,i,j,1);
				//rca += varca;
				//nca ++;
				//gradroz[IJK]=gradroxy*tan(varca-pi2);
				///*******************************************************************************************/
				///*******************************************************************************************/

				//const double gradro2=sqrt(SQUARE(gradrox[IJK])+SQUARE(gradroy[IJK])+SQUARE(gradroz[IJK])+em6);
				//gradrox[IJK]*=gradro1/gradro2;
				//gradroy[IJK]*=gradro1/gradro2;
				//gradroz[IJK]*=gradro1/gradro2;

			//}
//#endif	//CA_4x4
	//}//if ncyc !=0

	if(mpi.obst_flag)				/* set contact angles for obstacle cells */
		normalsobs(NULL);

    xchg<double> (gradrox);			/* exchange gradro_'s before calculating avn_'s */
    xchg<double> (gradroy);
    xchg<double> (gradroz);
}
void PrintCycleInfo(void){
	/*
	 * This function prints cycle info to stdout and summary file.  This used to be in
	 * ripple.cpp suboruitne but I moved it here to clean up the main() funciton.
	 */
	fprintf (files.summary,"%d: Iteration time: %d. t=%.3e, delt=%.3e, runtime=%d ms\n", ncyc, LTime, t, delt, wtime());
	/* only root process prints to screen*/
	if (mpi.MyRank ==0)
		printf ("%d: Iteration time: %d. t=%.3e, delt=%.3e, runtime=%d ms\n\n",
				ncyc, LTime, t, delt, wtime());
}

#define NDIM 3
void crossProduct(double *a, double *b, double *c) { //a = b x c
	a[1] = b[2] * c[3] - c[2] * b[3]; 
	a[2] = b[3] * c[1] - c[3] * b[1]; 
	a[3] = b[1] * c[2] - c[1] * b[2];
}

/*
#define crossProduct(a,b,c) \ //a = b x c
	(a)[1] = (b)[2] * (c)[3] - (c)[2] * (b)[3]; \
	(a)[2] = (b)[3] * (c)[1] - (c)[3] * (b)[1]; \
	(a)[3] = (b)[1] * (c)[2] - (c)[1] * (b)[2];
*/
	
#ifdef rudman_fine
#ifdef __solid
//-----------please follow the alphabetic order to add function declarations------------------------
void add_fvirt();
double area3D_polygon (st_point *vert, st_point *nor, int n_vert);
void calc_inertia_cube(double In[][NDIM+1], st_point *cent, st_point *lcent, double vol);
void calc_inertia_poly(double In[][NDIM+1],st_point *cent, st_point *corner, st_polyhedron *psi_poly);
void calc_inertia_tetra(double lIn[][NDIM+1],st_point *tri);
void calc_nor(st_point *nor, st_point *vec_c, double *r, double *theta, st_point *vec_a, st_point *vec_b);
void const_face (st_point *cell_vert, int n_verts, st_point *cent, st_point *nor, st_polyhedron *ptr, int m);
void contact_2p(int i, int j, int k);
void contact_1p(int i, int j, int k);
void contact_3p(int i, int j, int k);
void cross_prod(st_point *vec_c, st_point *vec_a, st_point *vec_b);
void cube_plane_int2(double *f_p, st_polyhedron *ipsi_ptr, st_point *nor, st_point *cent, int i, int j, int k, int i2, int j2, int k2, int sp);
double dif_dot(st_point *pt, st_point *cent, st_point *nor);
int equal_vert(st_point *pt1, st_point *pt2);
void flag_2p1p();
void func_g (double *g_x, st_polyhedron *ipsi_poly, st_point *nor, st_point *cent, int i, int j, int k);
void fvirt_call2();
void layer_3p();
void lubksb(double a[][NDIM+1], int n, int *indx, double b[]);
void ludcmp(double a[][NDIM+1], int n, int *indx, double *d);
void lump_mat(double In[][NDIM+1],double lIn[][NDIM+1]) ;
void lump_vec(double vec[NDIM+1],double lvec[NDIM+1]);
void m23_one_cell(double *f_p, double *alpha_p, int i, int j, int k);
void point2Quat(Quat *qq, st_point *pt);
double poly_area(st_point *vert, int n_vert);
void Quat2point(st_point *pt, Quat *qq);
Quat qt_mul (Quat *qL, Quat *qR);
void recons_3p(st_polyhedron *ipsi_poly, st_point *nor, st_point *cent, int i, int j, int k);
void scal_vec_mul(st_point *vec_c, double scal_a, st_point *vec_b);
void sort_ccw(st_point *vert, int *n, int *vert_indx);
void sort_ccw2(st_point *vert, int *n, int *vert_indx);
void sph_one_cell(double *f_p, int i, int j, int k, st_point* cent, double r2); 
template <class T> void val_indx(int i, int j, int k, T &val, T *array, T *gArray);
void vec_dot(double *d, st_point *vec_a, st_point *vec_b);
void vec_weight(st_point *p, st_point *p1, st_point *p2, double mu); 
//-----------declarations end here please follow alphabetical order---------------------------------

void initpsi_f(st_point *cent, double *rad) 
{
	double tx, ty, tz, txm, tym, tzm; //temporary x,y,z of ijk
	
	double Sradius=(*rad); //enter the radius of solid sphere here
	double r2=Sradius*Sradius;
	double Xcent, Ycent, Zcent,p_vol; //center of the solid sphere
	//Xcent = 0.5; Ycent = 0.234375; Zcent = 0.234375;
	Xcent = cent->x, Ycent = cent->y, Zcent = cent->z;
	double psitotal=0.0;
	double psi_total = 0.0;
	int i,j,k;

	//loop that initialized the psi-field of a sphere

	for (i=1;i<im1_f;i++) //loop through REAL cells
		for (j=1;j<jm1_f;j++)
			for (k=1;k<km1_f;k++)
			{	
				//cell is empty?
				tx = (i+2*mpi.OProc[0])*0.5e0*delx[1]; //global coordinates in fine-grid
				ty = (j+2*mpi.OProc[1])*0.5e0*dely[1];
				tz = (k+2*mpi.OProc[2])*0.5e0*delz[1];
				
				txm = tx-0.5e0*delx[1];
				tym = ty-0.5e0*dely[1];
				tzm = tz-0.5e0*delz[1];
								
				//goto cube;
				if ( MIN(SQUARE(txm-Xcent), SQUARE(tx-Xcent))
					+MIN(SQUARE(tym-Ycent), SQUARE(ty-Ycent))
					+MIN(SQUARE(tzm-Zcent), SQUARE(tz-Zcent))
					>= r2) {
					p_vol=0.0; //do nothing for multiple bodies
				}
				//cell is full?
				else if ( MAX(SQUARE(txm-Xcent), SQUARE(tx-Xcent))
					+MAX(SQUARE(tym-Ycent), SQUARE(ty-Ycent))
					+MAX(SQUARE(tzm-Zcent), SQUARE(tz-Zcent))
					<= r2)
					p_vol=1.0;
	
				//cell neither empty nor full
				else
				{
					p_vol=0.0;
					for (int l=0;l<25;l++)
						for (int m=0;m<25;m++)
							for (int n=0;n<25;n++)
							{	
								if (SQUARE(txm+(l+0.5)/25.0*delx[1]*0.5e0-Xcent)+
									SQUARE(tym+(m+0.5)/25.0*dely[1]*0.5e0-Ycent)+
									SQUARE(tzm+(n+0.5)/25.0*delz[1]*0.5e0-Zcent)
									< r2)
									p_vol+= 6.4e-5;
							}
				}
				psitotal += p_vol*vol_f[IJK_f];
				psi_total += p_vol;
				psi_f[IJK_f] += p_vol;
			}

	fprintf (files.sphere, "psi_volume = %12.8e, and ftotal = %12.8e\n", psitotal, psi_total);
	//printf("mpiproc = %d: psitotal=%12.8e adn psi_total=%12.8e\n",mpi.MyRank,psitotal,psi_total);
}


void initvoidpsi_f() {
	double tx, ty, tz, txm, tym, tzm; //temporary x,y,z of ijk
	double Sradius=0.15625; //enter the radius of solid sphere here
	double r2=Sradius*Sradius;
	double Xcent, Ycent, Zcent; //center of the solid sphere
	Xcent = 0.75; Ycent = 0.25; Zcent = 0.5;
	double psitotal=0.0;
	double psi_total = 0.0;
	int i,j,k;

	//loop that initialized the psi-field of a sphere

	for (i=1;i<im1_f;i++) //loop through REAL cells
		for (j=1;j<jm1_f;j++)
			for (k=1;k<km1_f;k++)
			{	
				//cell is empty?
				tx = (i+2*mpi.OProc[0])*0.5e0*delx[1]; //global coordinates in fine-grid
				ty = (j+2*mpi.OProc[1])*0.5e0*dely[1];
				tz = (k+2*mpi.OProc[2])*0.5e0*delz[1];
				
				txm = tx-0.5e0*delx[1];
				tym = ty-0.5e0*dely[1];
				tzm = tz-0.5e0*delz[1];
								
				//goto cube;
				if ( MIN(SQUARE(txm-Xcent), SQUARE(tx-Xcent))
					+MIN(SQUARE(tym-Ycent), SQUARE(ty-Ycent))
					+MIN(SQUARE(tzm-Zcent), SQUARE(tz-Zcent))
					>= r2)
					psi_f[IJK_f]=1.0;
				//cell is full?
				else if ( MAX(SQUARE(txm-Xcent), SQUARE(tx-Xcent))
					+MAX(SQUARE(tym-Ycent), SQUARE(ty-Ycent))
					+MAX(SQUARE(tzm-Zcent), SQUARE(tz-Zcent))
					<= r2)
					psi_f[IJK_f]=0.0;
	
				//cell neither empty nor full
				else
				{
					psi_f[IJK_f]=0.0;
					for (int l=0;l<25;l++)
						for (int m=0;m<25;m++)
							for (int n=0;n<25;n++)
							{	
								
								if (SQUARE(txm+(l+0.5)/25.0*delx[1]*0.5e0-Xcent)+
									SQUARE(tym+(m+0.5)/25.0*dely[1]*0.5e0-Ycent)+
									SQUARE(tzm+(n+0.5)/25.0*delz[1]*0.5e0-Zcent)
									>= r2)
									psi_f[IJK_f]+= 6.4e-5;
							}
				}
				psitotal += psi_f[IJK_f]*vol_f[IJK_f];
				psi_total += psi_f[IJK_f];
			}

	fprintf (files.sphere, "psi_volume = %12.8e, and ftotal = %12.8e\n", psitotal, psi_total);
}

void init_sol_cube(st_point *cent, st_point *dimen) {
	//solid density is set in rinput()
	int i,j,k;
	double tx,ty,tz,txm,tym,tzm;
	double xl,xr,yb,yf,zu,zo,p_vol;
	
	double psitotal = 0.0;
	double psi_total = 0.0;
	
	//the limits of the solid cube... cells allowed partial cell in this routine
	xl=cent->x-0.5*(dimen->x), xr=cent->x+0.5*(dimen->x);
	yb=cent->y-0.5*(dimen->y), yf=cent->y+0.5*(dimen->y);
	zu=cent->z-0.5*(dimen->z), zo=cent->z+0.5*(dimen->z);
	
	for(i=1;i<im1_f;i++)
		for(j=1;j<jm1_f;j++)
			for(k=1;k<km1_f;k++) 
			{	
				tx = (i+2*mpi.OProc[0])*0.5e0*delx[1];
				ty = (j+2*mpi.OProc[1])*0.5e0*dely[1];
				tz = (k+2*mpi.OProc[2])*0.5e0*delz[1];
				
				txm = tx - 0.5e0*delx[1];
				tym = ty - 0.5e0*dely[1];
				tzm = tz - 0.5e0*delz[1];
				
				p_vol = 0.e0;
				if(txm>=xl && tx<=xr) p_vol = 1.e0;
				else if(txm<xl && tx>xl) p_vol = (tx-xl)/(0.5e0*delx[1]);
				else if(txm<xr && tx>xr) p_vol = (xr-txm)/(0.5e0*delx[1]);
				
				//y-direction
				if(tym>=yb && ty<=yf) p_vol *=1.e0;
				else if(tym<yb && ty>yb) p_vol *= (ty-yb)/(0.5e0*dely[1]);
				else if(tym<yf && ty>yf) p_vol *= (yf-tym)/(0.5e0*dely[1]);
				else p_vol *= 0.e0;
				
				//z-direction
				if(tzm>=zu && tz<=zo) p_vol *=1.e0;
				else if(tzm<zu && tz>zu) p_vol *= (tz-zu)/(0.5e0*delz[1]);
				else if(tzm<zo && tz>zo) p_vol *= (zo-tzm)/(0.5e0*delz[1]);
				else p_vol *= 0.e0;
				
				psitotal += p_vol*vol_f[IJK_f];
				psi_total += p_vol;
				
				psi_f[IJK_f] += p_vol; //for multiple solid bodies
				
			}
	fprintf (files.sphere, "psi_volume = %12.8e, and ftotal = %12.8e\n", psitotal, psi_total);
	//printf("mpiproc = %d: psitotal=%12.8e adn psi_total=%12.8e\n",mpi.MyRank,psitotal,psi_total);
}

void init_inc_rect (st_point *pcent, st_point *dimen, double phi0) {
	//initializes initial rectangle for Jung et al. (2006) free roll decay
	double H,L;
	st_point pt[4],ct[4]; st_point cent;
	st_point nor[4];
	st_polyhedron cube_poly, tmp_poly1, tmp_poly2;
	int i,j,k,ii;
	
	//set dimensions and initial inclination
	H = dimen->z, L = dimen->x; //phi0 = 15.0*M_PI / 180.0; ...made an input now
	equate_pt(&cent,pcent);
	
	//if(mpi.MyRank==0) printf("sin = %e cos = %e \n",sin(phi0),cos(phi0));
	pt[0].x = cent.x - (H/2.0)*sin(phi0), pt[0].y = 0.0, pt[0].z = cent.z +  (H/2.0)*cos(phi0);
	nor[0].x = sin(phi0), nor[0].y = 0.0, nor[0].z = -cos(phi0);
	
	pt[1].x = cent.x + (H/2.0)*sin(phi0), pt[1].y = 0.0, pt[1].z = cent.z -  (H/2.0)*cos(phi0);
	nor[1].x = -sin(phi0), nor[1].y = 0.0, nor[1].z = cos(phi0);
	
	pt[2].x = cent.x - (L/2.0)*cos(phi0), pt[2].y = 0.0, pt[2].z = cent.z - (L/2.0)*sin(phi0);
	nor[2].x = cos(phi0), nor[2].y = 0.0, nor[2].z = sin(phi0);
	
	pt[3].x = cent.x + (L/2.0)*cos(phi0), pt[3].y = 0.0, pt[3].z = cent.z + (L/2.0)*sin(phi0);
	nor[3].x = -cos(phi0), nor[3].y = 0.0, nor[3].z = -sin(phi0);
	
	for(ii=0;ii<4;ii++) {
		pt[ii].x /= (0.5*delx[1]);
		pt[ii].y /= (0.5*dely[1]);
		pt[ii].z /= (0.5*delz[1]);
	}
	
	const_sim_polyhedron(&cube_poly);
	
	for(i=1;i<im1_f;i++)
	 for(j=1;j<jm1_f;j++)
	  for(k=1;k<km1_f;k++) {
			//perform scaling in unit coordinate system of current cell
			for(ii=0;ii<4;ii++) {
				ct[ii].x = pt[ii].x-(double)(i-1+2*mpi.OProc[0]);
				ct[ii].y = pt[ii].y-(double)(j-1+2*mpi.OProc[1]);
				ct[ii].z = pt[ii].z-(double)(k-1+2*mpi.OProc[2]); 
			}
			
			const_com_polyhedron(&cube_poly,&tmp_poly1,&(ct[0]),&(nor[0]),1);
			const_com_polyhedron(&tmp_poly1,&tmp_poly2,&(ct[1]),&(nor[1]),1);
			const_com_polyhedron(&tmp_poly2,&tmp_poly1,&(ct[2]),&(nor[2]),1);
			const_com_polyhedron(&tmp_poly1,&tmp_poly2,&(ct[3]),&(nor[3]),0);
			
			psi_f[IJK_f] += calc_poly_vol(&tmp_poly2);
			//if(mpi.MyRank==0 && IJK_f==IND_f(1,6,1)) {printf("pt.x=%e pt.y=%e pt.z=%e nor.x =%e nor.y=%e nor.z=%e psi_f[IJK_f]=%e\n",pt[0].x,pt[0].y,pt[0].z,nor[0].x,nor[0].y,nor[0].z,psi_f[IJK_f]); exit(1);}
	  }
}

void init_sol_cyl2 (st_point *cent, double *rad) {
	double tx, ty, tz, txm, tym, tzm;
	double R = (*rad); double Xcent, Ycent, Zcent,p_vol;
	//Xcent = 4.572; Ycent = 0.0; Zcent = 1.2446;
	Xcent = cent->x; Ycent = cent->y; Zcent = cent->z;
	double r2 = R*R;
	
	double ftotal = 0.0, f_total = 0.0;
	int i,j,k,ti,tj,tk;
	
	for(i=1;i<im1_f;i++)
	 for(j=1;j<jm1_f;j++)
	  for(k=1;k<km1_f;k++)
	  {
		  tx = (i+2*mpi.OProc[0]) * (0.5*delx[1]);
		  ty = (j+2*mpi.OProc[1]) * (0.5*dely[1]);
		  tz = (k+2*mpi.OProc[2]) * (0.5*delz[1]);
		  
		  txm = tx - (0.5*delx[1]);
		  tym = ty - (0.5*dely[1]);
		  tzm = tz - (0.5*delz[1]);
		  
		  ti=(i+1)/2, tj=(j+1)/2, tk=(k+1)/2;
		  
		  if ( MIN(SQUARE(txm-Xcent), SQUARE(tx-Xcent))
			+MIN(SQUARE(tym-Ycent), SQUARE(ty-Ycent))
			>= r2) {
			p_vol=0.0; 
		  }
		  else if ( MAX(SQUARE(txm-Xcent), SQUARE(tx-Xcent))
			+MAX(SQUARE(tym-Ycent), SQUARE(ty-Ycent))
			<= r2)
			p_vol=1.0;
		  else
		  {
			  p_vol=0.0;
			  for (int l=0;l<25;l++)
			   for (int m=0;m<25;m++)
			    for (int n=0;n<25;n++)
				{	
								
				  if (SQUARE(txm+(l+0.5)/25.0*delx[1]*0.5e0-Xcent)+
					SQUARE(tym+(m+0.5)/25.0*dely[1]*0.5e0-Ycent)
					< r2)
					p_vol += 6.4e-5;
				}
		  }
		  ftotal += p_vol*vol_f[IJK_f];
		  f_total += p_vol;
		  //if(ac[IND(ti,tj,tk)]<em6 || j+2*mpi.OProc[1]>88) continue;
		  //if(j+2*mpi.OProc[1]==87) psi_f[IJK_f] += (2.0/3.0)*p_vol; //modify back later ...ashish
		  //else psi_f[IJK_f] += p_vol;
		  //if (tz < && tz > )psi_f[IJK_f] += p_vol;
		  //if(k+mpi.OProc[2]==51) psi_f[IJK_f] += 0.8*p_vol;
		  //if(k+2*mpi.OProc[2]==261) psi_f[IJK_f] += 0.35*p_vol;
	  }
	  //printf("rank = %d: psitotal = %.12e psi_total = %.12e\n", mpi.MyRank,ftotal, f_total);
}

void init_sol_cyl (st_point *cent, double *rad) {
	double tx, ty, tz, txm, tym, tzm;
	double R = (*rad); double Xcent, Ycent, Zcent,p_vol;
//	Xcent = 3.0e-3; Ycent = 2.0e-3; Zcent = 5.4e-3;
	Xcent = cent->x; Ycent = cent->y; Zcent = cent->z;
	double r2 = R*R;
	
	double ftotal = 0.0, f_total = 0.0;
	int i,j,k,ti,tj,tk;
	
	for(i=1;i<im1_f;i++)
	 for(j=1;j<jm1_f;j++)
	  for(k=1;k<km1_f;k++)
	  {
		  tx = (i+2*mpi.OProc[0]) * (0.5*delx[1]);
		  ty = (j+2*mpi.OProc[1]) * (0.5*dely[1]);
		  tz = (k+2*mpi.OProc[2]) * (0.5*delz[1]);
		  
		  txm = tx - (0.5*delx[1]);
		  tym = ty - (0.5*dely[1]);
		  tzm = tz - (0.5*delz[1]);
		  
		  ti=(i+1)/2, tj=(j+1)/2, tk=(k+1)/2;
		  
		  if ( MIN(SQUARE(txm-Xcent), SQUARE(tx-Xcent))
			+MIN(SQUARE(tzm-Zcent), SQUARE(tz-Zcent))
			>= r2) {
			p_vol=0.0; 
		  }
		  else if ( MAX(SQUARE(txm-Xcent), SQUARE(tx-Xcent))
			+MAX(SQUARE(tzm-Zcent), SQUARE(tz-Zcent))
			<= r2)
			p_vol=1.0;
		  else
		  {
			  p_vol=0.0;
			  for (int l=0;l<25;l++)
			   for (int m=0;m<25;m++)
			    for (int n=0;n<25;n++)
				{	
								
				  if (SQUARE(txm+(l+0.5)/25.0*delx[1]*0.5e0-Xcent)+
					SQUARE(tzm+(n+0.5)/25.0*delz[1]*0.5e0-Zcent)
					< r2)
					p_vol += 6.4e-5;
				}
		  }
		  //ftotal += p_vol*vol_f[IJK_f];
		  //f_total += p_vol;
		  //if(ac[IND(ti,tj,tk)]<em6 || j+2*mpi.OProc[1]>88) continue;
		  //if(j+2*mpi.OProc[1]==87) psi_f[IJK_f] += (2.0/3.0)*p_vol; //modify back later ...ashish
		  //else psi_f[IJK_f] += p_vol;

		  psi_f[IJK_f] += p_vol;
	  }
	  //printf("rank = %d: psitotal = %.12e psi_total = %.12e\n", mpi.MyRank,ftotal, f_total);
}

int sm_cnt;
void corr_initf() {
	
	int i,j,k;
	double *rho_f = temp_f[1];
	double *psirho_f = temp_f[1];
	double *avnx_f = temp_f[6];
	double *avny_f = temp_f[7];
	double *avnz_f = temp_f[8];
	double *psiavnx_f = temp_f[9];
	double *psiavny_f = temp_f[10];
	double *psiavnz_f = temp_f[11];
	st_polyhedron ipsi_poly, liq_poly, cube_poly;
	st_point nor, cent, vec_a, cent1, nor1;
						   
	//boundary cells enabling reconstruction along subdomain boundaries
	bcf_f();
	bcpsi_f();
	
	//normals() call requires the calculation of density:
	 for(i=0;i<=im1_f;i++)
		for(j=0;j<=jm1_f;j++)
			for(k=0;k<=km1_f;k++) //calculation in ghost cells is a necessity... only after bcf etc. calls
			{
				rho_f[IJK_f] = f_f[IJK_f]*rhof1 + (1.e0-f_f[IJK_f])*1.e0; // density is calculated solely for the purpose of normals calculation...
													  // make sure this density is not used for any other purpose.. AP
			}
	
	//call normals for fluid and solid before the correction... the normals call is needed in vol_common
    normals_f();
    
    for(i=0;i<=im1_f;i++)
		for(j=0;j<=jm1_f;j++)
			for(k=0;k<=km1_f;k++) //calculation in ghost cells is a necessity... only after bcf etc. calls
			{
				psirho_f[IJK_f] = psi_f[IJK_f]*rhof0 + (1.e0-psi_f[IJK_f])*1.e0;
			}  
      
      normalspsi_f();
      const_sim_polyhedron(&cube_poly);
	
      for(i=1;i<im1_f;i++)
	    for(j=1;j<jm1_f;j++)
		  for(k=1;k<km1_f;k++)
		  { 
			if(psi_f[IJK_f]>em61) f_f[IJK_f]=0.e0; //full-solid cells
			else if(psi_f[IJK_f]>em6 && psi_f[IJK_f]<em61) { // partial solid-cells
				if(f_f[IJK_f]>em61) f_f[IJK_f] = f_f[IJK_f]-psi_f[IJK_f];
				else if(f_f[IJK_f]>em6 && f_f[IJK_f]<em61) {
					//area call for solid interface
					nor.x = psiavnx_f[IJK_f]; nor.y = psiavny_f[IJK_f]; nor.z = psiavnz_f[IJK_f];
					make_unity(&nor); //makes nor a unit vector
					area_2(psi_f[IJK_f],i,j,k,IJK_f,&nor,&cent,&vec_a); //output is cent [in unit cell coordinate system]
					
					//area call for liquid interface
					nor1.x = avnx_f[IJK_f]; nor1.y = avny_f[IJK_f]; nor1.z = avnz_f[IJK_f];
					make_unity(&nor1);
					area_2(f_f[IJK_f],i,j,k,IJK_f,&nor1,&cent1,&vec_a);
										
					//invert nor of psi
					nor.x = -nor.x; nor.y = -nor.y; nor.z = -nor.z;
					const_com_polyhedron(&cube_poly,&ipsi_poly,&cent,&nor,1);
					const_com_polyhedron(&ipsi_poly,&liq_poly,&cent1,&nor1,0);
					if(liq_poly.n < 4) f_f[IJK_f] = 0.0;
					else f_f[IJK_f] = calc_poly_vol(&liq_poly);
				}
			}
		  }
}

//define another function that calculates psi on the standard grid from fine grid psi_f values
void psifine2stnd()
{	
	int i,j,k;
	//on the standard grid
	for(k=1;k<km1;k++) //REAL cells
		for(j=1;j<jm1;j++)
			for(i=1;i<im1;i++) 
				psi[IJK]=0.125e0*(psi_f[IND_f(2*i,2*j,2*k)]+psi_f[IND_f(2*i-1,2*j,2*k)]+psi_f[IND_f(2*i-1,2*j-1,2*k)]+psi_f[IND_f(2*i,2*j-1,2*k)]
				+psi_f[IND_f(2*i,2*j,2*k-1)]+psi_f[IND_f(2*i-1,2*j,2*k-1)]+psi_f[IND_f(2*i-1,2*j-1,2*k-1)]+psi_f[IND_f(2*i,2*j-1,2*k-1)]);
}

double psi_ucv(int i,int j,int k)
{
	double psi_t;
	psi_t = 0.125e0*(psi_f[IND_f(2*i,2*j,2*k)]+psi_f[IND_f(2*i,2*j-1,2*k)]+psi_f[IND_f(2*i,2*j-1,2*k-1)]+psi_f[IND_f(2*i,2*j,2*k-1)]
			   +psi_f[IND_f(2*i+1,2*j,2*k)]+psi_f[IND_f(2*i+1,2*j-1,2*k)]+psi_f[IND_f(2*i+1,2*j-1,2*k-1)]+psi_f[IND_f(2*i+1,2*j,2*k-1)]);
	return psi_t;
}

double psi_vcv(int i,int j, int k) {
	double psi_t;
	psi_t = 0.125e0*(psi_f[IND_f(2*i,2*j,2*k)]+psi_f[IND_f(2*i-1,2*j,2*k)]+psi_f[IND_f(2*i-1,2*j,2*k-1)]+psi_f[IND_f(2*i,2*j,2*k-1)]
			    +psi_f[IND_f(2*i,2*j+1,2*k)]+psi_f[IND_f(2*i-1,2*j+1,2*k)]+psi_f[IND_f(2*i-1,2*j+1,2*k-1)]+psi_f[IND_f(2*i,2*j+1,2*k-1)]);
	return psi_t;
}

double psi_wcv(int i,int j,int k) {
	double psi_t;
	psi_t = 0.125e0*(psi_f[IND_f(2*i,2*j,2*k)]+psi_f[IND_f(2*i-1,2*j,2*k)]+psi_f[IND_f(2*i-1,2*j-1,2*k)]+psi_f[IND_f(2*i,2*j-1,2*k)]
			    +psi_f[IND_f(2*i,2*j,2*k+1)]+psi_f[IND_f(2*i-1,2*j,2*k+1)]+psi_f[IND_f(2*i-1,2*j-1,2*k+1)]+psi_f[IND_f(2*i,2*j-1,2*k+1)]);
	return psi_t;
}

typedef struct {
	st_point cent; //material volume centroid
} rigid_force;

void print_veloci() {
	int i,j,k;
	double *psimx = temp[21], *psimy = temp[22], *psimz = temp[23];
	i=35,j=1,k=91; printf("U(%d %d %d) = %e PSI=%e\n",i,j,k,u[IJK],psimx[IJK]);
	i=34,j=1,k=90; printf("U(%d %d %d) = %e PSI=%e\n",i,j,k,u[IJK],psimx[IJK]);
	i=37,j=1,k=89; printf("U(%d %d %d) = %e PSI=%e\n",i,j,k,u[IJK],psimx[IJK]);
	
	i=36,j=1,k=89; printf("W(%d %d %d) = %e PSI=%e\n",i,j,k,w[IJK],psimz[IJK]);
	i=35,j=1,k=88; printf("W(%d %d %d) = %e PSI=%e\n",i,j,k,w[IJK],psimz[IJK]);
	i=38,j=1,k=86; printf("W(%d %d %d) = %e PSI=%e\n",i,j,k,w[IJK],psimz[IJK]);
	
	i=34,j=1,k=90; printf("%e %e %e %e\n",psi_f[IND_f(2*i,2*j,2*k-1)],psi_f[IND_f(2*i+1,2*j,2*k-1)],psi_f[IND_f(2*i,2*j,2*k)],psi_f[IND_f(2*i+1,2*j,2*k)]);
} 

void solid_bc_rigid ();

void Nrigid_body_vel3(int bindx) {
	//written for six degrees of freedom..  for solid body dynamics
	int i,j,k;
	double *psimx = temp[21], *psimy = temp[22], *psimz = temp[23];
	double *psiavnx_f = temp_f[9];
	double *psiavny_f = temp_f[10];
	double *psiavnz_f = temp_f[11];
	
	st_point cent;
	equate_pt(&cent,&Cent[bindx]);
	
	int nmx, nmy, nmz;
	nmx=nmy=nmz=0;
	for(k=k_min[bindx];k<=k_max[bindx];k++)
	 for(j=j_min[bindx];j<=j_max[bindx];j++)
	   for(i=i_min[bindx];i<=i_max[bindx];i++) { //0.312/0.012=26
		  if(psimx[IJK] >= em6 && psimx[IJK] <= em61) //&& (bindx==1 || (bindx==2 && k+mpi.OProc[2]>26)))
			  nmx++;
		  if(psimy[IJK] >= em6 && psimy[IJK] <= em61) //&& (bindx==1 || (bindx==2 && k+mpi.OProc[2]>26))) 
			  nmy++;
		  if(psimz[IJK] >= em6 && psimz[IJK] <= em61) //&& (bindx==1 || (bindx==2 && k+mpi.OProc[2]>26)))
			  nmz++;
	  }
	
	rigid_force *mat_volx = (rigid_force*)calloc(nmx,sizeof(rigid_force)); //calloc initializes to zero
	rigid_force *mat_voly = (rigid_force*)calloc(nmy,sizeof(rigid_force));
	rigid_force *mat_volz = (rigid_force*)calloc(nmz,sizeof(rigid_force));
	
	//start working with material volumes
	double volt[8],voli; st_point vt[8],v0; int ii;
	double lrig_U[NDIM+1] = {0.0,0.0,0.0,0.0}, mass, lmass=0.0, Vol=delx[1]*dely[1]*delz[1]; 
	double r[NDIM+1], veloci[NDIM+1], I_Omega[NDIM+1], 	 //volume of a comp. cell
	lI_Omega[NDIM+1] = {0.0,0.0,0.0,0.0}; 	
	
	nmx=nmy=nmz=0;
	for(k=k_min[bindx];k<=k_max[bindx];k++)
	 for(j=j_min[bindx];j<=j_max[bindx];j++)
	   for(i=i_min[bindx];i<=i_max[bindx];i++) {
		  if(psimx[IJK] >= em6 && psimx[IJK] <= em61 ) {//&& (bindx==1 || (bindx==2 && k+mpi.OProc[2]>26))) { //only in partial cells
			  //centroid
			  sol_centroid(2*i,2*j,2*k,&vt[0],&volt[0]);
			  sol_centroid(2*i,2*j-1,2*k,&vt[1],&volt[1]);
			  sol_centroid(2*i,2*j-1,2*k-1,&vt[2],&volt[2]);
			  sol_centroid(2*i,2*j,2*k-1,&vt[3],&volt[3]);
		
			  sol_centroid(2*i+1,2*j,2*k,&vt[4],&volt[4]);
			  sol_centroid(2*i+1,2*j-1,2*k,&vt[5],&volt[5]);
			  sol_centroid(2*i+1,2*j-1,2*k-1,&vt[6],&volt[6]);
			  sol_centroid(2*i+1,2*j,2*k-1,&vt[7],&volt[7]);
			  v0.x = 0.0, v0.y = 0.0, v0.z = 0.0, voli = 0.0;
			  for(ii=0;ii<8;ii++) {
				  v0.x += vt[ii].x*volt[ii], v0.y += vt[ii].y*volt[ii],
				  v0.z += vt[ii].z*volt[ii];
				  voli += volt[ii];
			  }
			  v0.x /= voli, v0.y /= voli, v0.z /= voli;
			  equate_pt(&(mat_volx[nmx].cent),&(v0));
			  nmx++;
			  
			  if(IPRES[bindx]==0) {
				  //calculate vol*U for linear motion
				  lrig_U[1] += psimx[IJK]*rhof0*Vol*u[IJK];
				  //lmass += psimx[IJK]*rhof0*Vol;
				  //calculate vol* (r x u)
				  r[1]=v0.x - cent.x;
				  r[2]=v0.y - cent.y;
				  r[3]=v0.z - cent.z;
				 
				  veloci[1]=u[IJK]*rhof0*Vol*psimx[IJK], veloci[2]=0.0, veloci[3]=0.0;
				  crossProduct(I_Omega,r,veloci); //I_omega = Int (r x u dm)
				  //if(mpi.MyRank==1 || mpi.MyRank==2) fprintf(fp1,"%d %d %d %.18e %.18e %.18e\n",i,j,k,u[IJK],r[3],I_Omega[2]);
				  lump_vec(lI_Omega,I_Omega);
			  }
		  }
		  if(psimx[IJK]>em61 && IPRES[bindx]==0 ) {//&& (bindx==1 || (bindx==2 && k+mpi.OProc[2]>26))) {
			  v0.x = (i+mpi.OProc[0])*delx[1];
			  v0.y = (j+mpi.OProc[1]-0.5)*dely[1];
			  v0.z = (k+mpi.OProc[2]-0.5)*delz[1];
			  
			  //linear
			  lrig_U[1] += psimx[IJK]*rhof0*Vol*u[IJK];
			  //lmass += psimx[IJK]*rhof0*Vol;
			  //angular
			  r[1]=v0.x  - cent.x;
			  r[2]=v0.y  - cent.y;
			  r[3]=v0.z  - cent.z;
			  
			  veloci[1]=u[IJK]*rhof0*Vol*psimx[IJK], veloci[2]=0.0, veloci[3]=0.0;
			  crossProduct(I_Omega,r,veloci);
			  //if(mpi.MyRank==1 || mpi.MyRank==2) fprintf(fp1,"%d %d %d %.18e %.18e %.18e\n",i,j,k,u[IJK],r[3],I_Omega[2]);
			  lump_vec(lI_Omega,I_Omega);
		  }
		  
		  //y-momentum
		  if(psimy[IJK] >= em6 && psimy[IJK] <= em61){ //&& (bindx==1 || (bindx==2 && k+mpi.OProc[2]>26))) { //only in partial cells
			  //centroid
			  sol_centroid(2*i,2*j,2*k,&vt[0],&volt[0]);
			  sol_centroid(2*i-1,2*j,2*k,&vt[1],&volt[1]);
			  sol_centroid(2*i-1,2*j,2*k-1,&vt[2],&volt[2]);
			  sol_centroid(2*i,2*j,2*k-1,&vt[3],&volt[3]);
		
			  sol_centroid(2*i,2*j+1,2*k,&vt[4],&volt[4]);
			  sol_centroid(2*i-1,2*j+1,2*k,&vt[5],&volt[5]);
			  sol_centroid(2*i-1,2*j+1,2*k-1,&vt[6],&volt[6]);
			  sol_centroid(2*i,2*j+1,2*k-1,&vt[7],&volt[7]);
			  v0.x = 0.0, v0.y = 0.0, v0.z = 0.0, voli = 0.0;
			  for(ii=0;ii<8;ii++) {
				  v0.x += vt[ii].x*volt[ii], v0.y += vt[ii].y*volt[ii],
				  v0.z += vt[ii].z*volt[ii];
				  voli += volt[ii];
			  }
			  v0.x /= voli, v0.y /= voli, v0.z /= voli;
			  equate_pt(&(mat_voly[nmy].cent),&(v0));
			  nmy++;
			  
			  if(IPRES[bindx]==0) {
				  //calculate vol*U for linear motion
				  lrig_U[2] += psimy[IJK]*rhof0*Vol*v[IJK];
				  
				  //calculate vol* (r x u)
				  r[1]=v0.x  - cent.x;
				  r[2]=v0.y  - cent.y;
				  r[3]=v0.z  - cent.z;
				 
				  veloci[1]=0.0, veloci[2]=psimy[IJK]*rhof0*Vol*v[IJK], veloci[3]=0.0;
				  crossProduct(I_Omega,r,veloci);
				  lump_vec(lI_Omega,I_Omega);
			  }
		  }
		  if(psimy[IJK]>em61 && IPRES[bindx]==0 ){//&& (bindx==1 || (bindx==2 && k+mpi.OProc[2]>26))) {
			  v0.x = (i+mpi.OProc[0]-0.5)*delx[1];
			  v0.y = (j+mpi.OProc[1])*dely[1];
			  v0.z = (k+mpi.OProc[2]-0.5)*delz[1];
			  
			  //linear
			  lrig_U[2] += psimy[IJK]*rhof0*Vol*v[IJK];
			  
			  //angular
			  r[1]=v0.x  - cent.x;
			  r[2]=v0.y  - cent.y;
			  r[3]=v0.z  - cent.z;
			  
			  veloci[1]=0.0, veloci[2]=psimy[IJK]*rhof0*Vol*v[IJK], veloci[3]=0.0;
			  crossProduct(I_Omega,r,veloci);
			  lump_vec(lI_Omega,I_Omega);
		  }
		  
		  //z-momentum
		  if(psimz[IJK] >= em6 && psimz[IJK] <= em61 ) { //&& (bindx==1 || (bindx==2 && k+mpi.OProc[2]>26))) { //only in partial cells
			  //centroid
			  sol_centroid(2*i,2*j,2*k,&vt[0],&volt[0]);
			  sol_centroid(2*i-1,2*j,2*k,&vt[1],&volt[1]);
			  sol_centroid(2*i-1,2*j-1,2*k,&vt[2],&volt[2]);
			  sol_centroid(2*i,2*j-1,2*k,&vt[3],&volt[3]);

			  sol_centroid(2*i,2*j,2*k+1,&vt[4],&volt[4]);
			  sol_centroid(2*i-1,2*j,2*k+1,&vt[5],&volt[5]);
			  sol_centroid(2*i-1,2*j-1,2*k+1,&vt[6],&volt[6]);
			  sol_centroid(2*i,2*j-1,2*k+1,&vt[7],&volt[7]);
			  v0.x = 0.0, v0.y = 0.0, v0.z = 0.0, voli = 0.0;
			  
			  for(ii=0;ii<8;ii++) {
				v0.x += vt[ii].x*volt[ii], v0.y += vt[ii].y*volt[ii],
				v0.z += vt[ii].z*volt[ii];
				voli += volt[ii];
			  }
			  v0.x /= voli, v0.y /= voli, v0.z /= voli;
			  equate_pt(&(mat_volz[nmz].cent),&(v0));
			  nmz++;
			  
			  if(IPRES[bindx]==0) {
				  //calculate vol*U for linear motion
				  lrig_U[3] +=psimz[IJK]*rhof0*Vol*w[IJK];
				  lmass += psimz[IJK]*rhof0*Vol;
				  //calculate vol* (r x u)
				  r[1]=v0.x - cent.x;
				  r[2]=v0.y - cent.y;
				  r[3]=v0.z - cent.z;
				 
				  veloci[1]=0.0, veloci[2]=0.0, veloci[3]=psimz[IJK]*rhof0*Vol*w[IJK];
				  crossProduct(I_Omega,r,veloci);
				  //if(mpi.MyRank==1 || mpi.MyRank==2) fprintf(fp2,"%d %d %d %.18e %.18e %.18e\n",i,j,k,w[IJK],r[1],I_Omega[2]);
				  lump_vec(lI_Omega,I_Omega);
			  }
		  }
		  if(psimz[IJK]>em61 && IPRES[bindx]==0 ) { //&& (bindx==1 || (bindx==2 && k+mpi.OProc[2]>26))) {
			  v0.x = (i+mpi.OProc[0]-0.5)*delx[1];
			  v0.y = (j+mpi.OProc[1]-0.5)*dely[1];
			  v0.z = (k+mpi.OProc[2])*delz[1];
			  
			  //linear
			  lrig_U[3] += psimz[IJK]*rhof0*Vol*w[IJK];
			  lmass += psimz[IJK]*rhof0*Vol;
			  //angular
			  r[1]=v0.x - cent.x;
			  r[2]=v0.y - cent.y;
			  r[3]=v0.z - cent.z;
			  
			  veloci[1]=0.0, veloci[2]=0.0, veloci[3]=psimz[IJK]*rhof0*Vol*w[IJK];
			  crossProduct(I_Omega,r,veloci);
			  //if(mpi.MyRank==1 || mpi.MyRank==2) fprintf(fp2,"%d %d %d %.18e %.18e %.18e\n",i,j,k,w[IJK],r[1],I_Omega[2]);
			  lump_vec(lI_Omega,I_Omega);
		  }
		  }
 
	if(IPRES[bindx]==0) {
		//reduce U_rig
		dallreduce(lrig_U,rig_U[bindx],NDIM+1,OP_SUM);
		dallreduce(&lmass,&mass,1,OP_SUM);
		
#ifdef solid_entry
	//mass = 1.7319;
#endif		
		
		for(i=1;i<=NDIM;i++) rig_U[bindx][i] /= mass;
		//reduce I_Omega across mpi-subdomains
		dallreduce(lI_Omega,I_Omega,NDIM+1,OP_SUM);
		
/**
		//correction in gravity torque
		//---------------------------------------------------------------------------------
		double grav[NDIM+1], ntorque[NDIM+1], etorque[NDIM+1];
		double rmag, lenx, theta, elen, emass;
		st_point ncent, ecent;
		
		elen=0.363;//0.56875; //Hejar's solid-work's model .. actual center of mass
		emass=4.95/2.0;//228.66;
		
		Ncalc_psi_centroid(&ncent,bindx); //numerical centroid
		ncent.y = cent.y; 
		
		lenx=(ncent.x-cent.x);
		rmag=1.0/sqrt((ncent.x-cent.x)*(ncent.x-cent.x)
		+ (ncent.z-cent.z)*(ncent.z-cent.z));

		theta = asin(lenx*rmag); //theta in radians
		ecent.x = cent.x + elen*sin(theta);
		ecent.y = cent.y;
		ecent.z = cent.z + elen*cos(theta);
		
		grav[1] = gx, grav[2] = gy, grav[3] = gz;
		
		r[1] = ncent.x - cent.x;
		r[2] = ncent.y - cent.y;
		r[3] = ncent.z - cent.z;
		
		crossProduct(ntorque,r,grav);
		for(i=1;i<=NDIM;i++) ntorque[i] *= mass*delt;
		
		r[1] = ecent.x - cent.x;
		r[2] = ecent.y - cent.y;
		r[3] = ecent.z - cent.z;
		
		crossProduct(etorque,r,grav);
		for(i=1;i<=NDIM;i++) etorque[i] *= emass*delt;
		
		//correction done now
		//for(i=1;i<=NDIM;i++) I_Omega[i] = I_Omega[i] - ntorque[i] + etorque[i];
		
		//print also theta here...
		FILE *fptest;
		char sbuf[50];
		sprintf(sbuf,"theta_rig_%d",bindx);
		
		fptest=fopen(sbuf,"a+");
		if(mpi.MyRank==0) fprintf(fptest,"%e %e\n",t,theta);
		fclose(fptest);
		
		//-----------------------------------------------------------------------------------------------**/
		//if(mpi.MyRank==0) printf("I_Omega (%e %e %e)\n",I_Omega[1],I_Omega[2],I_Omega[3]);
		double In[NDIM+1][NDIM+1], 
		lIn[NDIM+1][NDIM+1]={{0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0}};
		st_point lcent;
	
		//moment of inertia tensor calculation
		int i_minf, i_maxf, j_minf, j_maxf, k_minf, k_maxf;
		i_minf=2*i_min[bindx]-1, i_maxf=2*i_max[bindx];
		j_minf=2*j_min[bindx]-1, j_maxf=2*j_max[bindx];
		k_minf=2*k_min[bindx]-1, k_maxf=2*k_max[bindx];
		
		//if(mpi.MyRank==0) printf("Cent.x=%e Cent.y=%e Cent.z=%e\n",Cent.x,Cent.y,Cent.z);
	
		st_point cent1,nor1,vec_a;
		st_polyhedron cube_poly, psi_poly;
		const_sim_polyhedron(&cube_poly);
		for(k=k_minf;k<=k_maxf;k++)
		 for(j=j_minf;j<=j_maxf;j++)
		  for(i=i_minf;i<=i_maxf;i++) {
			  if(psi_f[IJK_f] > em61 ) { //&& (bindx==1 || (bindx==2 && k+2*mpi.OProc[2]>52))) { //modify back later ...ashish
				  lcent.x = (i+2*mpi.OProc[0]-0.5)*0.5*delx[1];
				  lcent.y = (j+2*mpi.OProc[1]-0.5)*0.5*dely[1];
				  lcent.z = (k+2*mpi.OProc[2]-0.5)*0.5*delz[1];
				  
				  cent1.x = (cent.x);
				  cent1.y = (cent.y);
				  cent1.z = (cent.z);
				   
				  calc_inertia_cube(In,&cent1,&lcent,psi_f[IJK_f]);
				  lump_mat(lIn,In);
			  }
			  if(psi_f[IJK_f] >= em6 && psi_f[IJK_f]<= em61 ) { //&& (bindx==1 || (bindx==2 && k+2*mpi.OProc[2]>52))) {
				  
				  nor1.x=psiavnx_f[IJK_f], nor1.y=psiavny_f[IJK_f], nor1.z=psiavnz_f[IJK_f];
				  make_unity(&nor1);
				  area_2(psi_f[IJK_f],i,j,k,IJK_f,&nor1,&cent1,&vec_a);
				  const_com_polyhedron(&cube_poly,&psi_poly,&cent1,&nor1,1);
				  
				  lcent.x = (i+2*mpi.OProc[0]-1.0)*0.5*delx[1];
				  lcent.y = (j+2*mpi.OProc[1]-1.0)*0.5*dely[1];
				  lcent.z = (k+2*mpi.OProc[2]-1.0)*0.5*delz[1];
				  
				  cent1.x = (cent.x);
				  cent1.y = (cent.y);
				  cent1.z = (cent.z);
				  
				  calc_inertia_poly(In,&cent1,&lcent,&psi_poly);
				  lump_mat(lIn,In);
			  }
		  }
	
		
		for(i=1;i<=NDIM;i++)
		 for(j=1;j<=NDIM;j++) {
			 dallreduce(&(lIn[i][j]),&(In[i][j]),1,OP_SUM);
		 }
		 
		if(mpi.MyRank==0) printf("final In: \n(%e %e %e)\n(%e %e %e)\n(%e %e %e)\n",In[1][1],In[1][2],In[1][3],
		In[2][1],In[2][2],In[2][3],In[3][1],In[3][2],In[3][3]);
		
		if(mpi.MyRank==0) printf("mass =%e\n",mass);
		
		//calculate omega vector
		int indx[NDIM+1]={0,0,0,0}; double d;
		ludcmp(In,NDIM,indx,&d);
		lubksb(In,NDIM,indx,I_Omega); //the two steps perform: Omega = inv(In)*I_Omega
									  //I_Omega returned contains the solution
									  
		//half domain simulations... y-axis is normal to the plane of symmetry
		//comment the ludcmp and lubksb lines and uncomment do the following
		//I_Omega[1] = I_Omega[1] / In[1][1], I_Omega[2] = I_Omega[2] / In[2][2], I_Omega[3] = 0.0;
		//I_Omega[1] = 0.0, I_Omega[2] = 0.0, I_Omega[3] = 0.0;
	} //endif IPRES[bindx]
	
	if(IPRES[bindx]==1 && bindx==1) {
		double stroke,Ti;
		stroke=0.13; Ti=1.265406;
		rig_U[bindx][1]=(stroke/2.0)*(2.0*M_PI/Ti)*sin(2.0*M_PI*t/Ti);
	}
								  
	for(i=1;i<=3;i++) rig_U[bindx][i] *= (double)(ZDOF[bindx][i]); //set to zero some components
	for(i=4;i<=6;i++) I_Omega[i-3] *= (double)(ZDOF[bindx][i]);
	
	Omega[bindx].x = I_Omega[1],
	Omega[bindx].y = I_Omega[2],
	Omega[bindx].z = I_Omega[3];
	
	double omega[NDIM+1];
	omega[1]=Omega[bindx].x, omega[2]=Omega[bindx].y, omega[3]=Omega[bindx].z;
	//I_Omega now contains the omega in three directions
	nmx=nmy=nmz=0;
	for(k=k_min[bindx];k<=k_max[bindx];k++)
	 for(j=j_min[bindx];j<=j_max[bindx];j++)
	   for(i=i_min[bindx];i<=i_max[bindx];i++) {
		  //x-momentum
		  if(psimx[IJK]>=em6 && psimx[IJK] <= em61 ) { //&& (bindx==1 || (bindx==2 && k+mpi.OProc[2]>26))) {
			  equate_pt(&v0,&mat_volx[nmx].cent);
			  
			  r[1] = v0.x - cent.x;
			  r[2] = v0.y - cent.y;
			  r[3] = v0.z - cent.z;
			  
			  crossProduct(I_Omega,omega,r);
			  u[IJK]=rig_U[bindx][1] + I_Omega[1]; //performs u = U + Omega x r
			  nmx++;
		  }
		  if(psimx[IJK] > em61 ) { // && (bindx==1 || (bindx==2 && k+mpi.OProc[2]>26))) {
			  v0.x = (i+mpi.OProc[0])*delx[1];
			  v0.y = (j+mpi.OProc[1]-0.5)*dely[1];
			  v0.z = (k+mpi.OProc[2]-0.5)*delz[1];
			  
			  r[1] = v0.x - cent.x;
			  r[2] = v0.y - cent.y;
			  r[3] = v0.z - cent.z;
			  
			  crossProduct(I_Omega,omega,r);
			  u[IJK]=rig_U[bindx][1] + I_Omega[1]; //performs u = U + Omega x r
		  }
		  
		  //y-momentum
		  if(psimy[IJK]>=em6 && psimy[IJK] <= em61 ) { //&& (bindx==1 || (bindx==2 && k+mpi.OProc[2]>26))) {
			  equate_pt(&v0,&mat_voly[nmy].cent);
			  
			  r[1] = v0.x - cent.x;
			  r[2] = v0.y - cent.y;
			  r[3] = v0.z - cent.z;
			  
			  crossProduct(I_Omega,omega,r);
			  v[IJK]=rig_U[bindx][2] + I_Omega[2]; //performs u = U + Omega x r
			  nmy++;
		  }
		  if(psimy[IJK] > em61) { // && (bindx==1 || (bindx==2 && k+mpi.OProc[2]>26))) {
			  v0.x = (i+mpi.OProc[0]-0.5)*delx[1];
			  v0.y = (j+mpi.OProc[1])*dely[1];
			  v0.z = (k+mpi.OProc[2]-0.5)*delz[1];
			  
			  r[1] = v0.x - cent.x;
			  r[2] = v0.y - cent.y;
			  r[3] = v0.z - cent.z;
			  
			  crossProduct(I_Omega,omega,r);
			  v[IJK]=rig_U[bindx][2] + I_Omega[2]; //performs u = U + Omega x r
		  }
		  
		  //z-momentum
		  if(psimz[IJK]>=em6 && psimz[IJK] <= em61) { // && (bindx==1 || (bindx==2 && k+mpi.OProc[2]>26))) {
			  equate_pt(&v0,&mat_volz[nmz].cent);
			  
			  r[1] = v0.x - cent.x;
			  r[2] = v0.y - cent.y;
			  r[3] = v0.z - cent.z;
			  
			  crossProduct(I_Omega,omega,r);
			  w[IJK]=rig_U[bindx][3] + I_Omega[3]; //performs u = U + Omega x r
			  nmz++;
		  }
		  if(psimz[IJK] > em61) {// && (bindx==1 || (bindx==2 && k+mpi.OProc[2]>26))) {
			  v0.x = (i+mpi.OProc[0]-0.5)*delx[1];
			  v0.y = (j+mpi.OProc[1]-0.5)*dely[1];
			  v0.z = (k+mpi.OProc[2])*delz[1];
			  
			  r[1] = v0.x - cent.x;
			  r[2] = v0.y - cent.y;
			  r[3] = v0.z - cent.z;
			  
			  crossProduct(I_Omega,omega,r);
			  w[IJK]=rig_U[bindx][3] + I_Omega[3]; //performs u = U + Omega x r
		  }		  
	  }
	
#ifdef solid_entry
	solid_bc_rigid ();
#endif 
	
	free(mat_volx); //crashing issues make global variable
	free(mat_voly);
	free(mat_volz);
	
}

void sol_centroid (int i, int j, int k, st_point *v0, double *voli) {
	//calculates centroid of a fine grid cell, also returns the volume calculated
	//different strategies are adopted if the cell is completely filled with
	//solid or if it is partially filled with solid ... for computional efficiency
	//REMEMBER to compute psiavnx_f etc. before using this routine
	double *psiavnx_f = temp_f[9];
	double *psiavny_f = temp_f[10];
	double *psiavnz_f = temp_f[11];
	
	st_point nor,vec_a;
	st_polyhedron cube_poly, psi_poly;
	if(psi_f[IJK_f] < em6) {
		v0->x = v0->y = v0->z = 0.0;
		(*voli) = 0.0;
		return;
	}
	
	if(psi_f[IJK_f] > em61) {
		v0->x = (i+2*mpi.OProc[0]-0.5)*(0.5*delx[1]);
		v0->y = (j+2*mpi.OProc[1]-0.5)*(0.5*dely[1]);
		v0->z = (k+2*mpi.OProc[2]-0.5)*(0.5*delz[1]);
		(*voli) = vol_f[IJK_f];
	}
	else if(psi_f[IJK_f] >= em6 && psi_f[IJK_f] <= em61) {
		nor.x = psiavnx_f[IJK_f], nor.y = psiavny_f[IJK_f], nor.z = psiavnz_f[IJK_f];
		make_unity(&nor);
	      area_2(psi_f[IJK_f],i,j,k,IJK_f,&nor,v0,&vec_a); //v0 is the output
	      const_sim_polyhedron(&cube_poly);
		const_com_polyhedron(&cube_poly,&psi_poly,v0,&nor,0); //0 : sorting not required
		calc_polyhedron_centroid(i,j,k,&psi_poly,v0,voli); //v0 is being reutilized here, v0 and voli output
	}
}

void Nsol_bounding_box(int bindx) {
	//creates a bounding box around the solid object
	//function called in newcyc()
	int M,P;
	//x-direction
	M=(int)(Mvert[bindx].x/delx[1]); //global indices
	P=(int)(Pvert[bindx].x/delx[1])+1;
	M=M-mpi.OProc[0]; P=P-mpi.OProc[0]; //local indices
	i_min[bindx]=MAX(M,1); 
	i_max[bindx]=MIN(P,im2);
	
	//y-direction
	M=(int)(Mvert[bindx].y/dely[1]);
	P=(int)(Pvert[bindx].y/dely[1])+1;
	M=M-mpi.OProc[1]; P=P-mpi.OProc[1];
	j_min[bindx]=MAX(M,1);
	j_max[bindx]=MIN(P,jm2);
	
	//z-direction
	M=(int)(Mvert[bindx].z/delz[1]);
	P=(int)(Pvert[bindx].z/delz[1])+1;
	M=M-mpi.OProc[2]; P=P-mpi.OProc[2];
	k_min[bindx]=MAX(M,1);
	k_max[bindx]=MIN(P,km2);
}

void const_sim_polyhedron(st_polyhedron *ptr) {	
	
	//this routine creates a polyhedron from a computation cell
	
	//the vertices on each face are stored in a CCW direction
	int ii,jj,kk,cnt,m;
	//m is to track the face of polyhedron (ptr) as they are constructed
	
	m=0;
	//left x-face
	ii=0; cnt=0;
	for(kk=0;kk<2;kk++)
		for(jj=0;jj<2;jj++)
		{
			ptr->face[m].vert[cnt].x = (double)(ii);
			
			if(kk==ii) ptr->face[m].vert[cnt].y = (double)(1-jj);//for CCW storage.. looking from outside
			else ptr->face[m].vert[cnt].y = (double)(jj);
			
			ptr->face[m].vert[cnt].z = (double)(kk);
			cnt++;
		}
	equate_pt(&(ptr->face[m].vert[4]),&(ptr->face[m].vert[0])); //make the first node also the last node to complete a circle
	ptr->face[m].nor.x = 1.e0; // normal to the polyhedron face
	ptr->face[m].nor.y = 0.e0;
	ptr->face[m].nor.z = 0.e0;
	ptr->face[m].n=4;
	m++;
	
	//right x-face	
	ii=1; cnt=0;
	for(kk=0;kk<2;kk++)
		for(jj=0;jj<2;jj++)
		{
			ptr->face[m].vert[cnt].x = (double)(ii);
			
			if(kk==ii) ptr->face[m].vert[cnt].y = (double)(1-jj);
			else ptr->face[m].vert[cnt].y = (double)(jj);
			
			ptr->face[m].vert[cnt].z = (double)(kk);
			cnt++;
		}
	equate_pt(&(ptr->face[m].vert[4]),&(ptr->face[m].vert[0])); 
	ptr->face[m].nor.x = -1.e0; 
	ptr->face[m].nor.y = 0.e0;
	ptr->face[m].nor.z = 0.e0;
	ptr->face[m].n=4;
	m++;
	
	//back y-face
	jj=0; cnt=0;
	for(ii=0;ii<2;ii++)
		for(kk=0;kk<2;kk++)
		{
			ptr->face[m].vert[cnt].x = (double)(ii);
			ptr->face[m].vert[cnt].y = (double)(jj);
			
			if(ii==jj) ptr->face[m].vert[cnt].z = (double)(1-kk);
			else ptr->face[m].vert[cnt].z = (double)(kk);
			cnt++;
		}
	equate_pt(&(ptr->face[m].vert[4]),&(ptr->face[m].vert[0]));
	ptr->face[m].nor.x = 0.e0; 
	ptr->face[m].nor.y = 1.e0;
	ptr->face[m].nor.z = 0.e0;
	ptr->face[m].n=4;
	m++;
	
	//front y-face
	jj=1; cnt=0;
	for(ii=0;ii<2;ii++)
		for(kk=0;kk<2;kk++)
		{
			ptr->face[m].vert[cnt].x = (double)(ii);
			ptr->face[m].vert[cnt].y = (double)(jj);
			
			if(ii==jj) ptr->face[m].vert[cnt].z = (double)(1-kk);
			else ptr->face[m].vert[cnt].z = (double)(kk);
			cnt++;
		}
	equate_pt(&(ptr->face[m].vert[4]),&(ptr->face[m].vert[0]));
	ptr->face[m].nor.x = 0.e0; 
	ptr->face[m].nor.y = -1.e0;
	ptr->face[m].nor.z = 0.e0;
	ptr->face[m].n=4;
	m++;
	
	//under z-face
	kk=0; cnt=0;
	for(jj=0;jj<2;jj++)
		for(ii=0;ii<2;ii++)
		{
			if(jj==kk) ptr->face[m].vert[cnt].x = (double)(1-ii);
			else ptr->face[m].vert[cnt].x = (double)(ii);
			
			ptr->face[m].vert[cnt].y = (double)(jj);
			ptr->face[m].vert[cnt].z = (double)(kk);
			cnt++;
		}
	equate_pt(&(ptr->face[m].vert[4]),&(ptr->face[m].vert[0]));
	ptr->face[m].nor.x = 0.e0; 
	ptr->face[m].nor.y = 0.e0;
	ptr->face[m].nor.z = 1.e0;
	ptr->face[m].n=4;
	m++;
	
	//over z-face
	kk=1; cnt=0;
	for(jj=0;jj<2;jj++)
		for(ii=0;ii<2;ii++)
		{
			if(jj==kk) ptr->face[m].vert[cnt].x = (double)(1-ii);
			else ptr->face[m].vert[cnt].x = (double)(ii);
			
			ptr->face[m].vert[cnt].y = (double)(jj);
			ptr->face[m].vert[cnt].z = (double)(kk);
			cnt++;
		}
	equate_pt(&(ptr->face[m].vert[4]),&(ptr->face[m].vert[0]));
	ptr->face[m].nor.x = 0.e0; 
	ptr->face[m].nor.y = 0.e0;
	ptr->face[m].nor.z = -1.e0;
	ptr->face[m].n=4;
	m++;
	
	ptr->n = m; //total number of faces in the constructed polygon ..
}

void const_com_polyhedron(st_polyhedron *sim_ptr, st_polyhedron *com_ptr, st_point *cent, st_point *nor, int srt)
{
	//this routine constructs intersection of a polyhedron (*sim_ptr)
	//with a plane (*cent, *nor)
	//the intersection is stored in a polyhedron *com_ptr
	//srt: flag if sorting is required in the end
	int m, ii, n;
	//ii: face id for the polyhedron *sim_ptr
	//m: tracks faces of the new polyhedron *com_ptr 
	m=0;
	for(ii=0;ii<sim_ptr->n;ii++) { //loop through all faces of polyhedron sim_ptr
		const_face(&(sim_ptr->face[ii].vert[0]),sim_ptr->face[ii].n,cent,nor,com_ptr,m);
		
		if(com_ptr->face[m].n>2) {
			equate_pt(&(com_ptr->face[m].vert[com_ptr->face[m].n]),&(com_ptr->face[m].vert[0])); //equate last to one
			equate_pt(&(com_ptr->face[m].nor),&(sim_ptr->face[ii].nor)); //provide normal to the face
			m++;
		}
	}// for ii
	
	//m by now is the total number of faces save the last face
	
	//last face construction
	n=0; int id;
	for(ii=0;ii<m;ii++) {
		if(com_ptr->face[ii].tot_l==2) { //if face is cut by the plane
			
			if(com_ptr->face[ii].l[1] - com_ptr->face[ii].l[0] > 1) id=0;
			else id=1;
			
			equate_pt(&(com_ptr->face[m].vert[n]),&(com_ptr->face[ii].vert[com_ptr->face[ii].l[id]]));
			n++; //n: total # of vertices in the last face of com->ptr
		}
	}
			
	if(n>2) { //last face truly exists [if last is a valid face]

		//this polygon needs sorting only if srt=1
		if(srt == 1) {
			int vert_indx[10]; double theta, rlength; //qt: flag for seeing if quaternion operation is necessary 
			st_point vec_b, tmp_vert[10]; //needed for quaternion rotation
			vec_b.x = -(*nor).y; vec_b.y = (*nor).x; vec_b.z = 0.0;
			Quat qq, qL, qR;
			
			//save the original "clean" vertices
			for(ii=0; ii<n; ii++) {
				equate_pt(&(tmp_vert[ii]),&(com_ptr->face[m].vert[ii]));
			}
			
			if(sqrt(SQUARE(vec_b.x)+SQUARE(vec_b.y)) > 1.e-12)
			{	
				rlength = 1.e0/sqrt(SQUARE(vec_b.x)+SQUARE(vec_b.y));
				vec_b.x *= rlength; // make vec_b a unit vector
				vec_b.y *= rlength;
				
				theta = acos(-(*nor).z);
								
				//calculate the left and right quaternions
				qL.x = sin(theta/2.e0)*vec_b.x;
				qL.y = sin(theta/2.e0)*vec_b.y;
				qL.z = sin(theta/2.e0)*vec_b.z;
				qL.w = cos(theta/2.e0);
				
				qR.x = -sin(theta/2.e0)*vec_b.x;
				qR.y = -sin(theta/2.e0)*vec_b.y;
				qR.z = -sin(theta/2.e0)*vec_b.z;
				qR.w = cos(theta/2.e0);				
				
				for(ii=0; ii<n; ii++) {
					point2Quat(&qq,&(com_ptr->face[m].vert[ii]));
					qq=qt_mul(&qL,&qq);
					qq=qt_mul(&qq,&qR);
					Quat2point(&(com_ptr->face[m].vert[ii]),&qq); //pt. now in x-y plane
				}
			}
			
			sort_ccw(&(com_ptr->face[m].vert[0]),&n,&(vert_indx[0])); //n may become less here
			
			for(ii=0; ii<n+1; ii++)
				equate_pt(&(com_ptr->face[m].vert[ii]),&(tmp_vert[vert_indx[ii]]));
		}
		
		//n is total number of non-redundant vertices on last face
		com_ptr->face[m].n=n;
		com_ptr->face[m].tot_l=n; 
		equate_pt(&(com_ptr->face[m].nor),nor);
		
		m++;
	} //if(n>2) i.e. if valid face
	com_ptr->n = m; //store the total # of faces of our polyhedron
}

void const_face (st_point *cell_vert, int n_verts, st_point *cent, st_point *nor, st_polyhedron *ptr, int m) {
	//this function constructs face of a polyhedron (ptr) when given face[cell_vert] is cut by a cutting plane [cent,nor]
	//the cell_vert points should be in CCW.
	//polyhedron face stored in ptr. 
	//m: face id of the polyhedron ptr: ptr->face[m]
	//n_verts: number of vertices in the face cell_vert
	
	int ii, n, nt;
	double s_in1, s_in2, mu;
	
	ii=0; n=0; //n tracks the number of points in the resulting polygon
	nt=0; // nt tracks # of intersections
		
	s_in1 = dif_dot(&cell_vert[ii],cent,nor); //performs  --- (cell_vert - cent) . nor --- [vector dot product]
	
	for(ii=1;ii< n_verts+1 ;ii++) { //line segment [i,j) is considered here where i is included in domain , j is not 
		s_in2 = dif_dot(&cell_vert[ii],cent,nor);
		
		if(s_in1>=0.0) {
			equate_pt(&(ptr->face[m].vert[n]),&(cell_vert[ii-1]));
			if(s_in1 == 0.0) {
				ptr->face[m].l[nt]=n; //which vertices are intersection points
				nt++;
			}
			n++;
		}
		if(s_in1*s_in2 < 0.0) {
			
			mu = ((cell_vert[ii].x-(*cent).x)*(*nor).x+(cell_vert[ii].y-(*cent).y)*(*nor).y
			+(cell_vert[ii].z-(*cent).z)*(*nor).z) / ((cell_vert[ii].x-cell_vert[ii-1].x)*(*nor).x
			+(cell_vert[ii].y-cell_vert[ii-1].y)*(*nor).y+(cell_vert[ii].z-cell_vert[ii-1].z)*(*nor).z+tiny);
			
			ptr->face[m].vert[n].x = mu*(cell_vert[ii-1].x-cell_vert[0].x) + (1.e0-mu)*(cell_vert[ii].x-cell_vert[0].x);
			ptr->face[m].vert[n].y = mu*(cell_vert[ii-1].y-cell_vert[0].y) + (1.e0-mu)*(cell_vert[ii].y-cell_vert[0].y);
			ptr->face[m].vert[n].z = mu*(cell_vert[ii-1].z-cell_vert[0].z) + (1.e0-mu)*(cell_vert[ii].z-cell_vert[0].z);
			
			ptr->face[m].vert[n].x += cell_vert[0].x;
			ptr->face[m].vert[n].y += cell_vert[0].y;
			ptr->face[m].vert[n].z += cell_vert[0].z;
			
			ptr->face[m].l[nt]=n; //which vertices are intersection points
			nt++;
			n++;	
		}
		
		s_in1 = s_in2;
		
	}
	
	ptr->face[m].tot_l=nt; //total number of intersections in the polygon
	ptr->face[m].n=n; // total number of vertices in the polygon	
}



double calc_poly_vol (st_polyhedron *ptr) 
{
	st_point v0,v1; 
	int m,n,i; //m:counter for faces | n:for vertices on face
	double out_vol,p_area, H, epsilon;
	out_vol = 0.0, epsilon = 1.e-12;
	
	if(ptr->n < 4) return out_vol; //not a valid polyhedron
	
	m=ptr->n-1; //last face [index starts from 0 ...remember]
	n=ptr->face[m].n-1;
	equate_pt(&v0,&(ptr->face[m].vert[n])); //v0: vertex on the last face of polyhedron [to reduce # of sorts]
	for(m=0;m<(ptr->n-1);m++) //loop over all faces [last face not considered because v0 resides in it]
	{	
		equate_pt(&v1,&(ptr->face[m].vert[0])); //v1 is a vertex on current face
		H = dif_dot(&v0,&v1,&(ptr->face[m].nor));
		
		if(fabs(H) > epsilon) { //means the point v0 does not lie on current plane
			p_area = area3D_polygon(&(ptr->face[m].vert[0]),&(ptr->face[m].nor),ptr->face[m].n);
			out_vol += (1.e0/3.e0)*fabs(p_area*H);
		}
	}
	return out_vol;
}

void sort_ccw(st_point *vert, int *n, int *vert_indx) {
	//The function sorts the vertices of a 2-D polygon in CCW direction
	//by using insertion sort [Num. recipes in C, W. Press] based on 
	//polar angle each vertex makes with the centroid of the polygon. 
	//The polygon is assumed convex, so the centroid lies "inside" the polygon
	
	st_point cent; int ii,jj,b;
	double a,*pangle,dx,dy;
	
	//find the centroid of the polygon
	cent.x = cent.y = 0.0;
	for(ii=0; ii<(*n); ii++) {
		cent.x += vert[ii].x;
		cent.y += vert[ii].y;
	}
	cent.x /= ((double)(*n));
	cent.y /= ((double)(*n));
	
	pangle = (double *)malloc((*n+1)*sizeof(double)); //storing polar angles
	for(ii=0; ii<(*n); ii++){
		dx = vert[ii].x - cent.x;
		dy = vert[ii].y - cent.y; 
		pangle[ii] = atan2(dy,dx); //range now from [-pi,pi]
		//if(pangle[ii] < 0.0) pangle[ii] += 2.0*M_PI; //range now from [0,2*pi]
		vert_indx[ii] = ii; //initialize vert_indx 
	}
	
	//insertion sort in action
	for(jj=1; jj<(*n); jj++) {
		b = vert_indx[jj]; a = pangle[b];
		ii = jj-1;
		while (ii >= 0 && pangle[vert_indx[ii]] > a) {
			vert_indx[ii+1] = vert_indx[ii];
			ii--;
		}
		vert_indx[ii+1] = b;
	}
	vert_indx[*n] = vert_indx[0]; //first copied to last for a complete loop
	free(pangle);
}

void sort_ccw2(st_point *vert, int *n, int *vert_indx) {
	// *n is the number of vertices. the returned array would
	// have one more vertex
	
	double *uu, *vv;
	uu = (double *)malloc((*n+1)*sizeof(double));
	vv = (double *)malloc((*n+1)*sizeof(double));
	
	int ii,jj,k,k0,k1;
	double phi,phi1,phi0,dx,dy,min0,min1,max,r;
	
	min0=HUGE_VAL;
	for(ii=0;ii<(*n);ii++)
	{
		if(vert[ii].y<min0) {
			min0 = vert[ii].y;
			min1 = vert[ii].x;
			k = ii;
		}
		if(vert[ii].y==min0 && vert[ii].x<min1) {
			min1 = vert[ii].x;
			k = ii;
		}
	}
	
	uu[0] = vert[k].x; 
	vv[0] = vert[k].y;
	vert_indx[0] = k;
	
	phi0 = 0.e0;
	
	for(jj=1;jj<(*n);jj++)
	{
		phi1=4.e0*M_PI; max=0.e0;
		
		for(ii=0;ii<(*n);ii++) {
			
			dx = vert[ii].x - uu[jj-1]; dy = vert[ii].y - vv[jj-1];
			
			if(dx==0.e0 && dy==0.e0) {
				phi=2.e0*M_PI;
				r=0.e0;
			}
			else {
				phi = atan2(dy,dx);
				if(phi<0.e0 || (phi>=0.e0 && phi0 >= M_PI)) phi += 2.e0*M_PI;
				r = dx*dx + dy*dy;
			}
			if(phi<phi1) {
				phi1 = phi;
				max = r;
				k1 = ii;
			}
			if(phi == phi1 && max < r) {
				max = r;
				k1 = ii;
			}
		} //for ii
		
		phi0 = phi1;
		
		if(k!=k1) {
			uu[jj] = vert[k1].x;
			vv[jj] = vert[k1].y;
			vert_indx[jj] = k1;
			
		}
		else break;
	} // for jj
	
	uu[jj] = uu[0];
	vv[jj] = vv[0];
	vert_indx[jj] = vert_indx[0];
	(*n) = jj; //# returned may be less than # input

	free(uu);
	free(vv);
	
}

double dif_dot(st_point *pt, st_point *cent, st_point *nor) {
	//self-explanatory: calculates the vector dot product:
	//(\vec{pt}-\vec{cent}) \cdot \vec{n}
	double out;
	out = (pt->x-cent->x)*(nor->x) + (pt->y-cent->y)*(nor->y) + (pt->z-cent->z)*(nor->z);
	return out;
}

void equate_pt(st_point *pt1, st_point *pt2)
{
	//here pt1 is being set as pt2
	pt1->x = pt2->x;
	pt1->y = pt2->y;
	pt1->z = pt2->z;
}

int equal_vert(st_point *pt1, st_point *pt2)
{	
	//compares for inequality. returns 1 if unequal
	//use equal(a,b,TOL) command if exact equality doesn't work out TOL=1.e-12
	if((*pt1).x==(*pt2).x && (*pt1).y==(*pt2).y && (*pt1).z==(*pt2).z) 
		return 0;
	else 
		return 1; 
}

double poly_area(st_point *vert, int n_vert) {
	double sum=0.e0;
	int i;
	//calculate area of the polygon in x-y plane.. vertices should  
	//be sorted CCW or CW before using the function
	for(i=0;i<n_vert;i++)
		sum += 0.5e0*(vert[i].x*vert[i+1].y-vert[i+1].x*vert[i].y);
		
	return sum;	
}

double area3D_polygon (st_point *vert, st_point *nor, int n_vert) {
	//fast way of calculating a 3D polygon area
	//this routine adopted from :
	//Dan Sunday: "Fast polygon area and Newell Normal Computation", Journal 
	// of Graphics tools (jgt) vol 7 (2),2002
	
	double area = 0.0;
	double an, ax, ay, az; // abs value of normas and its coords
	int coord; // coord to ignore: 1=x, 2=y, 3=z
	
	int i,j,k;
	
	if(n_vert < 3) return 0; // a degenerate polygon
	
	//select the largest abs coordinate to igonre for projection
	ax = ((*nor).x>0 ? (*nor).x : -(*nor).x); // abs x-coord
	ay = ((*nor).y>0 ? (*nor).y : -(*nor).y); // abs y-coord
	az = ((*nor).z>0 ? (*nor).z : -(*nor).z); // abs z-coord
	
	coord=3; // ignore z-coord
	
	if(ax > ay) {
		if(ax > az) coord = 1; // ignore x-coord
	}
	else if (ay > az) coord = 2; // ignore y-coord
		
	//compute area of the 2D projection
	switch (coord) {
		case 1:
			for(i=1,j=2,k=0; i<n_vert; i++,j++,k++)
				area += ((vert[i].y - vert[0].y)*(vert[j].z - vert[k].z));
			break;
		case 2:
			for(i=1,j=2,k=0; i<n_vert; i++,j++,k++)
				area += ((vert[i].z - vert[0].z)*(vert[j].x - vert[k].x));
			break;
		case 3:
			for(i=1,j=2,k=0;i<n_vert;i++,j++,k++)
				area += ((vert[i].x - vert[0].x)*(vert[j].y-vert[k].y));
			break;
	}
	switch (coord) { // wrap-around term
		case 1:
			area += ((vert[n_vert].y - vert[0].y)*(vert[1].z-vert[n_vert-1].z));
			break;
		case 2:
			area += ((vert[n_vert].z - vert[0].z)*(vert[1].x-vert[n_vert-1].x));
			break;
		case 3:
			area += ((vert[n_vert].x - vert[0].x)*(vert[1].y - vert[n_vert-1].y));
			break;
	}
	//scale to get area before projection
	//an = sqrt(ax*ax + ay*ay + az*az); // length of normal vector
	an = 1.e0; // known unit vector
	switch (coord) {
		case 1:
			area *= (an / (2*(*nor).x));
			break;
		case 2:
			area *= (an / (2*(*nor).y));
			break;
		case 3:
			area *= (an / (2*(*nor).z));
	}
	
	return area;
}

Quat Qt_Mul (Quat qL, Quat qR)
{
      Quat qq;
      qq.w = qL.w*qR.w - qL.x*qR.x - qL.y*qR.y - qL.z*qR.z;
      qq.x = qL.w*qR.x + qL.x*qR.w + qL.y*qR.z - qL.z*qR.y;
      qq.y = qL.w*qR.y + qL.y*qR.w + qL.z*qR.x - qL.x*qR.z;
      qq.z = qL.w*qR.z + qL.z*qR.w + qL.x*qR.y - qL.y*qR.x;
      return (qq);
}

Quat qt_mul (Quat *qL, Quat *qR)
{
	//quaternion mul : passing by reference is a lot faster than passing by value
	Quat qq;
	qq.w = (*qL).w*(*qR).w - (*qL).x*(*qR).x - (*qL).y*(*qR).y - (*qL).z*(*qR).z;
      qq.x = (*qL).w*(*qR).x + (*qL).x*(*qR).w + (*qL).y*(*qR).z - (*qL).z*(*qR).y;
      qq.y = (*qL).w*(*qR).y + (*qL).y*(*qR).w + (*qL).z*(*qR).x - (*qL).x*(*qR).z;
      qq.z = (*qL).w*(*qR).z + (*qL).z*(*qR).w + (*qL).x*(*qR).y - (*qL).y*(*qR).x;
	return (qq);
}

void point2Quat(Quat *qq, st_point *pt)
{
	qq->x=pt->x;
	qq->y=pt->y;
	qq->z=pt->z;
	qq->w=0.0;
}

void Quat2point(st_point *pt, Quat *qq)
{
	pt->x=qq->x;
	pt->y=qq->y;
	pt->z=qq->z;
}

void make_unity(st_point *nor) {
	//this routine normalizes a vector given by nor
	double rlength;
	rlength = 1.e0/sqrt(SQUARE((*nor).x)+SQUARE((*nor).y)+SQUARE((*nor).z));
	(*nor).x = (*nor).x*rlength;
	(*nor).y = (*nor).y*rlength;
	(*nor).z = (*nor).z*rlength;
}

void cross_prod(st_point *vec_c, st_point *vec_a, st_point *vec_b) {
	//the routine calculates vector cross product
	// vec_c = vec_a X vec_b
	
	(*vec_c).x = (*vec_a).y*(*vec_b).z - (*vec_a).z*(*vec_b).y;
	(*vec_c).y = (*vec_a).z*(*vec_b).x - (*vec_a).x*(*vec_b).z;
	(*vec_c).z = (*vec_a).x*(*vec_b).y - (*vec_a).y*(*vec_b).x;
}

void scal_vec_mul(st_point *vec_c, double scal_a, st_point *vec_b) {
	//the routine calculates scalar, vector product
	// vec_c = scal_a . vec_b
	(*vec_c).x = scal_a*(*vec_b).x;
	(*vec_c).y = scal_a*(*vec_b).y;
	(*vec_c).z = scal_a*(*vec_b).z;
	
}

void calc_nor(st_point *nor, st_point *vec_c, double *r, double *theta, st_point *vec_a, st_point *vec_b) {
	//remove later.. just for testing
#ifdef two_dim
	//vec_c->x = 0.0; vec_c->y = 0.0; vec_c->z = 0.0;
	//*r = 1.0; 
	//vec_a->x = 1.0; vec_a->y=0.0; vec_a->z=0.0;
	//vec_b->x = 0.0; vec_b->y=0.0; vec_b->z=1.0;
#endif
	
	(*nor).x = (*vec_c).x + (*r)*cos(*theta)*(*vec_a).x + (*r)*sin(*theta)*(*vec_b).x;
	(*nor).y = (*vec_c).y + (*r)*cos(*theta)*(*vec_a).y + (*r)*sin(*theta)*(*vec_b).y;
	(*nor).z = (*vec_c).z + (*r)*cos(*theta)*(*vec_a).z + (*r)*sin(*theta)*(*vec_b).z;
}

void vec_dot(double *d, st_point *vec_a, st_point *vec_b) {
	*d = (vec_a->x)*(vec_b->x) +  (vec_a->y)*(vec_b->y) + (vec_a->z)*(vec_b->z);  
}

void vec_weight(st_point *p, st_point *p1, st_point *p2, double mu) {
	p->x = mu*(p1->x) + (1.0-mu)*(p2->x);
	p->y = mu*(p1->y) + (1.0-mu)*(p2->y);
	p->z = mu*(p1->z) + (1.0-mu)*(p2->z);
}

#define ITMAX 100
#define EPS2  2.22e-16
#define SIGN2(a,b) ((b) >= 0.0 ? fabs(a) : -fabs(a))
#define BRENT

void recons_3p(st_polyhedron *ipsi_poly, st_point *nor, st_point *cent, int i, int j, int k) {
    //this routine calculates the location of plane [*cent] inside a three phase cell.
    //given: unit normal to the liquid plane [*nor],
    // (i,j,k) is the index of the cell...
    
    st_polyhedron liq_poly;
    st_point nor1,cent1,v1,v2;
    int kk,jj,m,n,indx_min[2],indx_max[2];
    double min_val, max_val,d,v_liq;
    
    vec_dot(&d,&(ipsi_poly[13].face[0].vert[0]),nor); //13 th central element
    max_val = min_val = d;
    indx_min[0]=indx_min[1]=indx_max[0]=indx_max[1]=0;
    
    //two vertices to interpolate between: v1 & v2
    m = ipsi_poly[13].n;
    for(kk=0;kk<m;kk++) {
     n = ipsi_poly[13].face[kk].n;
     for(jj=0;jj<n;jj++) {
        vec_dot(&d,&(ipsi_poly[13].face[kk].vert[jj]),nor);
        if(d < min_val) {
            min_val = d;
            indx_min[0] = kk;
            indx_min[1] = jj;
        }
        if(d > max_val) {
            max_val = d;
            indx_max[0] = kk;
            indx_max[1] = jj;
        }    
     }
    }//for kk
    
    m=indx_min[0]; n=indx_min[1];
    equate_pt(&(v1),&(ipsi_poly[13].face[m].vert[n]));
    
    m=indx_max[0]; n=indx_max[1];
    equate_pt(&(v2),&(ipsi_poly[13].face[m].vert[n]));

#ifdef BRENT
    //root should lie between x1 and x2
    double x1, x2, epsilon=1.e-12;
    x1 = 0.0, x2 = 1.0;
    double a=x1, b=x2, c=x2, e, min1, min2;
    double fa, fb, fc, p, q, r, s, tol1, xm;
    
    //fa
    vec_weight(&cent1,&v1,&v2,a);
    const_com_polyhedron(&ipsi_poly[13],&liq_poly,&cent1,nor,0);
    if(liq_poly.n < 4) v_liq = 0.0;
    else v_liq = calc_poly_vol(&liq_poly);
    fa = (v_liq - f_f[IJK_f]);
    
    //fb
    vec_weight(&cent1,&v1,&v2,b);
    const_com_polyhedron(&ipsi_poly[13],&liq_poly,&cent1,nor,0);
    if(liq_poly.n < 4) v_liq = 0.0;
    else v_liq = calc_poly_vol(&liq_poly);
    fb = (v_liq - f_f[IJK_f]);
    
    if((fa > 0.0 && fb > 0.0) || (fa < 0.0 && fb < 0.0)) {
        printf("error in brent: roots must be bracketed: rank=%d (i,j,k)=(%d %d %d) fa=%e fb=%e v_liq=%e f_f=%e triple_flg=%d\n",mpi.MyRank,i,j,k,fa,fb,v_liq,f_f[IJK_f],triple_flg[IJK_f]);
        exit(1);
    }
    
    fc = fb;
    for(jj=1;jj<ITMAX;jj++) {
        if((fb > 0.0 && fc > 0.0)||(fb < 0.0 && fc < 0.0)) {
            c = a;
            fc = fa;
            e = d = b-a;
        }
        if(fabs(fc) < fabs(fb)) {
            a = b;
            b = c;
            c = a;
            fa = fb;
            fb = fc;
            fc = fa;
        }
        tol1 = 2.0*(EPS2)*fabs(b) + 0.5*epsilon;
        xm = 0.5*(c-b);
        if(fabs(xm) <= tol1 || fb == 0.0) break; //b is the answer
        if(fabs(e) >= tol1 && fabs(fa) > fabs(fb)) {
			s = fb/fa;					//inverse quadratic interpolation
            if(a == c) {
                p = 2.0*xm*s;
                q = 1.0-s;
            }
            else {
                q = fa/fc;
                r = fb/fc;
                p = s*(2.0*xm*q*(q-r)-(b-a)*(r-1.0));
                q = (q-1.0)*(r-1.0)*(s-1.0);
            }
            if(p > 0.0) q = -q;
            p = fabs(p);
            min1 = 3.0*xm*q - fabs(tol1*q);
            min2 = fabs(e*q);
            if(2.0*p < (min1 < min2 ? min1 : min2)) {
                e = d;
                d = p/q;
            }
            else {
                d = xm;
                e = d;
            }
        }
        else {
            d = xm;
            e = d;
        }
        a = b;
        fa = fb;
        if(fabs(d) > tol1)
            b += d;
        else 
            b += SIGN2(tol1,xm);
        //fb
        vec_weight(&cent1,&v1,&v2,b);
        const_com_polyhedron(&ipsi_poly[13],&liq_poly,&cent1,nor,0);
        if(liq_poly.n < 4) v_liq = 0.0;
        else v_liq = calc_poly_vol(&liq_poly);
        fb = (v_liq - f_f[IJK_f]);
        
    }
    //b is the answer
    vec_weight(&cent1,&v1,&v2,b);
    if(jj == ITMAX) printf("Brent's method iterations exceeded: rank=%d (i,j,k)=(%d %d %d)\n",mpi.MyRank,i,j,k);
#endif    
    equate_pt(cent,&cent1);
}

void contact_3p(int i, int j, int k) {
    //this routine performs golden section search on the orientation of liquid-gas
    //interface. output is the normal orientation [*nor], point on the plane [*cent].
    //the output will be used to create fvirt
    double p_vol; int n;
    st_point vec_a, vec_a2, vec_b, vec_c, nor, cent, nor1, cent1, nor2, cent2;
    double alpha, r;
    st_polyhedron psi_poly, cube_poly, com_poly;
    double *avnx_f = temp_f[6];
    double *avny_f = temp_f[7];
    double *avnz_f = temp_f[8];
    double *psiavnx_f = temp_f[9];
    double *psiavny_f = temp_f[10];
    double *psiavnz_f = temp_f[11];
    
    alpha = 90.0*M_PI / 180.0; //contact angle between the solid and the liquid-gas interface
	/*nor1.x = psiavnx_f[IJK_f]; nor1.y = psiavny_f[IJK_f]; nor1.z = psiavnz_f[IJK_f];
	make_unity(&nor1); */
	
	/*cent1.x = (i+2*mpi.OProc[0]-0.5)*(0.5*delx[1]); 
	cent1.y = (j+2*mpi.OProc[1]-0.5)*(0.5*dely[1]);
	cent1.z = (k+2*mpi.OProc[2]-0.5)*(0.5*delz[1]);
					
	nor1.x = -(cent1.x-t_cent.x*0.5*delx[1]); //nor1 overwritten here ... remove later.. ashish
	nor1.y = -(cent1.y-t_cent.y*0.5*dely[1]);
	nor1.z = -(cent1.z-t_cent.z*0.5*delz[1]); 
	make_unity(&nor1);
	nor1.x = -nor1.x, nor1.y = -nor1.y, nor1.z = -nor1.z; //invert normal vector for void*/
    
    //the array of ipsi-poly in the neighborhood...
    st_polyhedron ipsi_poly[27]; int ii, jj, kk, indx, ijkt;
    const_sim_polyhedron(&cube_poly);
    for(kk=-1;kk<2;kk++) 
     for(jj=-1;jj<2;jj++)
      for(ii=-1;ii<2;ii++) {
          ijkt = IND_f(i+ii,j+jj,k+kk);
          indx = (kk+1)*3*3 + (jj+1)*3 + (ii+1);
          
          ipsi_poly[indx].n=0; //# of faces initialized to zero
          //we are not constructing solid polyhedrons in cells with psi>em61
          if(psi_f[ijkt] >= em6 && psi_f[ijkt] <= em61) {
              nor2.x = psiavnx_f[ijkt], nor2.y = psiavny_f[ijkt], nor2.z = psiavnz_f[ijkt];
              make_unity(&nor2);
              
              area_2(psi_f[ijkt],i+ii,j+jj,k+kk,ijkt,&nor2,&cent2,&vec_a2);
              if(ii==0 && jj==0 && kk==0) {
                const_com_polyhedron(&cube_poly,&psi_poly,&cent2,&nor2,1); //to ascertain if two interfaces intersect
               
                equate_pt(&nor1,&nor2);
                equate_pt(&vec_a,&vec_a2);
               
                cross_prod(&vec_b,&vec_a,&nor1); //vec_b = vec_a X nor1
                make_unity(&vec_b);
                scal_vec_mul(&vec_c,cos(alpha),&nor1); //vec_c = cos(alpha) . nor1
               
                //vec_c is center of the 3D circle
                r = sin(alpha);
              }
              nor2.x = -nor2.x, nor2.y = -nor2.y, nor2.z = -nor2.z;
              const_com_polyhedron(&cube_poly,&ipsi_poly[indx],&cent2,&nor2,1);
          }
          
          if(psi_f[ijkt] < em6) {
              const_sim_polyhedron(&ipsi_poly[indx]);
          }
      }

	//calculate the normal to the liquid-gas interface... 
	//calc_nor(&nor,&vec_c,&r,&theta,&vec_a,&vec_b); //nor = vec_c + r(cos(theta))*vec_a + r(sin(theta))*vec_b

    //variables to be used in the golden section search:

    double epsilon, tau, x1, x2, g_x1, g_x2, theta1, theta2; 
    int iter, cnt;
    epsilon = 1.e-12;
    tau = (sqrt(5.e0)-1.e0) / 2.e0; //golden proportion ratio
    cnt = 0;
    iter = 110; //max iter can be found by a formula...
        
    double start_golden_time = MPI_Wtime(); // Start timing golden search
    
    theta1 = 0.0; 
    theta2 = 2.0*M_PI;
    
    //conditioning 
    double theta,g_min,h; int ii_min,N;
    g_min = 30.0; 
    
    N = 32; 
    h = (theta2 - theta1) / ((double)(N));
    
    for(ii=1;ii<=N;ii++)
    {
        theta = theta1 + (ii-0.5)*h;
        calc_nor(&nor1,&vec_c,&r,&theta,&vec_a,&vec_b);
        func_g(&g_x1,&(ipsi_poly[0]),&nor1,&cent1,i,j,k);
        if(g_x1 < g_min) {
            g_min=g_x1;
            ii_min=ii;
        }
    }
    theta1 = MAX(theta1+(ii_min-2)*h,theta1); theta2 = MIN(theta1+3*h,theta2); //keep theta1, theta2 in bounds
    
    x1 = theta1 + (1.e0 - tau)*(theta2 - theta1);
    x2 = theta1 + tau*(theta2 - theta1);
    
    //calculate g_x1
    calc_nor(&nor1,&vec_c,&r,&x1,&vec_a,&vec_b); //input x1, output nor1: parametric eqn of 3D circle
    func_g(&g_x1,&(ipsi_poly[0]),&nor1,&cent1,i,j,k); //returns g_x1, *cent1
    //calculates g_x2
    calc_nor(&nor2,&vec_c,&r,&x2,&vec_a,&vec_b);
    func_g(&g_x2,&(ipsi_poly[0]),&nor2,&cent2,i,j,k);
    
    while ((fabs(theta1 - theta2) > epsilon) && (cnt < iter)) { // maximum iter would depend on epsilon and |theta1 - theta2| (initial)
        cnt++;
        if(g_x1 < g_x2) {
            theta2 = x2;
            x2 = x1;
            x1 = theta1 + (1.e0-tau)*(theta2 - theta1);
            
            //calculate g_x1
            calc_nor(&nor1,&vec_c,&r,&x1,&vec_a,&vec_b); //x1 ---> nor1
            func_g(&g_x1,&(ipsi_poly[0]),&nor1,&cent1,i,j,k); // nor1 ---> g_x1
                
            //calculate g_x2
            calc_nor(&nor2,&vec_c,&r,&x2,&vec_a,&vec_b); //x2 ---> nor2
            func_g(&g_x2,&(ipsi_poly[0]),&nor2,&cent2,i,j,k); // nor2 ---> g_x2
        }
        else {
            theta1 = x1;
            x1 = x2;
            x2 = theta1 + tau*(theta2 - theta1);
            
            //calculate g_x1
            calc_nor(&nor1,&vec_c,&r,&x1,&vec_a,&vec_b); //x1 ---> nor1
            func_g(&g_x1,&(ipsi_poly[0]),&nor1,&cent1,i,j,k); // nor1 ---> g_x1
                
            //calculate g_x2
            calc_nor(&nor2,&vec_c,&r,&x2,&vec_a,&vec_b); //x2 ---> nor2
            func_g(&g_x2,&(ipsi_poly[0]),&nor2,&cent2,i,j,k); // nor2 ---> g_x2
        }
    } //end-while
    if(g_x1 < g_x2) {
        equate_pt(&nor,&nor1);
        equate_pt(&cent,&cent1);
    }
    else {
        equate_pt(&nor,&nor2);
        equate_pt(&cent,&cent2);
    }
    
    double end_golden_time = MPI_Wtime(); // End timing golden search
    recon_timing.golden_search_time += (end_golden_time - start_golden_time);

    //--------------------------------------
#ifdef two_dim
    double xcoord = (i+2*mpi.OProc[0]-0.5)*(0.5*delx[1]);
    if(xcoord > Cent[NBODY].x) { 
        nor.x = -psiavnz_f[IJK_f], nor.y = 0.0, nor.z = psiavnx_f[IJK_f];
    }
    else {
        nor.x = psiavnz_f[IJK_f], nor.y = 0.0, nor.z = -psiavnx_f[IJK_f];
    }
    make_unity(&nor);
    recons_3p(&(ipsi_poly[0]),&nor,&cent,i,j,k);
#endif
    //--------------------------------------
    
    //calculation of com_poly    
    const_com_polyhedron(&psi_poly,&com_poly,&cent,&nor,0);
    
    //equate the normals ... for all 3 phase cells
    avnx_f[IJK_f] = nor.x; avny_f[IJK_f] = nor.y; avnz_f[IJK_f] = nor.z; 
    //extension of virtual f-field into solid domain
    if(com_poly.n < 4) {
        if(com_poly.face[0].n>1) { //the contact line lies at cell face
            if(triple_flg[IJK_f] != 5) triple_flg[IJK_f] = 1;
        }
    }
    else {
        
        p_vol = calc_poly_vol(&com_poly);
        fvirt_f[IJK_f] = f_f[IJK_f] + p_vol;
        //common volume: intersection or not ?
        n = com_poly.n;
        if(com_poly.face[n-1].tot_l >= 2) {
            //if there is an intersection the last face is with tot_l >= 2
            if(triple_flg[IJK_f] != 5) triple_flg[IJK_f] = 1;
        }
    }
        
	/*if(t_prob2==1) {
		int ii,jj,kk;
		for(kk=1;kk>-2;kk--) {
			printf("----------kk=%d########-----------\n",kk);
		 for(jj=1;jj>-2;jj--) {
		  for(ii=-1;ii<2;ii++) {
			  printf("%e(%e,%e,%d) ",f_f[IND_f(i+ii,j+jj,k+kk)],psi_f[IND_f(i+ii,j+jj,k+kk)],1.0-f_f[IND_f(i+ii,j+jj,k+kk)]-psi_f[IND_f(i+ii,j+jj,k+kk)],triple_flg[IND_f(i+ii,j+jj,k+kk)]);
		  }
		  printf("\n");
		 }
		}
	}
	if(t_prob2==1) {
		printf("calc: nor.x=%e nor.y=%e nor.z=%e\n",avnx_f[IJK_f],avny_f[IJK_f],avnz_f[IJK_f]);
		//printf("x1=%e x2=%e g_x1=%e g_x2=%e \n",x1,x2,g_x1,g_x2);
		//exit(1);
	}*/
	
}

void func_g (double *g_x, st_polyhedron *ipsi_poly, st_point *nor, st_point *cent, int i, int j, int k) {
    //the routine calculates g_x for the golden section search in the calling function
    //*ipsi_poly is string of inverse-psi-polyhedrons
    //input is *nor, and output is *g_x alongwith *cent
    
    int ii,jj,kk;
    int ijkt, indx;
    double f_p; st_point vec_a;
    
    double start_ren_time = MPI_Wtime(); // Start timing Ren's method
    
    //construct liquid-gas interface given, [*nor], [f_f[IJK_f]]
    if(psi_f[IJK_f] >= em6 && psi_f[IJK_f] <= em61) {
        recons_3p(&(ipsi_poly[0]),nor,cent,i,j,k); //as outputs it would give [cent]
                                        // f exactly matched in this particular cell
    }
    else if(psi_f[IJK_f] < em6)
        area_2(f_f[IJK_f],i,j,k,IJK_f,nor,cent,&vec_a);
       
    else {
        printf("Oh: trying to reconstruct on a full solid cell, buddy think again:....\n");
        exit(1);
    }
            
    //extend this plane in 3x3x3 stencil around the three phase cell
    (*g_x) = 0.e0;
    for(kk=-1;kk<2;kk++)
        for(jj=-1;jj<2;jj++)
            for(ii=-1;ii<2;ii++)
            {    
                if(ii==0 && jj==0 && kk==0) continue; //f is exactly matched in this cell
                ijkt = IND_f(i+ii,j+jj,k+kk);    
                indx = (kk+1)*3*3 + (jj+1)*3 + (ii+1);
                cube_plane_int2(&f_p,&(ipsi_poly[indx]),nor,cent,i+ii,j+jj,k+kk,ii,jj,kk,1); //last arg=1: presence of solid is considered
                (*g_x) += (f_p - f_f[ijkt])*(f_p - f_f[ijkt]);
            } //for ii,jj,kk
            
    double end_ren_time = MPI_Wtime(); // End timing Ren's method
    recon_timing.ren_method_time += (end_ren_time - start_ren_time);
}

void layer_3p() {
    //a second layer checking for missed contact lines ...
    int i,j,k, ii,jj,kk, ijkt, cnt, ti,tj,tk;
    st_point vec_a, nor, cent;
    
    for(k=1;k<km1_f;k++)
        for(j=1;j<jm1_f;j++)
            for(i=1;i<im1_f;i++) {
                ti=(i+1)/2, tj=(j+1)/2, tk=(k+1)/2;
                if(ac[IND(ti,tj,tk)]<em6) continue;
                //if three phase cell and triple_flg = 0
                if(psi_f[IJK_f] >= em6 && f_f[IJK_f] >= em6 && (1.e0 - f_f[IJK_f] - psi_f[IJK_f]) >=em6 && triple_flg[IJK_f]==0) {
                    cnt=0;
                    for(kk=-1;kk<2;kk++)
                        for(jj=-1;jj<2;jj++)
                            for(ii=-1;ii<2;ii++) {
                                ijkt = IND_f(i+ii,j+jj,k+kk);
                                if(triple_flg[ijkt] ==1 ) cnt++; //before this step only three phase cells
                                                                                //have been tagged triple_flg = 1
                            }
                    if(cnt==0) { //no triple_flg found
                        triple_flg[IJK_f] = 2;
					}
				} //if 3 phase && triple_flg=0
			}//end i,j,k loop
}

void flag_2p1p() {
	//this routine resolves contact line in 2 phase cells and 1 phase cells
	
	int i,j,k, ii,jj,kk,ijkt,tf,ti,tj,tk;
	int alpha_cnt, f_cnt; double alpha;
	
	for(k=0;k<=km1_f;k++)
		for(j=0;j<=jm1_f;j++)
			for(i=0;i<=im1_f;i++) {
				if(psi_f[IJK_f] > em61 && ((fabs(psi_f[IJK_f]-psi_f[IMJK_f]) >= em6 && i>0) || (fabs(psi_f[IJK_f]-psi_f[IPJK_f]) >= em6 && i<im1_f)
				|| (fabs(psi_f[IJK_f]-psi_f[IJMK_f]) >= em6 && j>0) || (fabs(psi_f[IJK_f]-psi_f[IJPK_f]) >= em6 && j<jm1_f)
				|| (fabs(psi_f[IJK_f]-psi_f[IJKM_f]) >= em6 && k>0) || (fabs(psi_f[IJK_f]-psi_f[IJKP_f]) >= em6 && k<km1_f))) { //if a boundary solid cell
					
					alpha_cnt = 0; f_cnt = 0;
					for(kk=-1;kk<2;kk++)
						for(jj=-1;jj<2;jj++)
							for(ii=-1;ii<2;ii++) { //look in the 3x3x3 neighborhood
								ijkt = IND_f(i+ii,j+jj,k+kk);
								
								//if triple_point already in neighborhood skip the if condition
								val_indx<int>(i+ii,j+jj,k+kk,tf,triple_flg,triple_flg2);
								if(tf==1 || tf==2) goto end_lp;
								
								if(i+ii < 0 || i+ii > im1_f || j+jj < 0 || j+jj > jm1_f || k+kk < 0 || k+kk > km1_f) continue; //do not include invalid cells
								
								alpha = 1.0 - f_f[ijkt] - psi_f[ijkt]; //air vol. fraction
								if(alpha >= em6) alpha_cnt++;
								if(f_f[ijkt] >= em6) f_cnt++;
							}
					
					if(alpha_cnt>0 && f_cnt >0) { 
						for(kk=-1;kk<2;kk++)
							for(jj=-1;jj<2;jj++)
								for(ii=-1;ii<2;ii++) {
									if(i+ii <= 0 || i+ii >= im1_f || j+jj <= 0 || j+jj >= jm1_f || k+kk <= 0 || k+kk >= km1_f) continue; //only physical cells are tagged
									ijkt = IND_f(i+ii,j+jj,k+kk);
									
									ti=(i+ii+1)/2, tj=(j+jj+1)/2, tk=(k+kk+1)/2;
									if(ac[IND(ti,tj,tk)]<em6) continue;
									
									if(psi_f[ijkt] < em6 && f_f[ijkt] >= em6 && f_f[ijkt] <= em61) { //if 2 phase cell
										triple_flg[ijkt] = 3;
									}
									
									if(f_f[ijkt] > em61 && ((1.e0 - psi_f[ijkt-1] - f_f[ijkt-1] >= em6 && f_f[ijkt-1] < em6) || (1.e0 - psi_f[ijkt+1] - f_f[ijkt+1] >= em6 && f_f[ijkt+1] < em6)
										|| (1.e0 - psi_f[ijkt-imax_f] - f_f[ijkt-imax_f] >= em6 && f_f[ijkt-imax_f] < em6) || (1.e0 - psi_f[ijkt+imax_f] - f_f[ijkt+imax_f] >= em6 && f_f[ijkt+imax_f] < em6)
										|| (1.e0 - psi_f[ijkt-ijmax_f] - f_f[ijkt-ijmax_f] >= em6 && f_f[ijkt-ijmax_f] < em6) || (1.e0 - psi_f[ijkt+ijmax_f] - f_f[ijkt+ijmax_f] >= em6 && f_f[ijkt+ijmax_f] < em6))) {
											triple_flg[ijkt] = 4;
									}
									
									if(f_f[ijkt] >= em6 && psi_f[ijkt]>=em6 && f_f[ijkt]+psi_f[ijkt] > em61
									      && ((1.e0 - psi_f[ijkt-1] - f_f[ijkt-1] >= em6 && f_f[ijkt-1] < em6) || (1.e0 - psi_f[ijkt+1] - f_f[ijkt+1] >= em6 && f_f[ijkt+1] < em6)
										|| (1.e0 - psi_f[ijkt-imax_f] - f_f[ijkt-imax_f] >= em6 && f_f[ijkt-imax_f] < em6) || (1.e0 - psi_f[ijkt+imax_f] - f_f[ijkt+imax_f] >= em6 && f_f[ijkt+imax_f] < em6)
										|| (1.e0 - psi_f[ijkt-ijmax_f] - f_f[ijkt-ijmax_f] >= em6 && f_f[ijkt-ijmax_f] < em6) || (1.e0 - psi_f[ijkt+ijmax_f] - f_f[ijkt+ijmax_f] >= em6 && f_f[ijkt+ijmax_f] < em6))) {
											triple_flg[ijkt] = 5;
									}
									
								} //end for
					}
										
				end_lp:
				;
				}
			}
	
	//second to filter out "spurious" triple flags created due to numerical inaccuracies.
	int tp_cnt;
	for(k=1;k<km1_f;k++) 
	 for(j=1;j<jm1_f;j++)
	  for(i=1;i<im1_f;i++) {
		  if(triple_flg[IJK_f]==3) {
			  tp_cnt=0;
			  for(kk=-2;kk<3;kk++)
			   for(jj=-2;jj<3;jj++)
			     for(ii=-2;ii<3;ii++){
				    val_indx<int>(i+ii,j+jj,k+kk,tf,triple_flg,triple_flg2);
				    if(tf==1 || tf==2) tp_cnt++;
			    }
			    if(tp_cnt>0) triple_flg[IJK_f]=0;
		  }
	  }
	  
	xchg_f<int>(triple_flg);
	xchg2_f<int>(triple_flg,triple_flg2,planIn2);
	
	double tf_f, tpsi_f;  
	for(k=1;k<km1_f;k++)
	 for(j=1;j<jm1_f;j++)
	  for(i=1;i<im1_f;i++) {
		  if(triple_flg[IJK_f]==4 || triple_flg[IJK_f]==5) {
			  tp_cnt=0; f_cnt=0; alpha_cnt=0; 
			  for(kk=-2;kk<3;kk++)
			   for(jj=-2;jj<3;jj++)
			    for(ii=-2;ii<3;ii++) {
				    ijkt = IND_f(i+ii,j+jj,k+kk);
				    val_indx<int>(i+ii,j+jj,k+kk,tf,triple_flg,triple_flg2);
				    val_indx<double>(i+ii,j+jj,k+kk,tf_f,f_f,f2_f);
				    val_indx<double>(i+ii,j+jj,k+kk,tpsi_f,psi_f,psi2_f);
				    if(tf_f>em61) f_cnt++;
				    if(tf_f+tpsi_f<em6) alpha_cnt++;
				    if(tf==1 || tf==2 || tf==3) tp_cnt++;
			    }
			    if(tp_cnt>0 || alpha_cnt == 0 || f_cnt == 0) triple_flg[IJK_f]=0;
			    //if(tp_cnt>0 || f_cnt == 0) triple_flg[IJK_f]=0;
		  }
	  }
}

//void printGhostArray();
void virtfine2stnd();
void recons_contact_line() {
	//the routine calculates the normal vectors in cells in the vicinity of contact line
	//it also extends virtual f- field inside the solid domain
	//requires psinormals_f() call before it 
	int i,j,k,ti,tj,tk;
	double *rho_f = temp_f[1];
	double *avnx_f = temp_f[6];
	double *avny_f = temp_f[7];
	double *avnz_f = temp_f[8];	
	
	memset(triple_flg,0,NX_f*NY_f*NZ_f*sizeof(int));
	memcpy(fvirt_f,f_f,NX_f*NY_f*NZ_f*sizeof(double));
		
	for(k=1;k<km1_f;k++) //in physical cells
		for(j=1;j<jm1_f;j++)
			for(i=1;i<im1_f;i++) {
				//if a three-phase cell
				ti=(i+1)/2, tj=(j+1)/2, tk=(k+1)/2;
				if(ac[IND(ti,tj,tk)]<em6) continue;
				if(psi_f[IJK_f] >= em6 && f_f[IJK_f] >= em6 && (1.e0 - f_f[IJK_f] - psi_f[IJK_f]) >=em6) contact_3p(i,j,k);	
			}
	xchg_f<int>(triple_flg); //triple_flg information will be used in layer_3p();
	
	//2nd layer of looking for triple points ... the three phase cells with no intersections around them
	layer_3p();
	
	xchg_f<int>(triple_flg); //triple_flg information to be used in flag_2p1p;
	xchg2_f<int>(triple_flg,triple_flg2,planIn2);
	xchg2_f<double>(psi_f,psi2_f,planDo2); xchg2_f<double>(f_f,f2_f,planDo2);
	
	//find 2 phase and 1 phase cells that are connected to contact line
	flag_2p1p();
	
	//reconstruct in 1 phase and 2 phase cells 
	for(k=1;k<km1_f;k++) 
		for(j=1;j<jm1_f;j++)
			for(i=1;i<im1_f;i++) {
				if(psi_f[IJK_f] < em6 && f_f[IJK_f] >= em6 && f_f[IJK_f] <= em61 && triple_flg[IJK_f] == 3) contact_2p(i,j,k);
				if(triple_flg[IJK_f]==4) contact_1p(i,j,k);
				if(triple_flg[IJK_f]==5) contact_1p(i,j,k);
			}
		
	//the reconstructions along mpi-subdomain boundaries get communicated: 
	xchg_f<int>(triple_flg);
	xchg_f<double>(fvirt_f);
	xchg_f<double>(avnx_f); xchg_f<double>(avny_f); xchg_f<double>(avnz_f);
	
	//xchg information in the second layer of the ghost cell
	xchg2_f<int>(triple_flg,triple_flg2,planIn2);
	xchg2_f<double>(fvirt_f,fvirt2_f,planDo2);
	
	xchg2_f<double>(avnx_f,avnx2_f,planDo2); xchg2_f<double>(avny_f,avny2_f,planDo2);
	xchg2_f<double>(avnz_f,avnz2_f,planDo2);
	
	//xchg2_f<double>(psi_f,psi2_f,planDo2); xchg2_f<double>(f_f,f2_f,planDo2);
	
	//now extend virtf in the neighborhood of triple_flg cells
	fvirt_call2();
	
	//exchange the fvirt_f field across virtual boundaries and domain boundaries
	bcfvirt_f();
	
	//calculate the density based on fvirt_f field
	for(k=0;k<=km1_f;k++)
	 for(j=0;j<=jm1_f;j++)
	   for(i=0;i<=im1_f;i++) {
		  rho_f[IJK_f] = rhof1*fvirt_f[IJK_f] + 1.0*(1.e0 - fvirt_f[IJK_f]); //only for the purpose of calculating normals
	  }
	
	normals_fvirt(); //calculates the normals on the basis of fvirt_f and exchanges them across virtual boundaries
	
//	virtfine2stnd(); // Cory Added This for plotting, not necessary otherwise
}

void contact_2p(int i, int j, int k) {
	//this routine reconstructs the 2p cell and extends in the neighborhood solid region
	st_point nor1, cent1, nor2, cent2, vec_a, vec_a2, vec_b, vec_c;
	st_point nor, cent;
	int ii,jj,kk,ijkt;
	
	double psi_tmp, alpha, r;
	double *avnx_f = temp_f[6];
	double *avny_f = temp_f[7];
	double *avnz_f = temp_f[8];
	double *psiavnx_f = temp_f[9];
	double *psiavny_f = temp_f[10];
	double *psiavnz_f = temp_f[11];
	
	alpha = 90.0*M_PI / 180.0; //contact angle 90.0 between solid surface and f-plane
	
	for(kk=-1;kk<2;kk++)
		for(jj=-1;jj<2;jj++)
			for(ii=-1;ii<2;ii++) {
				ijkt = IND_f(i+ii,j+jj,k+kk);
				if(psi_f[ijkt] > em61) {
					nor1.x = psiavnx_f[ijkt]; nor1.y = psiavny_f[ijkt]; nor1.z = psiavnz_f[ijkt];
					make_unity(&nor1);
					psi_tmp = psi_f[ijkt] - 2.e0*em6;
					goto out_lp;
				}
			}
	
	out_lp:
	
	/*cent1.x = (i+2*mpi.OProc[0]-0.5)*(0.5*delx[1]); 
	cent1.y = (j+2*mpi.OProc[1]-0.5)*(0.5*dely[1]);
	cent1.z = (k+2*mpi.OProc[2]-0.5)*(0.5*delz[1]);
					
	nor1.x = -(cent1.x-t_cent.x*0.5*delx[1]); //nor1 overwritten here ... remove later.. ashish
	nor1.y = -(cent1.y-t_cent.y*0.5*dely[1]);
	nor1.z = -(cent1.z-t_cent.z*0.5*delz[1]); 
	make_unity(&nor1);
	nor1.x = -nor1.x, nor1.y = -nor1.y, nor1.z = -nor1.z; //invert normal vector for void*/
	
	area_2(psi_tmp,i,j,k,IJK_f,&nor1,&cent1,&vec_a);
	cross_prod(&vec_b,&vec_a,&nor1);
	make_unity(&vec_b);
	
	//------------------------------------------------------
#ifdef two_dim
	st_point snor;
	equate_pt(&snor,&nor1); 
#endif
	//------------------------------------------------------
					
	scal_vec_mul(&vec_c,cos(alpha),&nor1); //vec_c is being set here
	r = sin(alpha);
	
	//array of neighboring ipsi_poly
	st_polyhedron ipsi_poly[27], cube_poly; int indx;
	const_sim_polyhedron(&cube_poly);
	
	for(kk=-1;kk<2;kk++) 
	 for(jj=-1;jj<2;jj++)
	  for(ii=-1;ii<2;ii++) {
		  ijkt = IND_f(i+ii,j+jj,k+kk);
		  indx = (kk+1)*3*3 + (jj+1)*3 + (ii+1);
		  
		  ipsi_poly[indx].n=0; //# of faces initialized to zero
		  //we are not constructing solid polyhedrons in cells with psi< em6 or psi>em61
		  if(psi_f[ijkt] >= em6 && psi_f[ijkt] <= em61) {
			  nor2.x = psiavnx_f[ijkt], nor2.y = psiavny_f[ijkt], nor2.z = psiavnz_f[ijkt];
			  make_unity(&nor2);
			  
			  area_2(psi_f[ijkt],i+ii,j+jj,k+kk,ijkt,&nor2,&cent2,&vec_a2);
			  nor2.x = -nor2.z, nor2.y = 0.0, nor2.z = nor2.x;
			  const_com_polyhedron(&cube_poly,&ipsi_poly[indx],&cent2,&nor2,1);
		  }
		  
		  if(psi_f[ijkt] <= em6) {
			  const_sim_polyhedron(&ipsi_poly[indx]);
		  }
	  }
	
	//variables for golden section search
	double epsilon, tau, x1, x2, g_x1, g_x2, theta1, theta2; 
	int iter, cnt;
	epsilon = 1.e-12;
	tau = (sqrt(5.e0)-1.e0) / 2.e0; //golden ratio
	cnt = 0;
	iter = 110;
	
	theta1 = 0.0; 
	theta2 = 2.0*M_PI;
	
	//conditioning
	double theta,g_min,h; int ii_min,N;
	g_min = 30.0; 
	
	N = 32; h = (theta2 - theta1) / ((double)(N));
	
	for(ii=1;ii<=N;ii++)
	{
		theta = theta1 + (ii-0.5)*h;
		calc_nor(&nor1,&vec_c,&r,&theta,&vec_a,&vec_b);
		func_g(&g_x1,&(ipsi_poly[0]),&nor1,&cent1,i,j,k); //cent1 is output
		
		if(g_x1 < g_min) {
			g_min=g_x1;
			ii_min=ii;
		}
	}
	theta1 = MAX(theta1+(ii_min-2)*h,theta1); theta2 = MIN(theta1+3*h,theta2);
	
	x1 = theta1 + (1.e0 - tau)*(theta2 - theta1);
	x2 = theta1 + tau*(theta2 - theta1);
	
	//calculate g_x1
	calc_nor(&nor1,&vec_c,&r,&x1,&vec_a,&vec_b); //input x1, output nor1: 
	func_g(&g_x1,&(ipsi_poly[0]),&nor1,&cent1,i,j,k); //output is cent1 ... the location.. and g_x1
								  
	//calculate g_x2
	calc_nor(&nor2,&vec_c,&r,&x2,&vec_a,&vec_b); 
	func_g(&g_x2,&(ipsi_poly[0]),&nor2,&cent2,i,j,k);
	
	while ((fabs(theta1 - theta2) > epsilon) && (cnt < iter)) {
		cnt++;
		if(g_x1 < g_x2) {
			theta2 = x2;
			x2 = x1;
			x1 = theta1 + (1.e0-tau)*(theta2 - theta1);
			//calculate g_x1
			calc_nor(&nor1,&vec_c,&r,&x1,&vec_a,&vec_b); //x1 ---> nor1
			func_g(&g_x1,&(ipsi_poly[0]),&nor1,&cent1,i,j,k); // nor1 ---> g_x1
				
			//calculate g_x2
			calc_nor(&nor2,&vec_c,&r,&x2,&vec_a,&vec_b); //x2 ---> nor2
			func_g(&g_x2,&(ipsi_poly[0]),&nor2,&cent2,i,j,k); // nor2 ---> g_x2
		}
		else {
			theta1 = x1;
			x1 = x2;
			x2 = theta1 + tau*(theta2 - theta1);
			
			//calculate g_x1
			calc_nor(&nor1,&vec_c,&r,&x1,&vec_a,&vec_b); //x1 ---> nor1
			func_g(&g_x1,&(ipsi_poly[0]),&nor1,&cent1,i,j,k); // nor1 ---> g_x1
				
			//calculate g_x2
			calc_nor(&nor2,&vec_c,&r,&x2,&vec_a,&vec_b); //x2 ---> nor2
			func_g(&g_x2,&(ipsi_poly[0]),&nor2,&cent2,i,j,k); // nor2 ---> g_x2
		}
	} //end-while
	
	if(g_x1 < g_x2) {
		equate_pt(&nor,&nor1);
		equate_pt(&cent,&cent1);
	}
	else {
		equate_pt(&nor,&nor1);
		equate_pt(&cent,&cent1);
	}
	//--------------------------------------
#ifdef two_dim
	double xcoord = (i+2*mpi.OProc[0]-0.5)*(0.5*delx[1]);
	if(xcoord > Cent[NBODY].x) { 
		nor.x = -snor.z, nor.y = 0.0, nor.z = snor.x;
	}
	else {
		nor.x = snor.z, nor.y = 0.0, nor.z = -snor.x;
	}
	make_unity(&nor);
#endif
	//--------------------------------------
	
	//use the normal calculated from golden section search
	//nor.y = 0.0; make_unity(&nor);
	avnx_f[IJK_f] = nor.x; avny_f[IJK_f] = nor.y; avnz_f[IJK_f] = nor.z;

}

void contact_1p(int i, int j, int k) {
 //this routine identifies which face of the f=1 computational cell is liquid interface and would need extension
 
 st_point nor;
 double *avnx_f = temp_f[6];
 double *avny_f = temp_f[7];
 double *avnz_f = temp_f[8];
 //left x-face
 if(1.0 - f_f[IMJK_f] - psi_f[IMJK_f] >= em6 && f_f[IMJK_f] < em6) {
	nor.x = 1.e0; nor.y = 0.e0; nor.z = 0.e0;
 }
 
 //right x-face
 else if(1.0 - f_f[IPJK_f] - psi_f[IPJK_f] >= em6 && f_f[IPJK_f] < em6) {
	nor.x = -1.e0; nor.y = 0.e0; nor.z = 0.e0;
 }
 
 //back y-face
 else if(1.0 - f_f[IJMK_f] - psi_f[IJMK_f] >= em6 && f_f[IJMK_f] < em6) {
	nor.x = 0.e0; nor.y = 1.e0; nor.z = 0.e0;
 }
 
 //front y-face
 else if(1.0 - f_f[IJPK_f] - psi_f[IJPK_f] >= em6 && f_f[IJPK_f] < em6) {
	nor.x = 0.e0; nor.y = -1.e0; nor.z = 0.e0;
 }
 
 //under z-face
 else if(1.0 - f_f[IJKM_f] - psi_f[IJKM_f] >= em6 && f_f[IJKM_f] < em6) {
	nor.x = 0.e0; nor.y = 0.e0; nor.z = 1.e0;
 }
 
 //over z-face
 else if(1.0 - f_f[IJKP_f] - psi_f[IJKP_f] >= em6 && f_f[IJKP_f] < em6) {
	nor.x = 0.e0; nor.y = 0.e0; nor.z = -1.e0;
 }
 
 avnx_f[IJK_f] = nor.x; avny_f[IJK_f] = nor.y; avnz_f[IJK_f] = nor.z;
 fvirt_f[IJK_f] = 1.0;
}

void cube_plane_int(double *f_p, st_point *nor, st_point *cent, int i, int j, int k, int sp) {
	//the present routine returns the volume [*f_p] due to plane[*cent, *nor] cutting cube i,j,k
	//the plane may or may not cut the cube
	//sp = 1: when presence of solid is considered
	//   = 0: when the presence of solid is ignored [e.g. while calculating fvirtual field]
	
	int it,jt,kt,chg;
	double g_in, s_f; 
	double *psiavnx_f = temp_f[9];
	double *psiavny_f = temp_f[10];
	double *psiavnz_f = temp_f[11];
	st_point vert,vec_a, nor1, cent1, ct; //nor1, cent1 locating the psi-plane
	st_polyhedron cube_poly, liq_poly, ipsi_poly;
	
	*f_p = 0.0;
	chg = 0;
	
	ct.x = cent->x - (double)(i+2*mpi.OProc[0]-1); 
	ct.y = cent->y - (double)(j+2*mpi.OProc[1]-1); 
	ct.z = cent->z - (double)(k+2*mpi.OProc[2]-1);
	
	for(it=0;it<2;it++)
	 for(jt=0;jt<2;jt++)
	  for(kt=0;kt<2;kt++) {
		  vert.x = (double)(it); //vertices of the cube
		  vert.y = (double)(jt);
		  vert.z = (double)(kt);
		  
		  s_f = dif_dot(&vert,&ct,nor);
		  if(it==0 && jt==0 && kt==0) 
			g_in = s_f;
		  else {
			  if(g_in*s_f <= 0.0) {
				  chg = 1;
				  goto out_lp;
			  }
		  }
	  }
	
	out_lp:
	
	if(sp==1) { //presence of solid is considered
		if(chg == 0) {
			if(g_in > 0.0) 
				*f_p = 1.0 - psi_f[IJK_f];
			else
				*f_p = 0.0;
		}
		else { //chg == 1
			//intersection or at least grazing found between the cell and 
			//plane is found to be true
			if(psi_f[IJK_f] < em6) {
				const_sim_polyhedron(&cube_poly);
				const_com_polyhedron(&cube_poly,&liq_poly,&ct,nor,0);
				if(liq_poly.n < 4) *f_p = 0.0;
				else *f_p = calc_poly_vol(&liq_poly);
			}
			else if(psi_f[IJK_f] >= em6 && psi_f[IJK_f] <= em61) {
				//solid interface present inside the cell
				nor1.x = psiavnx_f[IJK_f]; nor1.y = psiavny_f[IJK_f]; nor1.z = psiavnz_f[IJK_f];
				make_unity(&nor1);
				area_2(psi_f[IJK_f],i,j,k,IJK_f,&nor1,&cent1,&vec_a); //vec_a is again a dummy variable
				
				//alternate method
				nor1.x = -nor1.x, nor1.y = -nor1.y, nor1.z = - nor1.z;
				const_sim_polyhedron(&cube_poly);
				const_com_polyhedron(&cube_poly,&ipsi_poly,&cent1,&nor1,1);
				const_com_polyhedron(&ipsi_poly,&liq_poly,&ct,nor,0);
				if(liq_poly.n < 4) (*f_p) = 0.0;
				else (*f_p) = calc_poly_vol(&liq_poly);
			}
			else if(psi_f[IJK_f] > em61) {
				*f_p = 0.0;
			}
		} //if chg==1
	} // if sp == 1
	
	else if(sp==0) { //presence of solid is ignored
		if(chg==0) {
			if(g_in > 0.0)
				*f_p = 1.0;
			else
				*f_p = 0.0;
		}
		else {
			const_sim_polyhedron(&cube_poly);
			const_com_polyhedron(&cube_poly,&liq_poly,&ct,nor,0);
			if(liq_poly.n < 4) *f_p = 0.0;
			else *f_p = calc_poly_vol(&liq_poly);
			
		} //if chg=1
	} //if sp == 0
}

void cube_plane_int2(double *f_p, st_polyhedron *ipsi_ptr, st_point *nor, st_point *cent, int i, int j, int k, int i2, int j2, int k2, int sp) {
	//the present routine returns the volume [*f_p] due to plane[*cent, *nor] cutting cube i,j,k
	//the plane may or may not cut the cube
	//sp = 1: when presence of solid is considered
	//   = 0: when the presence of solid is ignored [e.g. while calculating fvirtual field]
	
	int it,jt,kt,chg;
	double g_in, s_f; 
	st_point vert,ct;
	st_polyhedron liq_poly;
	
	*f_p = 0.0;
	chg = 0;
	
	ct.x = cent->x - (double)(i2); 
	ct.y = cent->y - (double)(j2); 
	ct.z = cent->z - (double)(k2);
	
	for(it=0;it<2;it++)
	 for(jt=0;jt<2;jt++)
	  for(kt=0;kt<2;kt++) {
		  vert.x = (double)(it); //vertices of the cube
		  vert.y = (double)(jt);
		  vert.z = (double)(kt);
		  
		  s_f = dif_dot(&vert,&ct,nor);
		  if(it==0 && jt==0 && kt==0) 
			g_in = s_f;
		  else {
			  if(g_in*s_f <= 0.0) {
				  chg = 1;
				  goto out_lp;
			  }
		  }
	  }
	
	out_lp:
	
	if(sp==1) { //presence of solid is considered
		if(chg == 0) {
			if(g_in > 0.0) 
				*f_p = 1.0 - psi_f[IJK_f];
			else
				*f_p = 0.0;
		}
		else { //chg == 1
			//intersection or at least grazing found between the cell and 
			//plane is found to be true
			if(psi_f[IJK_f] <= em61) {
				const_com_polyhedron(ipsi_ptr,&liq_poly,&ct,nor,0);
				if(liq_poly.n < 4) *f_p =0.0;
				else *f_p = calc_poly_vol(&liq_poly);
			}
			else if(psi_f[IJK_f] > em61) {
				*f_p = 0.0;
			}
		} //if chg==1
	} // if sp == 1
	
	else if(sp==0) { //presence of solid is ignored
		if(chg==0) {
			if(g_in > 0.0)
				*f_p = 1.0;
			else
				*f_p = 0.0;
		}
		else {
			const_com_polyhedron(ipsi_ptr,&liq_poly,&ct,nor,0);
			if(liq_poly.n < 4) *f_p = 0.0;
			else *f_p = calc_poly_vol(&liq_poly);
		} //if chg=1
	} //if sp == 0
}

void fvirt_call2() {
	
	int i,j,k,ii,jj,kk,ijkt,tf; //tf stores the triple_flg value
	double v_f,sum,p_vol,wgt,tf_f,tpsi_f; 
	st_point nor,cent,vec_a;
	st_polyhedron cube_poly;
	double *avnx_f = temp_f[6];
	double *avny_f = temp_f[7];
	double *avnz_f = temp_f[8];
	
	const_sim_polyhedron(&cube_poly);
	
	memset (neigh_triple,0,NX_f*NY_f*NZ_f*sizeof(int));
	
	for(k=-1;k<=kmax_f;k++)  //include 2 layers of ghost cells
	 for(j=-1;j<=jmax_f;j++)
	  for(i=-1;i<=imax_f;i++) {
		  
		  val_indx<int>(i,j,k,tf,triple_flg,triple_flg2);
		  
		  if(tf>0) {
			  for(kk=-2;kk<3;kk++)
			   for(jj=-2;jj<3;jj++)
			    for(ii=-2;ii<3;ii++) {
				    if(i+ii < 1 || i+ii > im2_f || j+jj < 1 || j+jj > jm2_f || k+kk < 1 || k+kk > km2_f) continue;
				    ijkt = IND_f(i+ii,j+jj,k+kk);
				    neigh_triple[ijkt] = 1;
			    }
		  } // only physical cells have been tagged neigh_triple
	  }
	  
	  //loop in all the physical cells

	  for(k=1;k<km1_f;k++)
	   for(j=1;j<jm1_f;j++)
	    for(i=1;i<im1_f;i++) { //...........................sol+liq > em61 || sol+air > em61
		    if(neigh_triple[IJK_f]==1 && (psi_f[IJK_f]+f_f[IJK_f] > em61 || 1.0 - f_f[IJK_f] > em61) && (psi_f[IJK_f] > em6) && triple_flg[IJK_f]==0) {
			    sum=0.0; 
			    //look around in 5x5x5 neighborhood
			    for(kk=-2;kk<3;kk++)		    
#ifdef two_dim
			     for(jj=0;jj<=0;jj++)
#endif
#ifndef two_dim
				 for(jj=-2;jj<3;jj++)
#endif
			      for(ii=-2;ii<3;ii++) {
					 val_indx<int>(i+ii,j+jj,k+kk,tf,triple_flg,triple_flg2);
					 if(tf>0) {
						 val_indx<double>(i+ii,j+jj,k+kk,tf_f,f_f,f2_f);
						 val_indx<double>(i+ii,j+jj,k+kk,tpsi_f,psi_f,psi2_f);
						 sum += tf_f * (1.0 - tpsi_f);
					 }
				}
				
			    fvirt_f[IJK_f] = 0.0;
			    avnx_f[IJK_f] = 0.0, avny_f[IJK_f] = 0.0, avnz_f[IJK_f] = 0.0;
			    
			    for(kk=-2;kk<3;kk++)
#ifdef two_dim
			     for(jj=0;jj<=0;jj++)
#endif
#ifndef two_dim
				 for(jj=-2;jj<3;jj++)
#endif
			     for(ii=-2;ii<3;ii++)  {
					val_indx<int>(i+ii,j+jj,k+kk,tf,triple_flg,triple_flg2);
					if(tf>0) {
						
						val_indx<double>(i+ii,j+jj,k+kk,v_f,fvirt_f,fvirt2_f);
						val_indx<double>(i+ii,j+jj,k+kk,nor.x,avnx_f,avnx2_f); //normals in triple_point cells are stored 
						val_indx<double>(i+ii,j+jj,k+kk,nor.y,avny_f,avny2_f); //in (avnx_f,avny_f,avnz_f)
						val_indx<double>(i+ii,j+jj,k+kk,nor.z,avnz_f,avnz2_f);
						val_indx<double>(i+ii,j+jj,k+kk,tf_f,f_f,f2_f); 
						val_indx<double>(i+ii,j+jj,k+kk,tpsi_f,psi_f,psi2_f); 
						ijkt = IND_f(i+ii,j+jj,k+kk); 
						
						//normal vectors in tf > 0 already normalized no need for make_unity
						
						if(v_f <= em61) // 2 or 3-phase cells
							area_2(v_f,i+ii,j+jj,k+kk,ijkt,&nor,&cent,&vec_a); //ijkt dummy variable
						else {
							if(nor.x > em6) {
								cent.x = 0.0; 
								cent.y = 0.5;
								cent.z = 0.5;
							}
							if(nor.x < -em6) {
								cent.x = 1.0; 
								cent.y = 0.5;
								cent.z = 0.5;
							}
							if(nor.y > em6) {
								cent.x = 0.5; 
								cent.y = 0.0;
								cent.z = 0.5;
							}
							if(nor.y < -em6) {
								cent.x = 0.5; 
								cent.y = 1.0;
								cent.z = 0.5;
							}
							if(nor.z > em6) {
								cent.x = 0.5; 
								cent.y = 0.5;
								cent.z = 0.0;
							}
							if(nor.z < -em6) {
								cent.x = 0.5; 
								cent.y = 0.5;
								cent.z = 1.0;
							}
						} //else v_f > em61
						cube_plane_int2(&p_vol,&cube_poly,&nor,&cent,i,j,k,-ii,-jj,-kk,0);
						wgt = tf_f * (1.0 - tpsi_f); wgt = wgt / (sum + tiny);
						fvirt_f[IJK_f] += wgt * p_vol;
						avnx_f[IJK_f] += wgt * nor.x;
						avny_f[IJK_f] += wgt * nor.y;	
						avnz_f[IJK_f] += wgt * nor.z;	 //normalize these normal vectors unity before using them					
					 } //if tf > 0
				} //ii,jj,kk loop
		    } // if neigh_triple ==1
	    } //for i,j,k
	    
	    add_fvirt(); //sets fvirt_f in additional solid cells	
}

void add_fvirt() {
	//the routine fills additional cells with fvirtual which was not 
	//performed before in the extension of contact line [plane] into the 
	//solid region
	
	int i,j,k, ii,jj,kk,ijkt;
	int cnt_f, cnt_2p, cnt_alpha;
	double tf_f, tpsi_f, alpha; //hold values of f_f & psi_f resp.
	
	//i=78, j=120, k=189;
	//if(mpi.MyRank==0) printf("(78,120,189): before fvirt=%e\n",fvirt_f[IJK_f]);
	
	for(k=1;k<km1_f;k++) //loop in physical cells only
	 for(j=1;j<jm1_f;j++)
	  for(i=1;i<im1_f;i++)
	  {
		  //if a solid cell and not in vicinity of triple point cell
		  if(psi_f[IJK_f] > em6 && neigh_triple[IJK_f] == 0) {
			  cnt_f=0; cnt_2p=0;
			  //look in 5x5x5 stencil 
			  for(kk=-2;kk<3;kk++)
			   for(jj=-2;jj<3;jj++)
			    for(ii=-2;ii<3;ii++) {
				    val_indx<double>(i+ii,j+jj,k+kk,tf_f,f_f,f2_f); //tf_f calculated here
				    val_indx<double>(i+ii,j+jj,k+kk,tpsi_f,psi_f,psi2_f);
				    if(tpsi_f < em6 && tf_f >= em6 && tf_f <= em61) cnt_2p++;
				    if(tf_f > em61) cnt_f++;
			    }
			    
			  //if(cnt_f > 0 && cnt_2p > 0) {
			  if(cnt_f > 0) {   
				  //additional criteria for obtuse contact angles
				  cnt_alpha=0;
				  for(kk=-1;kk<2;kk++)
				   for(jj=-1;jj<2;jj++)
				    for(ii=-1;ii<2;ii++) {
						val_indx<double>(i+ii,j+jj,k+kk,tf_f,f_f,f2_f);
						val_indx<double>(i+ii,j+jj,k+kk,tpsi_f,psi_f,psi2_f);
						alpha = 1.0 - tf_f - tpsi_f;
						if(alpha > em61) cnt_alpha++;
				    }
				  if(cnt_alpha==0) {
					   fvirt_f[IJK_f] = 1.0;
				  }
			  }
		  }
	  }
	  
	//i=78, j=120, k=189;
	//if(mpi.MyRank==0) printf("(78,120,189): after fvirt=%e\n",fvirt_f[IJK_f]);
}

void modify_boundary(int nsubcyc, st_point *cent, st_point *nor) {
	
	//the routine "extends" the f-field inside the ghost cells to 
	//aid in the correct calculation of normals in physical cells 
	//along the domain boundaries
	
	int i,j,k;
	int looper[6][3]={{3,2,1},{1,2,3},{2,3,1},{1,3,2},{2,1,3},{3,1,2}};
	int isweep=ncyc%6;
	double f_p, U, V, W;
	double *u_f = temp_f[3], *v_f = temp_f[4], *w_f = temp_f[5];
	st_point ct;
	
	U = u_f[IND_f(1,1,1)]; V = v_f[IND_f(1,1,1)]; W = w_f[IND_f(1,1,1)];
	nor->x = sin(M_PI_4); nor->y = 0.0; nor->z = cos(M_PI_4);
	equate_pt(&t_nor,nor);
	if(nsubcyc==0) {
		cent->x = 20.5*(0.5*delx[1]) + U*(t - delt); //previous time-step
		cent->y = 40.0*(0.5*dely[1]) + V*(t - delt);
		cent->z = 20.5*(0.5*delz[1]) + W*(t - delt);
	}
	else {
		switch (looper[isweep][nsubcyc-1]) {
			case 1: 
				cent->x += U*delt;
				break;
			case 2:
				cent->y += V*delt;
				break;
			case 3:
				cent->z += W*delt;
				break;
		}
	}
	
	ct.x = cent->x / (0.5*delx[1]);
	ct.y = cent->y / (0.5*dely[1]);
	ct.z = cent->z / (0.5*delz[1]);
	
	equate_pt(&t_cent,&ct);
	
	if(mpi.Neighbors[0]==-1) {
		i = 0;
		for(j=0;j<=jm1_f;j++)
		 for(k=0;k<=km1_f;k++) {
			 f_p = 0.0;
			 cube_plane_int(&f_p,nor,&ct,i,j,k,1); //presence of solid acknowledged
			 f_f[IND_f(i,j,k)] = f_p;
			 fn_f[IND_f(i,j,k)] = f_p;
		 } 
	}
	
	if(mpi.Neighbors[1]==-1) {
		i = im1_f;
		for(j=0;j<=jm1_f;j++)
		 for(k=0;k<=km1_f;k++) {
			 f_p = 0.0;
			 cube_plane_int(&f_p,nor,&ct,i,j,k,1); //presence of solid acknowledged
			 f_f[IND_f(i,j,k)] = f_p;
			 fn_f[IND_f(i,j,k)] = f_p;
		 } 
	}
	
	if(mpi.Neighbors[4]==-1) {
		k = 0;
		for(j=0;j<=jm1_f;j++)
		 for(i=0;i<=im1_f;i++) {
			 f_p = 0.0;
			 cube_plane_int(&f_p,nor,&ct,i,j,k,1);
			 f_f[IND_f(i,j,k)] = f_p;
			 fn_f[IND_f(i,j,k)] = f_p;
		 } 
	}
	
	if(mpi.Neighbors[5]==-1) {
		k = km1_f;
		for(j=0;j<=jm1_f;j++)
		 for(i=0;i<=im1_f;i++) {
			 f_p = 0.0;
			 cube_plane_int(&f_p,nor,&ct,i,j,k,1);
			 f_f[IND_f(i,j,k)] = f_p;
			 fn_f[IND_f(i,j,k)] = f_p;
		 } 
	}
	
	//if(mpi.MyRank==1) printf("0 1 2 nsubcyc=%d: cent.x=%.12e cent.y=%.12e cent.z=%.12e f_f=%.12e fn_f=%.12e U=%e V=%e W=%e\n",nsubcyc,cent->x,cent->y,cent->z,f_f[IND_f(0,1,2)],fn_f[IND_f(0,1,2)],U,V,W);
	//kidding here ...cool
}

void modify_boundary2(int nsubcyc, st_point *cent, double *theta) {
	
	//the routine "extends" the f-field inside the ghost cells to 
	//aid in the correct calculation of normals in physical cells 
	//along the domain boundaries
	
	int i,j,k;
	int looper[6][3]={{3,2,1},{1,2,3},{2,3,1},{1,3,2},{2,1,3},{3,1,2}};
	int isweep=ncyc%6;
	double f_p, U, V, W, omeg, ctheta, len;
	
	/*if(nsubcyc==0) {
		omeg = 1.0; (*theta) = (M_PI / 6.0) + omeg * (t-delt);
		cent->x = 0.5 - sqrt(3.0) * 0.15625 * cos(*theta);
		cent->y = 0.234375;
		cent->z = 0.234375 + sqrt(3.0) * 0.15625 * sin(*theta);
	}
	else {
		len = sqrt((cent->x-0.5)*(cent->x-0.5) + (cent->z-0.234375)*(cent->z-0.234375) + tiny);
		U = len*sin(*theta); V = 0.0; W = len*cos(*theta);
		switch (looper[isweep][nsubcyc-1]) {
			case 1:
				cent->x += U*delt;
				break;
			case 2:
				cent->y += V*delt;
				break;
			case 3:
				cent->z += W*delt;
				break;
		}
	}
	
	t_cent.x = cent->x / (0.5*delx[1]);
	t_cent.y = cent->y / (0.5*dely[1]);
	t_cent.z = cent->z / (0.5*delz[1]);
	if(mpi.MyRank==0) printf("cent->x = %e cent->y = %e cent->z = %e\n",cent->x,cent->y,cent->z);*/
	/*double t1, t2;
	if(nsubcyc==0) {
		omeg = 1.0; (*theta) = 0.0 + omeg * (t-delt);
		cent->x = 0.25*cos(*theta); cent->y = 0.0; cent->z = 0.25*sin(*theta); 
		t1 = 30.0*M_PI/180.0, t2 = (*theta)-60.0*M_PI/180.0;
		
		t_nor.x = cos(t1)*cos(t2); t_nor.y = sin(t1); t_nor.z = cos(t1)*sin(t2);
		//t_nor.x = sin(*theta); t_nor.y = 0.0; t_nor.z = -cos(*theta);
	}
	else {
		len = sqrt((cent->x)*(cent->x) + (cent->z)*(cent->z));
		U = -len*sin(*theta); V=0.0; W=len*cos(*theta);
		switch (looper[isweep][nsubcyc-1]) {
			case 1:
				cent->x += U*delt;
				break;
			case 2:
				cent->y += V*delt;
				break;
			case 3:
				cent->z += W*delt;
				break;
		}
		len = sqrt((cent->x)*(cent->x) + (cent->z)*(cent->z));		
		ctheta = cent->x / (len + tiny);
		(*theta) = acos(ctheta); if(cent->z < 0.0) (*theta) = 2.0*M_PI - (*theta);
		t1 = 30.0*M_PI/180.0, t2 = (*theta)-60.0*M_PI/180.0;
		t_nor.x = cos(t1)*cos(t2); t_nor.y = sin(t1); t_nor.z = cos(t1)*sin(t2);
		//t_nor.x = sin(*theta); t_nor.y = 0.0; t_nor.z = -cos(*theta);
	}
	t_cent.x = (0.5 + cent->x) / (0.5*delx[1]);
	t_cent.y = (0.25) / (0.5*dely[1]); 
	t_cent.z = (0.5 + cent->z) / (0.5*delz[1]);
	if(mpi.MyRank==0) printf("t_nor.x=%e t_nor.y=%e t_nor.z=%e\n",t_nor.x,t_nor.y,t_nor.z);*/
	if(nsubcyc==0) {
		omeg = 1.0; (*theta) = M_PI_4 + omeg * (t-delt);
		cent->x = t_cent.x*(0.5*delx[1]) - 1.0*cos(*theta); cent->y = 0.3125; cent->z = 1.0*sin(*theta); 
		t_nor.x = sin(*theta); t_nor.y = 0.0; t_nor.z = cos(*theta);
	}
	else {
		len = sqrt((cent->x-t_cent.x*(0.5*delx[1]))*(cent->x-t_cent.x*(0.5*delx[1])) + (cent->z-t_cent.z*(0.5*delz[1]))*(cent->z-t_cent.z*(0.5*delz[1])));
		U = len*sin(*theta); V=0.0; W=len*cos(*theta);
		switch (looper[isweep][nsubcyc-1]) {
			case 1:
				cent->x += U*delt;
				break;
			case 2:
				cent->y += V*delt;
				break;
			case 3:
				cent->z += W*delt;
				break;
		}
		len = sqrt((cent->x-t_cent.x*(0.5*delx[1]))*(cent->x-t_cent.x*(0.5*delx[1])) + (cent->z-t_cent.z*(0.5*delz[1]))*(cent->z-t_cent.z*(0.5*delz[1])));
		ctheta = (t_cent.x*(0.5*delx[1]) - cent->x)/(len+tiny);
		(*theta) = acos(ctheta); t_nor.x = sin(*theta); t_nor.y = 0.0; t_nor.z = cos(*theta);
	}
	
		
	if(mpi.Neighbors[0]==-1) {
		i = 0;
		for(j=0;j<=jm1_f;j++)
		 for(k=0;k<=km1_f;k++) {
			 f_p = 0.0;
			 cube_plane_int(&f_p,&t_nor,&t_cent,i,j,k,1); //presence of solid acknowledged
			 f_f[IND_f(i,j,k)] = f_p;
			 fn_f[IND_f(i,j,k)] = f_p;
		 } 
	}
	
	if(mpi.Neighbors[1] == -1) {
		i = im1_f;
		for(j=0;j<=jm1_f;j++)
		 for(k=0;k<=km1_f;k++) {
			 f_p = 0.0;
			 cube_plane_int(&f_p,&t_nor,&t_cent,i,j,k,1); 
			 f_f[IND_f(i,j,k)] = f_p;
			 fn_f[IND_f(i,j,k)] = f_p;
		 } 
	}
	
	if(mpi.Neighbors[2] == -1) {
		j = 0;
		for(i=0;i<=im1_f;i++)
		 for(k=0;k<=km1_f;k++) {
			 f_p = 0.0;
			 cube_plane_int(&f_p,&t_nor,&t_cent,i,j,k,1); 
			 f_f[IND_f(i,j,k)] = f_p;
			 fn_f[IND_f(i,j,k)] = f_p;
		 }
	}
	
	if(mpi.Neighbors[3] == -1) {
		j = jm1_f;
		for(i=0;i<=im1_f;i++)
		 for(k=0;k<=km1_f;k++) {
			 f_p = 0.0;
			 cube_plane_int(&f_p,&t_nor,&t_cent,i,j,k,1); 
			 f_f[IND_f(i,j,k)] = f_p;
			 fn_f[IND_f(i,j,k)] = f_p;
		 }
	}
	
	if(mpi.Neighbors[4] == -1) {
		k = 0;
		for(i=0;i<=im1_f;i++)
		 for(j=0;j<=jm1_f;j++) {
			 f_p = 0.0;
			 cube_plane_int(&f_p,&t_nor,&t_cent,i,j,k,1); 
			 f_f[IND_f(i,j,k)] = f_p;
			 fn_f[IND_f(i,j,k)] = f_p;
		 }
	}
	
	if(mpi.Neighbors[5] == -1) {
		k = km1_f;
		for(i=0;i<=im1_f;i++)
		 for(j=0;j<=jm1_f;j++) {
			 f_p = 0.0;
			 cube_plane_int(&f_p,&t_nor,&t_cent,i,j,k,1); 
			 f_f[IND_f(i,j,k)] = f_p;
			 fn_f[IND_f(i,j,k)] = f_p;
		 }
	}
	if(mpi.MyRank==0) printf("t_nor.x = %e t_nor.y = %e t_nor.z = %e\n",t_nor.x,t_nor.y,t_nor.z);
}

void printError(int nsubcyc) {
	//error calculating routine
	FILE *fp;
	st_point err_2p, indx_2p, err_3p, indx_3p;
	double cnt_2p, cnt_3p; double f_p, alpha_p, alpha, rudE, trudE, mvol, tmvol; int i,j,k; int m,n,p;
	double *avnx_f = temp_f[6];
	double *avny_f = temp_f[7];
	double *avnz_f = temp_f[8];
	
	//for mpi-reduce
	st_point terr_2p, tindx_2p, terr_3p, tindx_3p;
	double tcnt_2p, tcnt_3p; double tmp_val;
	//set t_nor and t_cent here
	//t_nor.x = sin(M_PI_4); t_nor.y = 0.0; t_nor.z = cos(M_PI_4);
	/*t_nor.x = -1.0, t_nor.y = 0.0, t_nor.z = 0.0;
	int looper[6][3]={{3,2,1},{1,2,3},{2,3,1},{1,3,2},{2,1,3},{3,1,2}};
	int isweep=ncyc%6;
	
	if(nsubcyc==0) {
		t_cent.x = 20.5 + 0.5*(t-delt) / (0.5*delx[1]);
		t_cent.y = 0.0;
		t_cent.z = 20.5 + 1.0*(t-delt) / (0.5*delz[1]);
	}
	else {
		switch(looper[isweep][nsubcyc-1]) {
			case 1:
				t_cent.x += 0.5*delt / (0.5*delx[1]);
				break;
			case 2:
				t_cent.y += 0.0;
				break;
			case 3:
				t_cent.z += 1.0*delt / (0.5*delz[1]);
				break;
		}
	}*/
	
	cnt_2p=0.0, cnt_3p=0.0;
	err_2p.x = err_2p.y = err_2p.z = err_3p.x = err_3p.y = err_3p.z = 0.0;
	indx_2p.x = indx_2p.y = indx_2p.z = indx_3p.x = indx_3p.y = indx_3p.z=0.0;
	
	if(ncyc==401 && nsubcyc==0) {
		fp = fopen("err_f","a+");
		rudE = 0.0, mvol = 0.0;
		//f-distribution
		for(i=1;i<im1_f;i++)
		 for(j=1;j<jm1_f;j++)
		  for(k=1;k<km1_f;k++) {
			  
			  alpha = 1.0 - f_f[IJK_f] - psi_f[IJK_f];
			  m23_one_cell(&f_p,&alpha_p,i,j,k);
			  rudE += fabs(f_p - f_f[IJK_f]) + fabs(alpha_p - alpha);
			  mvol += f_p + alpha_p;
			  
			  if((f_f[IJK_f] >= em6 && psi_f[IJK_f] < em6 && f_f[IJK_f] <=em61) || (f_f[IJK_f]>=em6 && 1.0-f_f[IJK_f]-psi_f[IJK_f]<em6 && triple_flg[IJK_f]==0 && 
			  ((f_f[IMJK_f]<em6 && 1.0-f_f[IMJK_f]-psi_f[IMJK_f]>=em6)||(f_f[IPJK_f]<em6 && 1.0-f_f[IPJK_f]-psi_f[IPJK_f]>=em6)
			  ||(f_f[IJMK_f]<em6 && 1.0-f_f[IJMK_f]-psi_f[IJMK_f]>=em6)||(f_f[IJPK_f]<em6 && 1.0-f_f[IJPK_f]-psi_f[IJPK_f]>=em6)
			  ||(f_f[IJKM_f]<em6 && 1.0-f_f[IJKM_f]-psi_f[IJKM_f]>=em6)||(f_f[IJKP_f]<em6 && 1.0-f_f[IJKP_f]-psi_f[IJKP_f]>=em6)))) {
				  //f_p=0.0;
				  //cube_plane_int(&f_p,&t_nor,&t_cent,i,j,k,1);
				  cnt_2p += 1.0;
				  
				  if(fabs(f_p-f_f[IJK_f]) > err_2p.x) {
					  err_2p.x = fabs(f_p-f_f[IJK_f]);
					  indx_2p.x = i+2*mpi.OProc[0], indx_2p.y = j+2*mpi.OProc[1], indx_2p.z = k+2*mpi.OProc[2];
				  }
				  err_2p.y += fabs(f_p - f_f[IJK_f]);
				  err_2p.z += (f_p - f_f[IJK_f])*(f_p - f_f[IJK_f]);
			  }
			  
			  if((f_f[IJK_f] >= em6 && psi_f[IJK_f] >= em6 && f_f[IJK_f] + psi_f[IJK_f] <=em61) || triple_flg[IJK_f]!=0) {
				  //f_p=0.0;
				  //cube_plane_int(&f_p,&t_nor,&t_cent,i,j,k,1);
				  cnt_3p += 1.0;
				  
				  if(fabs(f_p-f_f[IJK_f]) > err_3p.x) {
					  err_3p.x = fabs(f_p-f_f[IJK_f]);
					  indx_3p.x = i+2*mpi.OProc[0], indx_3p.y = j+2*mpi.OProc[1], indx_3p.z = k+2*mpi.OProc[2];
				  }
				  err_3p.y += fabs(f_p - f_f[IJK_f]);
				  err_3p.z += (f_p - f_f[IJK_f])*(f_p - f_f[IJK_f]);
			  }
		  }
		
		dallreduce(&err_2p.x,&terr_2p.x,1,OP_MAX);
		dallreduce(&err_2p.y,&terr_2p.y,1,OP_SUM); 
		dallreduce(&err_2p.z,&terr_2p.z,1,OP_SUM);
		dallreduce(&cnt_2p,&tcnt_2p,1,OP_SUM);
		tmp_val = err_2p.x;
		if(err_2p.x==terr_2p.x) tmp_val += mpi.MyRank;
		dallreduce(&tmp_val,&terr_2p.x,1,OP_MAX);
		if(tmp_val==terr_2p.x) {
			err_2p.y = terr_2p.y / (tcnt_2p + tiny);
			err_2p.z = sqrt(terr_2p.z / (tcnt_2p + tiny));
			fprintf(fp,"%d %d %e %e %e %e %e %e %e ",ncyc,nsubcyc,tcnt_2p,indx_2p.x,indx_2p.y,indx_2p.z,err_2p.x,err_2p.y,err_2p.z);
		}
		dallreduce(&err_3p.x,&terr_3p.x,1,OP_MAX);
		dallreduce(&err_3p.y,&terr_3p.y,1,OP_SUM); 
		dallreduce(&err_3p.z,&terr_3p.z,1,OP_SUM);
		dallreduce(&cnt_3p,&tcnt_3p,1,OP_SUM);
		tmp_val = err_3p.x;
		if(err_3p.x==terr_3p.x) tmp_val += mpi.MyRank;
		dallreduce(&tmp_val,&terr_3p.x,1,OP_MAX);
		if(tmp_val==terr_3p.x) {
			err_3p.y = terr_3p.y / (tcnt_3p + tiny);
			err_3p.z = sqrt(terr_3p.z / (tcnt_3p + tiny));
			mc = (int)(indx_3p.x)-2*mpi.OProc[0]; nc = (int)(indx_3p.y)-2*mpi.OProc[1]; oc = (int)(indx_3p.z)-2*mpi.OProc[2];
			printf("max n at err=%e f_f=%e psi_f=%e alpha=%e (%d %d %d) rank=%d triple_flg=%d\n",err_3p.x,f_f[IND_f(mc,nc,oc)],psi_f[IND_f(mc,nc,oc)],1.0-psi_f[IND_f(mc,nc,oc)]-f_f[IND_f(mc,nc,oc)],mc,nc,oc,mpi.MyRank,triple_flg[IND_f(mc,nc,oc)]);
			printf("max n : calc n: avnx=%e avny=%e avnz=%e\n",avnx_f[IND_f(mc,nc,oc)],avny_f[IND_f(mc,nc,oc)],avnz_f[IND_f(mc,nc,oc)]);
			fprintf(fp,"%e %e %e %e %e %e %e\n",tcnt_3p,indx_3p.x,indx_3p.y,indx_3p.z,err_3p.x,err_3p.y,err_3p.z);
		}
		fclose(fp);
	
	//int ii,jj,kk;
	/*if(t_prob==1) {
		i=38, j=29, k=17;
		for(kk=1;kk>-2;kk--) {
		 printf("----------correct-field######kk=%d------------\n",kk);
		 for(jj=1;jj>-2;jj--) {
		  for(ii=-1;ii<2;ii++) {
			  cube_plane_int(&f_p,&t_nor,&t_cent,i+ii,j+jj,k+kk,1);
			  printf("%e(%e) ",f_p,psi_f[IND_f(i+ii,j+jj,k+kk)]);
		  }
		  printf("\n");
		 }
		}
	}*/
	//if(mpi.MyRank==0) printf("t_nor.x=%e t_nor.y=%e t_nor.z=%e\n",t_nor.x,t_nor.y,t_nor.z);
	
}

void clean_VOF() {
	int i,j,k;
	double alpha_t, alpha, f_t;
//	int isolation_counter_water = 0;
//	int isolation_counter_air = 0;
	
	//please note that fn_f and f_f should be the same at this point
	for(k=1;k<km1_f;k++)
	 for(j=1;j<jm1_f;j++)
	  for(i=1;i<im1_f;i++) {
		  if(f_f[IJK_f] > em61) f_f[IJK_f] = 1.0;
		  if(f_f[IJK_f] < em6) f_f[IJK_f] = 0.0;
		  if(psi_f[IJK_f] > em61) psi_f[IJK_f] = 1.0;
		  if(psi_f[IJK_f] < em6) psi_f[IJK_f] = 0.0;
		  if(f_f[IJK_f] + psi_f[IJK_f] > em61) f_f[IJK_f] = 1.0 - psi_f[IJK_f];
		  
		  //check for air pocket
		  alpha = 1.0 - fn_f[IJK_f] - psin_f[IJK_f];
		  if(alpha > em6 && alpha < 0.1) {
			  alpha_t = (1.0-fn_f[IJK_f]-psin_f[IJK_f]) + (1.0-fn_f[IMJK_f]-psin_f[IMJK_f]) + (1.0-fn_f[IJMK_f]-psin_f[IJMK_f]) + (1.0-fn_f[IJKM_f]-psin_f[IJKM_f])
			  + (1.0-fn_f[IPJK_f]-psin_f[IPJK_f]) + (1.0-fn_f[IJPK_f]-psin_f[IJPK_f]) + (1.0-fn_f[IJKP_f]-psin_f[IJKP_f]) + (1.0-fn_f[IMJMK_f]-psin_f[IMJMK_f])
			  + (1.0-fn_f[IMJPK_f]-psin_f[IMJPK_f]) + (1.0-fn_f[IPJMK_f]-psin_f[IPJMK_f]) + (1.0-fn_f[IPJPK_f]-psin_f[IPJPK_f]) + (1.0-fn_f[IJMKM_f]-psin_f[IJMKM_f])
			  + (1.0-fn_f[IJMKP_f]-psin_f[IJMKP_f]) + (1.0-fn_f[IJPKM_f]-psin_f[IJPKM_f]) + (1.0-fn_f[IJPKP_f]-psin_f[IJPKP_f]) + (1.0-fn_f[IMJKM_f]-psin_f[IMJKM_f])
			  + (1.0-fn_f[IPJKM_f]-psin_f[IPJKM_f]) + (1.0-fn_f[IMJKP_f]-psin_f[IMJKP_f]) + (1.0-fn_f[IPJKP_f]-psin_f[IPJKP_f]);
			  if(alpha_t < 0.1) {
				  fprintf (files.error, " air isolated on cycle %5d, time %13.5e : ALPHA(%2d,%2d,%2d) = %14.7e\n", ncyc, t, i,j,k, 1.0-f_f[IJK_f]-psi_f[IJK_f]);
				  //printf (" air isolated on cycle %5d, time %13.5e : ALPHA(%2d,%2d,%2d) = %14.7e\n", ncyc, t, i,j,k, 1.0-f_f[IJK_f]-psi_f[IJK_f]);
//				  isolation_counter_air +=1;
				  f_f[IJK_f] = 1.0 - psi_f[IJK_f]; 
			  }
		  }
		  
		  //check for isolated liquid
		  if(f_f[IJK_f] >= em6 && f_f[IJK_f] < 0.1) {
			  f_t = fn_f[IJK_f] + fn_f[IMJK_f] + fn_f[IJMK_f] + fn_f[IJKM_f] + fn_f[IPJK_f] + fn_f[IJPK_f] + fn_f[IJKP_f] + fn_f[IMJMK_f]
				+ fn_f[IMJPK_f] + fn_f[IPJMK_f] + fn_f[IPJPK_f] + fn_f[IJMKM_f] + fn_f[IJMKP_f] + fn_f[IJPKM_f] + fn_f[IJPKP_f] + fn_f[IMJKM_f]
				+ fn_f[IPJKM_f] + fn_f[IMJKP_f] + fn_f[IPJKP_f];
			  
			  if(f_t < 0.1) {
				  fprintf (files.error, " water isolated on cycle %5d, time %13.5e : f_f(%2d,%2d,%2d) = %14.7e\n", ncyc, t, i,j,k, f_f[IJK_f]);
				  //printf (" water isolated on cycle %5d, time %13.5e : f_f(%2d,%2d,%2d) = %14.7e\n", ncyc, t, i,j,k, f_f[IJK_f]);
//				  isolation_counter_water +=1;
				  f_f[IJK_f] = 0.0;
			  }
		  }
	  }
//	  printf(" water isolated in %d cells\n",isolation_counter_water);
//	  printf(" air isolated in %d cells\n",isolation_counter_air);
}

void sph_one_cell(double *f_p, int i, int j, int k, st_point* cent, double r2) {
	
	//initializes one cell of a sphere... [*cent] is center of the sphere 
	double tx,ty,tz,txm,tym,tzm;

	tx = (i+2*mpi.OProc[0])*(0.5*delx[1]);
	ty = (j+2*mpi.OProc[1])*(0.5*dely[1]);
	tz = (k+2*mpi.OProc[2])*(0.5*delz[1]);  
		
	txm = tx - 0.5*delx[1];
	tym = ty - 0.5*dely[1];
	tzm = tz - 0.5*delz[1];
		
	if ( MIN(SQUARE(txm-cent->x), SQUARE(tx-cent->x))
	    +MIN(SQUARE(tym-cent->y), SQUARE(ty-cent->y))
	    +MIN(SQUARE(tzm-cent->z), SQUARE(tz-cent->z))
	    >= r2)
		(*f_p)=0.0;
	//cell is full?
	else if ( MAX(SQUARE(txm-cent->x), SQUARE(tx-cent->x))
	    +MAX(SQUARE(tym-cent->y), SQUARE(ty-cent->y))
	    +MAX(SQUARE(tzm-cent->z), SQUARE(tz-cent->z))
	    <= r2)
		(*f_p)=1.0;
	
	//cell neither empty nor full
	else
	{
		(*f_p)=0.0;
		for (int l=0;l<25;l++)
		 for (int m=0;m<25;m++)
		  for (int n=0;n<25;n++)
		  {	
								
			if (SQUARE(txm+(l+0.5)/25.0*delx[1]*0.5e0-cent->x)+
			SQUARE(tym+(m+0.5)/25.0*dely[1]*0.5e0-cent->y)+
			SQUARE(tzm+(n+0.5)/25.0*delz[1]*0.5e0-cent->z)
			< r2)
				(*f_p) += 6.4e-5;
		  }
	}
}

void m23_one_cell(double *f_p, double *alpha_p, int i, int j, int k) {
	(*f_p) = 0.0; (*alpha_p) = 0.0;
	st_point cent, nor, cent1, nor1, vec_a;
	st_polyhedron cube_poly, ipsi_poly, liq_poly;
	double psi_p,r2,tx,ty,tz;
	
	//cell center coordinates
	tx = (i+2*mpi.OProc[0]-0.5)*0.5*delx[1];
	ty = (j+2*mpi.OProc[1]-0.5)*0.5*dely[1];
	tz = (k+2*mpi.OProc[2]-0.5)*0.5*delz[1]; 
	
	//fluid
	cube_plane_int(f_p,&t_nor,&t_cent,i,j,k,0);
	/*cent.x = t_cent.x*0.5*delx[1]; cent.y = t_cent.y*0.5*dely[1]; cent.z = t_cent.z*0.5*delz[1];
	r2 = 0.15625*0.15625;
	sph_one_cell(f_p,i,j,k,&cent,r2);*/
	
	//solid
	nor1.x = 1.0, nor1.y = 0.0, nor1.z = 0.0;
	cube_plane_int(&psi_p,&nor1,&t_cent,i,j,k,0);
	//cent1.x = 0.5; cent1.y = 0.234375; cent1.z = 0.234375;
	/*cent1.x = t_cent.x*0.5*delx[1], cent1.y = t_cent.y*0.5*dely[1], cent1.z = t_cent.z*0.5*delz[1];
	r2 = 0.15625*0.15625; 
	sph_one_cell(&psi_p,i,j,k,&cent1,r2);*/
	//invert psi_p
	//psi_p = 1.0 - psi_p; //done for void*/
	
	if(psi_p > em61) {
		(*f_p) = 0.0;
	}
	else if(psi_p >= em6 && psi_p <= em61) {
		if((*f_p) > em61) {
			(*f_p) = (*f_p) - psi_p;
		}
		else if((*f_p) >= em6 && (*f_p) <= em61) {
			//nor1.x = -(tx-cent1.x); nor1.y = -(ty-cent1.y); nor1.z = -(tz-cent1.z);
			//make_unity(&nor1);
			//nor1.x = -nor1.x, nor1.y = -nor1.y, nor1.z = -nor1.z; //invert normal vector components for void
			area_2(psi_p,i,j,k,IJK_f,&nor1,&cent1,&vec_a); //cent1 is centroid of the psi plane
			
			/*nor.x = -(tx-cent.x); nor.y = -(ty-cent.y); nor.z = -(tz-cent.z);
			make_unity(&nor);*/
			equate_pt(&nor,&t_nor);
			area_2(*f_p,i,j,k,IJK_f,&nor,&cent,&vec_a); //cent now is centroid of f-plane
						
			//invert the psi normal vector
			nor1.x = -nor1.x; nor1.y = -nor1.y; nor1.z = -nor1.z;
			const_sim_polyhedron(&cube_poly);
			const_com_polyhedron(&cube_poly,&ipsi_poly,&cent1,&nor1,1);
			const_com_polyhedron(&ipsi_poly,&liq_poly,&cent,&nor,0);
			if(liq_poly.n < 4) (*f_p) = 0.0;
			else (*f_p) = calc_poly_vol(&liq_poly);
		}
	}
	(*alpha_p) = 1.0 - (*f_p) - psi_p;
}

void calc_polyhedron_centroid (int i, int j, int k, st_polyhedron *ptr, st_point *cent, double *tot_vol) {
	//returned are centroid cent of polyhedron ptr
	//and volume tot_vol of polyhedron
	st_point v0,v1,tcent,ct,tri[4];
	int m,n,ii,jj;
	double H,epsilon,voli,p_area,t_area;
	epsilon = 1.e-12;
	
	if(ptr->n < 4) {
		printf("calc_polyhedron_centroid: not a valid polyhedron i,j,k=%d %d %d\n",i,j,k); 
		return;
	}
	
	m = ptr->n-1;
	n = ptr->face[m].n-1;
	equate_pt(&v0,&(ptr->face[m].vert[n])); //last vertex of last face
	
	cent->x = 0.0, cent->y = 0.0, cent->z = 0.0; //cent and tot_vol will initially be 
	(*tot_vol) = 0.0; //on a unit coordinate system, will be converted to global system later
	for(ii=0;ii<m;ii++) { //loop over all faces save the last
		equate_pt(&v1,&(ptr->face[ii].vert[0])); //first vertex of a face ii
		H=dif_dot(&v0,&v1,&(ptr->face[ii].nor)); //height of v0 from given face
		if(fabs(H)>epsilon) { //if a valid pyramid made
			tcent.x = 0.0, tcent.y = 0.0, tcent.z = 0.0; //centroid and area of each face polygon
			p_area = 0.0;
			equate_pt(&(tri[0]),&v1); 
			equate_pt(&(tri[3]),&v1);
			for(jj=2;jj<(ptr->face[ii].n);jj++) { //loop over all triangles of a face
				equate_pt(&(tri[1]),&(ptr->face[ii].vert[jj-1]));
				equate_pt(&(tri[2]),&(ptr->face[ii].vert[jj]));
				t_area = area3D_polygon(&(tri[0]),&(ptr->face[ii].nor),3);
				t_area = fabs(t_area); //area of the triangle
				ct.x = (tri[0].x+tri[1].x+tri[2].x)/3.0; //ct: centroid of a triangle
				ct.y = (tri[0].y+tri[1].y+tri[2].y)/3.0;
				ct.z = (tri[0].z+tri[1].z+tri[2].z)/3.0;
				tcent.x += t_area*ct.x, tcent.y += t_area*ct.y, tcent.z += t_area*ct.z;
				p_area += t_area;
			}
			tcent.x /= p_area, tcent.y /= p_area, tcent.z /= p_area; //centroid of the base polygon
			
			vec_weight(&ct,&v0,&tcent,0.25); //ct: centroid of pyramid, which divides
			//line segment joining base centroid to apex in 1:3 ratio
			
			voli = (1.0/3.0)*fabs(H*p_area);
			cent->x += ct.x*voli, cent->y += ct.y*voli, cent->z += ct.z*voli;
			(*tot_vol) += voli;
		} //if(H>epsilon)
	}//if(ii)
	cent->x /= (*tot_vol), cent->y /=(*tot_vol), cent->z /= (*tot_vol);
	//map to global coordinates from the unit local coordinates
	cent->x = (i+2*mpi.OProc[0]-1 + cent->x)*(0.5*delx[1]);
	cent->y = (j+2*mpi.OProc[1]-1 + cent->y)*(0.5*dely[1]);
	cent->z = (k+2*mpi.OProc[2]-1 + cent->z)*(0.5*delz[1]);
	(*tot_vol) = (*tot_vol)*vol_f[IJK_f];
}

void Ncalc_psi_centroid(st_point *cent, int bindx) {
	//before calling this routine make sure psinormals_f() is called before this function.
	//calculation of solid density is further requirement of psinormals_f()
	int i,j,k;
	int i_minf,i_maxf,j_minf,j_maxf,k_minf,k_maxf;
	st_point v0,nor,vec_a;
	st_polyhedron cube_poly, psi_poly;
	double *psiavnx_f = temp_f[9];
	double *psiavny_f = temp_f[10];
	double *psiavnz_f = temp_f[11];
	
	double voli, tot_vol; //tot_vol over an mpi-subdomain,
	cent->x = 0.0, cent->y = 0.0, cent->z = 0.0;
	tot_vol = 0.0;
	const_sim_polyhedron(&cube_poly);
	
	i_minf=2*i_min[bindx]-1, i_maxf=2*i_max[bindx];
	j_minf=2*j_min[bindx]-1, j_maxf=2*j_max[bindx];
	k_minf=2*k_min[bindx]-1, k_maxf=2*k_max[bindx];
	
	//FILE *fp;
	//fp=fopen("rank0","wt");
	for(k=k_minf;k<=k_maxf;k++) 
	 for(j=j_minf;j<=j_maxf;j++)
	  for(i=i_minf;i<=i_maxf;i++) {
		  if(psi_f[IJK_f] > em61 ) {//&& (bindx==1 || (bindx==2 && k+2*mpi.OProc[2]>52))) { //modify back later ...ashish
			  v0.x = (i+2*mpi.OProc[0]-0.5)*(0.5*delx[1]);
			  v0.y = (j+2*mpi.OProc[1]-0.5)*(0.5*dely[1]);
			  v0.z = (k+2*mpi.OProc[2]-0.5)*(0.5*delz[1]);
			  voli = vol_f[IJK_f];
			  cent->x += v0.x*voli, cent->y += v0.y*voli, cent->z += v0.z*voli;
			  tot_vol += voli;
		  }
		  else if(psi_f[IJK_f] >= em6 && psi_f[IJK_f] <= em61) {// && (bindx==1 || (bindx==2 && k+2*mpi.OProc[2]>52))) {
			  nor.x = psiavnx_f[IJK_f], nor.y = psiavny_f[IJK_f], nor.z = psiavnz_f[IJK_f];
			  make_unity(&nor);
			  area_2(psi_f[IJK_f],i,j,k,IJK_f,&nor,&v0,&vec_a); //v0 is the output
			  const_com_polyhedron(&cube_poly,&psi_poly,&v0,&nor,0); //0 : sorting not required
			  calc_polyhedron_centroid(i,j,k,&psi_poly,&v0,&voli); //v0 is being reutilized here, v0 and vol output
			  //if(mpi.MyRank==0 && IJK_f==IND_f(33,64,64)) {
				  cent->x += v0.x*voli, cent->y += v0.y*voli, cent->z += v0.z*voli;
				  tot_vol += voli;
				  //fprintf(fp,"(%d %d %d): %e %e |%e| %e nor: %e %e %e\n",i,j,k,v0.x,v0.y,v0.z-0.5,voli,psiavnx_f[IJK_f],psiavny_f[IJK_f],psiavnz_f[IJK_f]);
			  //}
		  }
	  }
	//fclose(fp);
	dallreduce(&(cent->x),&(v0.x),1,OP_SUM); //summation over all mpi-processors
	dallreduce(&(cent->y),&(v0.y),1,OP_SUM);
	dallreduce(&(cent->z),&(v0.z),1,OP_SUM);
	dallreduce(&tot_vol,&voli,1,OP_SUM);  
	cent->x = v0.x / voli;
	cent->y = v0.y / voli;
	cent->z = v0.z / voli;
	
}

void Nset_rigid_body_vel(int loop, int bindx) {
	//this routine should be called in the beginning of each subcycle of vofdly. It overwrites
	//the fine grid velocities to rigid body velocity at cell faces that are very close to 
	//solid interface. 

	int i,j,k;
	int i_minf,j_minf,k_minf,i_maxf,j_maxf,k_maxf;
	st_point v0;
	double r[NDIM+1],omega[NDIM+1],vel[NDIM+1];
	double *u_f = temp_f[3], *v_f = temp_f[4], *w_f = temp_f[5];

	i_minf = 2*i_min[bindx]-2; i_maxf = 2*i_max[bindx];
	j_minf = 2*j_min[bindx]-2; j_maxf = 2*j_max[bindx];
	k_minf = 2*k_min[bindx]-2; k_maxf = 2*k_max[bindx];
	omega[1]=Omega[bindx].x, omega[2]=Omega[bindx].y, omega[3]=Omega[bindx].z;
	//if(mpi.MyRank==0) printf("set rig: Omega = (%e %e %e) rig_U (%e %e %e)\n",Omega.x,Omega.y,Omega.z,rig_U[1],rig_U[2],rig_U[3]);
	for(k=k_minf;k<=k_maxf;k++)
	 for(j=j_minf;j<=j_maxf;j++)
	   for(i=i_minf;i<=i_maxf;i++) {
		  switch(loop) {
			  case 1:
				if(j==0 || k==0) continue;
				if(psi_f[IJK_f]<em6 && psi_f[IJK_f+1]<em6) continue;
				v0.x = (i+2*mpi.OProc[0])*(0.5*delx[1]);
				v0.y = (j+2*mpi.OProc[1]-0.5)*(0.5*dely[1]);
				v0.z = (k+2*mpi.OProc[2]-0.5)*(0.5*delz[1]);
				
				r[1] = v0.x - Cent[bindx].x, 
				r[2] = v0.y - Cent[bindx].y,
				r[3] = v0.z - Cent[bindx].z;
				
				crossProduct(vel,omega,r);
				u_f[IJK_f] = rig_U[bindx][1] + vel[1];
				break;
			  case 2:
				if(i==0 || k==0) continue;
				if(psi_f[IJK_f]<em6 && psi_f[IJK_f+imax_f]<em6) continue;
				v0.x = (i+2*mpi.OProc[0]-0.5)*(0.5*delx[1]);
				v0.y = (j+2*mpi.OProc[1])*(0.5*dely[1]);
				v0.z = (k+2*mpi.OProc[2]-0.5)*(0.5*delz[1]);
				
				r[1] = v0.x - Cent[bindx].x, 
				r[2] = v0.y - Cent[bindx].y,
				r[3] = v0.z - Cent[bindx].z;
				
				crossProduct(vel,omega,r);
				v_f[IJK_f] = rig_U[bindx][2] + vel[2];
				break;
			  case 3:
			  	if(i==0 || j==0) continue;
				if(psi_f[IJK_f]<em6 && psi_f[IJK_f+ijmax_f]<em6) continue;
				v0.x = (i+2*mpi.OProc[0]-0.5)*(0.5*delx[1]);
				v0.y = (j+2*mpi.OProc[1]-0.5)*(0.5*dely[1]);
				v0.z = (k+2*mpi.OProc[2])*(0.5*delz[1]);
				
				r[1] = v0.x - Cent[bindx].x, 
				r[2] = v0.y - Cent[bindx].y,
				r[3] = v0.z - Cent[bindx].z;
				
				crossProduct(vel,omega,r);
				w_f[IJK_f] = rig_U[bindx][3] + vel[3];
				break;
		  }
	  }

	switch(loop) {
		case 1:  
			xchg_f<double>(u_f);
			break;
		case 2:
			xchg_f<double>(v_f);
			break;
		case 3:
			xchg_f<double>(w_f);
			break;
	}
}

void epsi1_sol (int i, int j, int k, int loop, double vel, double *epsi1) {
	//epsi1 is the output
	double *vold_f = temp_f[2];
	double xns,yns,zns,epsi;
	int ijkd,ijka;
	double *psiavnx_f = temp_f[9];
	double *psiavny_f = temp_f[10];
	double *psiavnz_f = temp_f[11];
	
	if(vel == 0.0)
		(*epsi1) = 0.0;
	else {
		switch(loop) {
			case 1:
				if(vel > 0.0) {
					ijkd = IJK_f; ijka = IJK_f+1;
					xns=-psiavnx_f[ijkd]*2.e0*rdx[1];
					yns=-psiavny_f[ijkd]*2.e0*rdy[1];
					zns=-psiavnz_f[ijkd]*2.e0*rdz[1];
				}
				else {
					ijkd = IJK_f+1; ijka = IJK_f;
					xns=psiavnx_f[ijkd]*2.e0*rdx[1];
					yns=-psiavny_f[ijkd]*2.e0*rdy[1];
					zns=psiavnz_f[ijkd]*2.e0*rdz[1];
				}
				epsi=fabs(vel)*0.25e0*dely[1]*delz[1]*delt/vold_f[ijkd];
				break;
			case 2:
				if(vel > 0.0) {
					ijkd = IJK_f; ijka = IJK_f+imax_f;
					xns=-psiavny_f[ijkd]*2.e0*rdy[1];
					yns=psiavnx_f[ijkd]*2.e0*rdx[1];
					zns=-psiavnz_f[ijkd]*2.e0*rdz[1];
				}
				else {
					ijkd = IJK_f+imax_f; ijka = IJK_f;
					xns=psiavny_f[ijkd]*2.e0*rdy[1];
					yns=-psiavnx_f[ijkd]*2.e0*rdx[1];
					zns=-psiavnz_f[ijkd]*2.e0*rdz[1];	
				}
				epsi=fabs(vel)*0.25e0*delx[1]*delz[1]*delt/vold_f[ijkd];
				break;
			case 3:
				if(vel > 0.0) {
					ijkd = IJK_f; ijka = IJK_f+ijmax_f;
					xns=-psiavnz_f[ijkd]*2.e0*rdz[1];
					yns=-psiavny_f[ijkd]*2.e0*rdy[1];
					zns=psiavnx_f[ijkd]*2.e0*rdx[1];
				}
				else {
					ijkd = IJK_f+ijmax_f; ijka = IJK_f;
					xns=psiavnz_f[ijkd]*2.e0*rdz[1];
					yns=-psiavny_f[ijkd]*2.e0*rdy[1];
					zns=-psiavnx_f[ijkd]*2.e0*rdx[1];	
				}
				epsi=fabs(vel)*0.25e0*delx[1]*dely[1]*delt/vold_f[ijkd];
				break; 
		} //end switch
		//psin_f and psi_f are same at this stage
		if(psi_f[ijkd] > em61) (*epsi1) = epsi;
		else if(psi_f[ijkd] < em6) (*epsi1) = 0.0;
		else (*epsi1) = recons_2P(xns,yns,zns,psi_f[ijkd],epsi,ijkd,ijka); 
	}
}

void scale_psi_cells(int bindx) {
	//this routine scales the the cells that contain solid cells
	//so solid mass is not lost due to non-solenoidal velocity field
	//called at the end of three subcycles
	double *vnew_f=temp_f[0],fold;
	int i_minf,j_minf,k_minf,i_maxf,j_maxf,k_maxf;
	int i,j,k;
	
	i_minf = 2*i_min[bindx]-1; i_maxf = 2*i_max[bindx];
	j_minf = 2*j_min[bindx]-1; j_maxf = 2*j_max[bindx];
	k_minf = 2*k_min[bindx]-1; k_maxf = 2*k_max[bindx];
	
	for(k=k_minf;k<=k_maxf;k++)
	 for(j=j_minf;j<=j_maxf;j++)
	   for(i=i_minf;i<=i_maxf;i++) {
		if(psi_f[IJK_f] >= em6) {
			if(psi_f[IJK_f] > em61) fold = 0.0;
			else fold = f_f[IJK_f]/(1.0-psi_f[IJK_f]+tiny); //fraction of non-solid space occupied by liquid
			
			psi_f[IJK_f] *= (vnew_f[IJK_f]/vol_f[IJK_f]);
			if(psi_f[IJK_f] > 1.0+em6) {
				fprintf(files.error,"scale_psi_cells: more than one error: psi_f = %e in cell (%d,%d,%d)\n",psi_f[IJK_f],i,j,k);
				printf("scale_psi_cells: rank=%d more than one error: psi_f = %e in cell (%d,%d,%d)\n",mpi.MyRank,psi_f[IJK_f],i,j,k);
				printf("scale_psi_cells: rank=%d more than one error: psi_f-1.0 = %e in cell (%d,%d,%d)\n",mpi.MyRank,psi_f[IJK_f]-1.0,i,j,k);
				psi_f[IJK_f] = 1.0;
			}
			fold = fold*(1.0-psi_f[IJK_f]); //volume fraction of liquid
			if(fold+psi_f[IJK_f] > em61 && fold > em6) f_f[IJK_f] = fold;
		}
	  }
}

void calc_solid_mass() {
	int i,j,k;
	double mass = 0.0; double tot_mass;
	for(k=1;k<km1_f;k++)
	 for(j=1;j<jm1_f;j++)
	  for(i=1;i<im1_f;i++) {
		  mass += vol_f[IJK_f]*psi_f[IJK_f];
	  }
	  
	dallreduce(&mass, &tot_mass, 1, OP_SUM);
	if(mpi.MyRank==1) printf("total mass at the end of advection is %e\n",tot_mass);
}

void mod_xmu() {
	//make sure that psinormals_f() is called before this function
	int i,j,k;
	
	for(i=1;i<im1;i++)
	 for(j=1;j<jm1;j++)
	  for(k=1;k<km1;k++) {
		if(psi[IJK] > em6) {
			double fvirt;
			if(psi[IJK]+f[IJK] > em61 && f[IJK] > em6) { //solid+liquid cell
				xmu[IJK]=xmuf1;
			}
			if(f[IJK] > em6 && 1.0-f[IJK]-psi[IJK] > em6) { //solid+liquid+air cell
				fvirt=0.125e0*(fvirt_f[IND_f(2*i,2*j,2*k)]+fvirt_f[IND_f(2*i-1,2*j,2*k)]+fvirt_f[IND_f(2*i-1,2*j-1,2*k)]+fvirt_f[IND_f(2*i,2*j-1,2*k)]
					+fvirt_f[IND_f(2*i,2*j,2*k-1)]+fvirt_f[IND_f(2*i-1,2*j,2*k-1)]+fvirt_f[IND_f(2*i-1,2*j-1,2*k-1)]+fvirt_f[IND_f(2*i,2*j-1,2*k-1)]);
				//xmu[IJK] = xmuf1*fvirt + xmuf2*(1.0-fvirt);
				xmu[IJK] = xmuf1*xmuf2/(fvirt*xmuf2+(1.0-fvirt)*xmuf1+tiny);//harmonic average
			}
			if(1.0-psi[IJK]-f[IJK]>em6 && f[IJK] < em6) { //solid+air cell
				xmu[IJK]=xmuf2;
			}	  
		}
	  }
	  
	//this routine can be improved to consider cases where the solid is grid aligned.
	xchg<double>(xmu);
}

void gfine2stnd(double *S, double *s);
void new_plug()
{
	int i,j,k;
	double tx,ty,txm,tym;
	k = km1_f;
	
	double r2 = (2.e-3)*(2.e-3);
	double rl = (2.e-3 - 0.2*2e-3)*(2.e-3 - 0.2*2e-3);
	
	double w_avg = -0.1015;
	
	double xcent = 67.2e-3 / 2.0; //xe/2;
	double ycent = 6.4e-3 / 2.0; // ye/2;
	
	
	for (i=1; i<im1_f; i++)
		for (j=1; j<jm1_f; j++)
		{
			
			tx = (i+2*mpi.OProc[0])*0.5e0*delx[1]; //global coordinates in fine-grid
			ty = (j+2*mpi.OProc[1])*0.5e0*dely[1];
			
			txm = tx-0.5e0*delx[1];
			tym = ty-0.5e0*dely[1];
			
			if ( MIN(SQUARE(txm-xcent), SQUARE(tx-xcent)) + MIN(SQUARE(tym-ycent), SQUARE(ty-ycent)) >= r2)
			{
				f_f[IJK_f] = f_f[IJKM_f] = 0;
			}
			else if ( MAX(SQUARE(txm-xcent), SQUARE(tx-xcent)) + MAX(SQUARE(tym-ycent), SQUARE(ty-ycent)) <= r2)
			{		
				f_f[IJK_f] = f_f[IJKM_f] = 1.0;
				scal[IJK_f] = scal[IJKM_f] = 1.0;
			}
			else
			{
				f_f[IJK_f] = f_f[IJKM_f] = 1.0;
			}
		}
	
	gfine2stnd(crse_scal,scal);
	fine2stnd();
}

void stop_new_plug()
{
        int i,j,k;
        double tx,ty,txm,tym;
        k = km1_f;

        double r2 = (2.e-3)*(2.e-3);
        double rl = (2.e-3 - 0.2*2e-3)*(2.e-3 - 0.2*2e-3);

        double w_avg = -0.1015;

        double xcent = 67.2e-3 / 2.0; //xe/2;
        double ycent = 6.4e-3 / 2.0; // ye/2;


        for (i=1; i<im1_f; i++)
                for (j=1; j<jm1_f; j++)
                {
			tx = (i+2*mpi.OProc[0])*0.5e0*delx[1]; //global coordinates in fine-grid
                        ty = (j+2*mpi.OProc[1])*0.5e0*dely[1];

                        txm = tx-0.5e0*delx[1];
                        tym = ty-0.5e0*dely[1];

                        if ( MIN(SQUARE(txm-xcent), SQUARE(tx-xcent)) + MIN(SQUARE(tym-ycent), SQUARE(ty-ycent)) >= r2)
                        {
                                f_f[IJK_f] = f_f[IJKM_f] = 0;
                        }
                        else if ( MAX(SQUARE(txm-xcent), SQUARE(tx-xcent)) + MAX(SQUARE(tym-ycent), SQUARE(ty-ycent)) <= r2)
                        {
                                f_f[IJK_f] = f_f[IJKM_f] = 0.0;
                                scal[IJK_f] = scal[IJKM_f] = 0.0;
                        }
                        else
                        {
                                f_f[IJK_f] = f_f[IJKM_f] = 0.0;
                        }
                }

        gfine2stnd(crse_scal,scal);
        fine2stnd();
}

void ytube_inflow_O_face()
{
	int i,j,k;
	double tx,ty,txm, tym;
	k = km1;
	
	double r2 = (2.e-3)*(2.e-3);
	double rl = (2.e-3 - 0.21249*2e-3)*(2.e-3 - 0.21249*2e-3);	

	double w_avg = -0.1015;
	
	double xcent = 76.8e-3 / 2.0; //xe/2;
	double ycent = 6.4e-3 / 2.0; // ye/2;
	
	for (i=1;i<im1;i++)
		for (j=1;j<jm1;j++)
		{
			tx = (i+mpi.OProc[0])*delx[1] - 0.5*delx[1]; //global coordinates in coarse-grid
			ty = (j+mpi.OProc[1])*dely[1] - 0.5*dely[1];

			txm = tx-0.5e0*delx[1];
			tym = ty-0.5e0*dely[1];
			
			if (MAX(SQUARE(txm-xcent), SQUARE(tx-xcent)) + MAX(SQUARE(tym-ycent), SQUARE(ty-ycent)) <= rl)
			{
				u[IJKM] = u[IJKM - ijmax] = 0.0;
				v[IJKM] = v[IJKM - ijmax] = 0.0;
				w[IJKM] = w[IJKM - ijmax]= 2*w_avg*(1 - ( SQUARE(tx-xcent) + SQUARE(ty-ycent) ) / r2 );
				
				f[IJK] = f[IJKM] = 0.0;
				p[IJK] = p[IJKM];
			}
			else
			{
				u[IJKM] = u[IJKM - ijmax] = 0.0;
				v[IJKM] = v[IJKM - ijmax] = 0.0;
				w[IJKM] = w[IJKM - ijmax] = 0.0;
				f[IJK]	= f[IJKM];
				p[IJK] 	= p[IJKM];
			}
		}
	
	if ( (t > 0.2163 && t < 0.2650) || (t > 0.4255 && t < 0.4743) ) // initial plug is after 10*7e-4 till a dt of 0.048750 
	{
		new_plug();
	}
	else if ( (t > 0.2650 && (t < 0.2650 + 5.0*delt)) || (t > 0.4743 && (t < 0.4743 + 5.0*delt)) )
	{
		stop_new_plug();
	}
	
	/**
	// if (t > 0.007 && plug_number == 0) // if flow is fully developed
	if (plug_number == 0)
	{
		// if (plug_i_time < 0.046875 ) // uncoment all of these comments for normal plug instillation
		if (plug_i_time < 0.046875/4.0)// this is a short plug test
		{
			plug_i_time += delt;
			
			new_plug();
			printf("Initializing a new plug\n");
		}
		// else if (plug_i_time > 0.046875 && (plug_i_time < 0.046875 + 5.0*delt))
		else if (plug_i_time > 0.046875/4.0 && (plug_i_time < 0.046875/4.0 + 5.0*delt))
		{
			stop_new_plug();
			plug_i_time = 0.0;
			plug_number = 1;
		}
	}
	else if (plug_number > 0)
	{
		// if (plug_frequency < 0.011719) // if plug freq < distance-between-plugs divided by velocity
		if (plug_frequency < 0.046875/8.0)
		{
			plug_frequency += delt;
		}
		//else if (plug_i_time < 0.046875 )
		else if (plug_i_time < 0.046875/8.0)
		{
			plug_i_time += delt;
			
			new_plug();
			printf("Initializing a new plug\n");
		}
		else
		{
			stop_new_plug();
			plug_i_time = 0.0;
			plug_frequency = 0.0;
			plug_number += 1;
		}
	}**/
}

void ytube_outflow_bc()
{
	int i,j,k;
	
	double tz;
	
	for (i=1; i<im1; ++i)
		for (j=1; j<jm1; ++j)
			for (k=1; k<km1; ++k)
			{
				tz = (k+2*mpi.OProc[2])*0.5*delz[1];
				if (tz < 1.5e-3 && scal[IJK_f] > em6)
				{
					f_f[IJK_f] -= scal[IJK_f];
				}
			}
	
}

//void init_ytube(st_point *dimen1, st_point *dimen11, double *rad1_o, double *rad1_i, double *height1, st_point *dimen2, st_point *dimen22, double *rad2_o, double *rad2_i, double *height2, st_point *theta2, st_point *dimen3, st_point *dimen33, double *rad3_o, double *rad3_i, double *height3, st_point *theta3)
double distance_line_to_point(st_point *vec_c, st_point *vec_a, st_point *vec_b);
void init_ytube(st_point *dimen1, st_point *theta1, double *rad1_o, double *rad1_i, double *height1, st_point *dimen2, st_point *theta2, double *rad2_o, double *rad2_i, double *height2, st_point *dimen3, double *rad3_o, double *rad3_i, double *height3)
{
	int i,j,k;
	double tx, ty, tz, txm, tym, tzm, p_vol, f_vol;
	st_point X0, X00, X1, X11;

	//First Cylinder 
	double theta1x=theta1->x;
	double theta1y=theta1->y;
	double theta1z=theta1->z;
	
	double x1=dimen1->x; //Bottom Dimensions
	double y1=dimen1->y;
	double z1=dimen1->z;
	
	double x11=x1 + ((*height1)*cos(theta1x)); //Top Dimensions
	double y11=y1 + ((*height1)*cos(theta1y));
	double z11=z1 + ((*height1)*cos(theta1z));
	
	double r1_o = (*rad1_o), r1_i = (*rad1_i);
	
	//Second Cylinder
	double theta2x=theta2->x;
	double theta2y=theta2->y;
	double theta2z=theta2->z;
	
	double x2=dimen2->x; //Bottom Dimensions
	double y2=dimen2->y;
	double z2=dimen2->z;
	
	double x22=x2 + ((*height2)*cos(theta2x)); //Top Dimensions
	double y22=y2 + ((*height2)*cos(theta2y));
	double z22=z2 + ((*height2)*cos(theta2z));
	
	double r2_o = (*rad2_o), r2_i = (*rad2_i);
	
	//Third Cylinder
	double x3=dimen3->x; //Bottom Dimensions
	double y3=dimen3->y;
	double z3=dimen3->z; // Need to Change this because the z3 passed in is not correct
	
	double x33=x3; //Top Dimensions
	double y33=y3;
	double z33=z3 + (*height3); 
	
	double r3_o = (*rad3_o), r3_i = (*rad3_i);
	
	double dist[8]; //distance from vertex point of cell to center line
	int cnt1; //counter for number of vertexes outside of the cylinder
	int cnt2; //counter for number of vertexes inside the hollow part
	int cnt3;
	
	double radius_waterfilm; // for a two fine cell thick water film coating the solid
	radius_waterfilm = r3_i - film_thickness; // = 0.36*(1 - exp(-2*Ca^0.523)) * radius
	
	// Storing the F field of the plug so it is not over written with the following code:
	memcpy(plug_f, f_f, NX_f*NY_f*NZ_f*sizeof(double));
	
	memset(f, 0, NX*NY*NZ*sizeof(double));
	memset(f_f, 0, NX_f*NY_f*NZ_f*sizeof(double));
	
	//Box for third cylinder
	
	double right_face;
	double left_face;
	double over_face;
	double under_face;
	
	double P, opp;
	
	right_face = x1 + ((*height1)*cos(theta1x)) + (r1_i*cos(theta1z));
	x_carina = right_face; // global
	
	left_face = x1 - (r1_i/cos(theta1z));
	
	P = (right_face - left_face)*tan(theta1x) + z1;  // Must account for height above the boundary.
	opp = r3_i*tan(theta1x);
	
	z3 = P - opp; // Recalculation
	z_bifurcation = z3; // global
	
	z_upper_bound = z3 + (*height3); //global, needed for y boundary condition
	z_upper_bound = ze;	

//	over_face = floor(2*((z3 + (*height3) + (delx[1]/20))/delx[1]));
	over_face = floor(2*((ze + (delx[1]/20))/delx[1]));
	under_face = floor(2*((z3 + (delx[1]/20))/delx[1]));
	
	int o_f = ((int)over_face) +1;
	int u_f = ((int)under_face) +1;
	
	// Need to Check if the box is correct or if it should be the mpi boundary
	if( o_f > (km1_f+2*mpi.OProc[2]) ) 
	{
		o_f = km1_f;
	}
	else 
	{
		o_f -= 2*mpi.OProc[2];
	}
	
	if( u_f < (1+2*mpi.OProc[2]) ) 
	{
		u_f = 1;
	}
	else
	{
		u_f -= 2*mpi.OProc[2];
	}
	
	//Third Cylinder
	for(int i=1; i<im1_f; i++)
		for(int j=1; j<jm1_f; j++)
			for(int k=u_f; k<o_f; k++)
			{
				tx = (i+2*mpi.OProc[0]) * (0.5*delx[1]);
				ty = (j+2*mpi.OProc[1]) * (0.5*dely[1]);
				tz = (k+2*mpi.OProc[2]) * (0.5*delz[1]);
				txm = tx - (0.5*delx[1]);
				tym = ty - (0.5*dely[1]);
				tzm = tz - (0.5*delz[1]);
				
				X1.x = x3;
				X1.y = y3;
				X1.z = z3;
				X11.x = x33;
				X11.y = y33;
				X11.z = z33;
				
				X0.x = txm;
				X0.y = tym;
				X0.z = tzm;
				dist[0] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = txm;
				X0.y = ty;
				X0.z = tzm;
				dist[1] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = txm;
				X0.y = tym;
				X0.z = tz;
				dist[2] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = txm;
				X0.y = ty;
				X0.z = tz;
				dist[3] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = tx;
				X0.y = ty;
				X0.z = tzm;
				dist[4] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = tx;
				X0.y = tym;
				X0.z = tzm;
				dist[5] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = tx;
				X0.y = tym;
				X0.z = tz;
				dist[6] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = tx;
				X0.y = ty;
				X0.z = tz;
				dist[7] = distance_line_to_point(&X0, &X1, &X11);
				
				cnt1=0; //outside of cylinder
				cnt2=0; //inside of hollow part
				cnt3=0;
				
				for(int qq=0;qq<8;qq++)
				{
					if(dist[qq]>r3_i) cnt1++;
					if(dist[qq]>radius_waterfilm) cnt2++;
				}
					if(cnt2==8) f_vol=0.0;
					else if(cnt2==0) f_vol=1.0;
					else
					{	f_vol=0.0;
						for(int l=0;l<25;l++)
							for(int m=0;m<25;m++)
								for(int n=0;n<25;n++)
								{	X00.x=txm+(l+0.5)/25.0*delx[1]*0.5e0;
									X00.y=tym+(m+0.5)/25.0*dely[1]*0.5e0;
									X00.z=tzm+(n+0.5)/25.0*delz[1]*0.5e0;
									if( (distance_line_to_point(&X00, &X1, &X11))<radius_waterfilm) f_vol+=6.4e-5;
								}
					}
					f_f[IJK_f] += f_vol;	
					if(cnt1==8) p_vol=0.0;
					else if(cnt1==0) p_vol=1.0;
					else
					{	p_vol=0.0;
						for(int l=0;l<25;l++)
							for(int m=0;m<25;m++)
								for(int n=0;n<25;n++)
								{	X00.x=txm+(l+0.5)/25.0*delx[1]*0.5e0;
									X00.y=tym+(m+0.5)/25.0*dely[1]*0.5e0;
									X00.z=tzm+(n+0.5)/25.0*delz[1]*0.5e0;
									if( (distance_line_to_point(&X00, &X1, &X11))<r3_i) p_vol+=6.4e-5;
								}		
					}	
				psi_f[IJK_f] += p_vol;
			}
	
	//Box For the first cylinder
	
	double top_face;
	double bottom_face;
	
	right_face = floor(2*((x1 + ((*height1)*cos(theta1x)) + (r1_i*cos(theta1z)) + (delx[1]/20))/delx[1]));
	left_face = floor(2*((x1 - (r1_i/cos(theta1z)) + (delx[1]/20))/delx[1]));
	over_face = (right_face - left_face)*tan(theta1x) + 2*z3/delx[1];
	under_face = floor(2*((z1 - (r1_i*sin(theta1z)) + (delx[1]/20))/delx[1]));
	top_face = floor(2*((y1 + r1_i + (delx[1]/20))/delx[1]));
	bottom_face = floor(2*((y1 - r1_i + (delx[1]/20))/delx[1]));
	
	o_f = ((int)over_face) +1;
	u_f = ((int)under_face) +1;
	int r_f = ((int)right_face) +1;
	int l_f = ((int)left_face) +1;
	int t_f = ((int)top_face) +1;
	int b_f = ((int)bottom_face) +1;
	
	// Need to Check if the box is correct or if it should be the mpi boundary and make coordinates local not global
	if( o_f > (km1_f+2*mpi.OProc[2]) ) 
	{
		o_f = km1_f;
	}
	else 
	{
		o_f -= 2*mpi.OProc[2];
	}
	
	if( u_f < (1+2*mpi.OProc[2]) ) 
	{
		u_f = 1;
	}
	else
	{
		u_f -= 2*mpi.OProc[2];
	}
	// Need to now do the right and left faces
	if( r_f > (im1_f+2*mpi.OProc[0]) ) 
	{
		r_f = im1_f;
	}
	else 
	{
		r_f -= 2*mpi.OProc[0];
	}
	
	if( l_f < (1+2*mpi.OProc[0]) ) 
	{
		l_f = 1;
	}
	else
	{
		l_f -= 2*mpi.OProc[0];
	}
	
	radius_waterfilm = r1_i - film_thickness;
	
	//First Cylinder
	for(int i=1; i<r_f; i++)                               
		for(int j=1; j<jm1_f; j++)
			for(int k=1; k<o_f; k++)
			{
				tx = (i+2*mpi.OProc[0]) * (0.5*delx[1]);
				ty = (j+2*mpi.OProc[1]) * (0.5*dely[1]);
				tz = (k+2*mpi.OProc[2]) * (0.5*delz[1]);
				txm = tx - (0.5*delx[1]);
				tym = ty - (0.5*dely[1]);
				tzm = tz - (0.5*delz[1]);
				
				X1.x = x1;
				X1.y = y1;
				X1.z = z1;
				
				X11.x = x11;
				X11.y = y11;
				X11.z = z11;
				
				X0.x = txm;
				X0.y = tym;
				X0.z = tzm;
				
				dist[0] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = txm;
				X0.y = ty;
				X0.z = tzm;
				dist[1] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = txm;
				X0.y = tym;
				X0.z = tz;
				dist[2] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = txm;
				X0.y = ty;
				X0.z = tz;
				dist[3] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = tx;
				X0.y = ty;
				X0.z = tzm;
				dist[4] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = tx;
				X0.y = tym;
				X0.z = tzm;
				dist[5] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = tx;
				X0.y = tym;
				X0.z = tz;
				dist[6] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = tx;
				X0.y = ty;
				X0.z = tz;
				dist[7] = distance_line_to_point(&X0, &X1, &X11);
				
				cnt1=0; //outside of cylinder
				cnt2=0; //inside of hollow part
				
				for(int qq=0;qq<8;qq++)
				{	
					if(dist[qq]>r1_i) cnt1++;
					if(dist[qq]>radius_waterfilm) cnt2++;
				}
				if(cnt2==8) f_vol=0.0;
				else if(cnt2==0) f_vol=1.0;
				else
				{	f_vol=0.0;
					for(int l=0;l<25;l++)
					{	for(int m=0;m<25;m++)
						{	for(int n=0;n<25;n++)
							{	X00.x=txm+(l+0.5)/25.0*delx[1]*0.5e0;
								X00.y=tym+(m+0.5)/25.0*dely[1]*0.5e0;
								X00.z=tzm+(n+0.5)/25.0*delz[1]*0.5e0;
								if( (distance_line_to_point(&X00, &X1, &X11))<radius_waterfilm) f_vol+=6.4e-5;
							}
						}	
					}	
				}
				f_f[IJK_f] += f_vol;	
				if(cnt1==8) p_vol=0.0;
				else if (cnt1==0) p_vol=1.0;
				else
				{	p_vol=0.0;
					for(int l=0;l<25;l++)
					{	for(int m=0;m<25;m++)
						{	for(int n=0;n<25;n++)
							{	X00.x=txm+(l+0.5)/25.0*delx[1]*0.5e0;
								X00.y=tym+(m+0.5)/25.0*dely[1]*0.5e0;
								X00.z=tzm+(n+0.5)/25.0*delz[1]*0.5e0;
								if( (distance_line_to_point(&X00, &X1, &X11))<r1_i) p_vol+=6.4e-5;
							}
						}	
					}
				}	
				psi_f[IJK_f] += p_vol;
			}

	//Box for the Second Cylinder
	
	right_face = floor(2*((x1 + 2*(((*height1)*cos(theta1x)) + (r1_i*cos(theta1z))) + (r1_i/sin(theta1x)) + (delx[1]/20))/delx[1]));
	left_face = floor(2*((x1 + ((*height1)*cos(theta1x)) + (r1_i*cos(theta1z)) + (delx[1]/20))/delx[1]));
	over_face = (right_face - left_face)*tan(theta1x) + 2*z3/delx[1];
	under_face = floor(2*((z1 - (r1_i*sin(theta1z)) + (delx[1]/20))/delx[1]));
	top_face = floor(2*((y1 + r1_i + (delx[1]/20))/delx[1]));
	bottom_face = floor(2*((y1 - r1_i + (delx[1]/20))/delx[1]));
	
	r_f = ((int)right_face) +1;
	o_f = ((int)over_face) +1;
	u_f = ((int)under_face) +1;
	l_f = ((int)left_face) +1;
	t_f = ((int)top_face) +1;
	b_f = ((int)bottom_face) +1;
	
	// Need to Check if the box is correct or if it should be the mpi boundary
	if( o_f > (km1_f+2*mpi.OProc[2]) ) 
	{
		o_f = km1_f;
	}
	else 
	{
		o_f -= 2*mpi.OProc[2];
	}
	
	if( u_f < (1+2*mpi.OProc[2]) ) 
	{
		u_f = 1;
	}
	else
	{
		u_f -= 2*mpi.OProc[2];
	}
	// Need to now do the right and left faces
	if( r_f > (im1_f+2*mpi.OProc[0]) ) 
	{
		r_f = im1_f;
	}
	else 
	{
		r_f -= 2*mpi.OProc[0];
	}
	
	if( l_f < (1+2*mpi.OProc[0]) ) 
	{
		l_f = 1;
	}
	else
	{
		l_f -= 2*mpi.OProc[0];
	}
	
	//Second Cylinder
	for(int i=l_f; i<im1_f;i++)                                 
	{	for(int j=1; j<jm1_f;j++)
		{	for(int k=1; k<o_f;k++)
			{	
				
				tx = (i+2*mpi.OProc[0]) * (0.5*delx[1]);
				ty = (j+2*mpi.OProc[1]) * (0.5*dely[1]);
				tz = (k+2*mpi.OProc[2]) * (0.5*delz[1]);
				txm = tx - (0.5*delx[1]);
				tym = ty - (0.5*dely[1]);
				tzm = tz - (0.5*delz[1]);
				
				X1.x = x2;
				X1.y = y2;
				X1.z = z2;
				X11.x = x22;
				X11.y = y22;
				X11.z = z22;
				
				X0.x = txm;
				X0.y = tym;
				X0.z = tzm;
				dist[0] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = txm;
				X0.y = ty;
				X0.z = tzm;
				dist[1] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = txm;
				X0.y = tym;
				X0.z = tz;
				dist[2] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = txm;
				X0.y = ty;
				X0.z = tz;
				dist[3] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = tx;
				X0.y = ty;
				X0.z = tzm;
				dist[4] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = tx;
				X0.y = tym;
				X0.z = tzm;
				dist[5] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = tx;
				X0.y = tym;
				X0.z = tz;
				dist[6] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = tx;
				X0.y = ty;
				X0.z = tz;
				dist[7] = distance_line_to_point(&X0, &X1, &X11);
				
				cnt1=0; //outside of cylinder
				cnt2=0; //inside of hollow part
				
				for(int qq=0;qq<8;qq++)
				{	
					if(dist[qq]>r2_i) cnt1++;
					if(dist[qq]>radius_waterfilm) cnt2++;
				}
				if(cnt2==8) f_vol=0.0;
				else if(cnt2==0) f_vol=1.0;
				else
				{	f_vol=0.0;
					for(int l=0;l<25;l++)
					{	for(int m=0;m<25;m++)
						{	for(int n=0;n<25;n++)
							{	X00.x=txm+(l+0.5)/25.0*delx[1]*0.5e0;
								X00.y=tym+(m+0.5)/25.0*dely[1]*0.5e0;
								X00.z=tzm+(n+0.5)/25.0*delz[1]*0.5e0;
								if( (distance_line_to_point(&X00, &X1, &X11))<radius_waterfilm) f_vol+=6.4e-5;
							}
						}	
					}	
				}
				f_f[IJK_f] += f_vol;	
				if(cnt1==8) p_vol=0.0;
				else if(cnt1==0) p_vol=1.0;
				else
				{	p_vol=0.0;
					for(int l=0;l<25;l++)
					{	for(int m=0;m<25;m++)
						{	for(int n=0;n<25;n++)
							{	X00.x=txm+(l+0.5)/25.0*delx[1]*0.5e0;
								X00.y=tym+(m+0.5)/25.0*dely[1]*0.5e0;
								X00.z=tzm+(n+0.5)/25.0*delz[1]*0.5e0;
								if( (distance_line_to_point(&X00, &X1, &X11))<r2_i) p_vol+=6.4e-5;
							}
						}	
					}
				}		
				psi_f[IJK_f] += p_vol;
			}
		}
	}
	
	// Trying to Remove the liquid lip which has formed

	over_face = floor(2*((z3 + (*height3) + (delx[1]/20))/delx[1]));
	under_face = floor(2*((z3 + (delx[1]/20))/delx[1]));
	
	o_f = ((int)over_face) +1;
	u_f = ((int)under_face) +1;
	
	// Now I need to begin Tapering the top cylinder.

	over_face = floor(2*((z3 + (delx[1]/20))/delx[1]));
//	under_face = floor(2*((z1 + ((*height1)*sin(theta1x)) - (r1_i*sin(theta1z)) + (delx[1]/20))/delx[1]));
	under_face = floor(2*(z3 - 1.4e-3 + (delx[1]/20))/delx[1]);
	
	// How many cells do we have to work with for the tapering between these two faces?
	
	double available_tcells; // # of avaiable tapering cells
	double radius_differnce;
	double tn_cells; // total number of needed cells
	
	double tapering_gradient;
	
	double new_radius = r3_i;
	double inside_radius = r1_i - 0.5e-3;
	
	available_tcells = over_face - under_face;
	radius_differnce = r3_i - inside_radius; // Extra difference is needed hence the 0.5e-3
	
	tn_cells = (2*radius_differnce)/delx[1];
	
	tapering_gradient = (tn_cells / available_tcells)*0.5*delx[1];
	
	o_f = ((int)over_face) + 1;
	u_f = over_face - 1;
	
	// Need to Check if the box is correct or if it should be the mpi boundary
	if( o_f > (km1_f+2*mpi.OProc[2]) )
	{
		o_f = km1_f;
	}
	else 
	{
		o_f -= 2*mpi.OProc[2];
	}
	
	if( u_f < (1+2*mpi.OProc[2]) )
	{
		u_f = 1;
	}
	else
	{
		u_f -= 2*mpi.OProc[2];
	}

	// Tapering Cylinder
	while(new_radius > inside_radius) {
		
		new_radius -= tapering_gradient;
		radius_waterfilm = new_radius - 0.925*film_thickness;
	//	radius_waterfilm -= tapering_gradient;
		
	for(int i=1; i<im1_f; i++)
		for(int j=1; j<jm1_f; j++)
			for(int k=u_f; k<o_f; k++)
			{
				tx = (i+2*mpi.OProc[0]) * (0.5*delx[1]);
				ty = (j+2*mpi.OProc[1]) * (0.5*dely[1]);
				tz = (k+2*mpi.OProc[2]) * (0.5*delz[1]);
				txm = tx - (0.5*delx[1]);
				tym = ty - (0.5*dely[1]);
				tzm = tz - (0.5*delz[1]);
				
				X1.x = x3;
				X1.y = y3;
				X1.z = z3;
				X11.x = x33;
				X11.y = y33;
				X11.z = z33;
				
				X0.x = txm;
				X0.y = tym;
				X0.z = tzm;
				dist[0] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = txm;
				X0.y = ty;
				X0.z = tzm;
				dist[1] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = txm;
				X0.y = tym;
				X0.z = tz;
				dist[2] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = txm;
				X0.y = ty;
				X0.z = tz;
				dist[3] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = tx;
				X0.y = ty;
				X0.z = tzm;
				dist[4] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = tx;
				X0.y = tym;
				X0.z = tzm;
				dist[5] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = tx;
				X0.y = tym;
				X0.z = tz;
				dist[6] = distance_line_to_point(&X0, &X1, &X11);
				X0.x = tx;
				X0.y = ty;
				X0.z = tz;
				dist[7] = distance_line_to_point(&X0, &X1, &X11);
				
				cnt1=0; //outside of cylinder
				cnt2=0; //inside of hollow part
				cnt3=0;
				
				for(int qq=0;qq<8;qq++)
				{
					if(dist[qq]>new_radius) cnt1++;
					if(dist[qq]>radius_waterfilm) cnt2++;
				}
					if(cnt2==8) f_vol=0.0;
					else if(cnt2==0) f_vol=1.0;
					else
					{	f_vol=0.0;
						for(int l=0;l<25;l++)
							for(int m=0;m<25;m++)
								for(int n=0;n<25;n++)
								{	X00.x=txm+(l+0.5)/25.0*delx[1]*0.5e0;
									X00.y=tym+(m+0.5)/25.0*dely[1]*0.5e0;
									X00.z=tzm+(n+0.5)/25.0*delz[1]*0.5e0;
									if( (distance_line_to_point(&X00, &X1, &X11))<radius_waterfilm) f_vol+=6.4e-5;
								}
					}
					f_f[IJK_f] += f_vol;	
					if(cnt1==8) p_vol=0.0;
					else if(cnt1==0) p_vol=1.0;
					else
					{	p_vol=0.0;
						for(int l=0;l<25;l++)
							for(int m=0;m<25;m++)
								for(int n=0;n<25;n++)
								{	X00.x=txm+(l+0.5)/25.0*delx[1]*0.5e0;
									X00.y=tym+(m+0.5)/25.0*dely[1]*0.5e0;
									X00.z=tzm+(n+0.5)/25.0*delz[1]*0.5e0;
									if( (distance_line_to_point(&X00, &X1, &X11))<new_radius) p_vol+=6.4e-5;
								}		
					}	
				psi_f[IJK_f] += p_vol;
			}
			
			o_f -= 1;
			u_f -= 1;
			
		}
	
	right_face = floor(2*((x1 + 2*(((*height1)*cos(theta1x)) + (r1_i*cos(theta1z))) + (r1_i/sin(theta1x)) + (delx[1]/20))/delx[1]));
	left_face = floor(2*((x1 - (r1_i/cos(theta1z)) + (delx[1]/20))/delx[1]));
	over_face = floor(2*((z3 + (*height3) + (delx[1]/20))/delx[1]));
	under_face = floor(2*((z1 - (r1_i*sin(theta1z)) + (delx[1]/20))/delx[1]));
	top_face = floor(2*(( (ye / 2) + r3_i + 1e-3 + (dely[1]/20))/dely[1]));
	//bottom_face = floor(2*(( (ye /2) - r3_i - 1e-3 + (dely[1]/20))/dely[1])); // not as symmetric as one below
	bottom_face = floor(2*(( 2.975e-3 + (dely[1]/20))/dely[1]));
	
	r_f = ((int)right_face) +1;
	o_f = ((int)over_face) +1;
	u_f = ((int)under_face) +1;
	l_f = ((int)left_face) +1;
	t_f = ((int)top_face) +1;
	b_f = ((int)bottom_face) +1;
	
	// Need to Check if the box is correct or if it should be the mpi boundary
	if( o_f > (km1_f+2*mpi.OProc[2]) ) 
	{
		o_f = km1_f;
	}
	else 
	{
		o_f -= 2*mpi.OProc[2];
	}
	
	if( u_f < (1+2*mpi.OProc[2]) ) 
	{
		u_f = 1;
	}
	else
	{
		u_f -= 2*mpi.OProc[2];
	}
	
	// Need to now do the right and left faces
	if( r_f > (im1_f+2*mpi.OProc[0]) ) 
	{
		r_f = im1_f;
	}
	else 
	{
		r_f -= 2*mpi.OProc[0];
	}
	
	if( l_f < (1+2*mpi.OProc[0]) ) 
	{
		l_f = 1;
	}
	else
	{
		l_f -= 2*mpi.OProc[0];
	}
	// Need to now do the top and bottom faces
	if( t_f > (jm1_f+2*mpi.OProc[1]) ) 
	{
		t_f = jm1_f;
	}
	else 
	{
		t_f -= 2*mpi.OProc[1] + 2;
	}
	
	if( b_f < (1+2*mpi.OProc[1]) ) 
	{
		b_f = 1;
	}
	else
	{
		b_f -= 2*mpi.OProc[1] + 2;
	}
	
	for(int i=1;i<im1_f;i++)
		for(int j=1;j<jm1_f;j++)
			for(int k=1;k<km1_f;k++)
			{
				if(psi_f[IJK_f] > em61) psi_f[IJK_f] = 1.0;
			}
	
	for(int i=1;i<im1_f;i++)
		for(int j=1;j<jm1_f;j++)
			for(int k=1;k<km1_f;k++)
			{
				psi_f[IJK_f] = 1 - psi_f[IJK_f];
			}
	
	for(int i=1;i<im1_f;i++)
		for(int j=1;j<jm1_f;j++)
			for(int k=1;k<km1_f;k++)		
			{
				if(FN_f[IJK_f] + f_f[IJK_f] > em61)
				{
					f_f[IJK_f] = 1;
				}
				else
				{
					f_f[IJK_f] += FN_f[IJK_f];
				}
			}
	
	for(int i=l_f; i<r_f; i++)
		for(int j=1; j<jm1_f; j++)
			for(int k=1; k<km1_f; k++)
			{
				f_f[IJK_f] = (1-f_f[IJK_f]);
			}
	
	for(int i=1; i<im1_f; i++)
		for(int j=1; j<jm1_f; j++)
			for(int k=1; k<km1_f; k++)
			{
				f_f[IJK_f] += plug_f[IJK_f];
			}

	fine2stnd();
}

void init_sol_cyl_angle ();
void init_cutting_plane(st_point *pcent, double phi0);

void init_sol_weight_quater(st_point *cent, double R);

void setup_rigid_body() {
	//this routine intializes and sets-up bounds for multiple solid objects 
	//... with prescribed/non-prescribed velocities
	
	int i,j,k,ii,indx; st_point cent[3], nor[3], lcent[3], pnor,pcent,pvec_a,dimen;
	st_polyhedron cube_poly, tmp_poly, new_poly;
	
	double len,wid,hei,rad,p_vol;
	double *psirho_f = temp_f[1];
	double *psiavnx_f = temp_f[9];
	double *psiavny_f = temp_f[10];
	double *psiavnz_f = temp_f[11];
	
	//rigid body #1 --Sphere
	indx = 1;
	
	//initialize_ytube();
	
	cent[0].x = 0.0;
	cent[0].y = 0.0;
	cent[0].z = 11.0e-3; //18.96e-2;

	rad = 2.0e-3;

	init_sol_weight_quater(cent, rad);
	
	/**
	st_point dimen1[3], dimen2[3], dimen3[3];
    st_point theta1[3], theta2[3], theta3[3];
	double rad1_o, rad1_i, rad2_o, rad2_i, rad3_o, rad3_i; // _o currently means nothing
	double height1, height2, height3;
	**/
	
	/** Old initialization
	film_thickness = 0.44e-3;
	tube_angle = 60*pi/180;

	//Third Cylinder
	dimen3[indx].x=xe/2, dimen3[indx].y=ye/2, dimen3[indx].z=  15.3e-3; // this z dimension is wrong and is recalculated later
	rad3_o=2.0e-3, rad3_i=2.0e-3;
	parent_radius = rad3_i;
	height3= (15.0e-3); //22.e-3;  //(rad3_i * 5 * 2);
	
	//First Cylinder
	theta1[indx].x=60*pi/180, theta1[indx].y=90*pi/180, theta1[indx].z=30*pi/180;
	rad1_o=1.9e-3, rad1_i=1.6e-3;
	height1= 15.6e-3; //(rad1_i * 3 * 2); Same length as the plug
	dimen1[indx].x=dimen3[indx].x - (height1*cos(theta1[indx].x)) - (rad1_i*cos(theta1[indx].z)), dimen1[indx].y=ye/2, dimen1[indx].z=0.0e-3;
	
	//Second Cylinder
	dimen2[indx].x=dimen1[indx].x + 2*((height1*cos(theta1[indx].x)) + (rad1_i*cos(theta1[indx].z))), dimen2[indx].y=ye/2, dimen2[indx].z=dimen1[indx].z;
	theta2[indx].x=120*pi/180, theta2[indx].y=90*pi/180, theta2[indx].z=30*pi/180;   
	rad2_o=1.9e-3, rad2_i=1.6e-3;
	height2= 15.6e-3; //(rad2_i * 3 * 2); Same length as the plug
	
	//init_ytube(&dimen1[indx], &theta1[indx], &rad1_o, &rad1_i, &height1, &dimen2[indx], &theta2[indx], &rad2_o, &rad2_i, &height2, &dimen3[indx], &rad3_o, &rad3_i, &height3);
	**/
	
	
	for(i=0;i<=im1_f;i++)
	 for(j=0;j<=jm1_f;j++) 
	  for(k=0;k<=km1_f;k++) 
	  {
		 psirho_f[IJK_f]=rhof0*psi_f[IJK_f]+1.0*(1.0-psi_f[IJK_f]); 
	  }
	normalspsi_f();
	
	// Now Cut Both Planes
	//cent[0].x = xe/2; cent[0].y = ye/2.0; cent[0].z = 0.9e-3;

//	init_cutting_plane (&cent[0], (180*pi/180) - (90*pi/180) - theta1[indx].x);

	for(i=1;i<im1_f;i++)
	 for(j=1;j<=jm1_f;j++)
	  for(k=1;k<=km1_f;k++) 
	  {		
		if(psi_f[IJK_f] < 0) psi_f[IJK_f] = 0.0;
		if(f_f[IJK_f] < 0) f_f[IJK_f] = 0.0;
	  }

	/**
	// Now Cut Plane 2
	cent[0].x = dimen1[indx].x; cent[0].y = ye/2.0; cent[0].z = dimen1[indx].z;
	nor[0].x = -0.5; nor[0].y = 0.0; nor[0].z = -0.866025;
	
	for(i=1;i<im1_f;i++)
	 for(j=1;j<=jm1_f;j++)
	  for(k=1;k<=km1_f;k++) 
	  {
		p_vol=0.0;
	
		cube_plane_int(&p_vol, &nor[0], &cent[0], i, j, k, 0);
		
		psi_f[IJK_f] -= p_vol;
		f_f[IJK_f] -= p_vol;
		
		if(psi_f[IJK_f] < 0) psi_f[IJK_f] = 0.0;
		if(f_f[IJK_f] < 0) f_f[IJK_f] = 0.0;
	  }
	 **/ 
	/**
	//Theta[indx].x=0.0, Theta[indx].y=0.0, Theta[indx].z=0.0;
	//Cent[indx].x = 1.8e-3, Cent[indx].y = 2.6e-3, Cent[indx].z = 2.6e-3;
	//rad = 1.e-3;
	//initpsi_f(&Cent[indx], &rad);
	//rigid body #1
	//indx=1; wid=0.16; hei=2.8;
	//pcent.x = 1.0, pcent.y = ye/2.0, pcent.z = hei/2.0;
	//dimen.x=wid, dimen.y=ye, dimen.z=hei;
	//init_sol_cube(&pcent,&dimen);
	
	//rigid body #2
	//indx=2;
	//cent[0].x = 5.5, cent[0].y = ye/2.0, cent[0].z = 2.2352;   
	//rad = 0.1524;
	//init_sol_cyl(&cent[0],&rad);
	
	//cent[0].x = 5.5, cent[0].y = 1.0668, cent[0].z = ze/2.0;
	//rad = 0.0762; 
	//init_sol_cyl2(&cent[0],&rad);
	
	//first plane
	//wid = 0.08255; 
	cent[0].x = 11.786e-3; cent[0].y = ye/2.0; cent[0].z = ze/2.0;
	cent[0].x/=(0.5*delx[1]); cent[0].y/=(0.5*dely[1]); cent[0].z/=(0.5*delz[1]);
	nor[0].x = 1.0; nor[0].y = 0.0; nor[0].z = 0.0;
	
	cent[1].x = 5.5 + wid/2.0; cent[1].y = ye/2.0; cent[1].z = ze/2.0;
	cent[1].x/=(0.5*delx[1]); cent[1].y/=(0.5*dely[1]); cent[1].z/=(0.5*delz[1]);
	nor[1].x = -1.0; nor[1].y = 0.0; nor[1].z = 0.0;
	
	for(i=0;i<=im1_f;i++)
	 for(j=0;j<=jm1_f;j++) 
	  for(k=0;k<=km1_f;k++) {
		 psirho_f[IJK_f]=rhof0*psi_f[IJK_f]+1.0*(1.0-psi_f[IJK_f]); 
	  }
	normalspsi_f(); //calculate the normals of the cylindrical part
	const_sim_polyhedron(&cube_poly);
	for(i=1;i<im1_f;i++)
	 for(j=1;j<=jm1_f;j++)
	  for(k=1;k<=km1_f;k++) {
		  if(j+2*mpi.OProc[1]>133 || k+2*mpi.OProc[2]<26 || k+2*mpi.OProc[2]>279) continue;
		  p_vol=0.0;
		  if(psi_f[IJK_f] <= em61) {
			for(ii=0;ii<2;ii++) {
				lcent[ii].x=cent[ii].x-(i+2*mpi.OProc[0]-1);
				lcent[ii].y=cent[ii].y-(j+2*mpi.OProc[1]-1);
				lcent[ii].z=cent[ii].z-(k+2*mpi.OProc[2]-1);
			}
			  
			if(psi_f[IJK_f] < em6) {	
				const_com_polyhedron(&cube_poly,&tmp_poly,&lcent[0],&nor[0],1);
				const_com_polyhedron(&tmp_poly,&new_poly,&lcent[1],&nor[1],0);
				p_vol=calc_poly_vol(&new_poly);
				//printf("entered here: rank=%d, p_vol=%e\n",mpi.MyRank,p_vol);
			}
			
			if(psi_f[IJK_f] >= em6) {
				pnor.x=-psiavnx_f[IJK_f], pnor.y=-psiavny_f[IJK_f], pnor.z=-psiavnz_f[IJK_f];
				make_unity(&pnor);
				area_2(1.0-psi_f[IJK_f],i,j,k,IJK_f,&pnor,&pcent,&pvec_a); //pcent output
				const_com_polyhedron(&cube_poly,&tmp_poly,&pcent,&pnor,1);
				const_com_polyhedron(&tmp_poly,&new_poly,&lcent[0],&nor[0],1);
				const_com_polyhedron(&new_poly,&tmp_poly,&lcent[1],&nor[1],0);
				p_vol=calc_poly_vol(&tmp_poly);
		    }
		    psi_f[IJK_f] -= p_vol;
		    if(psi_f[IJK_f] < 0) psi_f[IJK_f] = 0.0;
//
		  }

	} //for (i,j,k)
	* 	
//	if(1+2*mpi.OProc[2]<=26 && km2_f+2*mpi.OProc[2]>=26 && 1+2*mpi.OProc[0]<=687 && im2_f+2*mpi.OProc[0]>=687) {
//	k=26-2*mpi.OProc[2];
//	for(i=1;i<=im1_f;i++)
//	 for(j=1;j<=jm1_f;j++) {
//		 psi_f[IJK_f] = 0.6*psi_f[IJK_f];
// }
* **/
}

void init_cutting_plane(st_point *pcent, double phi0)
{
	double H,L;
	st_point pt[4],ct[4]; st_point cent;
	st_point nor[4];
	st_polyhedron cube_poly, cube_poly2, tmp_poly1, tmp_poly2, tmp_poly3, tmp_poly4;
	int i,j,k,ii;
	
	equate_pt(&cent,pcent);
	
	//if(mpi.MyRank==0) printf("sin = %e cos = %e \n",sin(phi0),cos(phi0));
	pt[0].x = cent.x, pt[0].y = 0.0, pt[0].z = cent.z;
	nor[0].x = sin(phi0), nor[0].y = 0.0, nor[0].z = -cos(phi0);
	
	pt[1].x = cent.x + 2e-3, pt[1].y = 0.0, pt[1].z = cent.z - 2e-3;
	nor[1].x = -sin(phi0), nor[1].y = 0.0, nor[1].z = cos(phi0);
	
	pt[2].x = cent.x, pt[2].y = 0.0, pt[2].z = cent.z;
	nor[2].x = -sin(phi0), nor[2].y = 0.0, nor[2].z = -cos(phi0);
	
	pt[3].x = cent.x - 2e-3, pt[3].y = 0.0, pt[3].z = cent.z - 2e-3;
	nor[3].x = sin(phi0), nor[3].y = 0.0, nor[3].z = cos(phi0);
	
	for(ii=0;ii<4;ii++) {
		pt[ii].x /= (0.5*delx[1]);
		pt[ii].y /= (0.5*dely[1]);
		pt[ii].z /= (0.5*delz[1]);
	}
	
	const_sim_polyhedron(&cube_poly);
	const_sim_polyhedron(&cube_poly2);
	
	for(i=1;i<im1_f;i++)
	 for(j=1;j<jm1_f;j++)
	  for(k=1;k<km1_f;k++) {
			//perform scaling in unit coordinate system of current cell
			for(ii=0;ii<4;ii++) {
				ct[ii].x = pt[ii].x-(double)(i-1+2*mpi.OProc[0]);
				ct[ii].y = pt[ii].y-(double)(j-1+2*mpi.OProc[1]);
				ct[ii].z = pt[ii].z-(double)(k-1+2*mpi.OProc[2]); 
			}
			
			const_com_polyhedron(&cube_poly,&tmp_poly1,&(ct[0]),&(nor[0]),0);
			const_com_polyhedron(&tmp_poly1,&tmp_poly2,&(ct[1]),&(nor[1]),0);
			
			psi_f[IJK_f] -= calc_poly_vol(&tmp_poly2);
			f_f[IJK_f] -= calc_poly_vol(&tmp_poly2);

			const_com_polyhedron(&cube_poly2,&tmp_poly3,&(ct[2]),&(nor[2]),0);
			const_com_polyhedron(&tmp_poly3,&tmp_poly4,&(ct[3]),&(nor[3]),0);

			psi_f[IJK_f] -= calc_poly_vol(&tmp_poly4);
			f_f[IJK_f] -= calc_poly_vol(&tmp_poly4);
	  }		
}

void multi_solid_ancillary() {
	
	int i,j,k,indx;
	double *psirho_f = temp_f[1];
	double len,wid,hei;
	//rigid body #1
	indx=1;
	Mvert[indx].x=0.00, Pvert[indx].x=xe;
	Mvert[indx].y=0.00, Pvert[indx].y=ye;
	Mvert[indx].z=0.00, Pvert[indx].z=ze;
	
	for(i=1;i<=6;i++) ZDOF[indx][i]=0;
	//ZDOF[indx][1]=ZDOF[indx][2]=ZDOF[indx][3]=1; //non-zero degree of freedom
	ZDOF[indx][3]=1; //non-zero degree of freedom
	IPRES[indx]=0; //prescribed velocity
	Cent[indx].x = 1.8e-3, Cent[indx].y = 2.6e-3, Cent[indx].z = 2.6e-3;
	
	//centroid and orientation not needed for rigid body #1
	
	//rigid body #2
	/*indx=2;
	Mvert[indx].x=2.5, Pvert[indx].x=8.5;
	Mvert[indx].y=0.00, Pvert[indx].y=ye;
	Mvert[indx].z=0.00, Pvert[indx].z=ze;
	
	len=1.144; hei=0.254;
	Theta[indx].x=0.0, Theta[indx].y=0.0, Theta[indx].z=0.0;
    Cent[indx].x=5.5; Cent[indx].y=len/2.0; Cent[indx].z=hei; //this center is the location of the hinge
	
	for(i=1;i<=6;i++) ZDOF[indx][i]=0;
	ZDOF[indx][5]=1;
	IPRES[indx]=0; //two-way FSI*/
	
	for(i=1;i<=NBODY;i++) Nsol_bounding_box(i);
	
	if(istart==1) { //if (istart==0) this is not needed because the corr_initf performs the same.
		for(i=0;i<=im1_f;i++)
		 for(j=0;j<=jm1_f;j++)
		  for(k=0;k<=km1_f;k++) {
			  psirho_f[IJK_f] = rhof0*(psi_f[IJK_f]) + 1.0*(1.0-psi_f[IJK_f]); //the density is only for the purpose of calculating normals
		  }
		normalspsi_f(); // calculates psiavnx_f, psiavny_f etc.
	}
}
double distance_line_to_point(st_point *vec_c, st_point *vec_a, st_point *vec_b);
void init_sol_cyl_angle ()//function which initializes cylinder at an angle, based on distance formula from line to a point in 3D space at http://mathworld.wolfram.com/Point-LineDistance3-Dimensional.html
{   // initialization if based on Finnigan and Flocard pitching cylinder experiments
	st_point hinge, theta;
	hinge.x=xe/2, hinge.y=0.0, hinge.z=6.0e-2;//location of hinge for cylinder.  should be fixed in y and z and free in x
	theta.x=60.0*pi/180.0, theta.y=90.0*pi/180.0, theta.z=30.0*pi/180.0;//angle defined in terms of direction cosines
	double height=7.25e-1;//height of cylinder
	double R = 1.0e-1;//radius of cylinder
	
	double x1=hinge.x+2.5e-2*cos(theta.x);//x component of first point on line (bottom of cylinder)
	double y1=hinge.y+2.5e-2*cos(theta.y);//y component of first point on line
	double z1=hinge.z+2.5e-2*cos(theta.z);//z component of first point on line
	double x2=hinge.x+(height+2.5e-2)*cos(theta.x);//second point... (top of cylinder)
	double y2=hinge.y+(height+2.5e-2)*cos(theta.y);
	double z2=hinge.z+(height+2.5e-2)*cos(theta.z);
	st_point X0, X00, X1, X2, X0m, V1P, V2P, V3P;
	double dist[8];//distance from point to line
	double tx, ty, tz, txm, tym, tzm, x0, y0, z0, x0m, y0m, z0m, p_vol;
	
	st_point num;
	int cnt, maxi, mini;
	
	if(mpi.MyRank==0) printf("initializing cylinder at an angle...\n\nx1=%e, y1=%e, z1=%e, x2=%e, y2=%e, z2=%e\n", x1, y1, z1, x2, y2, z2);
	
	for(int i=1;i<im1_f;i++)
	{	for(int j=1;j<jm1_f;j++)
		{	for(int k=1;k<km1_f;k++)
			{	tx = (i+2*mpi.OProc[0]) * (0.5*delx[1]);
				ty = (j+2*mpi.OProc[1]) * (0.5*dely[1]);
				tz = (k+2*mpi.OProc[2]) * (0.5*delz[1]);
				txm = tx - (0.5*delx[1]);
				tym = ty - (0.5*dely[1]);
				tzm = tz - (0.5*delz[1]);
				
				X1.x = x1;
				X1.y = y1;
				X1.z = z1;
				X2.x = x2;
				X2.y = y2;
				X2.z = z2;
				
				X0.x = txm;
				X0.y = tym;
				X0.z = tzm;
				dist[0] = distance_line_to_point(&X0, &X1, &X2);
				X0.x = txm;
				X0.y = ty;
				X0.z = tzm;
				dist[1] = distance_line_to_point(&X0, &X1, &X2);
				X0.x = txm;
				X0.y = tym;
				X0.z = tz;
				dist[2] = distance_line_to_point(&X0, &X1, &X2);
				X0.x = txm;
				X0.y = ty;
				X0.z = tz;
				dist[3] = distance_line_to_point(&X0, &X1, &X2);
				X0.x = tx;
				X0.y = ty;
				X0.z = tzm;
				dist[4] = distance_line_to_point(&X0, &X1, &X2);
				X0.x = tx;
				X0.y = tym;
				X0.z = tzm;
				dist[5] = distance_line_to_point(&X0, &X1, &X2);
				X0.x = tx;
				X0.y = tym;
				X0.z = tz;
				dist[6] = distance_line_to_point(&X0, &X1, &X2);
				X0.x = tx;
				X0.y = ty;
				X0.z = tz;
				dist[7] = distance_line_to_point(&X0, &X1, &X2);
				
				
				cnt=0;
				for(int qq=0;qq<8;qq++)
				{	if(dist[qq]>R) cnt++;		
				}
				if(cnt==8) p_vol=0.0;
				else if(cnt==0) p_vol=1.0;
				else
				{	p_vol=0.0;
					for(int l=0;l<25;l++)
					{	for(int m=0;m<25;m++)
						{	for(int n=0;n<25;n++)
							{	X00.x=txm+(l+0.5)/25.0*delx[1]*0.5e0;
								X00.y=tym+(m+0.5)/25.0*dely[1]*0.5e0;
								X00.z=tzm+(n+0.5)/25.0*delz[1]*0.5e0;
								if( (distance_line_to_point(&X00, &X1, &X2)) < R) p_vol+=6.4e-5;
							}
						}	
					}	
				}	
				psi_f[IJK_f] += p_vol;
			}
		}
	}
	
	//now calculate intersection of two planes with cylinder
	int i, j ,k;
	double *psirho_f = temp_f[1];
	double *psiavnx_f = temp_f[9];
	double *psiavny_f = temp_f[10];
	double *psiavnz_f = temp_f[11];
	double f_p;
	st_point pnor, cent1, vec_a;
	
	for(i=0;i<=im1_f;i++)
		for(j=0;j<=jm1_f;j++)
			for(k=0;k<=km1_f;k++) //calculation in ghost cells is a necessity... only after bcf etc. calls
			{
				psirho_f[IJK_f] = psi_f[IJK_f]*rhof0 + (1.e0-psi_f[IJK_f])*1.e0;
			}
	
	normalspsi_f();
	
	st_polyhedron cube_poly, temp_poly, new_poly;
	st_point nor1[2], cent[2], ct;
	nor1[0].x = -cos(theta.x), nor1[0].y=-cos(theta.y), nor1[0].z = -cos(theta.z), nor1[1].x = cos(theta.x), nor1[1].y=cos(theta.y), nor1[1].z = cos(theta.z);
	if(mpi.MyRank==0) printf("nor1[0].x=%e, nor1[0].y=%e, nor1[0].z=%e, nor1[1].x=%e, nor1[1].y=%e, nor1[1].z=%e\n", nor1[0].x, nor1[0].y, nor1[0].z, nor1[1].x, nor1[1].y, nor1[1].z);
	cent[0].x = x2, cent[0].y = y2, cent[0].z = z2, cent[1].x = x1, cent[1].y = y1, cent[1].z = z1;
	const_sim_polyhedron(&cube_poly);
	
		
	for(i=0;i<=im1_f;i++)
		for(j=0;j<=jm1_f;j++)
			for(k=0;k<=km1_f;k++) 
			{	if(psi_f[IJK_f]>em61)
				{	ct.x=cent[0].x/(5.0e-1*delx[1]) - (double)(i+2*mpi.OProc[0]-1);
					ct.y=cent[0].y/(5.0e-1*dely[1]) - (double)(j+2*mpi.OProc[1]-1);
					ct.z=cent[0].z/(5.0e-1*delz[1]) - (double)(k+2*mpi.OProc[2]-1);
					const_com_polyhedron(&cube_poly, &temp_poly, &ct, &nor1[0], 1);
					ct.x=cent[1].x/(5.0e-1*delx[1]) - (double)(i+2*mpi.OProc[0]-1);
					ct.y=cent[1].y/(5.0e-1*dely[1]) - (double)(j+2*mpi.OProc[1]-1);
					ct.z=cent[1].z/(5.0e-1*delz[1]) - (double)(k+2*mpi.OProc[2]-1);
					const_com_polyhedron(&temp_poly, &new_poly, &ct, &nor1[1], 1);
					f_p=calc_poly_vol(&new_poly);
					psi_f[IJK_f]=f_p;	
				}	
				if(psi_f[IJK_f]>em6 && psi_f[IJK_f]<em61)
				{	pnor.x=psiavnx_f[IJK_f];
					pnor.y=psiavny_f[IJK_f];
					pnor.z=psiavnz_f[IJK_f];
					make_unity(&pnor);
					area_2(psi_f[IJK_f], i,j,k,IJK_f, &pnor, &cent1, &vec_a);
					const_com_polyhedron(&cube_poly, &new_poly, &cent1, &pnor, 1);
					ct.x=cent[0].x/(5.0e-1*delx[1]) - (double)(i+2*mpi.OProc[0]-1);
					ct.y=cent[0].y/(5.0e-1*dely[1]) - (double)(j+2*mpi.OProc[1]-1);
					ct.z=cent[0].z/(5.0e-1*delz[1]) - (double)(k+2*mpi.OProc[2]-1);
					const_com_polyhedron(&new_poly, &temp_poly, &ct, &nor1[0], 1);
					ct.x=cent[1].x/(5.0e-1*delx[1]) - (double)(i+2*mpi.OProc[0]-1);
					ct.y=cent[1].y/(5.0e-1*dely[1]) - (double)(j+2*mpi.OProc[1]-1);
					ct.z=cent[1].z/(5.0e-1*delz[1]) - (double)(k+2*mpi.OProc[2]-1);
					const_com_polyhedron(&temp_poly, &new_poly, &ct, &nor1[1], 1);
					f_p=calc_poly_vol(&new_poly);
					psi_f[IJK_f]=f_p;	
				}
				
			}
	
	
	
	
	
}

double distance_line_to_point(st_point *vec_c, st_point *vec_a, st_point *vec_b)
{//function that takes vectors a and b that lie on the line, and point represented by vector c. Returns the distance
	double mag1, mag2;
	double distance;
	st_point V1, V2, V3, V4;
	V1.x=(*vec_c).x-(*vec_a).x;
	V1.y=(*vec_c).y-(*vec_a).y;
	V1.z=(*vec_c).z-(*vec_a).z;
	V2.x=(*vec_c).x-(*vec_b).x;
	V2.y=(*vec_c).y-(*vec_b).y;
	V2.z=(*vec_c).z-(*vec_b).z;
	
	cross_prod(&V4, &V1, &V2);
	V3.x=(*vec_b).x-(*vec_a).x;
	V3.y=(*vec_b).y-(*vec_a).y;
	V3.z=(*vec_b).z-(*vec_a).z;
	
	mag1=SQUARE(V4.x) + SQUARE(V4.y) + SQUARE(V4.z);
	mag1=sqrt(mag1);
	
	mag2=SQUARE(V3.x) + SQUARE(V3.y) + SQUARE(V3.z);
	mag2=sqrt(mag2);
	
	distance=mag1/mag2;
	return distance;
}	

template <class T> void val_indx(int i, int j, int k, T &val, T *array, T *gArray)
{	
	//sets val from either the main array [*array] or
	//2nd layer of ghost cell [*gArray] whichever is appropriate
	int i2,j2,k2, gx,gy,gz, st_indx;
	
	val = 0;
	if(i<imax_f && i>-1 && j<jmax_f && j>-1 && k<kmax_f && k>-1)
		val = array[IJK_f];
	else {
		if(i==-1) {
			st_indx = 0;
			i2=0, j2=j+1, k2=k+1; //indices in gArray
			gx=1, gy=(jmax_f+2), gz =(kmax_f+2); //dimensions of gArray
		}
		if(i==imax_f) {
			st_indx = (jmax_f+2)*(kmax_f+2);
			i2=0, j2=j+1, k2=k+1;
			gx=1, gy=(jmax_f+2), gz =(kmax_f+2);
		}
		if(j==-1) {
			st_indx = 2*(jmax_f+2)*(kmax_f+2);
			i2=i+1, j2=0, k2=k+1;
			gx=imax_f+2, gy=1, gz=kmax_f+2;
		}
		if(j==jmax_f) {
			st_indx = 2*(jmax_f+2)*(kmax_f+2) + (imax_f+2)*(kmax_f+2);
			i2=i+1, j2=0, k2=k+1;
			gx=imax_f+2, gy=1, gz=kmax_f+2;
		}
		if(k==-1) {
			st_indx = 2*(jmax_f+2)*(kmax_f+2) + 2*(imax_f+2)*(kmax_f+2);
			i2=i+1, j2=j+1, k2=0;
			gx=(imax_f+2), gy=jmax_f+2, gz=1;
		}
		if(k==kmax_f) {
			st_indx = 2*(jmax_f+2)*(kmax_f+2) + 2*(imax_f+2)*(kmax_f+2)
				  + (imax_f+2)*(jmax_f+2);
			i2=i+1, j2=j+1, k2=0;
			gx=(imax_f+2), gy=(jmax_f+2), gz=1;
		}
		val = gArray[st_indx + i2 + j2*(gx) + k2*(gx)*(gy)];
	}
}

void printPolyVertices(st_polyhedron *ptr) {
	//this routine prints all the vertices in all faces of a given polyhedron
	int m,nn; //m counter for faces, nn for vertices
	
	for(m=0;m<ptr->n;m++) {
		printf("-----------------face %d-------------------------\n",m);
		for(nn=0;nn<ptr->face[m].n;nn++) 
			printf("vert %d : %.18e %.18e %.18e\n",nn,ptr->face[m].vert[nn].x,ptr->face[m].vert[nn].y,ptr->face[m].vert[nn].z);
		printf("face->tot.l=%d: two id's = %d %d\n",ptr->face[m].tot_l,ptr->face[m].l[0],ptr->face[m].l[1]);
	}
	
	printf("ptr->vol = %.18e\n",calc_poly_vol(ptr));
}

/**
void virtfine2stnd()
{
	int i,j,k;
	//on the standard grid
	for(i=1;i<im1;i++) //REAL cells
		for(j=1;j<jm1;j++)
			for(k=1;k<km1;k++)
				fvirt[IJK]=0.125e0*(fvirt_f[IND_f(2*i,2*j,2*k)]+fvirt_f[IND_f(2*i-1,2*j,2*k)]+fvirt_f[IND_f(2*i-1,2*j-1,2*k)]+fvirt_f[IND_f(2*i,2*j-1,2*k)]
				+fvirt_f[IND_f(2*i,2*j,2*k-1)]+fvirt_f[IND_f(2*i-1,2*j,2*k-1)]+fvirt_f[IND_f(2*i-1,2*j-1,2*k-1)]+fvirt_f[IND_f(2*i,2*j-1,2*k-1)]);
}
**/

//-------------------------------------------------------------------------------------------------------------------------------------------
//matrix math library
	
#define TINY 1.0e-25 //A small number

void ludcmp(double a[][NDIM+1], int n, int *indx, double *d)
//Given a matrix a[1..n][1..n] , this routine replaces it by the LU decomposition of a rowwise
//permutation of itself. a and n are input. a is output, arranged as in equation (2.3.14) above;
//indx[1..n] is an output vector that records the row permutation effected by the partial
//pivoting; d is output as ±1 depending on whether the number of row interchanges was even
//or odd, respectively. This routine is used in combination with lubksb to solve linear equations
//or invert a matrix.
{   	
	int i,Imax,j,k;

	double big,dum,sum,tempi;
	double vv[NDIM+1]={0.0,0.0,0.0,0.0}; //vv stores the implicit scaling of each row.
	
	*d=1.0; //No row interchanges yet.
	for (i=1;i<=n;i++) { //Loop over rows to get the implicit scaling information.
		big=0.0;
		for (j=1;j<=n;j++)
			if ((tempi=fabs(a[i][j])) > big) big=tempi;
		if (big == 0.0) printf("Singular matrix in routine ludcmp\n"); //No nonzero largest element.
		vv[i]=1.0/big; //Save the scaling.
	}
	
	for (j=1;j<=n;j++) { //This is the loop over columns of Crout's method.
		for (i=1;i<j;i++) { //This is equation (2.3.12) except for i = j.
			sum=a[i][j];
			for (k=1;k<i;k++) sum -= a[i][k]*a[k][j];
			a[i][j]=sum;
		}
		big=0.0; //Initialize for the search for largest pivot element.
		for (i=j;i<=n;i++) { //This is i = j of equation (2.3.12) and i = j + 1 . . . N
			sum=a[i][j]; //of equation (2.3.13).
			for (k=1;k<j;k++)
				sum -= a[i][k]*a[k][j];
			a[i][j]=sum;
			if ( (dum=vv[i]*fabs(sum)) >= big) { //Is the figure of merit for the pivot better than the best so far?
				big=dum;
				Imax=i;
			}
		}
		if (j != Imax) { //Do we need to interchange rows?
			for (k=1;k<=n;k++) { //Yes, do so...
				dum=a[Imax][k];
				a[Imax][k]=a[j][k];
				a[j][k]=dum;
			}
			*d = -(*d); //...and change the parity of d.
			vv[Imax]=vv[j]; //Also interchange the scale factor.
		}
		indx[j]=Imax;
		if (a[j][j] == 0.0) a[j][j]=TINY; 
		//If the pivot element is zero the matrix is singular (at least to the precision of the
		//algorithm). For some applications on singular matrices, it is desirable to substitute
		//TINY for zero.
		if (j != n) {
			//Now, finally, divide by the pivot element.
			dum=1.0/(a[j][j]);
			for (i=j+1;i<=n;i++) a[i][j] *= dum;
		}
	} //Go back for the next column in the reduction.

}

void lubksb(double a[][NDIM+1], int n, int *indx, double b[])
//Solves the set of n linear equations A·X = B. Here a[1..n][1..n] is input, not as the matrix
//A but rather as its LU decomposition, determined by the routine ludcmp . indx[1..n] is input
//as the permutation vector returned by ludcmp . b[1..n] is input as the right-hand side vector
//B, and returns with the solution vector X. a , n , and indx are not modified by this routine
//and can be left in place for successive calls with different right-hand sides b . This routine takes
//into account the possibility that b will begin with many zero elements, so it is efficient for use
//in matrix inversion.
{
	int i,ii=0,ip,j;
	double sum;
	for (i=1;i<=n;i++) { //When ii is set to a positive value, it will become the
		ip=indx[i]; //index of the first nonvanishing element of b. We now
		sum=b[ip]; //do the forward substitution, equation (2.3.6). The
		b[ip]=b[i]; //only new wrinkle is to unscramble the permutation
		if (ii) //as we go.
			for (j=ii;j<=i-1;j++) sum -= a[i][j]*b[j];
		else if (sum) ii=i; //A nonzero element was encountered, so from now on we
		b[i]=sum; //will have to do the sums in the loop above.
	}
	for (i=n;i>=1;i--) { //Now we do the backsubstitution, equation (2.3.7).
		sum=b[i];
		for (j=i+1;j<=n;j++) sum -= a[i][j]*b[j];
		b[i]=sum/a[i][i]; //Store a component of the solution vector X.
	} //All done!
}

void lump_mat(double In[][NDIM+1],double lIn[][NDIM+1]) {
	int i,j;
	for(i=1;i<=NDIM;i++)
	 for(j=1;j<=NDIM;j++) {
		 In[i][j] += lIn[i][j];
	 }
}

void lump_vec(double vec[NDIM+1],double lvec[NDIM+1]) {
	int i;
	for(i=1;i<=NDIM;i++) {
		vec[i] += lvec[i];
	}
	 
}
//-------------------------------------------------------------------------------------------------------------------------------------------
//routines to calculate the moment of inertia for cube and for a generalized polyhedron
void calc_inertia_cube(double In[][NDIM+1], st_point *cent, st_point *lcent, double voli) {
	int ii,jj;
	double r[4],mass;
	mass=rhof0*voli*0.125*delx[1]*dely[1]*delz[1]; //the cubes are on fine grid
	r[1]=(lcent->x - cent->x);
	r[2]=(lcent->y - cent->y);
	r[3]=(lcent->z - cent->z);
	
	for(ii=1;ii<=NDIM;ii++)
	 for(jj=1;jj<=NDIM;jj++) {
		 In[ii][jj] = -r[ii]*r[jj];
		 if(ii==jj) In[ii][jj] += (1.e0/6.e0)*(0.25*delx[1]*dely[1]) + r[1]*r[1] + r[2]*r[2] + r[3]*r[3];
		 In[ii][jj] = mass*In[ii][jj];
	 }
}

void calc_inertia_poly(double In[][NDIM+1],st_point *cent, st_point *corner, st_polyhedron *psi_poly) {
	
	int m,n,i,j;
	double epsilon = 1.e-12, H, scal; st_point tri[5],v0,v1; //tetrahedron vertices stored in tri
	double lIn[NDIM+1][NDIM+1];
	
	for(i=1;i<=NDIM;i++)
	 for(j=1;j<=NDIM;j++) {
		 In[i][j] = 0.0; //initialize inertia to zero
	 }
	
	scal = 0.5*delx[1];	//the polyhedrons are on fine grids
	m= psi_poly->n - 1;
	n= psi_poly->face[m].n - 1;
	equate_pt(&v0,&(psi_poly->face[m].vert[n])); //last vertex of the last face
	
	tri[1].x = (corner->x / scal + (v0.x) - cent->x / scal), 
	tri[1].y = (corner->y / scal + (v0.y) - cent->y / scal), 
	tri[1].z = (corner->z / scal + (v0.z) - cent->z / scal);
	
	for(i=0;i<m;i++) {
		equate_pt(&v1,&(psi_poly->face[i].vert[0]));
		H=dif_dot(&v0,&v1,&(psi_poly->face[i].nor));
		if(fabs(H) > epsilon) {
			tri[2].x = (corner->x / scal + (v1.x) - cent->x / scal), 
			tri[2].y = (corner->y / scal + (v1.y) - cent->y / scal), 
			tri[2].z = (corner->z / scal + (v1.z) - cent->z / scal);
			
			for(j=2;j<psi_poly->face[i].n;j++) {
				tri[3].x = (corner->x / scal + psi_poly->face[i].vert[j-1].x - cent->x / scal);
				tri[3].y = (corner->y / scal + psi_poly->face[i].vert[j-1].y - cent->y / scal);
				tri[3].z = (corner->z / scal + psi_poly->face[i].vert[j-1].z - cent->z / scal);
				
				tri[4].x = (corner->x / scal + psi_poly->face[i].vert[j].x - cent->x / scal);
				tri[4].y = (corner->y / scal + psi_poly->face[i].vert[j].y - cent->y / scal);
				tri[4].z = (corner->z / scal + psi_poly->face[i].vert[j].z - cent->z / scal);
				calc_inertia_tetra(lIn,tri);
				lump_mat(In,lIn); 
			}
		}
	}
	for(i=1;i<=NDIM;i++)
	 for(j=1;j<=NDIM;j++) {
		In[i][j] *= rhof0*pow(scal,5);
	 }
}

void calc_inertia_tetra(double lIn[][NDIM+1],st_point *tri) {
	int i,j,indx[NDIM+1]; double X[NDIM+2],Y[NDIM+2],Z[NDIM+2];
	double Jac[NDIM+1][NDIM+1],det,a,b,c,ap,bp,cp;
	
	for(i=1;i<=(NDIM+1);i++) {
		X[i]=tri[i].x; Y[i]=tri[i].y; Z[i]=tri[i].z;
	}
	
	Jac[1][1]=X[2]-X[1], Jac[1][2]=X[3]-X[1], Jac[1][3]=X[4]-X[1];
	Jac[2][1]=Y[2]-Y[1], Jac[2][2]=Y[3]-Y[1], Jac[2][3]=Y[4]-Y[1];
	Jac[3][1]=Z[2]-Z[1], Jac[3][2]=Z[3]-Z[1], Jac[3][3]=Z[4]-Z[1];
	   
	//calculate determinant
	ludcmp(Jac,3,indx,&det);
	for(j=1;j<=NDIM;j++) det *= Jac[j][j];
	
	a=fabs(det)*(Y[1]*Y[1] + Y[1]*Y[2] + Y[2]*Y[2] + Y[1]*Y[3] + Y[2]*Y[3]
	+ Y[3]*Y[3] + Y[1]*Y[4] + Y[2]*Y[4] + Y[3]*Y[4] + Y[4]*Y[4] + Z[1]*Z[1] + Z[1]*Z[2]
	+ Z[2]*Z[2] + Z[1]*Z[3] + Z[2]*Z[3] + Z[3]*Z[3] + Z[1]*Z[4] + Z[2]*Z[4] + Z[3]*Z[4] + Z[4]*Z[4])/60.0;
	
	b=fabs(det)*(X[1]*X[1] + X[1]*X[2] + X[2]*X[2] + X[1]*X[3] + X[2]*X[3] + X[3]*X[3]
	+ X[1]*X[4] + X[2]*X[4] + X[3]*X[4] + X[4]*X[4] + Z[1]*Z[1] + Z[1]*Z[2] + Z[2]*Z[2] + Z[1]*Z[3]
	+ Z[2]*Z[3] + Z[3]*Z[3] + Z[1]*Z[4] + Z[2]*Z[4] + Z[3]*Z[4] + Z[4]*Z[4])/60.0;
	
	c=fabs(det)*(X[1]*X[1] + X[1]*X[2] + X[2]*X[2] + X[1]*X[3] + X[2]*X[3] + X[3]*X[3] + X[1]*X[4]
	+ X[2]*X[4] + X[3]*X[4] + X[4]*X[4] + Y[1]*Y[1] + Y[1]*Y[2] + Y[2]*Y[2] + Y[1]*Y[3]
	+ Y[2]*Y[3] + Y[3]*Y[3] + Y[1]*Y[4] + Y[2]*Y[4] + Y[3]*Y[4] + Y[4]*Y[4])/60.0;
	
	ap=fabs(det)*(2.0*Y[1]*Z[1] + Y[2]*Z[1] + Y[3]*Z[1] + Y[4]*Z[1] + Y[1]*Z[2]
	+ 2.0*Y[2]*Z[2] + Y[3]*Z[2] + Y[4]*Z[2] + Y[1]*Z[3] + Y[2]*Z[3] + 2.0*Y[3]*Z[3]
	+ Y[4]*Z[3] + Y[1]*Z[4] + Y[2]*Z[4] + Y[3]*Z[4] + 2.0*Y[4]*Z[4])/120.0;
	
	cp=fabs(det)*(2.0*X[1]*Z[1] + X[2]*Z[1] + X[3]*Z[1] + X[4]*Z[1] + X[1]*Z[2]
	+ 2.0*X[2]*Z[2] + X[3]*Z[2] + X[4]*Z[2] + X[1]*Z[3] + X[2]*Z[3] + 2.0*X[3]*Z[3]
	+ X[4]*Z[3] + X[1]*Z[4] + X[2]*Z[4] + X[3]*Z[4] + 2.0*X[4]*Z[4])/120.0;
	
	bp=fabs(det)*(2.0*X[1]*Y[1] + X[2]*Y[1] + X[3]*Y[1] + X[4]*Y[1] + X[1]*Y[2]
	+ 2.0*X[2]*Y[2] + X[3]*Y[2] + X[4]*Y[2] + X[1]*Y[3] + X[2]*Y[3] + 2.0*X[3]*Y[3]
	+ X[4]*Y[3] + X[1]*Y[4] + X[2]*Y[4] + X[3]*Y[4] + 2.0*X[4]*Y[4])/120.0;

	lIn[1][1]=a,   lIn[1][2]=-bp, lIn[1][3]=-cp;
	lIn[2][1]=-bp, lIn[2][2]=b,   lIn[2][3]=-ap;
	lIn[3][1]=-cp, lIn[3][2]=-ap, lIn[3][3]=c;
}

void calc_total_fluid(double *f_total) {
	int i,j,k,ti,tj,tk;
	double ft=0.0;
	for(k=1;k<km1_f;k++)
	 for(j=1;j<jm1_f;j++)
	   for(i=1;i<im1_f;i++) {
		  ti=(i+1)/2, tj=(j+1)/2, tk=(k+1)/2;
		  if(ac[IND(ti,tj,tk)]<em6) continue;
		  ft += (f_f[IJK_f])*(vol_f[IJK_f]);
	  }
	  
	dallreduce(&ft,f_total,1,OP_SUM);
}
#endif

void calc_cross_visc(double *fvar) {
	//calculates the cross viscosities xmuxy, xmuyz, xmuxz
	//using the harmonic averaging of fvar
	double fc,fcc,psic;
	double *const xmuxz=temp[6];
	double *const xmuyz=temp[7];
	double *const xmuxy=temp[8];
	
	int i,j,k;
	  
	for(k=1;k<kmax;k++)
	 for(j=1;j<jmax;j++)
	  for(i=1;i<imax;i++) {
		  if(j<jm1) { //variable viscosities not considered here... ashish 
#ifndef __solid
		   fc=(fvar[IND_f(2*i-1,2*j-1,2*k-1)]+fvar[IND_f(2*i-1,2*j,2*k-1)]+fvar[IND_f(2*i-1,2*j,2*k-2)]+fvar[IND_f(2*i-1,2*j-1,2*k-2)] //xmuxz
				 +fvar[IND_f(2*i-2,2*j-1,2*k-1)]+fvar[IND_f(2*i-2,2*j,2*k-1)]+fvar[IND_f(2*i-2,2*j,2*k-2)]+fvar[IND_f(2*i-2,2*j-1,2*k-2)])/8.0;
		   xmuxz[IJK]=xmuf1*xmuf2/(fc*xmuf2+(1.0-fc)*xmuf1+tiny);
#endif
#ifdef __solid
		   psic=(psi_f[IND_f(2*i-1,2*j-1,2*k-1)]+psi_f[IND_f(2*i-1,2*j,2*k-1)]+psi_f[IND_f(2*i-1,2*j,2*k-2)]+psi_f[IND_f(2*i-1,2*j-1,2*k-2)]
				 +psi_f[IND_f(2*i-2,2*j-1,2*k-1)]+psi_f[IND_f(2*i-2,2*j,2*k-1)]+psi_f[IND_f(2*i-2,2*j,2*k-2)]+psi_f[IND_f(2*i-2,2*j-1,2*k-2)])/8.0;
		   fcc=(f_f[IND_f(2*i-1,2*j-1,2*k-1)]+f_f[IND_f(2*i-1,2*j,2*k-1)]+f_f[IND_f(2*i-1,2*j,2*k-2)]+f_f[IND_f(2*i-1,2*j-1,2*k-2)]
				 +f_f[IND_f(2*i-2,2*j-1,2*k-1)]+f_f[IND_f(2*i-2,2*j,2*k-1)]+f_f[IND_f(2*i-2,2*j,2*k-2)]+f_f[IND_f(2*i-2,2*j-1,2*k-2)])/8.0;
		   if(psic+fcc > em61 && psic>em6 && fcc>em6) 
				xmuxz[IJK]=xmuf1; //solid+water CVs
		   else {
			    fc=(fvar[IND_f(2*i-1,2*j-1,2*k-1)]+fvar[IND_f(2*i-1,2*j,2*k-1)]+fvar[IND_f(2*i-1,2*j,2*k-2)]+fvar[IND_f(2*i-1,2*j-1,2*k-2)]
				 +fvar[IND_f(2*i-2,2*j-1,2*k-1)]+fvar[IND_f(2*i-2,2*j,2*k-1)]+fvar[IND_f(2*i-2,2*j,2*k-2)]+fvar[IND_f(2*i-2,2*j-1,2*k-2)])/8.0;
		        xmuxz[IJK]=xmuf1*xmuf2/(fc*xmuf2+(1.0-fc)*xmuf1+tiny);
		   }
#endif
		  }
		  if(i<im1)	{
#ifndef __solid	
		   fc=(fvar[IND_f(2*i-1,2*j-1,2*k-1)]+fvar[IND_f(2*i-1,2*j-2,2*k-1)]+fvar[IND_f(2*i-1,2*j-2,2*k-2)]+fvar[IND_f(2*i-1,2*j-1,2*k-2)] //xmuyz
			       +fvar[IND_f(2*i,2*j-1,2*k-1)]+fvar[IND_f(2*i,2*j-2,2*k-1)]+fvar[IND_f(2*i,2*j-2,2*k-2)]+fvar[IND_f(2*i,2*j-1,2*k-2)])/8.0;
		   xmuyz[IJK]=xmuf1*xmuf2/(fc*xmuf2+(1.0-fc)*xmuf1+tiny);
#endif
#ifdef __solid
		   psic=(psi_f[IND_f(2*i-1,2*j-1,2*k-1)]+psi_f[IND_f(2*i-1,2*j-2,2*k-1)]+psi_f[IND_f(2*i-1,2*j-2,2*k-2)]+psi_f[IND_f(2*i-1,2*j-1,2*k-2)]
			       +psi_f[IND_f(2*i,2*j-1,2*k-1)]+psi_f[IND_f(2*i,2*j-2,2*k-1)]+psi_f[IND_f(2*i,2*j-2,2*k-2)]+psi_f[IND_f(2*i,2*j-1,2*k-2)])/8.0;
			       
		   fcc=(f_f[IND_f(2*i-1,2*j-1,2*k-1)]+f_f[IND_f(2*i-1,2*j-2,2*k-1)]+f_f[IND_f(2*i-1,2*j-2,2*k-2)]+f_f[IND_f(2*i-1,2*j-1,2*k-2)]
			       +f_f[IND_f(2*i,2*j-1,2*k-1)]+f_f[IND_f(2*i,2*j-2,2*k-1)]+f_f[IND_f(2*i,2*j-2,2*k-2)]+f_f[IND_f(2*i,2*j-1,2*k-2)])/8.0;
		   if(psic+fcc > em61 && psic>em6 && fcc>em6) 
				xmuyz[IJK]=xmuf1; //solid+water CVs
		   else {
			    fc=(fvar[IND_f(2*i-1,2*j-1,2*k-1)]+fvar[IND_f(2*i-1,2*j-2,2*k-1)]+fvar[IND_f(2*i-1,2*j-2,2*k-2)]+fvar[IND_f(2*i-1,2*j-1,2*k-2)] 
			       +fvar[IND_f(2*i,2*j-1,2*k-1)]+fvar[IND_f(2*i,2*j-2,2*k-1)]+fvar[IND_f(2*i,2*j-2,2*k-2)]+fvar[IND_f(2*i,2*j-1,2*k-2)])/8.0;
				xmuyz[IJK]=xmuf1*xmuf2/(fc*xmuf2+(1.0-fc)*xmuf1+tiny);
			}
#endif
		  }
		  if(k<km1)	{
#ifndef __solid     
		   fc=(fvar[IND_f(2*i-1,2*j-1,2*k-1)]+fvar[IND_f(2*i-1,2*j-2,2*k-1)]+fvar[IND_f(2*i-1,2*j-2,2*k)]+fvar[IND_f(2*i-1,2*j-1,2*k)] //xmuxy
				 +fvar[IND_f(2*i-2,2*j-1,2*k-1)]+fvar[IND_f(2*i-2,2*j-2,2*k-1)]+fvar[IND_f(2*i-2,2*j-2,2*k)]+fvar[IND_f(2*i-2,2*j-1,2*k)])/8.0;
		   xmuxy[IJK]=xmuf1*xmuf2/(fc*xmuf2+(1.0-fc)*xmuf1+tiny);
#endif
#ifdef __solid
		   psic=(psi_f[IND_f(2*i-1,2*j-1,2*k-1)]+psi_f[IND_f(2*i-1,2*j-2,2*k-1)]+psi_f[IND_f(2*i-1,2*j-2,2*k)]+psi_f[IND_f(2*i-1,2*j-1,2*k)]
				 +psi_f[IND_f(2*i-2,2*j-1,2*k-1)]+psi_f[IND_f(2*i-2,2*j-2,2*k-1)]+psi_f[IND_f(2*i-2,2*j-2,2*k)]+psi_f[IND_f(2*i-2,2*j-1,2*k)])/8.0;
		   fcc=(f_f[IND_f(2*i-1,2*j-1,2*k-1)]+f_f[IND_f(2*i-1,2*j-2,2*k-1)]+f_f[IND_f(2*i-1,2*j-2,2*k)]+f_f[IND_f(2*i-1,2*j-1,2*k)]
				 +f_f[IND_f(2*i-2,2*j-1,2*k-1)]+f_f[IND_f(2*i-2,2*j-2,2*k-1)]+f_f[IND_f(2*i-2,2*j-2,2*k)]+f_f[IND_f(2*i-2,2*j-1,2*k)])/8.0;
				 
		   if(psic+fcc > em61 && psic>em6 && fcc>em6) 
				xmuxy[IJK]=xmuf1; //solid+water CVs
		   else {
			    fc=(fvar[IND_f(2*i-1,2*j-1,2*k-1)]+fvar[IND_f(2*i-1,2*j-2,2*k-1)]+fvar[IND_f(2*i-1,2*j-2,2*k)]+fvar[IND_f(2*i-1,2*j-1,2*k)]
				   +fvar[IND_f(2*i-2,2*j-1,2*k-1)]+fvar[IND_f(2*i-2,2*j-2,2*k-1)]+fvar[IND_f(2*i-2,2*j-2,2*k)]+fvar[IND_f(2*i-2,2*j-1,2*k)])/8.0;
		        xmuxy[IJK]=xmuf1*xmuf2/(fc*xmuf2+(1.0-fc)*xmuf1+tiny);
		   } 
#endif
		  }
	  }	
}

void fine2stnd()
{	
	int i,j,k;
	//on the standard grid
	for(k=1;k<km1;k++)//REAL cells
		for(j=1;j<jm1;j++)
			for(i=1;i<im1;i++)
				f[IJK]=0.125e0*(f_f[IND_f(2*i,2*j,2*k)]+f_f[IND_f(2*i-1,2*j,2*k)]+f_f[IND_f(2*i-1,2*j-1,2*k)]+f_f[IND_f(2*i,2*j-1,2*k)]
				+f_f[IND_f(2*i,2*j,2*k-1)]+f_f[IND_f(2*i-1,2*j,2*k-1)]+f_f[IND_f(2*i-1,2*j-1,2*k-1)]+f_f[IND_f(2*i,2*j-1,2*k-1)]);
}
#endif

			