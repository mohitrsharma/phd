#include "ripple.h"
#include <stdlib.h>
#include <time.h>
#include "testing.h"

/******************************************************************************
This subroutine INTERP interpolates temperature dependent variables to find
values at a specific temperature

Subroutine INTERP is called by:	SETPROPERTIES

Subroutine INTERP calls:

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

- Crated this subroutine for interpolation			Babak		Sep 13 2009


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE

*******************************************************************************/

double interp (double *array1, double *array2, double value1)
{
	int i,k,nvar;
	double value2;

	if(array1 == FLUID1_T)
		nvar = nFLUID1;
	else
		nvar = nFLUID2;
	
	if (nvar == 1)
	{
		value2 = array2[0];
		return value2;
	}

	for (i=0; i<nvar-1; i++)
	{
		k = -1;

		if (value1 < array1[0]) k = 0;
		if (value1 >= array1[i] && value1 <= array1[i+1]) k = i;
		if (value1 > array1[nvar-1]) k = nvar-2;
		if (k >= 0) 
		{
			value2 = array2[k]+(array2[k+1]-array2[k])*(value1-array1[k])/(array1[k+1]-array1[k]);
			return value2;
		}
	}

}
