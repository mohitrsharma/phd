#include "ripple.h"
#include <stdlib.h>
#include "comm.h"
#include <string.h>
#include "testing.h"

/******************************************************************************
This subroutine sets thermal boundary conditions on the 6 real faces of the 
numerical domain.  There are currently 2 types of boundary conditions that are
implemented in P3PPLE, and they are set by setting appropriate ke value in
the INPUT file.

ke  BC
------
1   Known temperature
2   Known flux

mpi.Neighbors[index] array is defined as follows

Index   Side
------------
0       Left
1       Right
2       Back
3       Front
4       Under
5       Over

If mpi.Neighbors[index]= -1 that means that the processor has a real and
not virtual boundary accross that face

Subroutine BCE is called by: DIFFUSION, SETUP

Subroutine BCE calls:

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION                                         NAME        DATE

- Subroutine modified for variable properties		Babak		Sep 14 2009
  
- Subroutine added									Babak		May 15 2009
  
_________________________________TO DO LIST____________________________________

DESCRIPTION                                         NAME        DATE


*******************************************************************************/


void bce()
{
	
    //Use of temp is ok. 
    //temp[20] is only used in convect, but temp[20] is overwritten immediately after bc returns.
    //(i.e. temp[20] need not be preserved)

    int i,j,k;
    int *neighs = (int*)temp[12];
    double cpTf1,cpTf2,ff1,ff2;

    memset (neighs, 0, NX*NY*NZ*sizeof(int));

    /*LEFT FACE*/
    if (mpi.Neighbors[0] == -1)
    {
        for(j=0;j<jmax;j++)
            for(k=0;k<kmax;k++)
            {
                const int ijkl = IND(0, j, k);

                if (kel == 1)                /*Known TMP*/
                {
					tmp[ijkl] = bcvl;
					rho[ijkl] = rho[ijkl+1];

					ff1 = f[ijkl]*rhof1/rho[ijkl];
					ff2 = (1.0-f[ijkl])*rhof2/rho[ijkl];
					if (VARPROP)
					{
						cpTf1 = interp(FLUID1_T,FLUID1_Cp,tmp[ijkl]);
						cpTf2 = interp(FLUID2_T,FLUID2_Cp,tmp[ijkl]);
					}
					else
					{
						cpTf1 = cpf1;
						cpTf2 = cpf2;
					}	

					h[ijkl] = ff1*cpTf1*tmp[ijkl]+ff2*(h0f2+cpTf2*tmp[ijkl]);
                }           
                else if (kel == 2)           /*Known Flux*/
                {
					tmp[ijkl] = tmp[ijkl+1];
					h[ijkl] = h[ijkl+1];
                }
                else
                {
                    printf("Error in kel\n");
                    exit(0);
                }           
            }
			done_LeftBC: ;
    }

    /*RIGHT FACE*/
    if (mpi.Neighbors[1] == -1)
    {
        for (j=0;j<jmax;j++)
            for (k=0;k<kmax;k++)
            {
                const int ijkr = IND(im1, j, k);

                if (ker == 1)
                {
					tmp[ijkr] = bcvr;
					rho[ijkr] = rho[ijkr-1];
			
					ff1 = f[ijkr]*rhof1/rho[ijkr];
					ff2 = (1.0-f[ijkr])*rhof2/rho[ijkr];
					if (VARPROP)
					{
						cpTf1 = interp(FLUID1_T,FLUID1_Cp,tmp[ijkr]);
						cpTf2 = interp(FLUID2_T,FLUID2_Cp,tmp[ijkr]);
					}
					else
					{
						cpTf1 = cpf1;
						cpTf2 = cpf2;
					}	

					h[ijkr] = ff1*cpTf1*tmp[ijkr]+ff2*(h0f2+cpTf2*tmp[ijkr]);
                }           
                else if (ker == 2) 
                {
					tmp[ijkr] = tmp[ijkr-1];
					h[ijkr] = h[ijkr-1];
                }
                else
                {
                    printf("Error with ker\n");
                    exit(0);
                }
            }
			done_RightBC: ;
    }
    
    /*BACK FACE*/
    if (mpi.Neighbors[2] == -1)
    {
        for (i=0;i<imax;i++)
            for (k=0;k<kmax;k++)
            {
                const int ijkb = IND(i, 0, k);

                if (keb == 1) 
                {
					tmp[ijkb] = bcvb;
					rho[ijkb] = rho[ijkb+imax];
			
					ff1 = f[ijkb]*rhof1/rho[ijkb];
					ff2 = (1.0-f[ijkb])*rhof2/rho[ijkb];
					if (VARPROP)
					{
						cpTf1 = interp(FLUID1_T,FLUID1_Cp,tmp[ijkb]);
						cpTf2 = interp(FLUID2_T,FLUID2_Cp,tmp[ijkb]);
					}
					else
					{
						cpTf1 = cpf1;
						cpTf2 = cpf2;
					}	

					h[ijkb] = ff1*cpTf1*tmp[ijkb]+ff2*(h0f2+cpTf2*tmp[ijkb]);
                }           
                else if (keb == 2)
                {
					tmp[ijkb] = tmp[ijkb+imax];
					h[ijkb] = h[ijkb+imax];
                }
                else
                {
                    printf("Error with keb\n");
                    exit(0);
                }
            }
			done_BackBC: ;
    }

    /*FRONT FACE*/
    if (mpi.Neighbors[3] == -1)
    {
        for (i=0;i<imax;i++)
            for (k=0;k<kmax;k++)
            {
                const int ijkf = IND(i, jm1, k);

                if (kef == 1)
                {
					tmp[ijkf] = bcvf;
					rho[ijkf] = rho[ijkf-imax];
			
					ff1 = f[ijkf]*rhof1/rho[ijkf];
					ff2 = (1.0-f[ijkf])*rhof2/rho[ijkf];
					if (VARPROP)
					{
						cpTf1 = interp(FLUID1_T,FLUID1_Cp,tmp[ijkf]);
						cpTf2 = interp(FLUID2_T,FLUID2_Cp,tmp[ijkf]);
					}
					else
					{
						cpTf1 = cpf1;
						cpTf2 = cpf2;
					}	

					h[ijkf] = ff1*cpTf1*tmp[ijkf]+ff2*(h0f2+cpTf2*tmp[ijkf]);
                }           
                else if (kef == 2)
                {
					tmp[ijkf] = tmp[ijkf-imax];
					h[ijkf] = h[ijkf-imax];
                }
                else
                {
                    printf("Error in kef\n");
                    exit(0);
                }
            }
			done_FrontBC: ;
    }

    /*UNDER FACE*/
    if (mpi.Neighbors[4] == -1)
    {
        for (i=0;i<imax;i++)
            for (j=0;j<jmax;j++)
            {
                const int ijku = IND( i, j, 0 );

                if (keu == 1)
                {
					tmp[ijku] = bcvu;
					rho[ijku] = rho[ijku+ijmax];
			
					ff1 = f[ijku]*rhof1/rho[ijku];
					ff2 = (1.0-f[ijku])*rhof2/rho[ijku];
					if (VARPROP)
					{
						cpTf1 = interp(FLUID1_T,FLUID1_Cp,tmp[ijku]);
						cpTf2 = interp(FLUID2_T,FLUID2_Cp,tmp[ijku]);
					}
					else
					{
						cpTf1 = cpf1;
						cpTf2 = cpf2;
					}	

					h[ijku] = ff1*cpTf1*tmp[ijku]+ff2*(h0f2+cpTf2*tmp[ijku]);
                }           
                else if (keu == 2)
                {
					tmp[ijku] = tmp[ijku+ijmax];
					h[ijku] = h[ijku+ijmax];
                }
                else
                {
                    printf("Error in keu\n");
                    exit(0);
                }
            }
			done_UnderBC: ;
    }

    /*OVER FACE*/
    if (mpi.Neighbors[5] == -1)
    {
        for (i=0;i<imax;i++)
            for (j=0;j<jmax;j++)
            {
                const int ijko = IND(i, j, km1);

                if  (keo == 1)
                {
					tmp[ijko] = bcvo;
					rho[ijko] = rho[ijko-ijmax];
			
					ff1 = f[ijko]*rhof1/rho[ijko];
					ff2 = (1.0-f[ijko])*rhof2/rho[ijko];
					if (VARPROP)
					{
						cpTf1 = interp(FLUID1_T,FLUID1_Cp,tmp[ijko]);
						cpTf2 = interp(FLUID2_T,FLUID2_Cp,tmp[ijko]);
					}
					else
					{
						cpTf1 = cpf1;
						cpTf2 = cpf2;
					}	

					h[ijko] = ff1*cpTf1*tmp[ijko]+ff2*(h0f2+cpTf2*tmp[ijko]);
                }
                else if (keo == 2) 
                {
					tmp[ijko] = tmp[ijko-ijmax];
					h[ijko] = h[ijko-ijmax];
                }
                else 
                {
                    printf("Error in keo\n");
                    exit(1);
                }
            }
			done_OverBC: ;
    }

    /*Exchange tmp and h accros virtual boundaries...*/
    xchg<double>(tmp);
    xchg<double>(h);
}
    
