#include "ripple.h"
#include "comm.h"
#include "testing.h"

/******************************************************************************
This subroutine sets the f field of obstacle ghost cells equal to the f
field of fluid cells adjecent to them. (i.e. BC for VOF function of obstacles)

Subroutine BCFOBS is called by:	BCF

Subroutine MESHSET calls:	****

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Changed the subroutine so that loop only executes	Ben			May 14 2005
 if the current cell is the obstacle interface cell
-added pressure condition for ghots cells of obst	Ben			May 04 2005
-Wrote the body of bcfobs function					Ben			May 03 2005
-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/
void bcfobs()
{
	int i, j, k;
	for(k = 1; k < km1; k++)
		for(j = 1; j < jm1; j++)
			for(i = 1; i < im1; i++)
			{
				/*if current cell is the obstacle surface cell*/
				if(isobstsfc(IJK))
				{
                    if (obst[IJK].flag_r)  /*if obstacle cell is to the RIGHT of fluid cell*/
						f[IJK] = f[IMJK];

                    if (obst[IJK].flag_l)  /*if obstacle cell is to the LEFT of fluid cell*/
						f[IJK] = f[IPJK];

                    if (obst[IJK].flag_f)  /*if obst. is in of the FRONT of fluid cell*/
						f[IJK] = f[IJMK];

                    if (obst[IJK].flag_b)  /*if obstacle cell is to the BACK of fluid cell*/
						f[IJK] = f[IJPK];

                    if (obst[IJK].flag_o)  /*if obstacle cell is OVER the fluid cell*/
					    f[IJK] = f[IJKM];

                    if (obst[IJK].flag_u)  /*if obstacle cell is UNDER the fluid cell*/
						f[IJK] = f[IJKP];
                }/*if(isobstsfc(IJK))*/
			}
}

#ifdef rudman_fine
void bcfobs_f()
{
	int i, j, k;
	for(k = 1; k < km1; k++)
		for(j = 1; j < jm1; j++)
			for(i = 1; i < im1; i++)
			{
				/*if current cell is the obstacle surface cell*/
				if(isobstsfc(IJK))
				{
                    if (obst[IJK].flag_r)  /*if obstacle cell is to the RIGHT of fluid cell*/
			  {
				f_f[IND_f(2*i-1,2*j,2*k)]=f_f[IND_f(2*i-2,2*j,2*k)];
				f_f[IND_f(2*i-1,2*j-1,2*k)]=f_f[IND_f(2*i-2,2*j-1,2*k)];
				f_f[IND_f(2*i-1,2*j-1,2*k-1)]=f_f[IND_f(2*i-2,2*j-1,2*k-1)];
				f_f[IND_f(2*i-1,2*j,2*k-1)]=f_f[IND_f(2*i-2,2*j,2*k-1)];
		     	  }

                    if (obst[IJK].flag_l)  /*if obstacle cell is to the LEFT of fluid cell*/
                    {
				f_f[IND_f(2*i,2*j,2*k)]=f_f[IND_f(2*i+1,2*j,2*k)];
				f_f[IND_f(2*i,2*j-1,2*k)]=f_f[IND_f(2*i+1,2*j-1,2*k)];
				f_f[IND_f(2*i,2*j-1,2*k-1)]=f_f[IND_f(2*i+1,2*j-1,2*k-1)];
				f_f[IND_f(2*i,2*j,2*k-1)]=f_f[IND_f(2*i+1,2*j,2*k-1)];	
			  }

                    if (obst[IJK].flag_f)  /*if obst. is in of the FRONT of fluid cell*/
                    {
				f_f[IND_f(2*i,2*j-1,2*k)]=f_f[IND_f(2*i,2*j-2,2*k)];
				f_f[IND_f(2*i-1,2*j-1,2*k)]=f_f[IND_f(2*i-1,2*j-2,2*k)]; 
				f_f[IND_f(2*i-1,2*j-1,2*k-1)]=f_f[IND_f(2*i-1,2*j-2,2*k-1)];
				f_f[IND_f(2*i,2*j-1,2*k-1)]=f_f[IND_f(2*i,2*j-2,2*k-1)];
			  }

                    if (obst[IJK].flag_b)  /*if obstacle cell is to the BACK of fluid cell*/
                    {
				  f_f[IND_f(2*i,2*j,2*k)]=f_f[IND_f(2*i,2*j+1,2*k)];
				  f_f[IND_f(2*i-1,2*j,2*k)]=f_f[IND_f(2*i-1,2*j+1,2*k)];
				  f_f[IND_f(2*i-1,2*j,2*k-1)]=f_f[IND_f(2*i-1,2*j+1,2*k-1)];
				  f_f[IND_f(2*i,2*j,2*k-1)]=f_f[IND_f(2*i,2*j+1,2*k-1)];
			  }

                    if (obst[IJK].flag_o)  /*if obstacle cell is OVER the fluid cell*/
                    {
				  f_f[IND_f(2*i,2*j,2*k-1)]=f_f[IND_f(2*i,2*j,2*k-2)];
				  f_f[IND_f(2*i-1,2*j,2*k-1)]=f_f[IND_f(2*i-1,2*j,2*k-2)];
				  f_f[IND_f(2*i-1,2*j-1,2*k-1)]=f_f[IND_f(2*i-1,2*j-1,2*k-2)];
				  f_f[IND_f(2*i,2*j-1,2*k-1)]=f_f[IND_f(2*i,2*j-1,2*k-2)];
			  }

                    if (obst[IJK].flag_u)  /*if obstacle cell is UNDER the fluid cell*/
                    {
				  f_f[IND_f(2*i,2*j,2*k)]=f_f[IND_f(2*i,2*j,2*k+1)];
				  f_f[IND_f(2*i-1,2*j,2*k)]=f_f[IND_f(2*i-1,2*j,2*k+1)];
				  f_f[IND_f(2*i-1,2*j-1,2*k)]=f_f[IND_f(2*i-1,2*j-1,2*k+1)];
				  f_f[IND_f(2*i,2*j-1,2*k)]=f_f[IND_f(2*i,2*j-1,2*k+1)];
			  }
                }/*if(isobstsfc(IJK))*/
			}
}
#ifdef __solid
void bcpsiobs_f()
{
	int i, j, k;
	for(k = 1; k < km1; k++)
		for(j = 1; j < jm1; j++)
			for(i = 1; i < im1; i++)
			{
				/*if current cell is the obstacle surface cell*/
				if(isobstsfc(IJK))
				{
                    if (obst[IJK].flag_r)  /*if obstacle cell is to the RIGHT of fluid cell*/
			  {
				psi_f[IND_f(2*i-1,2*j,2*k)]=psi_f[IND_f(2*i-2,2*j,2*k)];
				psi_f[IND_f(2*i-1,2*j-1,2*k)]=psi_f[IND_f(2*i-2,2*j-1,2*k)];
				psi_f[IND_f(2*i-1,2*j-1,2*k-1)]=psi_f[IND_f(2*i-2,2*j-1,2*k-1)];
				psi_f[IND_f(2*i-1,2*j,2*k-1)]=psi_f[IND_f(2*i-2,2*j,2*k-1)];
		     	  }

                    if (obst[IJK].flag_l)  /*if obstacle cell is to the LEFT of fluid cell*/
                    {
				psi_f[IND_f(2*i,2*j,2*k)]=psi_f[IND_f(2*i+1,2*j,2*k)];
				psi_f[IND_f(2*i,2*j-1,2*k)]=psi_f[IND_f(2*i+1,2*j-1,2*k)];
				psi_f[IND_f(2*i,2*j-1,2*k-1)]=psi_f[IND_f(2*i+1,2*j-1,2*k-1)];
				psi_f[IND_f(2*i,2*j,2*k-1)]=psi_f[IND_f(2*i+1,2*j,2*k-1)];	
			  }

                    if (obst[IJK].flag_f)  /*if obst. is in of the FRONT of fluid cell*/
                    {
				psi_f[IND_f(2*i,2*j-1,2*k)]=psi_f[IND_f(2*i,2*j-2,2*k)];
				psi_f[IND_f(2*i-1,2*j-1,2*k)]=psi_f[IND_f(2*i-1,2*j-2,2*k)]; 
				psi_f[IND_f(2*i-1,2*j-1,2*k-1)]=psi_f[IND_f(2*i-1,2*j-2,2*k-1)];
				psi_f[IND_f(2*i,2*j-1,2*k-1)]=psi_f[IND_f(2*i,2*j-2,2*k-1)];
			  }

                    if (obst[IJK].flag_b)  /*if obstacle cell is to the BACK of fluid cell*/
                    {
				  psi_f[IND_f(2*i,2*j,2*k)]=psi_f[IND_f(2*i,2*j+1,2*k)];
				  psi_f[IND_f(2*i-1,2*j,2*k)]=psi_f[IND_f(2*i-1,2*j+1,2*k)];
				  psi_f[IND_f(2*i-1,2*j,2*k-1)]=psi_f[IND_f(2*i-1,2*j+1,2*k-1)];
				  psi_f[IND_f(2*i,2*j,2*k-1)]=psi_f[IND_f(2*i,2*j+1,2*k-1)];
			  }

                    if (obst[IJK].flag_o)  /*if obstacle cell is OVER the fluid cell*/
                    {
				  psi_f[IND_f(2*i,2*j,2*k-1)]=psi_f[IND_f(2*i,2*j,2*k-2)];
				  psi_f[IND_f(2*i-1,2*j,2*k-1)]=psi_f[IND_f(2*i-1,2*j,2*k-2)];
				  psi_f[IND_f(2*i-1,2*j-1,2*k-1)]=psi_f[IND_f(2*i-1,2*j-1,2*k-2)];
				  psi_f[IND_f(2*i,2*j-1,2*k-1)]=psi_f[IND_f(2*i,2*j-1,2*k-2)];
			  }

                    if (obst[IJK].flag_u)  /*if obstacle cell is UNDER the fluid cell*/
                    {
				  psi_f[IND_f(2*i,2*j,2*k)]=psi_f[IND_f(2*i,2*j,2*k+1)];
				  psi_f[IND_f(2*i-1,2*j,2*k)]=psi_f[IND_f(2*i-1,2*j,2*k+1)];
				  psi_f[IND_f(2*i-1,2*j-1,2*k)]=psi_f[IND_f(2*i-1,2*j-1,2*k+1)];
				  psi_f[IND_f(2*i,2*j-1,2*k)]=psi_f[IND_f(2*i,2*j-1,2*k+1)];
			  }
                }/*if(isobstsfc(IJK))*/
			}
}
#endif
#endif
