#include "ripple.h"
#include "testing.h"
#include <string.h>
#include <math.h>
#include "rtc.h"
#include "itersolv.h"
#include <stdio.h>
#include <stdlib.h>

#include "comm.h"

/* ............................................................................................................................ */
#define CGITER 1	/* Set CGITER 0 for multigrid and 1 for CGITER solver */
//#define SETP
#define B1 -0
#define B2 -0
/******************************************************************************
Tis subroutine calculates the pressures, based on the u,v and w.

Subroutine IMPLCTP is called by:	RIPPLE

Subroutine IMPLCTP calls:	ACCEL, BC, BDYCELL

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changes are made


DESCRIPTION											NAME			DATE
-Changed criteria for when to prescribe internal 	L.Berard		January 17 2013
 obstacle BCs so that BCs are implemented properly 
 for all computational domain

-Interfaced CUDA PCGIM solver						S.Codyer		Dec. 15 2011

-Created this template for tracking changes			Ben				April 21 2005

_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME			DATE


*******************************************************************************/

// laspack globals used in lapack solver
#ifndef CUDA
QMatrix			lasA;					// coefficient matrix
Vector			lasx,lasb;				// solution vector and RHS vector for AX=B
size_t			lasDim;					// dimension of the system
void initlassolve(void);				// sets up matrix A...see bottom of IMPLCTP
void destroylassolv(void);				// destroys LASPACK matrices & vectors
#endif

void implctp()
{

//***********************INITIALIZE LASPACK*************************
    // local variables used in generating laspack system
	int entry;
	int	bf_offset,bo_offset;
	int itmxiccg = 10000; /*maximum CGIter iterations*/

	/*initialize laspack*/
	#ifndef CUDA
	if(CGITER)
		initlassolve();
	#endif
//***********************END INITIALIZE LASPACK**********************
	int i,j,k,row,trigger,count;
	double *a = temp[0]; 
	double *rhs = temp[1];
	double *bl = temp[2];
	double *br = temp[3];
	double *bb = temp[4];
	double *bf = temp[5];
	double *bu = temp[6];
	double *bo = temp[7];
	double *res = temp[8];
	double *t_div = temp[13];
#ifdef rudman_fine
	//double *rhorc=temp[18], *rhofc=temp[19], *rhooc=temp[20];
	rhorc=temp[18], rhofc=temp[19], rhooc=temp[20];
#endif

#ifdef balanced_force
	double *tensx=temp[9], *tensy=temp[10], *tensz=temp[11];
#endif
	
	memset (rhs, 0, NX*NY*NZ*sizeof(double));	//let rhs be 0 on undefined region.
	memset (res, 0, NX*NY*NZ*sizeof(double));

	memset (p, 0, NX*NY*NZ*sizeof(double));
	memset (t_div,0,NX*NY*NZ*sizeof(double)); //div-test
	
	//density_pressure(); //testing only now... ashish
	
	/*load matrix coefficients*/
	double po=0.0;
	double maxdv=0.0;
	double sumdiv=0.0;
	int c=0;
	//if(mpi.MyRank==0) printf("just before the first loop\n");
	for (k=1;k<km1;k++)
		for (j=1;j<jm1;j++)
			for (i=1;i<im1;i++)
			{
				/*reset a*/
				a[IJK] = 0.0;
				double div =(rdx[i]*(ar[IJK]*u[IJK]-ar[IMJK]*u[IMJK])
							+rdy[j]*(af[IJK]*v[IJK]-af[IJMK]*v[IJMK])
							+rdz[k]*(ao[IJK]*w[IJK]-ao[IJKM]*w[IJKM]));
#ifdef balanced_force
				double divsft =(rdx[i]*(ar[IJK]*tensx[IJK]/rhorc[IJK]-ar[IMJK]*tensx[IMJK]/rhorc[IMJK])
							+rdy[j]*(af[IJK]*tensy[IJK]/rhofc[IJK]-af[IJMK]*tensy[IJMK]/rhofc[IJMK])
							+rdz[k]*(ao[IJK]*tensz[IJK]/rhooc[IJK]-ao[IJKM]*tensz[IJKM]/rhooc[IJKM]));
#endif
				t_div[IJK]=div; //div-test
				if (fabs(div) < tiny) div=0.0;
				if (f[IJK]>em61)
				{
					maxdv = MAX(maxdv, fabs(div));
					sumdiv += fabs(div);
					c++;
				}

				if (rhorc[IMJK]==0 || rhorc[IJK]==0 || rhofc[IJMK]==0 ||
					rhofc[IJK]==0 || rhooc[IJKM]==0 || rhooc[IJK]==0)
				{
					//Division by zero of rho.
					printf ("%e\n", rhorc[IMJK]);
					printf ("%e\n", rhofc[IJMK]);
					printf ("%e\n", rhooc[IJKM]);
					printf ("%e\n", rhorc[IJK]);
					printf ("%e\n", rhofc[IJK]);
					printf ("%e\n", rhooc[IJK]);
					printf ("rho=0 div. by 0 %d %d %d\n", i,j,k);

					//record in summary file
					fprintf (files.summary,"%e\n", rhorc[IMJK]);
					fprintf (files.summary,"%e\n", rhofc[IJMK]);
					fprintf (files.summary,"%e\n", rhooc[IJKM]);
					fprintf (files.summary,"%e\n", rhorc[IJK]);
					fprintf (files.summary,"%e\n", rhofc[IJK]);
					fprintf (files.summary,"%e\n", rhooc[IJK]);

					//recover from division by zero...
					rhorc[IMJK] = MAX(rhorc[IMJK], 1e-25);
					rhofc[IJMK] = MAX(rhofc[IJMK], 1e-25);
					rhooc[IJKM] = MAX(rhooc[IJKM], 1e-25);
					rhorc[IJK] = MAX(rhorc[IJK], 1e-25);
					rhofc[IJK] = MAX(rhofc[IJK], 1e-25);
					rhooc[IJK] = MAX(rhooc[IJK], 1e-25);
				}
				if (fabs(div) > 1e+20)
				{
					printf ("div > 1e+20\n");
					printf (" %d: %d %d %d\n", mpi.MyRank, i,j,k);
					printf (" %.3e %.3e %.3e, %.3e %.3e %.3e\n", u[IJK], v[IJK], w[IJK], u[IMJK], v[IJMK], w[IJKM]);
					printf (" %.3e %.3e %.3e, %.3e %.3e %.3e\n", ar[IJK], af[IJK], ao[IJK], ar[IMJK], af[IJMK], ao[IJKM]);
					printf (" %.3e %.3e %.3e, f=%.3e\n\n", rdx[i], rdy[j], rdz[k], f[IJK]);

					//record in summary file
					fprintf (files.summary,"div > 1e+20\n");
					fprintf (files.summary," %d: %d %d %d\n", mpi.MyRank, i,j,k);
					fprintf (files.summary," %.3e %.3e %.3e, %.3e %.3e %.3e\n", u[IJK], v[IJK], w[IJK], u[IMJK], v[IJMK], w[IJKM]);
					fprintf (files.summary," %.3e %.3e %.3e, %.3e %.3e %.3e\n", ar[IJK], af[IJK], ao[IJK], ar[IMJK], af[IJMK], ao[IJKM]);
					fprintf (files.summary," %.3e %.3e %.3e, f=%.3e\n\n", rdx[i], rdy[j], rdz[k], f[IJK]);

					div = 0;
					exit(1);
				}
#ifndef balanced_force
				rhs[IJK] = -ac[IJK]*div/delt;
#endif

#ifdef balanced_force
				rhs[IJK] =-ac[IJK]*(div/delt + divsft);
#endif
				bl[IJK]=-0.5*ar[IMJK]/rhorc[IMJK]*rdx[i]*(rdx[i]+rdx[i-1]);
				br[IJK]=-0.5*ar[IJK]/rhorc[IJK]*rdx[i]*(rdx[i]+rdx[i+1]);
				bb[IJK]=-0.5*af[IJMK]/rhofc[IJMK]*rdy[j]*(rdy[j]+rdy[j-1]);
				bf[IJK]=-0.5*af[IJK]/rhofc[IJK]*rdy[j]*(rdy[j]+rdy[j+1]);
				bu[IJK]=-0.5*ao[IJKM]/rhooc[IJKM]*rdz[k]*(rdz[k]+rdz[k-1]);
				bo[IJK]=-0.5*ao[IJK]/rhooc[IJK]*rdz[k]*(rdz[k]+rdz[k+1]);
				

				/*internal obstacle boundaries (enforce Neumann conditions)*/
				if (ac[IJK] >=em6)
				{
					/*if obstacle cell to the LEFT of fluid cell*/
					if (ac[IMJK]<em6 && ((mpi.Neighbors[0] != -1) || i > 1))
						bl[IJK]=B1;
					/*if obstacle cell to the RIGHT of fluid cell*/
					if (ac[IPJK]<em6 && ((mpi.Neighbors[1] != -1) || i < im2))
						br[IJK]=B1;
					/*if obstacle cell to the BACK of fluid cell*/
					if (ac[IJMK]<em6 && ((mpi.Neighbors[2] != -1) || j > 1))
						bb[IJK]=B1;
					/*if obstacle cell to the FRONT of fluid cell*/
					if (ac[IJPK]<em6 && ((mpi.Neighbors[3] != -1) || j < jm2))
						bf[IJK]=B1;
					/*if obstacle cell to the UNDER of fluid cell*/
					if (ac[IJKM]<em6 && ((mpi.Neighbors[4] != -1) || k > 1))
						bu[IJK]=B1;
					/*if obstacle cell to the OVER of fluid cell*/
					if (ac[IJKP]<em6 && ((mpi.Neighbors[5] != -1) || k < km2))
						bo[IJK]=B1;

					/*boundary conditions*/
					/*real boundary on LEFT face*/
					if (mpi.Neighbors[0]==-1 && i==1)
					{
						if (kl < 3)
							bl[IJK] = B1;
						else
						{
							a[IJK] -= bl[IJK];
							bl[IJK] = B1;
						}
					}
					/*real boundary on RIGHT face*/
					if (mpi.Neighbors[1]==-1 && i==im2)
					{
						if (kr < 3)
							br[IJK] = B1;
						else
						{
							a[IJK] -= br[IJK];
							br[IJK] = B1;
						}
					}
					/*real boundary on BACK face*/
					if (mpi.Neighbors[2]==-1 && j==1)
					{
						if (kb < 3)
							bb[IJK] = B1;
						else
						{
							a[IJK] -= bb[IJK];
							bb[IJK] = B1;
						}
					}
					/*real boundary on FRONT face*/
					if (mpi.Neighbors[3]==-1 && j==jm2)
					{
						if (kf < 3)
							bf[IJK] = B1;
						else
						{
							a[IJK] -= bf[IJK];
							bf[IJK] = B1;
						}
					}
					/*real boundary on UNDER face*/
					if (mpi.Neighbors[4]==-1 && k==1)
					{
						if (ku < 3)
							bu[IJK] = B1;
						else
						{
							a[IJK] -= bu[IJK];
							bu[IJK] = B1;
						}
					}
					/*real boundary on OVER face*/
					if (mpi.Neighbors[5]==-1 && k==km2)
					{
						if (ko < 3)
							bo[IJK] = B1;
						else
						{
							a[IJK] -= bo[IJK];
							bo[IJK] = B1;
						}
					}
					if (BUBBLE && bubble[IJK].current)
					{
						/*don't solve pressure inside bubble
						*/
						a[IJK] = 1e+50;
						continue;
					}
					a[IJK] += -(bl[IJK]+br[IJK]+bb[IJK]+bf[IJK]+bu[IJK]+bo[IJK]);
				}
				else
				{
				/*cell IJK is obstacle cell so don't calculate pressure for it*/
					a[IJK] = 1e+50;
				}/*if ac[IJK] >= em6*/
	}
	//if(mpi.MyRank==0) printf("after the first loop\n");
/*
	if (mpi.Neighbors[5]==-1) {
		k = km2;
		po = 0.0;
		for (j=1;j<jm1;j++)
			for (i=1;i<im1;i++)
			{	
				a[IJK] = 1.0;
				bl[IJK] = br[IJK] = bb[IJK] = bf[IJK] = bu[IJK] = bo[IJK] = 0.0;
				rhs[IJK] = po; //set gage pressure to 0
	
				rhs[IJKM] -= bo[IJKM] * po;
				bo[IJKM] = 0.0;
	
				rhs[IJKP] -= bu[IJKP] * po;
				bu[IJKP] = 0.0;
			}
	}
*/
	xchg<double> (rhs);

	if (mpi.MyRank ==0)
		printf("MaxDivb=%e, avdiv=%e\n", maxdv,sumdiv/(c+tiny));
	//record in summary file
	fprintf(files.summary,"MaxDivb=%e, avdiv=%e\n", maxdv,sumdiv/(c+tiny));

	unsigned int st = wtime();
	double nrm;
	int t1, t2;
	
	int ressize=NX*NY*NZ*sizeof(double);
	int nmtotal;
    if (mpi.NProc > 1) {
		nmtotal = imax*jmax*kmax+1;
		t1 = imax;
		t2 = (imax)*(jmax);
	}
	else {
		nmtotal = im2*jm2*km2+1;
		t1 = im2;
		t2 = (im2)*(jm2);
	}
	
	#ifdef CUDA
		int non_zeros 		= 7*(nmtotal-1) - 2 - 2*t1 - 2*t2;
		//int *A_row 			= (int*)malloc((nmtotal-1)*sizeof(*A_row));
		//int *A_col 			= (int*)malloc(non_zeros*sizeof(*A_col));
		//double *A_val 		= (double*)malloc(non_zeros*sizeof(*A_val));
		//double *jacobi_a 	= (double*)malloc((nmtotal-1)*sizeof(*jacobi_a));	
		//double *CUDA_RHS 	= (double*)malloc((nmtotal-1)*sizeof(*CUDA_RHS));
		//double *X 			= (double*)malloc((nmtotal-1)*sizeof(*X));
	#endif

/*	int cell = 0;
//	for(i=0;i<imax;i++)
	for(k=0;k<kmax;k++)
	for(j=0;j<jmax;j++)
	for(i=0;i<imax;i++)
	{
		cell++;
		if (a[IJK] != 0)
			fprintf(files.out,"a[%3d]= %5.4f  rhs[%3d]= %5.4f\n",IJK,a[IJK],IJK,rhs[IJK]);
	}

    exit(1);*/
//**********************************************************************
//****************2 SOLVERS CODE ***************************************


	if(!CGITER)			/* Call MG solver */
  	{
		mg (p, rhs, a, bl, br, bb, bf, bu, bo);			/* Do multigrid */

		residue (&res, &ressize, p, a, rhs, bl, br,		/* Calculate residual */
				  bb, bf, bu, bo, NX, NY, NZ);
		nrm = normres (res, rhs, a, NX, NY, NZ);

		if (nrm > maxres)
		{
			if (npre <= 4 && npost <= 4 && ntop <= 4)
			{
				npre+=3;
				npost+=3;
				ntop+=3;
				fprintf (files.summary,"MG iterations increased. (%d %d %d)\n", npre, npost, ntop);
			}
			else if (mgcycles < 25)
			{
				mgcycles++;
				printf ("MG cycles increased. (%d)\n", mgcycles);
			}
			else if (npre <= 100 && npost <= 100 && ntop <= 200)
			{
				npre+=3;
				npost+=3;
				ntop+=3;
				fprintf (files.summary,"MG iterations increased. (%d %d %d)\n", npre, npost, ntop);
			}
			iter = 100;					/* want smaller timesteps */
		}
		else if (nrm > maxres/4)
		{
			if (npre <= 40 && npost <= 40 && ntop <= 50)
			{
				npre++;
				npost++;
				ntop++;
				fprintf (files.summary,"MG iterations increased. (%d %d %d)\n", npre, npost, ntop);
			}
			iter = 30;					/* want smaller timesteps */
		}
		else if (nrm < maxres/30)
		{
			if (npre > 4 && npost > 4 && ntop > 4)
			{
				npre--;
				npost--;
				ntop--;
				fprintf (files.summary,"MG iterations decreased. (%d %d %d)\n",npre, npost, ntop);
			}
			else if (mgcycles > minmgcycles)
			{
				mgcycles--;
				fprintf (files.summary,"MG cycles decreased. (%d)\n", mgcycles);
			}
			else if(npre > 2 && npost > 2 && ntop > 2)
			{
				npre--;
				npost--;
				ntop--;
				fprintf (files.summary,"MG iterations decreased. (%d %d %d)\n",npre, npost, ntop);
			}
			iter = 0;	 				/* Want larger timesteps if possible */
		}
		int extracount=0;
		while (nrm > maxres)
		{
			mgv (p, rhs, a, bl, br, bb, bf, bu, bo);
			int ressize=NX*NY*NZ*sizeof(double);
			residue (&res, &ressize, p, a, rhs, bl, br, bb, bf, bu, bo, NX, NY, NZ);
			nrm = normres (res, rhs, a, NX, NY, NZ);
			fprintf (files.summary,"Extra V-cycle residual: %.4e\n", nrm);
			if (extracount++ >= 3 && maxres < nrm*1.01)
			{
				printf ("Giving up.\n");
				break;
			}
		}
  	}
	else/*use LASPACK*/
  	{
		#ifndef CUDA
			if (mpi.NProc > 1)
			{
				bf_offset	= imax;
				bo_offset	= imax*jmax;
				row		= 0;
				for(k=0;k<kmax;k++)
					for(j=0;j<jmax;j++)
						for(i=0;i<imax;i++)
						{
							row++;
							V_SetCmp(&lasb,row,rhs[IJK]);
							V_SetCmp(&lasx,row,p[IJK]);
							
							if (i==0 || j==0 || k==0)
							{
								Q_SetEntry(&lasA,row,0,row,1e50);
								continue;											/* Can skip ghost cells for matrix A */
							}
							if (i==im1 || j==jm1 || k==km1)
							{
								Q_SetEntry(&lasA,row,0,row,1e50);
								continue;
							}
							entry = 0;
							if((mpi.Neighbors[4] != -1) || k > 1)
							{
								Q_SetEntry(&lasA,row,entry,row-bo_offset,bu[IJK]);	/* set bu */
								entry++;
							}
							if((mpi.Neighbors[2] != -1) || j > 1)
							{
								Q_SetEntry(&lasA,row,entry,row-bf_offset,bb[IJK]);	/* set bb */
								entry++;
							}
							if((mpi.Neighbors[0] != -1) || i > 1)
							{
								Q_SetEntry(&lasA,row,entry,row-1,bl[IJK]);			/* set bl */
								entry++;
							}
																					/* middle diagonal always exists, set it */
							Q_SetEntry(&lasA,row,entry,row,a[IJK]);					/* set a */
							entry++;

							if((mpi.Neighbors[1] != -1) || i < im2)
							{
								Q_SetEntry(&lasA,row,entry,row+1,br[IJK]);			/* set br */
								entry++;
							}
							if((mpi.Neighbors[3] != -1) || j < jm2)
							{
								Q_SetEntry(&lasA,row,entry,row+bf_offset,bf[IJK]);	/* set bf */
								entry++;
							}
							if((mpi.Neighbors[5] != -1) || k < km2)
							{
								Q_SetEntry(&lasA,row,entry,row+bo_offset,bo[IJK]);	/* set bo */
								entry++;
							}
						}/*for IJK*/
			}/*if (mpi.NProc > 1)*/
			else
			{
				bf_offset	= im2;
				bo_offset	= im2*jm2;
				row 		= 0;
				for(k=1;k<km1;k++)
					for(j=1;j<jm1;j++)
						for(i=1;i<im1;i++)
						{
							row++;
							V_SetCmp(&lasb,row,rhs[IJK]);
							V_SetCmp(&lasx,row,p[IJK]);

							entry = 0;
							/*set UNDER diagonal*/
							if(k > 1)
							{
								Q_SetEntry(&lasA,row,entry,row-bo_offset,bu[IJK]);
								entry++;
							}
							/*set BACK diagonal*/
							if(j > 1)
							{
								Q_SetEntry(&lasA,row,entry,row-bf_offset,bb[IJK]);
								entry++;
							}
							/*set LEFT diagonal*/
							if(i > 1)
							{
								Q_SetEntry(&lasA,row,entry,row-1,bl[IJK]);
								entry++;
							}
							/*set MIDDLE diagonal*/
							Q_SetEntry(&lasA,row,entry,row,a[IJK]);
							entry++;
							/*set RIGHT diagonal*/
							if(i < im2)
							{
								Q_SetEntry(&lasA,row,entry,row+1,br[IJK]);
								entry++;
							}
							/*set FRONT diagonal*/
							if(j < jm2)
							{
								Q_SetEntry(&lasA,row,entry,row+bf_offset,bf[IJK]);
								entry++;
							}
							/*set OVER diagonal*/
							if(k < km2)
							{
								Q_SetEntry(&lasA,row,entry,row+bo_offset,bo[IJK]);
								entry++;
							}
						}/*for IJK*/
			}/*if (mpi.NProc > 1)*/
		#endif
		#ifdef CUDA //CUDA PCGIM solver
			row	= 0;
			count	= 0;
			if (mpi.NProc > 1)
			{
				bf_offset	= imax;
				bo_offset	= imax*jmax;
				for(k=0;k<kmax;k++) {
					for(j=0;j<jmax;j++) {
						for(i=0;i<imax;i++) {

							trigger	= 0;
							CUDA_RHS[row] = rhs[IJK];
							X[row] = p[IJK];

							if (i==0 || j==0 || k==0)
							{
								A_val[count] = 1e50;
								A_col[count] = row;
								A_row[row] = count;
								count++;
								jacobi_a[row] = 0.0;
								row ++;
								continue;									/* Can skip ghost cells for matrix A */
							}
							if (i==im1 || j==jm1 || k==km1)
							{
								A_val[count] = 1e50;
								A_col[count] = row;
								A_row[row] = count;
								count++;
								jacobi_a[row] = 0.0;
								row ++;
								continue;
							}
							if((mpi.Neighbors[4] != -1) || k > 1)
							{
								A_val[count] = bu[IJK];
								A_col[count] = row-bo_offset;
								A_row[row] = count;
								trigger = 1;
								count++;
							}
							if((mpi.Neighbors[2] != -1) || j > 1)
							{
								A_val[count] = bb[IJK];
								A_col[count] = row-bf_offset;
								if (trigger == 0) {
									A_row[row] = count;
									trigger = 1;
								}
								count++;
							}
							if((mpi.Neighbors[0] != -1) || i > 1)
							{
								A_val[count] = bl[IJK];
								A_col[count] = row-1;
								if (trigger == 0) {
									A_row[row] = count;
									trigger = 1;
								}
								count++;
							}
																					/* middle diagonal always exists, set it */
							jacobi_a[row] = 1.0 / a[IJK];
							A_val[count] = a[IJK];
							A_col[count] = row;
							if (trigger == 0) {
								A_row[row] = count;
								trigger = 1;
							}
							count++;

							if((mpi.Neighbors[1] != -1) || i < im2)
							{
								A_val[count] = br[IJK];
								A_col[count] = row+1;
								if (trigger == 0) {
									A_row[row] = count;
									trigger = 1;
								}
								count++;
							}
							if((mpi.Neighbors[3] != -1) || j < jm2)
							{
								A_val[count] = bf[IJK];
								A_col[count] = row+bf_offset;
								if (trigger == 0) {
									A_row[row] = count;
									trigger = 1;
								}
								count++;
							}
							if((mpi.Neighbors[5] != -1) || k < km2)
							{
								A_val[count] = bo[IJK];
								A_col[count] = row+bo_offset;
								if (trigger == 0) {
									A_row[row] = count;
									trigger = 1;
								}
								count++;
							}
							row ++;
						}/*for IJK*/
					}
				}
			}/*if (mpi.NProc > 1)*/
			else
			{
			bf_offset	= im2;
			bo_offset	= im2*jm2;
			for(k=1;k<km1;k++)
				for(j=1;j<jm1;j++)
					for(i=1;i<im1;i++)
					{
						trigger		= 0;
						CUDA_RHS[row] = rhs[IJK];
						X[row] = p[IJK];

						if(k > 1)
						{
							A_val[count] = bu[IJK];
							A_col[count] = row-bo_offset;
							if (trigger == 0) {
								A_row[row] = count;
								trigger = 1;
							}
							count++;
						}
						if(j > 1)
						{
							A_val[count] = bb[IJK];
							A_col[count] = row-bf_offset;
							if (trigger == 0) {
								A_row[row] = count;
								trigger = 1;
							}
							count++;
						}
						if(i > 1)
						{
							A_val[count] = bl[IJK];
							A_col[count] = row-1;
							if (trigger == 0) {
								A_row[row] = count;
								trigger = 1;
							}
							count++;
						}
						
						jacobi_a[row] = 1 / a[IJK];
						A_val[count] = a[IJK];
						A_col[count] = row;
						if (trigger == 0) {
							A_row[row] = count;
							trigger = 1;
						}
						count++;

						if(i < im2)
						{
							A_val[count] = br[IJK];
							A_col[count] = row+1;
							if (trigger == 0) {
								A_row[row] = count;
								trigger = 1;
							}
							count++;
						}
						if(j < jm2)
						{
							A_val[count] = bf[IJK];
							A_col[count] = row+bf_offset;
							if (trigger == 0) {
								A_row[row] = count;
								trigger = 1;
							}
							count++;
						}
						if(k < km2)
						{
							A_val[count] = bo[IJK];
							A_col[count] = row+bo_offset;
							if (trigger == 0) {
								A_row[row] = count;
								trigger = 1;
							}
							count++;
						}
						row ++;
					}/*for IJK*/
			}/*if (mpi.NProc > 1)*/
		A_row[row] = count;
		#endif

#ifdef SETP
#ifdef CUDA
	printf("SETP Not Implemented\n");
#endif
#ifndef CUDA
		printf("\n\nUSED SETP\n\n");
		row=1;
		Q_SetEntry(&lasA,row,1,row+1,0);
		Q_SetEntry(&lasA,row,2,row+bf_offset,0);
		Q_SetEntry(&lasA,row,3,row+bo_offset,0);
		V_SetCmp(&lasb,row,3*0);
#endif
#endif

/*		for(row = 1; row < nmtotal; row++)
			for(int col = 1; col < nmtotal; col++)
				if(Q_GetEl(&lasA,row,col) != 0.0)
					fprintf(files.out,"A[%3d][%3d] -> %6.4e\tb[%3d] ->%6.4f\n",row,col,Q_GetEl(&lasA,row,col),row,V_GetCmp(&lasb,row));

		exit(1);*/

		// perform conjugate gradient iteration
		int itericcg;// = itmxiccg

#ifdef CUDA //CUDA PCGIM solver
		itericcg = itmxiccg;
		cgitj_gpu(A_val, A_row, A_col, jacobi_a, row, count, X, CUDA_RHS, &itericcg, maxres);
#endif
#ifndef CUDA	
		CGIter(&lasA, &lasx, &lasb, itmxiccg, JacobiPrecond, 1.0,&itericcg);
#endif


		//bar(); tecpf(); bar(); 
		
  		if(itericcg >= itmxiccg)
		{
			if (mpi.MyRank == 0)
	     		printf("IMPLCTP pressure solution for cycle \n %5d\t time %2.5e,did not converge after %5d iterations\n", ncyc, t, itericcg);
     		fprintf(files.summary,"IMPLCTP pressure solution for cycle \n %5d\t time %2.5e,did not converge after %5d iterations\n", ncyc, t, itericcg);
			exit(1);
    		}
		else
		{
			if (mpi.MyRank == 0)
				printf("Converged after %d iterations.\n", itericcg);
			fprintf(files.summary,"Converged after %d iterations\n", itericcg);

		}
		if (mpi.NProc > 1)
		{
			row = 0;//reset row to 0
			for(k=0;k<kmax;k++)
				for(j=0;j<jmax;j++)
					for(i=0;i<imax;i++)
					{
						#ifndef CUDA
						row++;
						p[IJK] = V_GetCmp(&lasx,row);
						#endif
						#ifdef CUDA
						p[IJK] = X[row];
						row++;
						#endif
						//fprintf(files.out,"p[%3d] -> %f\n",IJK,p[IJK]);
					}
		 }/*if (mpi.NProc > 1)*/
		else
		{
			row = 0;//reset row to 0
			for(k=1;k<km1;k++)
				for(j=1;j<jm1;j++)
					for(i=1;i<im1;i++)
					{
						#ifndef CUDA
						row++;
						p[IJK] = V_GetCmp(&lasx,row);
						#endif
						#ifdef CUDA
						p[IJK] = X[row];
						row++;
						#endif
						//fprintf(files.out,"p[%d] -> %f\n",IJK,p[IJK]);
					}
		 }/*if (mpi.NProc > 1)*/
	}/*if(!CGITER)*/
//	if (ncyc == 1) exit(1);
	/******************END OF 2 SOLVER CODE********************************/

	/*destroy LASPACK*/
	#ifndef CUDA
	if(CGITER)
		destroylassolv();
	#endif

	#ifdef CUDA
		//free(A_row);
		//free(A_col);
		//free(A_val);
		//free(jacobi_a);
		//free(CUDA_RHS);
		//free(X);
	#endif
	
#ifdef two_dim
	for(j=2;j<jm1;j++) 
	 for(i=1;i<im1;i++)
	  for(k=1;k<km1;k++) {
		  p[IND(i,j,k)] = p[IND(i,1,k)];
	  }
#endif
	  
	bc();		//bc call added by LRB so that complete pressure information is available for when accel is called - LRB 7/11/2012
   	bdycell();
	accel();
	bc();
}

#ifndef CUDA
void initlassolve(void)
{
	/*This function sets up the matrix A in Ax=b, as required
	 by LASPACK
	*/
	int bf_offset,bo_offset,i,j,k;
	int entry;
	int nmtotal;
    if (mpi.NProc > 1)
	{
		lasDim		= imax*jmax*kmax;
		nmtotal 	= lasDim +1;

		Q_Constr(&lasA, "A", lasDim, False, Rowws, Normal, True);
		V_Constr(&lasx, "x", lasDim, Normal, True);
		V_Constr(&lasb, "b", lasDim, Normal, True);

		/*set number of non-zero elements for each row of A*/
		int row = 0;
		for (k=0;k<kmax;k++)
			for (j=0;j<jmax;j++)
				for(i=0;i<imax;i++)
				{
					row++;
					/*can skip ghost cells for matrix A*/
					if (i==0 || j==0 || k==0)
					{
						Q_SetLen(&lasA,row,1);
						continue;
					}
					if (i==im1 || j==jm1 || k==km1)
					{
						Q_SetLen(&lasA,row,1);
						continue;
					}

					entry = 1;/*main diagonal always exists*/

					/*check if bl band exists in this row*/
					if((mpi.Neighbors[0] != -1) || i > 1)
						entry++;
					/*check if br band exists in this row*/
					if((mpi.Neighbors[1] != -1) || i < im2)
						entry++;
					/*check if bb band exists in this row*/
					if((mpi.Neighbors[2] != -1) || j > 1)
						entry++;
					/*check if bf band exists in this row*/
					if((mpi.Neighbors[3] != -1) || j < jm2)
						entry++;
					/*check if bu band exists in this row*/
					if((mpi.Neighbors[4] != -1) || k > 1)
						entry++;
					/*check if bo band exists in this row*/
					if((mpi.Neighbors[5] != -1) || k < km2)
						entry++;

					/*set the number of non-zero entries for row*/
					Q_SetLen(&lasA,row,entry);
	//				fprintf(files.out,"row(%d) -> %d\n",row,entry);
				}
	//			exit(1);
        }/*if (mpi.NProc > 1)*/
	else
	{
		bf_offset	= im2;
		bo_offset	= im2*jm2;
		lasDim		= im2*jm2*km2;		// size of the linear system
		nmtotal		= lasDim + 1;
		int i,j,k,row;

		Q_Constr(&lasA, "A", lasDim, False, Rowws, Normal, True);
		V_Constr(&lasx, "x", lasDim, Normal, True);
		V_Constr(&lasb, "b", lasDim, Normal, True);

		//set number of non-zero elements for each row of A
		row = 0;
		for (k=1;k<km1;k++)
			for (j=1;j<jm1;j++)
				for (i=1;i<im1;i++)
				{
					row++;
					entry = 1;
					/*check bl*/
					if (i > 1)
						entry++;
					/*check br*/
					if (i < im2)
						entry++;
					/*check bb*/
					if (j > 1)
						entry++;
					/*check bf*/
					if (j < jm2)
						entry++;
					/*check bu*/
					if (k > 1)
						entry++;
					/*check bo*/
					if (k < km2)
						entry++;

					/*now set the number of non-zero entries for row*/
					Q_SetLen(&lasA,row,entry);
				}
    }/*if (mpi.NProc > 1)*/
}

void destroylassolv(void)
{
	Q_Destr(&lasA);
	V_Destr(&lasx);
	V_Destr(&lasb);
}
#endif
