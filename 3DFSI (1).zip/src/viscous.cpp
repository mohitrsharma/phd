#include "ripple.h"
#include "testing.h"

/******************************************************************************


Subroutine VISCOUS is called by:	RIPPLE

Subroutine VISCOUS calls:	BC

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Changed the arrangement of the if statements which	Ben			May 24 2005
 makes the process more logical
-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/
#ifdef rudman_fine
void calc_axi_visc();
void calc_cross_visc();
#endif

void viscous()
{	//un,vn,wn changed to u,v and w ...according to consistent mass and momentum scheme
	double *const tauxx=temp[0];
	double *const tauyy=temp[1];
	double *const tauzz=temp[2];
	double *const tauxy=temp[3];
	double *const tauxz=temp[4];
	double *const tauyz=temp[5];
	double *const xmuxz=temp[6];
	double *const xmuyz=temp[7];
	double *const xmuxy=temp[8];
	double *const xmuxx=temp[9];
	double *const xmuyy=temp[10];
	double *const xmuzz=temp[11];
#ifdef rudman_fine
	//double *rhorc=temp[18], *rhofc=temp[19], *rhooc=temp[20];
	rhorc=temp[18], rhofc=temp[19], rhooc=temp[20];
	calc_axi_visc();
#endif

	//calculate the strain tensors
	int i,j,k;
	for (k=1;k<km1;k++)
		for (j=1;j<jm1;j++)
			for (i=1;i<im1;i++)
			{
				if (ac[IJK]<em6) continue;

				tauxx[IJK] = (u[IJK] - u[IMJK]) * rdx[i];
				tauyy[IJK] = (v[IJK] - v[IJMK]) * rdy[j];
				tauzz[IJK] = (w[IJK] - w[IJKM]) * rdz[k];
			}
	//calculate rotation tensors
	for (k=1;k<km1;k++)
		for (j=1;j<jm1;j++)
			for (i=1;i<im1;i++)
			{
				if (ac[IJK]<em6) continue;

				tauxy[IPJPK] = 0.5 * ((u[IJPK]-u[IJK])*rdelyb[j+1] + (v[IPJK]-v[IJK])*rdelxl[i+1]);
				tauxz[IPJKP] = 0.5 * ((u[IJKP]-u[IJK])*rdelzu[k+1] + (w[IPJK]-w[IJK])*rdelxl[i+1]);
				tauyz[IJPKP] = 0.5 * ((v[IJKP]-v[IJK])*rdelzu[k+1] + (w[IJPK]-w[IJK])*rdelyb[j+1]);
			}
	/*
	 * set cell corner viscosity
	 */
#ifndef rudman_fine
	for(k=1;k<kmax;k++)
		for(j=1;j<jmax;j++)
			for(i=1;i<imax;i++)
			{
				xmuxz[IJK] = (xmu[IJK] + xmu[IJKM] + xmu[IMJKM] + xmu[IMJK]) / 4.0;
				xmuyz[IJK] = (xmu[IJK] + xmu[IJKM] + xmu[IJMKM] + xmu[IJMK]) / 4.0;
				xmuxy[IJK] = (xmu[IJK] + xmu[IJMK] + xmu[IMJMK] + xmu[IMJK]) / 4.0;
			}
#endif
#ifdef rudman_fine
	calc_cross_visc();
#endif

	//set the tau's in the ghost cells
	//forget about tauii, as I only allow no-penetration conditions
	//at the grid edges, where the normal velocity is zero

	//left and right boundaries
	for (k = 1; k < km1; k++ )
	 for (j = 1; j < jm1; j++ ) //jmax	
		{
			//left boundaries
			if (mpi.Neighbors[0] != -1)//if the LEFT boundary is virtual
			{
				tauxy[IND(1,j,k)]=0.5 * ((u[IND(0,j,k)]-u[IND(0,j-1,k)])*rdelyb[j] + (v[IND(1,j-1,k)]-v[IND(0,j-1,k)])*rdelxl[1]);
				tauxz[IND(1,j,k)]=0.5 * ((u[IND(0,j,k)]-u[IND(0,j,k-1)])*rdelzu[k] + (w[IND(1,j,k-1)]-w[IND(0,j,k-1)])*rdelxl[1]);
				tauyz[IND(1,j,k)]=0.5 * ((v[IND(1,j-1,k)]-v[IND(1,j-1,k-1)])*rdelzu[k] + (w[IND(1,j,k-1)]-w[IND(1,j-1,k-1)])*rdelyb[j]);
			}
			else if (kl == 2)
			{
				tauxy[IND(1,j,k)]=v[IND(1,j-1,k)]*rdx[1];
				tauxz[IND(1,j,k)]=w[IND(1,j,k-1)]*rdx[1];
			}
			else
			{
				tauxy[IND(1,j,k)] = 0.0;
				tauxz[IND(1,j,k)] = 0.0;
			}

			//right boundaries
			if (mpi.Neighbors[1]!=-1)//if the RIGHT boundary is virtual
			{
				tauxy[IND(im1,j,k)]=0.5 * ((u[IND(im1-1,j,k)]-u[IND(im1-1,j-1,k)])*rdelyb[j] + (v[IND(im1,j-1,k)]-v[IND(im1-1,j-1,k)])*rdelxl[im1]);
				tauxz[IND(im1,j,k)]=0.5 * ((u[IND(im1-1,j,k)]-u[IND(im1-1,j,k-1)])*rdelzu[k] + (w[IND(im1, j, k-1)]-w[IND(im1,j,k-1)])*rdelxl[im1]);
				tauyz[IND(im1,j,k)]=0.5 * ((v[IND(im1,j-1,k)]-v[IND(im1,j-1,k-1)])*rdelzu[k] + (w[IND(im1,j,k-1)]-w[IND(im1,j-1,k-1)])*rdelyb[j]);
			}
			else if (kr==2)
			{
				tauxy[IND(im1,j,k)]=v[IND(im1,j-1,k)]*rdx[im1];
				tauxz[IND(im1,j,k)]=w[IND(im1,j,k-1)]*rdx[im1];
			}
			else
			{
				tauxy[IND(im1,j,k)]=0;
				tauxz[IND(im1,j,k)]=0;
			}
		}

	//back and front boundaries
	for(k = 1; k < km1; k++)
	 for(i = 1; i < im1; i++)	
		{
			//back boundaries  i.e. y=0 plane
			if (mpi.Neighbors[2] != -1 )//if the BACK boundary is virtual
			{
				tauxy[IND(i,1,k)]=0.5 * ((u[IND(i-1,1,k)]-u[IND(i-1,0,k)])*rdelyb[1] + (v[IND(i,0,k)]-v[IND(i-1,0,k)])*rdelxl[i]);
				tauxz[IND(i,1,k)]=0.5 * ((u[IND(i-1,1,k)]-u[IND(i-1,1,k-1)])*rdelzu[k] + (w[IND(i,1,k-1)]-w[IND(i-1,1,k-1)])*rdelxl[i]);
				tauyz[IND(i,1,k)]=0.5 * ((v[IND(i,0,k)]-v[IND(i,0,k-1)])*rdelzu[k] + (w[IND(i,1,k-1)]-w[IND(i,0,k-1)])*rdelyb[1]);
			}
			else if (kb == 2)
			{
				tauxy[IND(i,1,k)] = u[IND(i-1,1,k)]*rdy[1];
				tauyz[IND(i,1,k)] = w[IND(i,1,k-1)]*rdy[1];
			}
			else
			{
				tauxy[IND(i,1,k)]=0.0;
				tauyz[IND(i,1,k)]=0.0;
			}

			//front boundaries y=jm1 plane
			if (mpi.Neighbors[3]!=-1)//if the FRONT boundary is virtual
			{
				tauxy[IND(i,jm1,k)]=0.5 * ((u[IND(i-1,jm1,k)]-u[IND(i-1,jm1-1,k)])*rdelyb[jm1] + (v[IND(i,jm1-1,k)]-v[IND(i-1,jm1-1,k)])*rdelxl[i]);
				tauxz[IND(i,jm1,k)]=0.5 * ((u[IND(i-1,jm1,k)]-u[IND(i-1,jm1,k-1)])*rdelzu[k] + (w[IND(i,jm1,k-1)]-w[IND(i-1,jm1,k-1)])*rdelxl[i]);
				tauyz[IND(i,jm1,k)]=0.5 * ((v[IND(i,jm1-1,k)]-v[IND(i,jm1-1,k-1)])*rdelzu[k] + (w[IND(i,jm1,k-1)]-w[IND(i,jm1-1,k-1)])*rdelyb[jm1]);
			}
			else if (kf == 2)//wall bc
			{
				tauxy[IND(i,jm1,k)] = u[IND(i-1,jm1,k)] * rdy[jm1];
				tauyz[IND(i,jm1,k)] = w[IND(i,jm1,k-1)] * rdy[jm1];
			}
			else
			{
				tauxy[IND(i,jm1,k)]=0.0;
				tauyz[IND(i,jm1,k)]=0.0;
			}
		}

	//under and over boundaries
	for(j = 1;j < jm1; j++) //jmax
	 for(i = 1;i < im1; i++)		//imax	
		{
			//under boundary
			if (mpi.Neighbors[4]!=-1)//if the UNDER boundary is virtual
			{
				tauxy[IND(i,j,1)]=0.5 * ((u[IND(i-1,j,1)]-u[IND(i-1,j-1,1)])*rdelyb[j] + (v[IND(i,j-1,1)]-v[IND(i-1,j-1,1)])*rdelxl[i]);
				tauxz[IND(i,j,1)]=0.5 * ((u[IND(i-1,j,1)]-u[IND(i-1,j,0)])*rdelzu[1] + (w[IND(i,j,0)]-w[IND(i-1,j,0)])*rdelxl[i]);
				tauyz[IND(i,j,1)]=0.5 * ((v[IND(i,j-1,1)]-v[IND(i,j-1,0)])*rdelzu[1] + (w[IND(i,j,0)]-w[IND(i,j-1,0)])*rdelyb[j]);

			}
			else if (ku==2)
			{
				tauxz[IND(i,j,1)]=u[IND(i-1,j,1)]*rdz[1];
				tauyz[IND(i,j,1)]=v[IND(i,j-1,1)]*rdz[1];
			}
			else
			{
				tauxz[IND(i,j,1)]=0;
				tauyz[IND(i,j,1)]=0;
			}

			//over boundary
			if (mpi.Neighbors[5]!=-1)//if the OVER boundary is virtual
			{
				tauxy[IND(i,j,km1)]=0.5 * ((u[IND(i-1,j,km1)]-u[IND(i-1,j-1,km1)])*rdelyb[j] + (v[IND(i,j-1,km1)]-v[IND(i-1,j-1,km1)])*rdelxl[i]);
				tauxz[IND(i,j,km1)]=0.5 * ((u[IND(i-1,j,km1)]-u[IND(i-1,j,km1-1)])*rdelzu[km1] + (w[IND(i,j,km1-1)]-w[IND(i-1,j,km1-1)])*rdelxl[i]);
				tauyz[IND(i,j,km1)]=0.5 * ((v[IND(i,j-1,km1)]-v[IND(i,j-1,km1-1)])*rdelzu[km1] + (w[IND(i,j,km1-1)]-w[IND(i,j-1,km1-1)])*rdelyb[j]);
			}
			else if(ko==2)
			{
				tauxz[IND(i,j,km1)]=u[IND(i-1,j,km1)]*rdz[km1];
				tauyz[IND(i,j,km1)]=v[IND(i,j-1,km1)]*rdz[km1];
			}
			else if (ko == 5)//lid driven flow
					;//do nothing
			else
			{
				tauxz[IND(i,j,km1)] = 0;
				tauyz[IND(i,j,km1)] = 0;
			}
		}

	/*
	** Set the tau_'s in the obstacle surface cells same as in the k==2 case above.
	*/
	if(mpi.obst_flag)
		viscousobs(tauxy,tauxz,tauyz);

	xchg<double> (tauxx);
	xchg<double> (tauyy);
	xchg<double> (tauzz);
	xchg<double> (tauxy);
	xchg<double> (tauxz);
	xchg<double> (tauyz);


	for (k=0;k<kmax;k++)
		for (j=0;j<jmax;j++)
			for (i=0;i<imax;i++)
			{
#ifndef rudman_fine
				tauxx[IJK]*=2.0*xmu[IJK];
				tauyy[IJK]*=2.0*xmu[IJK];
				tauzz[IJK]*=2.0*xmu[IJK];
#endif

#ifdef rudman_fine
				tauxx[IJK]*=2.0*xmuxx[IJK];
				tauyy[IJK]*=2.0*xmuyy[IJK];
				tauzz[IJK]*=2.0*xmuzz[IJK];
#endif
				tauxy[IJK]*=2.0*xmuxy[IJK];
				tauxz[IJK]*=2.0*xmuxz[IJK];
				tauyz[IJK]*=2.0*xmuyz[IJK];
			}
#ifdef __solid	
	double *psimx=temp[21], *psimy=temp[22], *psimz=temp[23];
#endif
	for (k=1;k<km1;k++)
		for (j=1;j<jm1;j++)
			for (i=1;i<im1;i++)
			{
				//compute the x-direction viscous stress
				if(ar[IJK] >= em6)
				{
					double tauxxx=(tauxx[IPJK]-tauxx[IJK])*rdelxl[i+1];
					double tauxyy=(tauxy[IPJPK]-tauxy[IPJK])*rdy[j];
					double tauxzz=(tauxz[IPJKP]-tauxz[IPJK])*rdz[k];
					double visx;
					
					visx=(tauxxx+tauxyy+tauxzz)/rhorc[IJK];
					
					//update the x-velocity
					u[IJK] += delt*(visx+gx);
				}

				//compute the y-direction viscous stress
				if(af[IJK] >= em6)
				{
					double tauxyx=(tauxy[IPJPK]-tauxy[IJPK])*rdx[i];
					double tauyyy=(tauyy[IJPK]-tauyy[IJK])*rdelyb[j+1];
					double tauyzz=(tauyz[IJPKP]-tauyz[IJPK])*rdz[k];
					double visy;

					visy=(tauxyx+tauyyy+tauyzz)/rhofc[IJK];

					//update the y-velocity
					v[IJK] += delt*(visy+gy);
				}

				//computer the z-direction viscous stress
				if(ao[IJK] >=em6)
				{
					double tauxzx=(tauxz[IPJKP]-tauxz[IJKP])*rdx[i];
					double tauyzy=(tauyz[IJPKP]-tauyz[IJKP])*rdy[j];
					double tauzzz=(tauzz[IJKP]-tauzz[IJK])*rdelzu[k+1];
					double visz;

					visz=(tauxzx+tauyzy+tauzzz)/rhooc[IJK];

					//update the z-velocity
					w[IJK] += delt*(visz+gz);
				}
			}
	bc();
}

#ifdef rudman_fine
void calc_axi_visc() {
	
	double *const xmuxx=temp[9];
	double *const xmuyy=temp[10];
	double *const xmuzz=temp[11];
	
	double *const mu_f = temp_f[0];
	
	int i,j,k;
	double mu_l,mu_r,mu_b,mu_t,mu_u,mu_o;
	//the averaging is based on the scheme provided by rudman 1998
	
	for(k=1;k<km1;k++)
	 for(j=1;j<jm1;j++)
	   for(i=1;i<im1;i++) {
		  //calculate xmuxx
		  mu_l = 0.25e0*(mu_f[IND_f(2*i-1,2*j,2*k)]     + mu_f[IND_f(2*i-1,2*j-1,2*k)]
		               + mu_f[IND_f(2*i-1,2*j-1,2*k-1)] + mu_f[IND_f(2*i-1,2*j,2*k-1)]);
		  
		  mu_r = 0.25e0*(mu_f[IND_f(2*i,2*j,2*k)]     + mu_f[IND_f(2*i,2*j-1,2*k)]
		               + mu_f[IND_f(2*i,2*j-1,2*k-1)] + mu_f[IND_f(2*i,2*j,2*k-1)]);
		               
		  xmuxx[IJK] = 2.e0*mu_l*mu_r/(mu_l + mu_r + tiny);
		  //xmuxx[IJK] = 0.e0;
		  
		  //calculate xmuyy
		  mu_b = 0.25e0*(mu_f[IND_f(2*i,2*j-1,2*k)]     + mu_f[IND_f(2*i-1,2*j-1,2*k)]
		               + mu_f[IND_f(2*i-1,2*j-1,2*k-1)] + mu_f[IND_f(2*i,2*j-1,2*k-1)]);
		                 
		  mu_t = 0.25e0*(mu_f[IND_f(2*i,2*j,2*k)]     + mu_f[IND_f(2*i-1,2*j,2*k)]
		               + mu_f[IND_f(2*i-1,2*j,2*k-1)] + mu_f[IND_f(2*i,2*j,2*k-1)]);
		                 
		  xmuyy[IJK] = 2.e0*mu_b*mu_t/(mu_b + mu_t + tiny);
		  //xmuyy[IJK] = 0.e0;
		  
		  //compute xmuzz
		  mu_u = 0.25e0*(mu_f[IND_f(2*i,2*j,2*k-1)]     + mu_f[IND_f(2*i-1,2*j,2*k-1)]
		               + mu_f[IND_f(2*i-1,2*j-1,2*k-1)] + mu_f[IND_f(2*i,2*j-1,2*k-1)]);
		                 
		  mu_o = 0.25e0*(mu_f[IND_f(2*i,2*j,2*k)]     + mu_f[IND_f(2*i-1,2*j,2*k)]
		               + mu_f[IND_f(2*i-1,2*j-1,2*k)] + mu_f[IND_f(2*i,2*j-1,2*k)]);
		  
		  xmuzz[IJK] = 2.e0*mu_u*mu_o/(mu_u + mu_o + tiny);
		  //xmuzz[IJK] = 0.e0;
		  
	  }
	  
	//xchange the information at subdomain boundaries
	xchg<double>(xmuxx);
	xchg<double>(xmuyy);
	xchg<double>(xmuzz);
}


void calc_cross_visc() {
	//calculates the cross viscosities xmuxy, xmuyz, xmuxz
	//using the harmonic averaging of fvar
	double mu_l,mu_r,mu_b,mu_t,mu_u,mu_o;
	double mu_lr,mu_bt,mu_uo;
	
	double *const xmuxz=temp[6];
	double *const xmuyz=temp[7];
	double *const xmuxy=temp[8];
	
	double *const mu_f=temp_f[0];
	
	int i,j,k;
	  
	for(k=1;k<kmax;k++)
	 for(j=1;j<jmax;j++)
	  for(i=1;i<imax;i++) {
		  //compute xmuxz
		  if(j<jm1) { 
		   
		    mu_l =  0.25e0*(mu_f[IND_f(2*i-2,2*j-1,2*k-1)] + mu_f[IND_f(2*i-2,2*j,2*k-1)] + mu_f[IND_f(2*i-2,2*j,2*k-2)] + mu_f[IND_f(2*i-2,2*j-1,2*k-2)]);
		    mu_r =  0.25e0*(mu_f[IND_f(2*i-1,2*j-1,2*k-1)] + mu_f[IND_f(2*i-1,2*j,2*k-1)] + mu_f[IND_f(2*i-1,2*j,2*k-2)] + mu_f[IND_f(2*i-1,2*j-1,2*k-2)]);
		    mu_lr = 2.e0*mu_l*mu_r/(mu_l + mu_r + tiny);
		    
		    mu_u = 0.25e0*(mu_f[IND_f(2*i-2,2*j-1,2*k-2)] + mu_f[IND_f(2*i-1,2*j-1,2*k-2)] + mu_f[IND_f(2*i-1,2*j,2*k-2)] + mu_f[IND_f(2*i-2,2*j,2*k-2)]);
		    mu_o = 0.25e0*(mu_f[IND_f(2*i-2,2*j-1,2*k-1)] + mu_f[IND_f(2*i-1,2*j-1,2*k-1)] + mu_f[IND_f(2*i-1,2*j,2*k-1)] + mu_f[IND_f(2*i-2,2*j,2*k-1)]);
		    mu_uo = 2.e0*mu_u*mu_o/(mu_u + mu_o + tiny);
		    
		    xmuxz[IJK] = MIN(mu_lr,mu_uo);
		           
		  }
		  
		  //compute xmuyz
		  if(i<im1)	{
			
			mu_b = 0.25e0*(mu_f[IND_f(2*i-1,2*j-2,2*k-2)] + mu_f[IND_f(2*i,2*j-2,2*k-2)] + mu_f[IND_f(2*i,2*j-2,2*k-1)] + mu_f[IND_f(2*i-1,2*j-2,2*k-1)]);
			mu_t = 0.25e0*(mu_f[IND_f(2*i-1,2*j-1,2*k-2)] + mu_f[IND_f(2*i,2*j-1,2*k-2)] + mu_f[IND_f(2*i,2*j-1,2*k-1)] + mu_f[IND_f(2*i-1,2*j-1,2*k-1)]);
			mu_bt = 2.e0*mu_b*mu_t/(mu_b + mu_t + tiny);
			
			mu_u = 0.25e0*(mu_f[IND_f(2*i-1,2*j-2,2*k-2)] + mu_f[IND_f(2*i,2*j-2,2*k-2)] + mu_f[IND_f(2*i,2*j-1,2*k-2)] + mu_f[IND_f(2*i-1,2*j-1,2*k-2)]);
			mu_o = 0.25e0*(mu_f[IND_f(2*i-1,2*j-2,2*k-1)] + mu_f[IND_f(2*i,2*j-2,2*k-1)] + mu_f[IND_f(2*i,2*j-1,2*k-1)] + mu_f[IND_f(2*i-1,2*j-1,2*k-1)]);
			mu_uo = 2.e0*mu_u*mu_o / (mu_u + mu_o + tiny);
			
			xmuyz[IJK] = MIN(mu_bt,mu_uo);
		  }
		  
		  //compute xmuxy
		  if(k<km1)	{
			
			mu_l = 0.25e0*(mu_f[IND_f(2*i-2,2*j-2,2*k-1)] + mu_f[IND_f(2*i-2,2*j-2,2*k)] + mu_f[IND_f(2*i-2,2*j-1,2*k)] + mu_f[IND_f(2*i-2,2*j-1,2*k-1)]);
			mu_r = 0.25e0*(mu_f[IND_f(2*i-1,2*j-2,2*k-1)] + mu_f[IND_f(2*i-1,2*j-2,2*k)] + mu_f[IND_f(2*i-1,2*j-1,2*k)] + mu_f[IND_f(2*i-1,2*j-1,2*k-1)]);
			mu_lr = 2.e0*mu_l*mu_r/(mu_l + mu_r + tiny);
			
			mu_b = 0.25e0*(mu_f[IND_f(2*i-2,2*j-2,2*k-1)] + mu_f[IND_f(2*i-1,2*j-2,2*k-1)] + mu_f[IND_f(2*i-1,2*j-2,2*k)] + mu_f[IND_f(2*i-2,2*j-2,2*k)]);
			mu_t = 0.25e0*(mu_f[IND_f(2*i-2,2*j-1,2*k-1)] + mu_f[IND_f(2*i-1,2*j-1,2*k-1)] + mu_f[IND_f(2*i-1,2*j-1,2*k)] + mu_f[IND_f(2*i-2,2*j-1,2*k)]);
			mu_bt = 2.e0*mu_b*mu_t/(mu_b + mu_t + tiny);
			
			xmuxy[IJK] = MIN(mu_lr,mu_bt);
		  }
	  }	
}
#endif
