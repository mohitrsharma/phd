#include "ripple.h"
#include "comm.h"
#include <stdlib.h>
#include <string.h>
#include "testing.h"

/******************************************************************************
This subroutine sets WALL boundary conditions on the obstacle ghost cells

Subroutine BCOBS is called by:	BC

Subroutine BCOBS calls:	****

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Added loops to implement BCs for obstacles in 		L.Berard	January 17 2013
 ghost cells. Added loops to ensure no-penetration 
 when there is a conflict between no-slip and 
 no-penetration.
-made the big loop only execute if the current cell	Ben			May 14 2005
 is obstacle interface cell
-wrote the big loop which sets the velocities on 	Ben			May 03 2005
 the ghost cells of the obstacles according to no
 slip boundary conditions

-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

void bcobs() {
	int i,j,k;
	
	//here we have separated the no-penetration and no-slip boundary condition
	
	//---first no penetration bc-----------------
	for(k = 1; k < km1; k++)
		for(j = 1; j < jm1; j++)
			for(i = 1; i < im1; i++) //this loop goes over all the obstacle cells in the physical domain 
			{			
                		if (isobstsfc(IJK))             /*if current cell is the obstacle interface cell*/
				{

                    			if (obst[IJK].flag_r)      /*if obstacle cell is to the RIGHT of fluid cell*/
					{
						u[IMJK] = 0.0;
						//v[IJK] = -v[IMJK];
						//w[IJK] = -w[IMJK];
					}

                    			if (obst[IJK].flag_l)      /*if obstacle cell is to the LEFT of fluid cell*/
					{
						u[IJK] = 0.0;
						//v[IJK] = -v[IPJK];
						//w[IJK] = -w[IPJK];
					}

                    			if (obst[IJK].flag_f)      /*if obst. is in of the FRONT of fluid cell*/
					{
						//u[IJK] = -u[IJMK];
						v[IJMK] = 0.0;
						//w[IJK] = -w[IJMK];
					}

                    			if (obst[IJK].flag_b)      /*if obstacle cell is to the BACK of fluid cell*/
					{
						//u[IJK] = -u[IJPK];
						v[IJK] = 0.0;
						//w[IJK] = -w[IJPK];
					}

                    			if (obst[IJK].flag_o)      /*if obstacle cell is OVER the fluid cell*/
					{
						//u[IJK] = -u[IJKM];
						//v[IJK] = -v[IJKM];
						w[IJKM] = 0.0;
					}

                    			if (obst[IJK].flag_u)      /*if obstacle cell is UNDER the fluid cell*/
					{
						//u[IJK] = -u[IJKP];
						//v[IJK] = -v[IJKP];
						w[IJK] = 0.0;
					}
				}
			}
			
	//now look for obstacles in the ghost cells
	//Loops added by LRB to account for face velocities at ghost cell obstacles
	//Right side
    for (j=1;j<jm1;j++)
		for (k=1;k<km1;k++)
		{
                	const int ijkr = IND(im1, j, k);
			if (ac[ijkr] == 0 && ac[ijkr - 1] == 1) //if (obst[ijkr].flag_r)
            		{     				
                    		u[ijkr - 1] = 0;
                    		//v[ijkr] = -v[ijkr - 1];
                    		//w[ijkr] = -w[ijkr - 1];
            		}
		}
	//Front Side
    for (i=1;i<im1;i++)
		for (k=1;k<km1;k++)
		{
                	const int ijkf = IND(i, jm1, k);
			if (ac[ijkf] == 0 && ac[ijkf - imax] == 1) //if (obst[ijkf].flag_f)
            		{
                	    	v[ijkf - imax] = 0.0;
                	    	//u[ijkf] = -u[ijkf - imax];
                	    	//w[ijkf] = -w[ijkf - imax];
			}
		}	
	//Over Side
	for (i=1;i<im1;i++)
		for (j=1;j<jm1;j++)
		{		
			const int ijko = IND(i, j, km1);
			if (ac[ijko] == 0 && ac[ijko - ijmax] == 1) //if (obst[ijko].flag_o)			
			{
				w[ijko - ijmax] = 0.0;
				//u[ijko] = -u[ijko - ijmax];
				//v[ijko] = -v[ijko - ijmax];
			}
		}
	
	//second -----------------no slip bc-------------------------------------
	for(k = 1; k < km1; k++)
		for(j = 1; j < jm1; j++)
			for(i = 1; i < im1; i++) //this loop goes over all the obstacle cells in the physical domain 
			{			
                		if (isobstsfc(IJK))             /*if current cell is the obstacle interface cell*/
				{

                    			if (obst[IJK].flag_r)      /*if obstacle cell is to the RIGHT of fluid cell*/
					{
						//u[IMJK] = 0.0;
						if(ac[IJK]+ac[IJPK] < em6) v[IJK] = -v[IMJK];
						if(ac[IJK]+ac[IJKP] < em6) w[IJK] = -w[IMJK];
					}

                    			if (obst[IJK].flag_l)      /*if obstacle cell is to the LEFT of fluid cell*/
					{
						//u[IJK] = 0.0;
						if(ac[IJK]+ac[IJPK] < em6) v[IJK] = -v[IPJK];
						if(ac[IJK]+ac[IJKP] < em6) w[IJK] = -w[IPJK];
					}

                    			if (obst[IJK].flag_f)      /*if obst. is in of the FRONT of fluid cell*/
					{
						if(ac[IJK]+ac[IPJK] < em6) u[IJK] = -u[IJMK];
						//v[IJMK] = 0.0;
						if(ac[IJK]+ac[IJKP] < em6) w[IJK] = -w[IJMK];
					}

                    			if (obst[IJK].flag_b)      /*if obstacle cell is to the BACK of fluid cell*/
					{
						if(ac[IJK]+ac[IPJK] < em6) u[IJK] = -u[IJPK];
						//v[IJK] = 0.0;
						if(ac[IJK]+ac[IJKP] < em6) w[IJK] = -w[IJPK];
					}

                    			if (obst[IJK].flag_o)      /*if obstacle cell is OVER the fluid cell*/
					{
						if(ac[IJK]+ac[IPJK] < em6) u[IJK] = -u[IJKM];
						if(ac[IJK]+ac[IJPK] < em6) v[IJK] = -v[IJKM];
						//w[IJKM] = 0.0;
					}

                    			if (obst[IJK].flag_u)      /*if obstacle cell is UNDER the fluid cell*/
					{
						if(ac[IJK]+ac[IPJK] < em6) u[IJK] = -u[IJKP];
						if(ac[IJK]+ac[IJPK] < em6) v[IJK] = -v[IJKP];
						//w[IJK] = 0.0;
					}
				}
			}
			
	//Right side
    for (j=1;j<jm1;j++)
		for (k=1;k<km1;k++)
		{
                	const int ijkr = IND(im1, j, k);
			if (ac[ijkr] == 0 && ac[ijkr - 1] == 1) //if (obst[ijkr].flag_r)
            		{     				
                    		//u[ijkr - 1] = 0;
                    		if(ac[ijkr]+ac[ijkr+ imax] < em6) v[ijkr] = -v[ijkr - 1];
                    		if(ac[ijkr]+ac[ijkr+ijmax] < em6) w[ijkr] = -w[ijkr - 1];
            		}
		}
	//Front Side
    for (i=1;i<im1;i++)
		for (k=1;k<km1;k++)
		{
                	const int ijkf = IND(i, jm1, k);
			if (ac[ijkf] == 0 && ac[ijkf - imax] == 1) //if (obst[ijkf].flag_f)
            		{
                	    	//v[ijkf - imax] = 0.0;
                	    	if(ac[ijkf]+ac[ijkf+    1] < em6) u[ijkf] = -u[ijkf - imax];
                	    	if(ac[ijkf]+ac[ijkf+ijmax] < em6) w[ijkf] = -w[ijkf - imax];
			}
		}	
	//Over Side
	for (i=1;i<im1;i++)
		for (j=1;j<jm1;j++)
		{		
			const int ijko = IND(i, j, km1);
			if (ac[ijko] == 0 && ac[ijko - ijmax] == 1) //if (obst[ijko].flag_o)			
			{
				//w[ijko - ijmax] = 0.0;
				if(ac[ijko]+ac[ijko+   1] < em6) u[ijko] = -u[ijko - ijmax];
				if(ac[ijko]+ac[ijko+imax] < em6) v[ijko] = -v[ijko - ijmax];
			}
		}
	
}

//void bcobs()
//{
    //*bc's of obstacle interface cells according to WALLL BC (i.e. no-slip)
    //*/
	//int i, j, k;

	//for(k = 1; k < km1; k++)
		//for(j = 1; j < jm1; j++)
			//for(i = 1; i < im1; i++)
			//{
                		//if (isobstsfc(IJK))             /*if current cell is the obstacle interface cell*/
				//{

                    			//if (obst[IJK].flag_r)      /*if obstacle cell is to the RIGHT of fluid cell*/
					//{
						//u[IMJK] = 0.0;
						//v[IJK] = -v[IMJK];
						//w[IJK] = -w[IMJK];
					//}

                    			//if (obst[IJK].flag_l)      /*if obstacle cell is to the LEFT of fluid cell*/
					//{
						//u[IJK] = 0.0;
						//v[IJK] = -v[IPJK];
						//w[IJK] = -w[IPJK];
					//}

                    			//if (obst[IJK].flag_f)      /*if obst. is in of the FRONT of fluid cell*/
					//{
						//u[IJK] = -u[IJMK];
						//v[IJMK] = 0.0;
						//w[IJK] = -w[IJMK];
					//}

                    			//if (obst[IJK].flag_b)      /*if obstacle cell is to the BACK of fluid cell*/
					//{
						//u[IJK] = -u[IJPK];
						//v[IJK] = 0.0;
						//w[IJK] = -w[IJPK];
					//}

                    			//if (obst[IJK].flag_o)      /*if obstacle cell is OVER the fluid cell*/
					//{
						//u[IJK] = -u[IJKM];
						//v[IJK] = -v[IJKM];
						//w[IJKM] = 0.0;
					//}

                    			//if (obst[IJK].flag_u)      /*if obstacle cell is UNDER the fluid cell*/
					//{
						//u[IJK] = -u[IJKP];
						//v[IJK] = -v[IJKP];
						//w[IJK] = 0.0;
					//}
				//}
			//}
	
	////Loops added by LRB to account for face velocities at ghost cell obstacles
	////Right side
    //for (j=1;j<jm1;j++)
		//for (k=1;k<km1;k++)
		//{
                	//const int ijkr = IND(im1, j, k);
			//if (ac[ijkr] == 0 && ac[ijkr - 1] == 1) //if (obst[ijkr].flag_r)
            		//{     				
                    		//u[ijkr - 1] = 0;
                    		//v[ijkr] = -v[ijkr - 1];
                    		//w[ijkr] = -w[ijkr - 1];
            		//}
		//}
	////Front Side
    //for (i=1;i<im1;i++)
		//for (k=1;k<km1;k++)
		//{
                	//const int ijkf = IND(i, jm1, k);
			//if (ac[ijkf] == 0 && ac[ijkf - imax] == 1) //if (obst[ijkf].flag_f)
            		//{
                	    	//v[ijkf - imax] = 0.0;
                	    	//u[ijkf] = -u[ijkf - imax];
                	    	//w[ijkf] = -w[ijkf - imax];
			//}
		//}	
	////Over Side
	//for (i=1;i<im1;i++)
		//for (j=1;j<jm1;j++)
		//{		
			//const int ijko = IND(i, j, km1);
			//if (ac[ijko] == 0 && ac[ijko - ijmax] == 1) //if (obst[ijko].flag_o)			
			//{
				//w[ijko - ijmax] = 0.0;
				//u[ijko] = -u[ijko - ijmax];
				//v[ijko] = -v[ijko - ijmax];
			//}
		//}
	////Ensure No-penetration backup loop added by LRB
	//for(k = 1; k < km1; k++)
		//for(j = 1; j < jm1; j++)
			//for(i = 1; i < im1; i++)
			//{
                		//if (isobstsfc(IJK))             /*if current cell is the obstacle interface cell*/
				//{

                    			//if (obst[IJK].flag_r)      /*if obstacle cell is to the RIGHT of fluid cell*/
					//{
						//u[IMJK] = 0.0;
					//}

                    			//if (obst[IJK].flag_l)      /*if obstacle cell is to the LEFT of fluid cell*/
					//{
						//u[IJK] = 0.0;
					//}

                    			//if (obst[IJK].flag_f)      /*if obst. is in of the FRONT of fluid cell*/
					//{
						//v[IJMK] = 0.0;
					//}

                    			//if (obst[IJK].flag_b)      /*if obstacle cell is to the BACK of fluid cell*/
					//{
						//v[IJK] = 0.0;
					//}

                    			//if (obst[IJK].flag_o)      /*if obstacle cell is OVER the fluid cell*/
					//{
						//w[IJKM] = 0.0;
					//}

                    			//if (obst[IJK].flag_u)      /*if obstacle cell is UNDER the fluid cell*/
					//{
						//w[IJK] = 0.0;
					//}
				//}
			//}
	////Ensure no-penetration for ghost obstacles
	////Right side
    //for (j=1;j<jm1;j++)
		//for (k=1;k<km1;k++)
		//{
                	//const int ijkr = IND(im1, j, k);
			//if (ac[ijkr] == 0 && ac[ijkr - 1] == 1) //if (obst[ijkr].flag_r)
            		//{     				
                    		//u[ijkr - 1] = 0;
            		//}
		//}	
	////Front Side
    //for (i=1;i<im1;i++)
		//for (k=1;k<km1;k++)
		//{                
			//const int ijkf = IND(i, jm1, k);
			//if (ac[ijkf] == 0 && ac[ijkf - imax] == 1) //if (obst[ijkf].flag_f)
            		//{
                	    	//v[ijkf - imax] = 0.0;
			//}
		//}	
	////Over Side
	//for (i=1;i<im1;i++)
		//for (j=1;j<jm1;j++)
		//{		
			//const int ijko = IND(i, j, km1);
			//if (ac[ijko] == 0 && ac[ijko - ijmax] == 1) //if (obst[ijko].flag_o)			
			//{
				//w[ijko - ijmax] = 0.0;
			//}
		//}
//}

