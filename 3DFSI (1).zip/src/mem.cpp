#include "ripple.h"
#include <stdlib.h>
#include <malloc.h>
#include "testing.h"

/******************************************************************************
This subroutine allocates memory for all arrays and variables

Subroutine MEM is called by:	

Subroutine MEM calls:			

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

- Allocating memory for enthalpy, temperature,		Babak		May 16 2009
  and specific heat

- Allocating memory for xmu							Amirreza		Dec. 2, 2005

- Allocating memory for rho							Amirreza		Dec. 7, 2005

_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

int alloc;	//count of allocated memory.
void arraysalloc(int sx, int sy, int sz)
{
	//allocate *all* arrays to be sx * sy * sz.
	//Typically, sx,sy,sz is set to be nx,ny,nz.
//I'm lazy:
#define AXYZ (double*)memalloc (sx, sy, sz, sizeof(double))

alloc=0;

//fldvarr
		u = AXYZ;
		v = AXYZ;
		w = AXYZ;
		p = AXYZ;
		f = AXYZ;
if(ENERGY) {
		h = AXYZ;
 	  tmp = AXYZ;
 	  hn = AXYZ;
	 tmpn = AXYZ;
	 cp = AXYZ;
	 cond = AXYZ;
  }

#ifdef CUDA
	int nmtotal, t1,t2;
	nmtotal = imax*jmax*kmax+1;
	t1 = imax;
	t2 = (imax)*(jmax);
	int non_zeros = 7*(nmtotal-1) - 2 - 2*t1 - 2*t2; 
	A_row = (int *)calloc(nmtotal-1,sizeof(int)); alloc += (nmtotal-1)*sizeof(int);
	A_col = (int *)calloc(non_zeros,sizeof(int)); alloc += (non_zeros)*sizeof(int);
	A_val = (double *)calloc(non_zeros,sizeof(double)); alloc += (non_zeros)*sizeof(double);
	jacobi_a = (double *)calloc(nmtotal-1,sizeof(double)); alloc += (nmtotal-1)*sizeof(double);
	CUDA_RHS = (double *)calloc(nmtotal-1,sizeof(double)); alloc += (nmtotal-1)*sizeof(double);
	X = (double *)calloc(nmtotal-1,sizeof(double)); alloc += (nmtotal-1)*sizeof(double);
#endif

#ifndef rudman_fine
		f1= AXYZ;
	difference= AXYZ;
	rhorc = AXYZ;
	rhofc = AXYZ;
	rhooc = AXYZ;
	utemp = AXYZ;
	vtemp = AXYZ;
#endif
	avnx = AXYZ;
	avny = AXYZ;
	avnz = AXYZ;
  gradrox = AXYZ;
  gradroy = AXYZ;
  gradroz = AXYZ;
	   un = AXYZ;
	   vn = AXYZ;
	   wn = AXYZ;
	   pn = AXYZ;
	   fn = AXYZ;
	   FN = AXYZ;
	   ar = AXYZ;
	   af = AXYZ;
	   ao = AXYZ;
	   ac = AXYZ;
	  xmu = AXYZ;
	sigma = AXYZ;
	ftemp = AXYZ;
	rho = AXYZ;
#ifndef no_obs
  	obst  = (_obst*)memalloc(sx,sy,sz, sizeof(_obst));
#endif

if(BUBBLE)
    bubble = (_bubble*)memalloc(sx,sy,sz, sizeof(_bubble));
      
//fldvari
       nf = (int*)memalloc (sx, sy, sz, sizeof(int));
	 kbot = (int*)memalloc (sx, sy, 1, sizeof(int));
	 ktop = (int*)memalloc (sx, sy, 1, sizeof(int));	

//meshr
	    x = (double*)memalloc (sx, 1, 1, sizeof(double));
		y = (double*)memalloc (1, sy, 1, sizeof(double));
		z = (double*)memalloc (1, 1, sz, sizeof(double));
	   xi = (double*)memalloc (sx, 1, 1, sizeof(double));
	   yj = (double*)memalloc (1, sy, 1, sizeof(double));
	   zk = (double*)memalloc (1, 1, sz, sizeof(double));
	 delx = (double*)memalloc (sx, 1, 1, sizeof(double));
	 dely = (double*)memalloc (1, sy, 1, sizeof(double));
	 delz = (double*)memalloc (1, 1, sz, sizeof(double));
	  rdx = (double*)memalloc (sx, 1, 1, sizeof(double));
	  rdy = (double*)memalloc (1, sy, 1, sizeof(double));
	  rdz = (double*)memalloc (1, 1, sz, sizeof(double));
	delxl = (double*)memalloc (sx, 1, 1, sizeof(double));
	delyb = (double*)memalloc (1, sy, 1, sizeof(double));
	delzu = (double*)memalloc (1, 1, sz, sizeof(double));
   rdelxl = (double*)memalloc (sx, 1, 1, sizeof(double));
   rdelyb = (double*)memalloc (1, sy, 1, sizeof(double));
   rdelzu = (double*)memalloc (1, 1, sz, sizeof(double));
      vol = AXYZ;

//frsrfi
   ijkfr = (int*)memalloc (sx, sy, sz, sizeof(int));

//temp
   //temp variables must be consecutive
   //In some cases, temp variables may be larger than sx*sy*sz.
#ifndef rudman_fine  
   temp[0] = (double*)memalloc (sx, sy, sz*21, sizeof(double));
   for (int i=1;i<21;i++)
		temp[i] = temp[i-1]+sx*sy*sz;
#endif
   
#ifdef rudman_fine
#ifndef __solid
      temp[0] = (double*)memalloc (sx, sy, sz*21, sizeof(double));
      for (int i=1;i<21;i++)
		temp[i] = temp[i-1]+sx*sy*sz;
		
	temp_f[0] = (double *)memalloc(2*sx-2,2*sy-2,(2*sz-2)*9,sizeof(double));
      for (int i=1;i<9;i++) //scope of i only inside the loop
	    temp_f[i] = temp_f[i-1]+(2*sx-2)*(2*sy-2)*(2*sz-2);
#endif
      #define AXYZ_f (double*)memalloc (2*sx-2, 2*sy-2, 2*sz-2, sizeof(double))
      f_f = AXYZ_f;
      fn_f = AXYZ_f;
      FN_f = AXYZ_f;
      vol_f = AXYZ_f;
      
//***************************************************************************//
      // passive scalar transport
      scal = AXYZ_f;
      crse_scal = AXYZ;
      scal_c = AXYZ_f;
      flx = AXYZ_f;
//***************************************************************************//
      
#ifdef __solid
    temp[0] = (double*)memalloc (sx, sy, sz*24, sizeof(double));
      for (int i=1;i<24;i++)
		temp[i] = temp[i-1]+sx*sy*sz;
		
	temp_f[0] = (double *)memalloc(2*sx-2,2*sy-2,(2*sz-2)*12,sizeof(double));
      for (int i=1;i<12;i++) //scope of i only inside the loop
	    temp_f[i] = temp_f[i-1]+(2*sx-2)*(2*sy-2)*(2*sz-2);
	    
	psi = AXYZ;
      psi_f = AXYZ_f;
      psin_f = AXYZ_f;
      PSIN_f = AXYZ_f;

//***************************************************************************//
      alpha_f = AXYZ_f;
      plug_f = AXYZ_f;
      ytubef_field = AXYZ_f;
      plug_c = AXYZ;
      
      g_fvirt = AXYZ;
#ifdef print_norm      
      global_kappa = AXYZ;
      g_normx = AXYZ;
      g_normy = AXYZ;
      g_normz = AXYZ;
      
#endif print_norm
//***************************************************************************//

      //variables for triple point 
      fvirt_f = AXYZ_f;
      triple_flg = (int*)memalloc (2*sx-2, 2*sy-2, 2*sz-2, sizeof(int));
      neigh_triple = (int *)memalloc (2*sx-2, 2*sy-2, 2*sz-2, sizeof(int));
      
      //2nd layer of ghost cells
      triple_flg2 = (int *)memalloc2(2*sx,2*sy,2*sz,sizeof(int));
      fvirt2_f = (double *)memalloc2(2*sx,2*sy,2*sz,sizeof(double));
      avnx2_f = (double *)memalloc2(2*sx,2*sy,2*sz,sizeof(double));
      avny2_f = (double *)memalloc2(2*sx,2*sy,2*sz,sizeof(double));
      avnz2_f = (double *)memalloc2(2*sx,2*sy,2*sz,sizeof(double));
      psi2_f = (double *)memalloc2(2*sx,2*sy,2*sz,sizeof(double));
      f2_f = (double *)memalloc2(2*sx,2*sy,2*sz,sizeof(double));
      
      //the two arrays to be 'decorated'
      planDo2 = (double *)memalloc3(2*sx,2*sy,2*sz,sizeof(double));
      planIn2 = (int *)memalloc3(2*sx,2*sy,2*sz,sizeof(int));
      
	//tArray = (int *)memalloc2(2*sx,2*sy,2*sz,sizeof(int));
	//mArray = (int *)memalloc(2*sx-2, 2*sy-2, 2*sz-2, sizeof(int));
	  //2nd layer of ghost cells on standard grid
	  psi2mx = (double *)memalloc2(sx+2,sy+2,sz+2,sizeof(double));
	  psi2my = (double *)memalloc2(sx+2,sy+2,sz+2,sizeof(double));
	  psi2mz = (double *)memalloc2(sx+2,sy+2,sz+2,sizeof(double));
#endif
	  //2nd layer of ghost cells on standard grid
	  f2mx = (double *)memalloc2(sx+2,sy+2,sz+2,sizeof(double));
	  f2my = (double *)memalloc2(sx+2,sy+2,sz+2,sizeof(double));
	  f2mz = (double *)memalloc2(sx+2,sy+2,sz+2,sizeof(double));
	  //decoration array
	  splanDo2 = (double *)memalloc3(sx+2,sy+2,sz+2,sizeof(double));
#ifdef impose_CA
	  f2_arr = (double *)memalloc2(sx+2,sy+2,sz+2,sizeof(double));
#endif

#endif
#ifdef bl_mg
	mg_param_init(); 
	bl_mg_memalloc();
#endif

   if(mpi.MyRank == 0) printf ("Each processor Allocated %.1fMB\n", alloc/1048576.0);   
	
}
void arraysfree()
{
	//free *all* arrays
	//the memory freeing should be in sync with arraysalloc above.
	//or dare face the seg. faults.. do corresponding changes here,
	//then uncomment
/*
//fldvarr
	memfree(u);
	memfree(v);
	memfree(w);
	memfree(p);
	memfree(f);
	memfree(h);
	memfree(tmp);
	memfree(f1);
	memfree(difference);
	memfree(un);
	memfree(vn);
	memfree(wn);
	memfree(pn);
	memfree(fn);
	memfree(hn);
	memfree(tmpn);
	memfree(ar);
	memfree(af);
	memfree(ao);
	memfree(ac);
	memfree(avnx);
	memfree(avny);
	memfree(avnz);
	memfree(rhorc);
	memfree(rhofc);
	memfree(rhooc);
	memfree(xmu);	
	memfree(rho);	
	memfree(cp);
	memfree(cond);
	memfree(sigma);
    memfree(gradrox);
    memfree(gradroy);
    memfree(gradroz);
    memfree(utemp);
	memfree(vtemp);
	memfree(ftemp);
	memfree(obst);
    memfree(bubble);
      memfree(t_div); //div-test
//fldvari
    memfree(nf);
	memfree(kbot);
	memfree(ktop);

//meshr
	memfree(x);
    memfree(y);
	memfree(z);
	memfree(xi);
	memfree(yj);
	memfree(zk);
	memfree(delx);
	memfree(dely);
	memfree(delz);
	memfree(rdx);
	memfree(rdy);
	memfree(rdz);
	memfree(delxl);
	memfree(delyb);
	memfree(delzu);
    memfree(rdelxl);
    memfree(rdelyb);
    memfree(rdelzu);
    memfree(vol);

//frsrfi
	memfree(ijkfr);

//temp
	memfree (temp[0]);
	temp[0]=temp[1]=temp[2]=0;
	temp[3]=temp[4]=temp[5]=0;
	temp[6]=temp[7]=temp[8]=0;
	temp[9]=temp[10]=temp[11]=0;
	temp[12]=temp[13]=temp[14]=0;
	temp[15]=temp[16]=temp[18]=0;
	temp[19]=temp[20]=temp[21]=0;
	*/
}

void* memalloc (int nx, int ny, int nz, int elsz)
{
	//Allocate one array of nx*ny*nz with element size of elsz bytes.
	//Typically, elsz = sizeof(double) (to allocate a double array)
	alloc += nx*ny*nz*elsz;
	return calloc (nx*ny*nz,elsz);
	
}
#ifdef rudman_fine
	
void *memalloc2(int nx, int ny, int nz, int elsz)
{
	//allocates array for 2nd layer of ghost cells... especially for triple
	//contact line purposes
	alloc += 2*(nx*ny + ny*nz + nz*nx)*elsz;
	return calloc (2*(nx*ny + ny*nz + nz*nx),elsz);
}	

void *memalloc3(int nx, int ny, int nz, int elsz)
{
	//allocates memory for array to be decorated and sent [*pArray]
	alloc += (nx*ny + ny*nz + nz*nx)*elsz;
	return calloc (nx*ny + ny*nz + nz*nx, elsz);
}	
#endif
void memfree (void *p)
{
	free (p);
}
