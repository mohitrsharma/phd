#include "ripple.h"
#include <stdlib.h>
#include <stdio.h>
#include "ripple.h"

/******************************************************************************


Subroutine DUMP is called by:	NEWCYC

Subroutine DUMP calls:

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

- Bugs fixed.										Babak		October 23 2008
  
- Dump file names corrected.                        Babak       October 20 2008
  
- Created this template for tracking changes.		Ben			April 21 2005


_________________________________TO DO LIST____________________________________

*******************************************************************************/

void dump(void)
{
	int i, j, k;
	int nfluid = 0;
	char filename[16];
	idump ++;
	nfluid = (NX-2) * (NY-2) * (NZ-2);

	sprintf(filename, "dump-%03d-%03d", mpi.MyRank, idump); /*Create dump file name*/

	FILE *in = fopen(filename, "w");						/*Create a pointer to a dump file*/

	if (!in)												/*Make sure dump file can be opened*/
	{
		printf ("Process %d unable to open %s file\n", mpi.MyRank, filename);
		exit (1);
	}

	/*Print relevant parameters for dump files*/
	fprintf(in, "%22.20e %22.20e %22.20e %22.20e %22.20e %d\n", delt, deltold, t, twplt, twdmp, ncyc);

	fprintf(in, "%d %d %d\n", nfluid, iplot, idump);

	/*Print i, j, k, u, v, w, f and p to a dump file*/
	
#ifndef rudman_fine
	for(k = 1; k < km1; k++)
		for(j = 1; j < jm1; j++)
			for(i = 1; i < im1; i++)
			{
        			fprintf(in, "%4d %4d %4d %22.20e %22.20e %22.20e %22.20e %22.20e\n", i, j, k,
	                        u[IJK], v[IJK], w[IJK], f[IJK], p[IJK]);
			}
#endif

#ifdef rudman_fine

#ifndef __solid
	for(k = 1; k < km1; k++)
		for(j = 1; j < jm1; j++)
			for(i = 1; i < im1; i++)
			{
        			fprintf(in, "%4d %4d %4d %22.20e %22.20e %22.20e %22.20e %22.20e %22.20e %22.20e %22.20e %22.20e %22.20e %22.20e %22.20e %22.20e\n", i, j, k,
	                        u[IJK], v[IJK], w[IJK], f[IJK], p[IJK],f_f[IND_f(2*i,2*j,2*k)],f_f[IND_f(2*i-1,2*j,2*k)],f_f[IND_f(2*i-1,2*j-1,2*k)],f_f[IND_f(2*i,2*j-1,2*k)],
	                        f_f[IND_f(2*i,2*j,2*k-1)],f_f[IND_f(2*i-1,2*j,2*k-1)],f_f[IND_f(2*i-1,2*j-1,2*k-1)],f_f[IND_f(2*i,2*j-1,2*k-1)]);
			}
#endif

#ifdef __solid
	for(k = 1; k < km1; k++)
		for(j = 1; j < jm1; j++)
			for(i = 1; i < im1; i++)
			{
        			fprintf(in, "%4d %4d %4d %22.20e %22.20e %22.20e %22.20e %22.20e %22.20e %22.20e %22.20e %22.20e %22.20e %22.20e %22.20e %22.20e %22.20e %22.20e %22.20e %22.20e %22.20e %22.20e %22.20e %22.20e\n", i, j, k,
	                        u[IJK], v[IJK], w[IJK], f[IJK], p[IJK],f_f[IND_f(2*i,2*j,2*k)],f_f[IND_f(2*i-1,2*j,2*k)],f_f[IND_f(2*i-1,2*j-1,2*k)],f_f[IND_f(2*i,2*j-1,2*k)],
	                        f_f[IND_f(2*i,2*j,2*k-1)],f_f[IND_f(2*i-1,2*j,2*k-1)],f_f[IND_f(2*i-1,2*j-1,2*k-1)],f_f[IND_f(2*i,2*j-1,2*k-1)],
	                        psi_f[IND_f(2*i,2*j,2*k)],psi_f[IND_f(2*i-1,2*j,2*k)],psi_f[IND_f(2*i-1,2*j-1,2*k)],psi_f[IND_f(2*i,2*j-1,2*k)],
	                        psi_f[IND_f(2*i,2*j,2*k-1)],psi_f[IND_f(2*i-1,2*j,2*k-1)],psi_f[IND_f(2*i-1,2*j-1,2*k-1)],psi_f[IND_f(2*i,2*j-1,2*k-1)]);
			}
			
	for(k = 1; k < km1; k++)
		for(j = 1; j < jm1; j++)
			for(i = 1; i < im1; i++)
			{
        			fprintf(in, "%4d %4d %4d %22.20e %22.20e %22.20e %22.20e %22.20e %22.20e %22.20e %22.20e %22.20e\n", i, j, k,
	                        crse_scal[IJK], scal[IND_f(2*i,2*j,2*k)],scal[IND_f(2*i-1,2*j,2*k)],scal[IND_f(2*i-1,2*j-1,2*k)],scal[IND_f(2*i,2*j-1,2*k)],
	                        scal[IND_f(2*i,2*j,2*k-1)],scal[IND_f(2*i-1,2*j,2*k-1)],scal[IND_f(2*i-1,2*j-1,2*k-1)],scal[IND_f(2*i,2*j-1,2*k-1)]);
			}
#endif

#endif

	fclose(in);												/*Close dump file*/

	if(mpi.MyRank == 0) {
		printf("Written dump-%03d\n", idump);
	}
	
	//if(mpi.MyRank == 0) {
		//sprintf(filename, "cory_dump-%03d-%03d", mpi.MyRank, idump); /*Create dump file name*/

		//FILE *cory = fopen(filename, "w");						/*Create a pointer to a dump file*/
		//fprintf(cory, "%4d %4e %4e\n", plug_number, plug_frequency, plug_i_time);
		//fclose(cory);
		//printf("Written cory-dump\n");
	//}
}
