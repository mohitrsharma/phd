#include "ripple.h"
#include <stdlib.h>
#include <time.h>
#include "testing.h"

/******************************************************************************
This subroutine INITENRG sets the initial enthalpy field. 

Subroutine INITENRG is called by:	SETUP

Subroutine INITENRG calls:	ENTHTMP

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

- Subroutine modified for variable properties       Babak       Sep 14 2009
  
- Created this subroutine to initialize enthalpy	Babak		May 15 2009


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

void initenrg()
{
	int i,j,k;
	double hif1,hif2,ff1,ff2,cpTf1,cpTf2;

	if (VARPROP)
	{
		cpTf1 = interp(FLUID1_T,FLUID1_Cp,tif1);
		cpTf2 = interp(FLUID2_T,FLUID2_Cp,tif2);
	}
	else
	{
		cpTf1 = cpf1;
		cpTf2 = cpf2;
	}	
	
	hif1= cpTf1*tif1;
	hif2= h0f2+cpTf2*tif2;

	//looping over all cells
	for (i=0;i<imax;i++)
		for (j=0;j<jmax;j++)
			for (k=0;k<kmax;k++)
			{
				if (f[IJK] < em6)
				{
					h[IJK] = hn[IJK] = hif2;
					tmp[IJK] = tmpn[IJK] = tif2;
				}
				else if (f[IJK] > em61)
				{
					h[IJK] = hn[IJK] = hif1;
					tmp[IJK] = tmpn[IJK] = tif1;
				}
				else
				{
					ff1 = f[IJK]*rhof1/rho[IJK];
					ff2 = (1.0-f[IJK])*rhof2/rho[IJK];
					h[IJK] = hn[IJK] = hif1*ff1+hif2*ff2;
					tmp[IJK] = tmpn[IJK] = h[IJK]/(cpTf1*ff1+cpTf2*ff2);
				}
			}
}
