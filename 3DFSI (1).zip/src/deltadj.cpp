#include "ripple.h"
#include "comm.h"
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include "testing.h"

/******************************************************************************
This subroutine adjusts delt.  It also restores old field variables (u,v,w,p,f)
if VOF limit is exceeded

Subroutine DELTADJ is called by:	NEWCYC

Subroutine DELTADJ calls:			

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

- Subroutine modified for variable properties		Babak		Sep 15 2009
  
- Check for diffusion time step added				Babak		May 15 2009


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

void deltadj()
{
	int i,j,k;
	double xmumin, alfa, sigmamax;

	//whoops! - VOF limit exceeded - decrease the previous timestep,
	//and reset all field variables
	if (flgc > 0.5)
	{
		//tecpf();
		
		//VOF limit exceeded. Undo.
		t -= delt;
		ncyc --;
		delt *= 0.8;
		//restore old field variables
		memcpy (p, pn, NX*NY*NZ*sizeof(double));
#ifndef rudman_fine
		memcpy (f, FN, NX*NY*NZ*sizeof(double));
#endif

#ifdef rudman_fine
		memcpy(f_f,FN_f,NX_f*NY_f*NZ_f*sizeof(double));
#ifdef __solid
		memcpy(psi_f,PSIN_f,NX_f*NY_f*NZ_f*sizeof(double));
		for(i=1;i<=NBODY;i++) equate_pt(&Omega[i],&Omegan[i]);
		for(i=1;i<=NBODY;i++) memcpy(rig_U[i],rig_Un[i],4*sizeof(double));
#endif
#endif
		memcpy (u, un, NX*NY*NZ*sizeof(double));
		memcpy (v, vn, NX*NY*NZ*sizeof(double));
		memcpy (w, wn, NX*NY*NZ*sizeof(double));
		if (ENERGY)
		{
			memcpy (h, hn, NX*NY*NZ*sizeof(double));
			memcpy (tmp, tmpn, NX*NY*NZ*sizeof(double));
		}
		flgc=0.0;
		nflgc++;
		
		if(mpi.MyRank==0) printf("the time step flgc>0.5 is %e\n",delt);
	}


	//now to adjust the timestep with regard to various criteria
	
	//find the Courant maximums
	double dumx=em10;
	double dvmx=em10;
	double dwmx=em10;
	int ijkx=0,ijky=0,ijkz=0;
	
	for(i = 1; i < im1; i++)
		for(j = 1; j < jm1; j++)
			for(k = 1; k < km1; k++)
			{
				double udm=fabs(un[IJK])/(xi[i+1]-xi[i]);
				double vdm=fabs(vn[IJK])/(yj[j+1]-yj[j]);
				double wdm=fabs(wn[IJK])/(zk[k+1]-zk[k]);
				
#ifdef rudman_fine
				udm*=2; vdm*=2; wdm*=2;
#endif

#ifndef __solid
				//if (f[IJK]>em6)
				//{
					dumx=MAX(dumx,udm);
					dvmx=MAX(dvmx,vdm);
					dwmx=MAX(dwmx,wdm);
					if (dumx==udm) ijkx=IJK;
					if (dvmx==vdm) ijky=IJK;
					if (dwmx==wdm) ijkz=IJK;
				//}
#endif

#ifdef rudman_fine
#ifdef __solid
				//if (f[IJK]>em6 || psi[IJK]>em6)
				//{
					dumx=MAX(dumx,udm);
					dvmx=MAX(dvmx,vdm);
					dwmx=MAX(dwmx,wdm);
					if (dumx==udm) ijkx=IJK;
					if (dvmx==vdm) ijky=IJK;
					if (dwmx==wdm) ijkz=IJK;
				//}
#endif
#endif
			}
	double temp;
	dallreduce (&dumx, &temp, 1, OP_MAX);
	dumx=temp;
	dallreduce (&dvmx, &temp, 1, OP_MAX);
	dvmx=temp;
	dallreduce (&dwmx, &temp, 1, OP_MAX);
	dwmx=temp;

	//first we check to see whether the previous timestep was defined
    //solely to reach a certain twplt; if so, base the next
    //timestep on the timestep of two steps ago

	if (deltold > 0.0) delt=deltold;	//deltold is saved if delt is modified to reach twplt. see end of routine.

	//let's start with a 5% increase in timestep

	double delto=1.05*delt; // 5% increase
	//double delto= delt;		
	//double delto= 1.01*delt; // 1% increase
	itc=0;
	jtc=0;
	ktc=0;
	strcpy(idt,"g");

	delt=delto;

	//check the x-Courant condition
	if (delt > con/dumx)
	{
		delt = con/dumx;
		ktc=(ijkx)/(ijmax);
		jtc=(ijkx-ktc*ijmax)/imax;
		itc=ijkx-ktc*ijmax-jtc*imax;
        strcpy(idt,"cx");
		if(mpi.MyRank == 0) printf("deltadj:  Delt changed to %12.5e to satisfy x-courant condition\n",delt);
	}

	//check the y-Courant condition
	if (delt > con/dvmx)
	{
		delt = con/dvmx;
		ktc=(ijky)/(ijmax);
		jtc=(ijky-ktc*ijmax)/imax;
		itc=ijky-ktc*ijmax-jtc*imax;
		strcpy(idt,"cy");
		if(mpi.MyRank == 0) printf("deltadj:  Delt changed to %12.5e to satisfy y-courant condition\n",delt);
	}
	
	//check the z-Courant condition
	if (delt > con/dwmx)
	{
		delt = con/dwmx;
		ktc=(ijkz)/(ijmax);
		jtc=(ijkz-ktc*ijmax)/imax;
		itc=ijkz-ktc*ijmax-jtc*imax;
		strcpy(idt,"cz");
		if(mpi.MyRank == 0) printf("deltadj:  Delt changed to %12.5e to satisfy z-courant condition\n",delt);
	}

	if (VARPROP)
	{	
		xmumin = 1.0e+20;
		sigmamax = 1.0e-20;
		alfa = 1.0e-20;

		for (i=0;i<imax;i++)
			for (j=0;j<jmax;j++)
				for (k=0;k<kmax;k++)
				{
					if (rho[IJK]/xmu[IJK] < xmumin) xmumin = rho[IJK]/xmu[IJK];
					if (cond[IJK]/(cp[IJK]*rho[IJK]) > alfa) alfa = cond[IJK]/(cp[IJK]*rho[IJK]);
					if (sigma[IJK] > sigmamax) sigmamax = sigma[IJK];
				}

		dallreduce (&xmumin, &temp, 1, OP_MIN);
		xmumin=temp;
		dallreduce (&alfa, &temp, 1, OP_MAX);
		alfa=temp;
		dallreduce (&sigmamax, &temp, 1, OP_MAX);
		sigmamax=temp;

		dtvis = dtvist*xmumin/3.0;
		dtdif = dtdift/(2.0*alfa);
		dtsft = sqrt(((rhof1+rhof2)/2.0)*CUBE(dtsftt)/(18.0*pi*sigmamax+tiny));
	}

	//surface tension limit
	if (delt > dtsft)
	{
		delt = dtsft;
		itc=isft;
		jtc=jsft;
		ktc=ksft;
		strcpy (idt, "st");
		if(mpi.MyRank == 0) printf("deltadj:  Delt changed to %12.5e to satisfy surface tension limit\n",delt);
	}
	
	//viscosity limit
	if (delt > dtvis)
	{
		delt = dtvis;
		itc=ivis;
		jtc=jvis;
		ktc=kvis;
		strcpy (idt,"v");
		if(mpi.MyRank == 0) printf("deltadj:  Delt changed to %12.5e to satisfy viscosity limit\n",delt);
	}

	//Diffusion limit
	if (ENERGY)
	{
		if (delt > dtdif)
		{
			delt=dtdif;
			itc=idif;
			jtc=jdif;
			ktc=kdif;
			strcpy (idt,"df");
			if(mpi.MyRank == 0) printf("deltadj:  Delt changed to %12.5e to satisfy diffusion limit\n",delt);
		}
	}

	//check whether this delt yields a t greater than twplt
	if (t+delt > twplt)
	{
		deltold=delt;
		delt=twplt-t;
	}
	/**else if (delt > 7.e-6)
	{
		if(mpi.MyRank == 0) printf("deltadj: Delt wanted to be changed higher than the original -%12.5e- Restricted by Cory to 5.e-6\n",delt);
		delt = 7.e-6;
		deltold = delt;
	}**/

	else
		deltold=0.0;
		
	//if(mpi.MyRank==0) printf("the time step at the end is %e\n",delt);
}
