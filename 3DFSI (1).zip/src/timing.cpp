#include "timing.h"
#include "mpi.h"
#include <stdio.h>

ReconstructionTiming recon_timing;

void init_timing() {
    recon_timing.recons_3p_time = 0.0;
    recon_timing.recons_contact_line_time = 0.0;
    recon_timing.layer_3p_time = 0.0;
    recon_timing.flag_2p1p_time = 0.0;
    recon_timing.total_reconstruction_time = 0.0;
    recon_timing.golden_search_time = 0.0;
    recon_timing.ren_method_time = 0.0;
}

void reset_timing() {
    init_timing();
}

void print_timing_results() {
    double total_time = recon_timing.recons_3p_time + 
                       recon_timing.recons_contact_line_time + 
                       recon_timing.layer_3p_time + 
                       recon_timing.flag_2p1p_time;
    
    recon_timing.total_reconstruction_time = total_time;
    
    if (mpi.MyRank == 0) {
        printf("\nThree-Phase Reconstruction Timing Results:\n");
        printf("----------------------------------------\n");
        printf("recons_3p_time: %.6f seconds (%.2f%%)\n", 
               recon_timing.recons_3p_time, 
               (recon_timing.recons_3p_time/total_time)*100);
        printf("recons_contact_line_time: %.6f seconds (%.2f%%)\n", 
               recon_timing.recons_contact_line_time,
               (recon_timing.recons_contact_line_time/total_time)*100);
        printf("layer_3p_time: %.6f seconds (%.2f%%)\n", 
               recon_timing.layer_3p_time,
               (recon_timing.layer_3p_time/total_time)*100);
        printf("flag_2p1p_time: %.6f seconds (%.2f%%)\n", 
               recon_timing.flag_2p1p_time,
               (recon_timing.flag_2p1p_time/total_time)*100);
        printf("----------------------------------------\n");
        printf("Golden search time: %.6f seconds (%.2f%% of total)\n",
               recon_timing.golden_search_time,
               (recon_timing.golden_search_time/total_time)*100);
        printf("Ren's method time: %.6f seconds (%.2f%% of total)\n", 
               recon_timing.ren_method_time,
               (recon_timing.ren_method_time/total_time)*100);
        printf("----------------------------------------\n");
        printf("Total reconstruction time: %.6f seconds\n", total_time);
        printf("----------------------------------------\n\n");
    }
} 