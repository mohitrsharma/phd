#include <math.h>
#include "ripple.h"
#include "testing.h"

/******************************************************************************
This subroutine calculates error_sum variable which is used as a measure of 
how well the spherical shape of droplet is preserved during translation

Subroutine RESIDUAL is called by:	SPHERICITY

Subroutine RESIDUAL calls:	

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Mace chages that make this subroutine work correct Ben         Sept 23 2005
 in MPI mode.  Now, the vars. sum_error, f1total are
 summed up and the result is stored on process 0. 
 these changes go with the changes made in sphericty
 and ripple subroutines made on this day.
-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

void residual()
{
	int i, j, k;
	double error_sum = 0.0;
	double f1total = 0.0;
	double f_total = 0.0;
	double temp;
	
	//every process needs to do this in order to find local values for error_sum
	//f1total and f_total
	for ( i = 1; i < im1; i++)
		for ( j = 1; j < jm1; j++)
			for ( k = 1; k < km1; k++)
			{
				error_sum += fabs( f[IJK] - f1[IJK] );
				f1total += f1[IJK];
				f_total += f[IJK];
			}
	//now the local error_sum, f1total anf f_total are summed up and result is
	//stored on process 0 
	dreduce(&error_sum,&temp,1,OP_SUM);
	if(mpi.MyRank == 0)
		error_sum = temp;//error_sum on process 0 is now equal to sum of all
						 //error_sum variables on every process
	
	dreduce(&f1total,&temp,1,OP_SUM);
	if(mpi.MyRank == 0)
		f1total = temp;
	
	dreduce(&f_total,&temp,1,OP_SUM);
	if(mpi.MyRank == 0)
		f_total = temp;
	
	if(mpi.MyRank == 0)
	{
		fprintf(files.sphere,"error_sum is %12.4e, f1total is %12.4e and ftotal is %12.4e\n",
		error_sum, f1total, f_total);
		fprintf( files.sphere, "Deviation from spherity at cycle %d = %12.4e\n",
				ncyc, error_sum/f1total);

	}
}

