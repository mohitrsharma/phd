#include "ripple.h"

/******************************************************************************


Subroutine DECL is called by:	

Subroutine DECL calls:			

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION												NAME		DATE

-New parameters added for variable properties           Babak       Sep 13 2009
-Created this template for tracking changes				Ben			April 21 2005
-Deleting xmu to the list of "double //intvarr"			Amirreza	Dec. 2,2005
-Adding xmu to the list of "double //fldvarr"			Amirreza	Dec. 2,2005
-Adding rho to the list of "double //fldvarr"			Amirreza	Dec. 7,2005
-Adding rhof2,xmuf2 to the list of "double //fldvarr"	Amirreza	Dec. 8,2005

_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

struct _dim dim;
struct _mpi mpi;
struct _files files;

//fldvarr
double *u,*v,*w,*p,*f,*h,*tmp;
double *un,*vn,*wn,*pn,*fn,*hn,*tmpn,*FN;
double *ar,*af,*ao,*ac;
#ifdef CUDA
int *A_row, *A_col;
double *A_val, *jacobi_a, *CUDA_RHS, *X;
#endif
#ifndef rudman_fine
double *utemp,*vtemp;
#endif
double *xmu,*rho,*cp,*cond,*sigma,*ftemp;
double *avnx,*avny,*avnz;
double *rhorc,*rhofc,*rhooc;
double *gradrox,*gradroy,*gradroz;

#ifdef rudman_fine
double *f_f,*fn_f,*vol_f,*FN_f;
//2nd layer of ghost in standard grid
double *f2mx,*f2my,*f2mz,*splanDo2;
int t_prob,t_prob2,p_flg; 
double *temp_f[12];

//*********************************** New Variables **************************//
double *ytubef_field;
double z_upper_bound;

double *plug_f;
double *plug_c;

double x_carina;
	
double z_bifurcation;

double parent_radius;

double film_thickness;

double tube_angle;

int plug_number = 0;
double plug_frequency = 0.0;
double plug_i_time = 0.0;

#ifdef impose_CA
	double *f2_arr;
#endif

// passive scalar transport
double *scal, *crse_scal, *scal_c, *flx;
//***************************************************************************//

#ifdef __solid
double *psi,*psi_f,*psin_f,*PSIN_f;
double psivol, pvchgt, rhof0;
double *planDo2,*fvirt_f,*fvirt2_f,*avnx2_f,*avny2_f,*avnz2_f;
int *planIn2, *triple_flg,*triple_flg2, *neigh_triple;
double *psi2_f,*f2_f;
double *psi2mx,*psi2my,*psi2mz;


//*********************************** New Variables **************************//
double *alpha_f;
double global_velocity=0;

double *g_fvirt;

double time_1, time_2;

#ifdef print_norm
double *global_kappa;
double *g_normx, *g_normy, *g_normz;

#endif print_norm
//***************************************************************************//

st_point t_nor, t_cent;
st_point Theta[NBODY+1], Omega[NBODY+1], Omegan[NBODY+1], Cent[NBODY+1];
st_point Mvert[NBODY+1],Pvert[NBODY+1];
double rig_U[NBODY+1][4], rig_Un[NBODY+1][4];
int i_max[NBODY+1],i_min[NBODY+1],j_min[NBODY+1],j_max[NBODY+1],k_min[NBODY+1],k_max[NBODY+1];
int ZDOF[NBODY+1][7], IPRES[NBODY+1];
#endif
#endif

#ifdef bl_mg
	double *mg_cc[MGLEVS+1], *mg_dd[MGLEVS+1], *mg_uu[MGLEVS];
	double *mg_ss[MGLEVS+1], *mg_ec[MGLEVS+1][4];
	int mg_bnd[MGLEVS+1][4];
	
	int mg_nu1,mg_nu2,mg_max_iter,mg_bottom_max_iter;
	double mg_eps,mg_abs_eps,mg_bottom_solve_eps,mg_dh[MGLEVS+1][4];
#endif

//multigrid parameters
int npre,npost,ntop,mgcycles;
double omega,maxres;
int minmgcycles;

//fldvari
int *nf, *kbot, *ktop;	//kbot[ny][nx], ktop[ny][nx]

//meshr
double *x,*y,*z;				//x[nx], y[ny], z[nz]
double *xi,*yj,*zk;			//xi[nx], yj[ny], zk[nz]
double *delx,*dely,*delz;	//delx[nx], dely[ny], delz[nz]
double *rdx,*rdy,*rdz;		//rdx[nx], rdy[ny], rdz[nz]
double *delxl,*delyb,*delzu;	//delxl[nx],delyb[ny],delzu[nz]
double *rdelxl,*rdelyb,*rdelzu;	//rdelxl[nx],rdelyb[ny],rdelzu[nz]
double *vol;					//vol[nz][ny][nx]
double xe,ye,ze;
double dxmn,dymn,dzmn,xmn,ymn,zmn;

//meshi
int nxmn,nymn,nzmn,inside[7];

//intvarr
double
    delt,t,prtdt,twprt,pltdt,twplt,twfin,xmuf1,
    dtend,dmpdt,twdmp,rhof1,vchgt,stf1,gx,gy,gz,uf1,
    vf1,wf1,uf2,vf2,wf2,flgc,xmin,xmax,ymin,ymax,zmin,
	zmax,tke,dudr,dudl,dudt,dudb,dudo,dudu,dvdr,
	dvdl,dvdt,dvdb,dvdo,dvdu,dwdr,dwdl,dwdt,dwdb,dwdo,
    dwdu,tquit,tbeg,dxmin,dymin,dzmin,psat,
	dtvis,dtvist,dtsft,dtsftt,dtdif,dtdift,
    deltold,con,fcvlim,cangler,canglel,
    canglet,cangleb,cangleo,cangleu,xmv,ymv,zmv,
    frctn,radius,xcent,ycent,zcent,fvol,spr,
    sprl,sprr,datadt,twdata,rhof2,xmuf2,
	condf1,condf2,cpf1,cpf2,h0f2,tif1,tif2,
	bcvl,bcvr,bcvb,bcvf,bcvu,bcvo;

//varprop
int nFLUID1, nFLUID2;
double FLUID1_T[20], FLUID1_xmu[20], FLUID1_st[20], FLUID1_Cp[20], FLUID1_K[20];
double FLUID2_T[20], FLUID2_xmu[20], FLUID2_st[20], FLUID2_Cp[20], FLUID2_K[20];

//intvari
int
	ncyc,kl,kr,kb,kf,ko,ku,iter,
	kel,ker,keb,kef,keu,keo,
    nocon,nflgc,liter,itc,jtc,ktc,ivis,jvis,
    kvis,isft,jsft,ksft,idif,jdif,kdif,ibcflg,
	ica,iplot,idump,islice,iar,istart;

//constr
double 
	emf,emf1,em10,ep10,em6p1,em61,
	pi,rpd,pi2,zero,pone,half,one,two;

//frsrfr
double frsurf;

//frsrfi
int *ijkfr;		//ijkfr[nz][ny][nx]

//labelc
char idt[3]="";

//Jet Pressure
double po_c;

//arear
double 
	n1,n2,n3,pcorner[8],pp[6],qq[6],rr[6],
	xco[6],yco[6],zco[6];

//temp
double *temp[25];
//bool sflag;
