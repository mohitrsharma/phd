#include "ripple.h"
#include <stdlib.h>
#include "comm.h"
#include <string.h>
#include "testing.h"

/******************************************************************************
This subroutine sets boundary conditions on the 6 real faces of the numerical
domain.  There are currently 4 types of boundary conditions that are
implemented in P3PPLE, and they are set by setting appropriate k value in
the INPUT file.

k   BC
------
1   Slip(symmetry)
2   No-slip(wall)
3   Inflow
4   Open
*5  Moving lid....experimental

mpi.Neighbors[index] array is defined as follows

Index   Side
------------
0       Left
1       Right
2       Back
3       Front
4       Under
5       Over

If mpi.Neighbors[index]= -1 that means that the processor has a real and
not virtual boundary accross that face

Subroutine BC is called by: ACCEL, CONVECT, SETUP, TENSION, VISCOUS, VOFDLY 

Subroutine BC calls:    BCOBS

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION                                         NAME        DATE

- Subroutine modified for inflow_U_jet on under		S.Codyer	Feb 1 2012
  face to have an inflow jet

- Subroutine modified for open under face for		Babak		Sep 24 2009
  jet, use ku == 5 to chop the jet at a certain
  Z plane.
  
- Subroutine modified to accomodate inflow jet		Babak		Sep 18 2009
  from the over boundary
  
- Velocity along the edges are not set to zero		Babak       October 23 2008
  anymore if one of the adjoining boundaries 
  is symmetry.
  
- Improved how BCs are applied by adding go to		Ben         June 19 2007
  done lines.

- Added extra condition to check for if nf=8.       Ben         Aug 20 2005

- Changed all IND(i,j,k) to IJK etc..               Ben         May 18 2005

- Added an extra if condition when setting the      Ben         May 17 2005
  tangential velocities so its not done for 
  obstacles.

- Fixed bc's applied to right, front and top ghost  Ben         May 14 2005
  cell. added "-1", "-jmax" and "-ijmax" terms in
  appropriate places in the code.

- Added a function call to bcobs at the end of		Ben         May 02 2005
  this subroutine.

- Created this template for tracking changes.       Ben         April 21 2005

- Fixed up the bc's for the ghost cells.            Ben         January  2005

_________________________________TO DO LIST____________________________________

DESCRIPTION                                         NAME        DATE


*******************************************************************************/

void ytube_inflow_O_face();
void solid_bc_entry ();
void solid_bc_rigid ();

void bc()
{
	/*
	 * This subroutine applies the boundary conditions on six faces of the 
	 * numerical domain.  This is done by setting velocity and pressure 
	 * components, in the gost cells, which are appropriate for that boundar
	 * condition.  Also, room is left so that subroutines applying custom
	 * subroutines can be called from here. All custom BC subroutines are 
	 * currently placed in headers/testing.h folder.
	 */
	
    //Use of temp is ok. 
    //temp[20] is only used in convect, but temp[20] is overwritten immediately after bc returns.
    //(i.e. temp[20] need not be preserved)

    int i,j,k;
    int *neighs = (int*)temp[12];
    double ftotal=0.0;
    
    memset (neighs, 0, NX*NY*NZ*sizeof(int));

    /*LEFT FACE*/
    if (mpi.Neighbors[0] == -1)
    {
          for(k=0;k<kmax;k++)
            for(j=0;j<jmax;j++) {
                const int ijkl = IND(0, j, k);
                p[ijkl] = p[ijkl + 1];
                f[ijkl] = f[ijkl + 1];

                if (kl == 1)                /*Symmetry BC*/
                {
                    u[ijkl] = 0.0;
                    v[ijkl] = v[ijkl + 1];
                    w[ijkl] = w[ijkl + 1];
                }           
                else if (kl == 2)           /*Wall BC*/
                {
                    u[ijkl] = 0.0;
                    v[ijkl] = -v[ijkl + 1];
                    w[ijkl] = -w[ijkl + 1];
                }
                else if (kl == 3)           /*Inflow BC*/
                {
                    inflow_L_face();
    //              inflow_L_jet();
					goto done_LeftBC;
    
                }
                else if (kl == 4)           /*Open BC*/
				{
                    open_L();
					goto done_LeftBC;
				}
					
                else
                {
                    printf("Error in kl\n");
                    exit(0);
                }           
            }
			done_LeftBC: ;
    }
    /*RIGHT FACE*/
    if (mpi.Neighbors[1] == -1)
    {
        for (k=0;k<kmax;k++)
         for (j=0;j<jmax;j++)            
            {
                const int ijkr = IND(im1, j, k);
                p[ijkr] = p[ijkr - 1];
                f[ijkr] = f[ijkr - 1];

                if (kr == 1)
                {
                    u[ijkr - 1] = 0;
                    v[ijkr] = v[ijkr - 1];
                    w[ijkr] = w[ijkr - 1];
                }           
                else if (kr == 2) 
                {
                    u[ijkr - 1] = 0;
                    v[ijkr] = -v[ijkr - 1];
                    w[ijkr] = -w[ijkr - 1];
                }
                else if (kr == 3)
                {
                    inflow_R_face();
    //              inflow_R_jet(); 
					goto done_RightBC;
                }
                else if (kr == 4) 
				{
                    open_R();
					goto done_RightBC;
					}
                else
                {
                    printf("Error with kr\n");
                    exit(0);
                }
            }
			done_RightBC: ;
    }
    
    /*BACK FACE*/
	if (mpi.Neighbors[2] == -1)
    {
        for (k=0;k<kmax;k++)
         for (i=0;i<imax;i++)            
            {
                const int ijkb = IND(i, 0, k);
                p[ijkb] = p[ijkb + imax];
                f[ijkb] = f[ijkb + imax];

                if (kb == 1) 
                {
                    v[ijkb] = 0.0;
                    u[ijkb] = u[ijkb + imax];
                    w[ijkb] = w[ijkb + imax];
                }           
                else if (kb == 2)
                {
                    v[ijkb] = 0.0;
                    u[ijkb] = -u[ijkb + imax];
                    w[ijkb] = -w[ijkb + imax];
                }
                else if (kb == 3) 
                {
                    inflow_B_face();
    //              inflow_B_jet();
					goto done_BackBC;
                }
                else if (kb == 4) 
				{
                    open_B();
					goto done_BackBC;
					}
                else
                {
                    printf("Error with kb\n");
                    exit(0);
                }
            }
			done_BackBC: ;
    }

    /*FRONT FACE*/
    if (mpi.Neighbors[3] == -1)
    {
        for (k=0;k<kmax;k++)
         for (i=0;i<imax;i++)            
            {
                const int ijkf = IND(i, jm1, k);
                p[ijkf] = p[ijkf - imax];
                f[ijkf] = f[ijkf - imax];

                if (kf == 1)
                {
                    v[ijkf-imax] = 0.0;
                    u[ijkf] = u[ijkf - imax];
                    w[ijkf] = w[ijkf - imax];
                }           
                else if (kf == 2)
                {
                    v[ijkf - imax] = 0.0;
                    u[ijkf] = -u[ijkf - imax];
                    w[ijkf] = -w[ijkf - imax];
                }
                else if (kf == 3)
                {
                    inflow_F_face();
    //              inflow_F_jet();             
					goto done_FrontBC;
                }
                else if (kf == 4)
				{
                    open_F();
					goto done_FrontBC;
				}
                else
                {
                    printf("Error in kf\n");
                    exit(0);
                }
            }
			done_FrontBC: ;
    }

    /*UNDER FACE*/
    if (mpi.Neighbors[4] == -1)
    {
        for (j=0;j<jmax;j++)
         for (i=0;i<imax;i++)            
            {
                const int ijku = IND( i, j, 0 );
                 p[ijku] = p[ijku + ijmax]; // -- Cory for dirichlet bc
                 f[ijku] = f[ijku + ijmax]; // plug_c[ijku];

                if (ku == 1)
                {
                    w[ijku] = 0.0;
                    u[ijku] = u[ijku + ijmax];
                    v[ijku] = v[ijku + ijmax];
                }           
                else if (ku == 2)
                {
                    w[ijku] = 0.0;
                    u[ijku] = -u[ijku + ijmax];
                    v[ijku] = -v[ijku + ijmax];
                }
                else if (ku == 3)
                {
//                  inflow_U_face();
		    inflow_U_jet_Laminar();
		    //inflow_U_jet_Turbulent();
		    goto done_UnderBC;
                }
                else if (ku == 4)
				{
//                    open_U();
//					outflow_pratt_nozzle();
					goto done_UnderBC;
				}
                else if (ku == 5)
				{
                    //open_U_jet();
					//inflow_U_jet();
					goto done_UnderBC;
				}
                else
                {
                    printf("Error in ku\n");
                    exit(0);
                }
            }
			done_UnderBC: ;
    }

    /*OVER FACE*/
	if (mpi.Neighbors[5] == -1)
		{
			//printf("Ko BC - MPI RANK = %d\n",mpi.MyRank);
		    for (j=0;j<jmax;j++)
		     for (i=0;i<imax;i++)		        
		        {
		            const int ijko = IND(i, j, km1);
		            p[ijko] = p[ijko - ijmax];
		            f[ijko] = f[ijko - ijmax];

		            if  (ko == 1)
		            {
		                w[ijko - ijmax] = 0.0; 
		                u[ijko] = u[ijko - ijmax];
		                v[ijko] = v[ijko - ijmax];
		            }
		            else if (ko == 2) 
		            {
		                w[ijko - ijmax] = 0.0;
		                u[ijko] = -u[ijko - ijmax];
		                v[ijko] = -v[ijko - ijmax];
		                
#ifdef solid_entry		                
		                solid_bc_entry ();
#endif
		            }
		            else if (ko == 3)
		            {
	//                  inflow_O_face();
		            //    inflow_O_jet();
		                ytube_inflow_O_face();
						goto done_OverBC;
		            }
		            else if(ko == 4)
					{
		                open_O();
						goto done_OverBC;
					}
		            else if(ko == 5)
					{
	//                  lid_O();
	//					inflow_DIHEN();
	// 					inflow_pratt_nozzle();
						inflow_O_jet();
						goto done_OverBC;
					}
		            else 
		            {
		                printf("Error in ko\n");
		                exit(1);
		            }
		        }
				done_OverBC: ;
		}

    
    /*Zero out all velocities along the edges of the grid
	  except for the symmetry boundaries*/
    
	/*Edges running along x-direction*/
    for (i=0;i<imax;i++)
    {
        /*Edge between back and under faces*/
        if (mpi.Neighbors[2]+mpi.Neighbors[4] == -2)
            if (kb != 1 && ku != 1)
				u[IND(i,0,0)]=0.0;

        /*Edge between front and under faces*/
        if (mpi.Neighbors[3]+mpi.Neighbors[4] == -2)
            if (kf != 1 && ku != 1)
	            u[IND(i,jm1,0)]=0.0;

        /*Edge between back and over faces*/
        if (mpi.Neighbors[2]+mpi.Neighbors[5] == -2)
            if (kb != 1 && ko != 1)
	            u[IND(i,0,km1)]=0.0;

        /*Edge between front and over faces*/
        if (mpi.Neighbors[3]+mpi.Neighbors[5] == -2)
            if (kf != 1 && ko != 1)
	            u[IND(i,jm1,km1)]=0.0;

    }
    /*Edges running along y-direction*/
    for (j=0;j<jmax;j++)
    {
        /*Edge between left and under faces*/
        if (mpi.Neighbors[0]+mpi.Neighbors[4] == -2)
            if (kl != 1 && ku != 1)
	            v[IND(0,j,0)]=0.0;

        /*Edge between right and under faces*/
        if (mpi.Neighbors[1]+mpi.Neighbors[4] == -2)
            if (kr != 1 && ku != 1)
	            v[IND(im1,j,0)]=0.0;

        /*Edge between left and over faces*/
        if (mpi.Neighbors[0]+mpi.Neighbors[5] == -2)
            if (kl != 1 && ko != 1)
	            v[IND(0,j,km1)]=0.0;

        /*Edge between right and over faces*/
        if (mpi.Neighbors[1]+mpi.Neighbors[5] == -2)
            if (kr != 1 && ko != 1)
	            v[IND(im1,j,km1)]=0.0;

    }
    /*Edges running along z-direction*/
    for (k=0;k<kmax;k++)
    {
        /*Edge between left and back faces*/
        if (mpi.Neighbors[0]+mpi.Neighbors[2] == -2)
            if (kl != 1 && kb != 1)
	            w[IND(0,0,k)]=0.0;

        /*Edge between right and back faces*/
        if (mpi.Neighbors[1]+mpi.Neighbors[2] == -2)
            if (kr != 1 && kb != 1)
	            w[IND(im1,0,k)]=0.0;

        /*Edge between left and front faces*/
        if (mpi.Neighbors[0]+mpi.Neighbors[3] == -2)
            if (kl != 1 && kf != 1)
	            w[IND(0,jm1,k)]=0.0;

        /*Edge between right and front faces*/
        if (mpi.Neighbors[1]+mpi.Neighbors[3] == -2)
            if (kr != 1 && kf != 1)
	            w[IND(im1,jm1,k)]=0.0;

    }

    /*Apply wall bc at obstacles, if there are obstacle
      surface cells in local domain*/
      
#ifndef no_obs
    xchg<double>(u);
    xchg<double>(v);
    xchg<double>(w);
#endif

    if(mpi.obst_flag) 
    {    
        bcobs();
    }

	//remove later... ashish
	/*for(i=0;i<im1;i++)
	 for(j=0;j<jm1;j++)
	  for(k=0;k<km1;k++) {
		  v[IJK]=0.0;
	  }*/

    /*Exchange u,v,w,p,f accros virtual boundaries...*/
    xchg<double>(u);
    xchg<double>(v);
    xchg<double>(w);
    xchg<double>(p);
    xchg<double>(f);
    
}
    
#ifdef rudman_fine
void bcvel() {
      //
      
    int i,j,k;
    /*LEFT FACE*/
    if (mpi.Neighbors[0] == -1)
    {
        for(k=0;k<kmax;k++)
         for(j=0;j<jmax;j++)            
            {
                const int ijkl = IND(0, j, k);
                //p[ijkl] = p[ijkl + 1];
                //f[ijkl] = f[ijkl + 1];

                if (kl == 1)                /*Symmetry BC*/
                {
                    u[ijkl] = 0.0;
                    v[ijkl] = v[ijkl + 1];
                    w[ijkl] = w[ijkl + 1];
                }           
                else if (kl == 2)           /*Wall BC*/
                {
                    u[ijkl] = 0.0;
                    v[ijkl] = -v[ijkl + 1];
                    w[ijkl] = -w[ijkl + 1];
                }
                else if (kl == 3)           /*Inflow BC*/
                {
                    inflow_L_face();
    //              inflow_L_jet();
					goto done_LeftBC;
    
                }
                else if (kl == 4)           /*Open BC*/
				{
                    open_L();
					goto done_LeftBC;
				}
					
                else
                {
                    printf("Error in kl\n");
                    exit(0);
                }           
            }
			done_LeftBC: ;
    }
    /*RIGHT FACE*/
    if (mpi.Neighbors[1] == -1)
    {
        for (k=0;k<kmax;k++)
         for (j=0;j<jmax;j++)            
            {
                const int ijkr = IND(im1, j, k);
                //p[ijkr] = p[ijkr - 1];
                //f[ijkr] = f[ijkr - 1];

                if (kr == 1)
                {
                    u[ijkr - 1] = 0;
                    v[ijkr] = v[ijkr - 1];
                    w[ijkr] = w[ijkr - 1];
                }           
                else if (kr == 2) 
                {
                    u[ijkr - 1] = 0;
                    v[ijkr] = -v[ijkr - 1];
                    w[ijkr] = -w[ijkr - 1];
                }
                else if (kr == 3)
                {
                    inflow_R_face();
    //              inflow_R_jet(); 
					goto done_RightBC;
                }
                else if (kr == 4) 
				{
                    open_R();
					goto done_RightBC;
					}
                else
                {
                    printf("Error with kr\n");
                    exit(0);
                }
            }
			done_RightBC: ;
    }
    
    /*BACK FACE*/
	if (mpi.Neighbors[2] == -1)
    {
        for (k=0;k<kmax;k++)
         for (i=0;i<imax;i++)            
            {
                const int ijkb = IND(i, 0, k);
                //p[ijkb] = p[ijkb + imax];
                //f[ijkb] = f[ijkb + imax];

                if (kb == 1) 
                {
                    v[ijkb] = 0.0;
                    u[ijkb] = u[ijkb + imax];
                    w[ijkb] = w[ijkb + imax];
                }           
                else if (kb == 2)
                {
                    v[ijkb] = 0.0;
                    u[ijkb] = -u[ijkb + imax];
                    w[ijkb] = -w[ijkb + imax];
                }
                else if (kb == 3) 
                {
                    inflow_B_face();
    //              inflow_B_jet();
					goto done_BackBC;
                }
                else if (kb == 4) 
				{
                    open_B();
					goto done_BackBC;
					}
                else
                {
                    printf("Error with kb\n");
                    exit(0);
                }
            }
			done_BackBC: ;
    }

    /*FRONT FACE*/
    if (mpi.Neighbors[3] == -1)
    {
        for (k=0;k<kmax;k++)
         for (i=0;i<imax;i++)           
            {
                const int ijkf = IND(i, jm1, k);
                //p[ijkf] = p[ijkf - imax];
                //f[ijkf] = f[ijkf - imax];

                if (kf == 1)
                {
                    v[ijkf-imax] = 0.0;
                    u[ijkf] = u[ijkf - imax];
                    w[ijkf] = w[ijkf - imax];
                }           
                else if (kf == 2)
                {
                    v[ijkf - imax] = 0.0;
                    u[ijkf] = -u[ijkf - imax];
                    w[ijkf] = -w[ijkf - imax];
                }
                else if (kf == 3)
                {
                    inflow_F_face();
    //              inflow_F_jet();             
					goto done_FrontBC;
                }
                else if (kf == 4)
				{
                    open_F();
					goto done_FrontBC;
				}
                else
                {
                    printf("Error in kf\n");
                    exit(0);
                }
            }
			done_FrontBC: ;
    }
    
     /*UNDER FACE*/
    if (mpi.Neighbors[4] == -1)
    {
        for (j=0;j<jmax;j++)
         for (i=0;i<imax;i++)            
            {
                const int ijku = IND( i, j, 0 );
                //p[ijku] = p[ijku + ijmax];
                //f[ijku] = f[ijku + ijmax];

                if (ku == 1)
                {
                    w[ijku] = 0.0;
                    u[ijku] = u[ijku + ijmax];
                    v[ijku] = v[ijku + ijmax];
                }           
                else if (ku == 2)
                {
                    w[ijku] = 0.0;
                    u[ijku] = -u[ijku + ijmax];
                    v[ijku] = -v[ijku + ijmax];
                }
                else if (ku == 3)
                {
//                  inflow_U_face();
					inflow_U_jet_Laminar();
					//inflow_U_jet_Turbulent();
					goto done_UnderBC;
                }
                else if (ku == 4)
				{
//                    open_U();
//					outflow_pratt_nozzle();
					goto done_UnderBC;
				}
                else if (ku == 5)
				{
                    //open_U_jet();
					//inflow_U_jet();
					goto done_UnderBC;
				}
                else
                {
                    printf("Error in ku\n");
                    exit(0);
                }
            }
			done_UnderBC: ;
    }

    /*OVER FACE*/
	if (mpi.Neighbors[5] == -1)
		{
			//printf("Ko BC - MPI RANK = %d\n",mpi.MyRank);
		    for (j=0;j<jmax;j++)
		     for (i=0;i<imax;i++)		        
		        {
		            const int ijko = IND(i, j, km1);
		            //p[ijko] = p[ijko - ijmax];
		            //f[ijko] = f[ijko - ijmax];

		            if  (ko == 1)
		            {
		                w[ijko - ijmax] = 0.0; 
		                u[ijko] = u[ijko - ijmax];
		                v[ijko] = v[ijko - ijmax];
		            }
		            else if (ko == 2) 
		            {
		                w[ijko - ijmax] = 0.0;
		                u[ijko] = -u[ijko - ijmax];
		                v[ijko] = -v[ijko - ijmax];
#ifdef solid_entry		                
		                solid_bc_entry ();
		                solid_bc_rigid ();
#endif
		            }
		            else if (ko == 3)
		            {
	//                  inflow_O_face();
		                //inflow_O_jet();
		                
		                ytube_inflow_O_face();
						goto done_OverBC;
		            }
		            else if(ko == 4)
					{
		                open_O();
						goto done_OverBC;
					}
		            else if(ko == 5)
					{
	//                  lid_O();
	//					inflow_DIHEN();
	// 					inflow_pratt_nozzle();
						inflow_O_jet();
						goto done_OverBC;
					}
		            else 
		            {
		                printf("Error in ko\n");
		                exit(1);
		            }
		        }
				done_OverBC: ;
		}
		
		
     /*Zero out all velocities along the edges of the grid
	  except for the symmetry boundaries*/
    
	/*Edges running along x-direction*/
    for (i=0;i<imax;i++)
    {
        /*Edge between back and under faces*/
        if (mpi.Neighbors[2]+mpi.Neighbors[4] == -2)
            if (kb != 1 && ku != 1)
				u[IND(i,0,0)]=0.0;

        /*Edge between front and under faces*/
        if (mpi.Neighbors[3]+mpi.Neighbors[4] == -2)
            if (kf != 1 && ku != 1)
	            u[IND(i,jm1,0)]=0.0;

        /*Edge between back and over faces*/
        if (mpi.Neighbors[2]+mpi.Neighbors[5] == -2)
            if (kb != 1 && ko != 1)
	            u[IND(i,0,km1)]=0.0;

        /*Edge between front and over faces*/
        if (mpi.Neighbors[3]+mpi.Neighbors[5] == -2)
            if (kf != 1 && ko != 1)
	            u[IND(i,jm1,km1)]=0.0;

    }
    /*Edges running along y-direction*/
    for (j=0;j<jmax;j++)
    {
        /*Edge between left and under faces*/
        if (mpi.Neighbors[0]+mpi.Neighbors[4] == -2)
            if (kl != 1 && ku != 1)
	            v[IND(0,j,0)]=0.0;

        /*Edge between right and under faces*/
        if (mpi.Neighbors[1]+mpi.Neighbors[4] == -2)
            if (kr != 1 && ku != 1)
	            v[IND(im1,j,0)]=0.0;

        /*Edge between left and over faces*/
        if (mpi.Neighbors[0]+mpi.Neighbors[5] == -2)
            if (kl != 1 && ko != 1)
	            v[IND(0,j,km1)]=0.0;

        /*Edge between right and over faces*/
        if (mpi.Neighbors[1]+mpi.Neighbors[5] == -2)
            if (kr != 1 && ko != 1)
	            v[IND(im1,j,km1)]=0.0;

    }
    /*Edges running along z-direction*/
    for (k=0;k<kmax;k++)
    {
        /*Edge between left and back faces*/
        if (mpi.Neighbors[0]+mpi.Neighbors[2] == -2)
            if (kl != 1 && kb != 1)
	            w[IND(0,0,k)]=0.0;

        /*Edge between right and back faces*/
        if (mpi.Neighbors[1]+mpi.Neighbors[2] == -2)
            if (kr != 1 && kb != 1)
	            w[IND(im1,0,k)]=0.0;

        /*Edge between left and front faces*/
        if (mpi.Neighbors[0]+mpi.Neighbors[3] == -2)
            if (kl != 1 && kf != 1)
	            w[IND(0,jm1,k)]=0.0;

        /*Edge between right and front faces*/
        if (mpi.Neighbors[1]+mpi.Neighbors[3] == -2)
            if (kr != 1 && kf != 1)
	            w[IND(im1,jm1,k)]=0.0;

    }
	//remove later... ashish
	/*for(i=0;i<im1;i++)
	 for(j=0;j<jm1;j++)
	  for(k=0;k<km1;k++) {
		  v[IJK]=0.0;
	  }*/
    
#ifndef no_obs
      xchg<double>(u);
      xchg<double>(v);
      xchg<double>(w);
#endif
	  if(mpi.obst_flag) 
	  {    
		  bcobs();
          }
    
        xchg<double>(u);
        xchg<double>(v);
        xchg<double>(w);

}
#endif
