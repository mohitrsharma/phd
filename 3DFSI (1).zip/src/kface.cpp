#include "ripple.h"
#include <stdlib.h>
#include <time.h>
#include "testing.h"

/******************************************************************************
This subroutine KFACE calculates the conductivity at the interface of two  
computational cell.

Subroutine KFACE is called by:	DIFFUSION

Subroutine KFACE calls:

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

- Crated this subroutine for conductivity at face	Babak		May 15 2009


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE

- Variable properties modification done!            Babak       Sep 11 2009
  
- Works only for constant properties.
  Variable properties to be added.					Babak		May 15 2009

*******************************************************************************/

double kface (int C1INDX, int C2INDX)
{
	double kface;

	kface = 2.0/(1.0/cond[C1INDX]+1.0/cond[C2INDX]);
//	kface = (cond[C1INDX]+cond[C2INDX])/2.0;

	return kface;

}
