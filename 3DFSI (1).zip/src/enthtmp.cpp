#include "ripple.h"
#include <stdlib.h>
#include <time.h>
#include "testing.h"

/******************************************************************************
This subroutine ENTHTMP converts enthalpy field into temperature field

Subroutine ENTHTMP is called by:	DIFFUSION, INITENRG

Subroutine ENTHTMP calls:

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

- Created this subroutine							Babak		May 15 2009


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE

- Subroutine modified for variable properties		Babak		Sep 26 2009
  
- Works only for constant properties.				Babak		May 15 2009

*******************************************************************************/

void enthtmp()
{
	double ff1, ff2, cpTf1, cpTf2;
	int i, j, k;

	for(i=1;i<im1;i++)
		for(j=1;j<jm1;j++)
			for(k=1;k<km1;k++)
			{
				if (VARPROP)
				{
					cpTf1=interp(FLUID1_T,FLUID1_Cp,tmp[IJK]);
					cpTf2=interp(FLUID2_T,FLUID2_Cp,tmp[IJK]);
				}
				else
				{
					cpTf1=cpf1;
					cpTf2=cpf2;
				}
				
				if (f[IJK] < em6)
					tmp[IJK] = (h[IJK]-h0f2)/cpTf2;
				else if (f[IJK] > em61)
				{
					tmp[IJK] = h[IJK]/cpTf1;
				}
				else
				{
					ff1 = f[IJK]*rhof1/rho[IJK];
					ff2 = (1.0-f[IJK])*rhof2/rho[IJK];
					tmp[IJK] = h[IJK]/(cpTf1*ff1+cpTf2*ff2);
				}

			}  

	fixtmp();

}
