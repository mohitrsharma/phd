#include "ripple.h"
#include "comm.h"
#include "testing.h"

/******************************************************************************
This subroutine copies f values to ghost cells on the real boundaries.  


Subroutine BCF is called by:	AREA, SETUP, VOFDLY	

Subroutine BCF calls:	BCFOBS

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION	                                        NAME        DATE

-Over face will not be updated for jet input.		Babak		Sep 18 2009
 Jet input updates will be done in BC.  
-Changed the look, but not functionality of bcf     Ben         July 25 2006
 because it was hard to understand what was going
 on in Henry's version of this function.
-Added a function call to bcfobs()                  Ben         May 02 2005
-Created this template for tracking changes         Ben         April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION                                         NAME        DATE


*******************************************************************************/
void solid_bc_entry ();

void bcf()
{
	int i,j,k;
    /*LEFT & RIGHT FACE*/
	for (k=0;k<kmax;k++)
		for (j=0;j<jmax;j++)
		{
			//left face
			if (mpi.Neighbors[0] == -1)
				f[IND(0,j,k)] = f[IND(1,j,k)];
			//right face
			if (mpi.Neighbors[1] == -1)
				f[IND(im1,j,k)] = f[IND(im2,j,k)];
		}
	/*BACK & FRONT FACE*/
	for (k=0;k<kmax;k++)
		for (i=0;i<imax;i++)
		{
			//back face
			if (mpi.Neighbors[2] == -1)
				f[IND(i,0,k)] = f[IND(i,1,k)];
			//front face
			if (mpi.Neighbors[3] == -1)
				f[IND(i,jm1,k)] = f[IND(i,jm2,k)];
		}
	/*UNDER & OVER FACE*/
	for (j=0;j<jmax;j++)
		for (i=0;i<imax;i++)
		{
			//under face
			if (mpi.Neighbors[4] == -1) {
				f[IND(i,j,0)] = f[IND(i,j,1)];
			}
			//over face
			if (mpi.Neighbors[5] == -1)
				f[IND(i,j,km1)] = f[IND(i,j,km2)];
			
		}
	/*copy f to obstacles, if there are obstacle
	  surface cells in local domain*/
	  
#ifndef no_obs
	xchg<double>(f);
#endif
	if( mpi.obst_flag )
	{
		bcfobs();	
	}
	/*exchange f accross virtual boundaries*/
	xchg<double> (f);
}

#ifdef rudman_fine
	void bcf_f()
	{
		int i,j,k;
		/*left and right faces*/
		for (k=0;k<kmax_f;k++)
			for (j=0;j<jmax_f;j++)		
			{
				//left face
				if (mpi.Neighbors[0] == -1)
					f_f[IND_f(0,j,k)] = f_f[IND_f(1,j,k)];
				//right face
				if (mpi.Neighbors[1] == -1)
					f_f[IND_f(im1_f,j,k)] = f_f[IND_f(im2_f,j,k)];
			}
		/*back and front face*/
		for (k=0;k<kmax_f;k++)
			for (i=0;i<imax_f;i++)	
			{
				//back face
				if (mpi.Neighbors[2] == -1)
					f_f[IND_f(i,0,k)] = f_f[IND_f(i,1,k)];
				//front face
				if (mpi.Neighbors[3] == -1)
					f_f[IND_f(i,jm1_f,k)] = f_f[IND_f(i,jm2_f,k)];
			}
		/*under and over face*/
		for (j=0;j<jmax_f;j++)
			for (i=0;i<imax_f;i++)	
			{
				//under face
				if (mpi.Neighbors[4] == -1) {
					f_f[IND_f(i,j,0)] = f_f[IND_f(i,j,1)];
				}
				//over face
				if (mpi.Neighbors[5] == -1)
					f_f[IND_f(i,j,km1_f)] = f_f[IND_f(i,j,km2_f)];
				
			}

#ifndef no_obs
	xchg_f<double> (f_f);
#endif
		if(mpi.obst_flag)
		{	
			bcfobs_f();
		}
		xchg_f<double>(f_f);
	}
	
#ifdef __solid	
	//boundary for solid 
	void bcpsi_f()
	{
		int i,j,k;
		/*left and right faces*/
		for (k=0;k<kmax_f;k++)
			for (j=0;j<jmax_f;j++)	
			{
				//left face
				if (mpi.Neighbors[0] == -1)
					psi_f[IND_f(0,j,k)] = psi_f[IND_f(1,j,k)];
				//right face
				if (mpi.Neighbors[1] == -1)
					psi_f[IND_f(im1_f,j,k)] = psi_f[IND_f(im2_f,j,k)];
			}
		/*back and front face*/
		for (k=0;k<kmax_f;k++)
			for (i=0;i<imax_f;i++)	
			{
				//back face
				if (mpi.Neighbors[2] == -1)
					psi_f[IND_f(i,0,k)] = psi_f[IND_f(i,1,k)];
				//front face
				if (mpi.Neighbors[3] == -1)
					psi_f[IND_f(i,jm1_f,k)] = psi_f[IND_f(i,jm2_f,k)];
			}
		/*under and over face*/
		for (j=0;j<jmax_f;j++)
			for (i=0;i<imax_f;i++)	
			{
				//under face
				if (mpi.Neighbors[4] == -1) {
					psi_f[IND_f(i,j,0)] = psi_f[IND_f(i,j,1)];
				}
				//over face
				if (mpi.Neighbors[5] == -1)
					psi_f[IND_f(i,j,km1_f)] = psi_f[IND_f(i,j,km2_f)];
				
			}
			
#ifdef solid_entry
	solid_bc_entry ();
#endif


#ifndef no_obs
	xchg_f<double> (psi_f);
#endif
		if(mpi.obst_flag)
		{	
			bcpsiobs_f();
		}
		xchg_f<double>(psi_f);
	}
	
void bcpsi()
{
	int i,j,k;
    /*LEFT & RIGHT FACE*/
	for (k=0;k<kmax;k++)
		for (j=0;j<jmax;j++)	
		{
			//left face
			if (mpi.Neighbors[0] == -1)
				psi[IND(0,j,k)] = psi[IND(1,j,k)];
			//right face
			if (mpi.Neighbors[1] == -1)
				psi[IND(im1,j,k)] = psi[IND(im2,j,k)];
		}
	/*BACK & FRONT FACE*/
	for (k=0;k<kmax;k++)
		for (i=0;i<imax;i++)	
		{
			//back face
			if (mpi.Neighbors[2] == -1)
				psi[IND(i,0,k)] = psi[IND(i,1,k)];
			//front face
			if (mpi.Neighbors[3] == -1)
				psi[IND(i,jm1,k)] = psi[IND(i,jm2,k)];
		}
	/*UNDER & OVER FACE*/
	for (j=0;j<jmax;j++)
		for (i=0;i<imax;i++)
		{
			//under face
			if (mpi.Neighbors[4] == -1) {
				psi[IND(i,j,0)] = psi[IND(i,j,1)];
			}
			//over face
			if (mpi.Neighbors[5] == -1)
				psi[IND(i,j,km1)] = psi[IND(i,j,km2)];
			
		}

	xchg<double> (psi);
}

void bcfvirt_f()
{
	int i,j,k;
	/*left and right faces*/
	for (k=0;k<kmax_f;k++)
		for (j=0;j<jmax_f;j++)	
		{
			//left face
			if (mpi.Neighbors[0] == -1)
				fvirt_f[IND_f(0,j,k)] = fvirt_f[IND_f(1,j,k)];
			//right face
			if (mpi.Neighbors[1] == -1)
				fvirt_f[IND_f(im1_f,j,k)] = fvirt_f[IND_f(im2_f,j,k)];
		}
	/*back and front face*/
	for (k=0;k<kmax_f;k++)
		for (i=0;i<imax_f;i++)
		{
			//back face
			if (mpi.Neighbors[2] == -1)
				fvirt_f[IND_f(i,0,k)] = fvirt_f[IND_f(i,1,k)];
			//front face
			if (mpi.Neighbors[3] == -1)
				fvirt_f[IND_f(i,jm1_f,k)] = fvirt_f[IND_f(i,jm2_f,k)];
		}
	/*under and over face*/
	for (j=0;j<jmax_f;j++)
		for (i=0;i<imax_f;i++)	
		{
			//under face
			if (mpi.Neighbors[4] == -1) {
				fvirt_f[IND_f(i,j,0)] = fvirt_f[IND_f(i,j,1)];
			}
			
			//over face
			if (mpi.Neighbors[5] == -1)
				fvirt_f[IND_f(i,j,km1_f)] = fvirt_f[IND_f(i,j,km2_f)];
			
		}
		
		//fix for sph-plane test... remove later
		/*if(mpi.Neighbors[4] == -1) {
			double f_p;
			k=0;
			for(i=0;i<=im1_f;i++)
			 for(j=0;j<=jm1_f;j++) {
				 f_p=0.0;
				 cube_plane_int(&f_p,&t_nor,&t_cent,i,j,k,0);
				 fvirt_f[IJK_f] = f_p;
			 }
		}*/
	
//obstacles later .... remember ...ashish
	xchg_f<double>(fvirt_f);
}
#endif
#endif

