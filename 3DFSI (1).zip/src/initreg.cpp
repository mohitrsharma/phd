#include <stdlib.h>
#include <math.h>
#include "testing.h"
#include "ripple.h"
#include "vector.h"
#include <string.h>/*memcpy*/
/******************************************************************************
This subroutine sets the initial velocity field into u, v, and w arrays given
an F field

Subroutine INITREG is called by:	SETUP	

Subroutine INITREG calls:			

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Created this template for tracking changes			Ben			April 21 2005

-Added Solid Velocity initialization                Cory        January 12 2017


-Added Solid Velocity Rotation initialization,      Cory        February 2 2017
 hower it will only initialize rotation for 
 1 solid body currently.


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

void initreg()
{
	//set initial velocity field into u, v, and w arrays, given an f field.
	int i,j,k;
	for (i=1;i<im1;i++)
		for (j=1;j<jm1;j++)
			for (k=1;k<km1;k++)
			{
				
				double tz = (k+mpi.OProc[2]) * (delz[1]);
				u[IJK]=uf2;
				if ( (ar[IJK] > em6) &&  
					((f[IJK] > emf) || (f[IPJK] > emf)))
					u[IJK] = uf1;
				v[IJK]=vf2;
				if ( (af[IJK] > em6) &&
					((f[IJK] > emf) || (f[IJPK] > emf)))
					v[IJK]=vf1;
				w[IJK]=wf2;
				if ((ao[IJK] > em6) && 
					((f[IJK] > emf) || (f[IJKP] > emf)))
					w[IJK] = wf1;
#ifdef rudman_fine
#ifdef __solid
				 //make following more sophisticated for initial solid 
				 //velocities-Omegas-multiple-bodies
				if ( (ar[IJK] > em6) &&  
					((psi[IJK] > emf) || (psi[IPJK] > emf)))
					u[IJK]=0.0;
				if ( (af[IJK] > em6) &&
					((psi[IJK] > emf) || (psi[IJPK] > emf)))
					v[IJK]=0.0;
				if ((ao[IJK] > em6) && 
					((psi[IJK] > emf) || (psi[IJKP] > emf)))
					w[IJK]=0.0;
#endif
#endif
				
				un[IJK]=u[IJK];
				vn[IJK]=v[IJK];
				wn[IJK]=w[IJK];
			}
			
#ifdef rudman_fine
#ifdef __solid
	for(i=1;i<=NBODY;i++) {
		//initialize rigid-body-velocities
		memset(rig_U[i],0,4*sizeof(double));
		Omega[i].x=Omega[i].y=Omega[i].z=0.0;
	}

	rig_U[1][3]= -1.0; //-3.18152; //-0.18152;
	
	//apply the rigid body velocity to the (u,v,w)
	//following is primitive at this stage, can be made more general
	//by getting hints from Nrigid_body_vel3()
	
	double *psimx = temp[21], *psimy = temp[22], *psimz = temp[23];
	for(k=1;k<km1;k++)
	 for(j=1;j<jm1;j++)
	  for(i=1;i<im1;i++) {
		  psimx[IND(i,j,k)] = 0.125* ( psi_f[IND_f(2*i  ,2*j-1,2*k-1)]
									  +psi_f[IND_f(2*i+1,2*j-1,2*k-1)]
									  +psi_f[IND_f(2*i  ,2*j  ,2*k-1)]
									  +psi_f[IND_f(2*i+1,2*j  ,2*k-1)]
									  
									  +psi_f[IND_f(2*i  ,2*j-1,2*k  )]
									  +psi_f[IND_f(2*i+1,2*j-1,2*k  )]
									  +psi_f[IND_f(2*i  ,2*j  ,2*k  )]
									  +psi_f[IND_f(2*i+1,2*j  ,2*k  )] );
		
		if(psimx[IND(i,j,k)] >= em6) u[IJK] = rig_U[1][1];
	  }
	  
	for(k=1;k<km1;k++)
	 for(j=1;j<jm1;j++)
	  for(i=1;i<im1;i++) {
		  psimy[IND(i,j,k)] = 0.125* ( psi_f[IND_f(2*i  ,2*j  ,2*k-1)]
									  +psi_f[IND_f(2*i-1,2*j+1,2*k-1)]
									  +psi_f[IND_f(2*i  ,2*j  ,2*k-1)]
									  +psi_f[IND_f(2*i-1,2*j+1,2*k-1)]
									  
									  +psi_f[IND_f(2*i  ,2*j  ,2*k  )]
									  +psi_f[IND_f(2*i-1,2*j+1,2*k  )]
									  +psi_f[IND_f(2*i  ,2*j  ,2*k  )]
									  +psi_f[IND_f(2*i-1,2*j+1,2*k  )] );
	  
	    if(psimy[IND(i,j,k)] >= em6) v[IJK] = rig_U[1][2];
	  }
	  
	for(k=1;k<km1;k++)
	 for(j=1;j<jm1;j++)
	  for(i=1;i<im1;i++) {
		  psimz[IND(i,j,k)] = 0.125* ( psi_f[IND_f(2*i  ,2*j-1,2*k  )]
									  +psi_f[IND_f(2*i-1,2*j-1,2*k+1)]
									  +psi_f[IND_f(2*i  ,2*j-1,2*k  )]
									  +psi_f[IND_f(2*i-1,2*j-1,2*k+1)]
									  
									  +psi_f[IND_f(2*i  ,2*j  ,2*k  )]
									  +psi_f[IND_f(2*i-1,2*j  ,2*k+1)]
									  +psi_f[IND_f(2*i  ,2*j  ,2*k  )]
									  +psi_f[IND_f(2*i-1,2*j  ,2*k+1)] );
	  
	    if(psimz[IND(i,j,k)] >= em6) w[IJK] = rig_U[1][3];
	  }
	  
	/* Now I need to initialized any rotational velocity on the solid
	 * This is done by first calculating the cell centroids and determining
	 * the distance between it and the solids center of mass. Using this
	 * we find v = omega x r and apply these velocity components to each
	 * cell. This is only being developed for 1 rigid body currently. */
	
	int bindx = NBODY;
	double *psiavnx_f = temp_f[9];
	double *psiavny_f = temp_f[10];
	double *psiavnz_f = temp_f[11];
	
	st_point cent;
	Ncalc_psi_centroid(&Cent[1],1);
	equate_pt(&cent,&Cent[bindx]);
	  
	#define NDIM 3
	//start working with material volumes
	double volt[8],voli; st_point vt[8],v0; int ii;
	double Vol=delx[1]*dely[1]*delz[1]; 
	double r[NDIM+1], I_Omega[NDIM+1];
	
//	Omega[1].x=1.0e0;
	
	double omega[NDIM+1];
	omega[1]=Omega[bindx].x, omega[2]=Omega[bindx].y, omega[3]=Omega[bindx].z;
	
	for(k=k_min[bindx];k<=k_max[bindx];k++)
	 for(j=j_min[bindx];j<=j_max[bindx];j++)
	   for(i=i_min[bindx];i<=i_max[bindx];i++)
	   {
		  //x-momentum
		  if(psimx[IJK] >= em6 && psimx[IJK] <= em61 )
		  {
			  sol_centroid(2*i,2*j,2*k,&vt[0],&volt[0]); // Calculates Centroid
			  sol_centroid(2*i,2*j-1,2*k,&vt[1],&volt[1]);
			  sol_centroid(2*i,2*j-1,2*k-1,&vt[2],&volt[2]);
			  sol_centroid(2*i,2*j,2*k-1,&vt[3],&volt[3]);
		
			  sol_centroid(2*i+1,2*j,2*k,&vt[4],&volt[4]);
			  sol_centroid(2*i+1,2*j-1,2*k,&vt[5],&volt[5]);
			  sol_centroid(2*i+1,2*j-1,2*k-1,&vt[6],&volt[6]);
			  sol_centroid(2*i+1,2*j,2*k-1,&vt[7],&volt[7]);
			  v0.x = 0.0, v0.y = 0.0, v0.z = 0.0, voli = 0.0;
			  
			  for(ii=0;ii<8;ii++) 
			  {
				  v0.x += vt[ii].x*volt[ii], v0.y += vt[ii].y*volt[ii],
				  v0.z += vt[ii].z*volt[ii];
				  voli += volt[ii];
			  }
			  
			v0.x /= voli, v0.y /= voli, v0.z /= voli;
			  
			r[1]=v0.x - cent.x;
			r[2]=v0.y - cent.y;
			r[3]=v0.z - cent.z;
				 
			crossProduct(I_Omega,omega,r);
			u[IJK]=rig_U[bindx][1] + I_Omega[1]; //performs u = U + Omega x r
		  }
		  
		  if(psimx[IJK]>em61)
		  {
			  v0.x = (i+mpi.OProc[0])*delx[1];
			  v0.y = (j+mpi.OProc[1]-0.5)*dely[1];
			  v0.z = (k+mpi.OProc[2]-0.5)*delz[1];
			  
			  r[1] = v0.x - cent.x;
			  r[2] = v0.y - cent.y;
			  r[3] = v0.z - cent.z;
			  
			  crossProduct(I_Omega,omega,r);
			  u[IJK]=rig_U[bindx][1] + I_Omega[1]; //performs u = U + Omega x r
		  }
		  
		  //y-momentum
		  if(psimy[IJK] >= em6 && psimy[IJK] <= em61)
		  {
			  sol_centroid(2*i,2*j,2*k,&vt[0],&volt[0]);
			  sol_centroid(2*i-1,2*j,2*k,&vt[1],&volt[1]);
			  sol_centroid(2*i-1,2*j,2*k-1,&vt[2],&volt[2]);
			  sol_centroid(2*i,2*j,2*k-1,&vt[3],&volt[3]);
		
			  sol_centroid(2*i,2*j+1,2*k,&vt[4],&volt[4]);
			  sol_centroid(2*i-1,2*j+1,2*k,&vt[5],&volt[5]);
			  sol_centroid(2*i-1,2*j+1,2*k-1,&vt[6],&volt[6]);
			  sol_centroid(2*i,2*j+1,2*k-1,&vt[7],&volt[7]);
			  v0.x = 0.0, v0.y = 0.0, v0.z = 0.0, voli = 0.0;
			  
			  for(ii=0;ii<8;ii++) 
			  {
				  v0.x += vt[ii].x*volt[ii], v0.y += vt[ii].y*volt[ii],
				  v0.z += vt[ii].z*volt[ii];
				  voli += volt[ii];
			  }
			  
			v0.x /= voli, v0.y /= voli, v0.z /= voli;
				  
			r[1]=v0.x  - cent.x;
			r[2]=v0.y  - cent.y;
			r[3]=v0.z  - cent.z;
				 
			crossProduct(I_Omega,omega,r);
			v[IJK]=rig_U[bindx][2] + I_Omega[2]; //performs u = U + Omega x r
		  }
		  if(psimy[IJK]>em61)
		  {
			  v0.x = (i+mpi.OProc[0]-0.5)*delx[1];
			  v0.y = (j+mpi.OProc[1])*dely[1];
			  v0.z = (k+mpi.OProc[2]-0.5)*delz[1];
			  
			  r[1] = v0.x - cent.x;
			  r[2] = v0.y - cent.y;
			  r[3] = v0.z - cent.z;
			  
			  crossProduct(I_Omega,omega,r);
			  v[IJK]=rig_U[bindx][2] + I_Omega[2]; //performs u = U + Omega x r
		  }
		  
		  //z-momentum
		  if(psimz[IJK] >= em6 && psimz[IJK] <= em61 )
		  { 
			  sol_centroid(2*i,2*j,2*k,&vt[0],&volt[0]);
			  sol_centroid(2*i-1,2*j,2*k,&vt[1],&volt[1]);
			  sol_centroid(2*i-1,2*j-1,2*k,&vt[2],&volt[2]);
			  sol_centroid(2*i,2*j-1,2*k,&vt[3],&volt[3]);

			  sol_centroid(2*i,2*j,2*k+1,&vt[4],&volt[4]);
			  sol_centroid(2*i-1,2*j,2*k+1,&vt[5],&volt[5]);
			  sol_centroid(2*i-1,2*j-1,2*k+1,&vt[6],&volt[6]);
			  sol_centroid(2*i,2*j-1,2*k+1,&vt[7],&volt[7]);
			  v0.x = 0.0, v0.y = 0.0, v0.z = 0.0, voli = 0.0;
			  
			  for(ii=0;ii<8;ii++) {
				v0.x += vt[ii].x*volt[ii], v0.y += vt[ii].y*volt[ii],
				v0.z += vt[ii].z*volt[ii];
				voli += volt[ii];
			  }
			  
			v0.x /= voli, v0.y /= voli, v0.z /= voli;

			r[1]=v0.x - cent.x;
			r[2]=v0.y - cent.y;
			r[3]=v0.z - cent.z;

			crossProduct(I_Omega,omega,r);
			w[IJK]=rig_U[bindx][3] + I_Omega[3]; //performs u = U + Omega x r

		  }
		  if(psimz[IJK]>em61)
		  { 
			  v0.x = (i+mpi.OProc[0]-0.5)*delx[1];
			  v0.y = (j+mpi.OProc[1]-0.5)*dely[1];
			  v0.z = (k+mpi.OProc[2])*delz[1];
			  
			  r[1] = v0.x - cent.x;
			  r[2] = v0.y - cent.y;
			  r[3] = v0.z - cent.z;
			  
			  crossProduct(I_Omega,omega,r);
			  w[IJK]=rig_U[bindx][3] + I_Omega[3]; //performs u = U + Omega x r
		  }
	  }

	//subsequent bc() call would xchg and velocity at bndry    
#endif
#endif
}
