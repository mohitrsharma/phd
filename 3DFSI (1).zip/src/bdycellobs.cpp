#include <stdio.h>
#include "ripple.h"
#include "testing.h"

/******************************************************************************
This subroutine is called from bdycell in order to set the pressure
in the obstacle interface cells

Subroutine BDCELLOBS is called by:	BDYCELL

Subroutine BDYCELLOBS calls:

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

void bdycellobs()
{
	int i, j, k;

	for(i = 1; i < im1; i++)
		for(j = 1; j < jm1; j++)
			for(k = 1; k < km1; k++)
			{

                if(isobstsfc(IJK))            /*if cell IJK is obstacle surface cell*/
				{

                    if(obst[IJK].flag_r)      /*if obstacle cell is to the RIGHT of fluid cell*/
						p[IJK] = p[IMJK];

                    if(obst[IJK].flag_l)      /*if obstacle cell is to the LEFT of fluid cell*/
						p[IJK] = p[IPJK];

                    if(obst[IJK].flag_f)      /*if obst. is in of the FRONT of fluid cell*/
						p[IJK] = p[IJMK];

                    if(obst[IJK].flag_b)      /*if obstacle cell is to the BACK of fluid cell*/
						p[IJK] = p[IJPK];

                    if(obst[IJK].flag_o)      /*if obstacle cell is OVER the fluid cell*/
						p[IJK] = p[IJKM];

                    if(obst[IJK].flag_u)      /*if obstacle cell is UNDER the fluid cell*/
						p[IJK] = p[IJKP];
				}
			}
			
			//obstacle in the ghost cells should be included here for the 
			//sake of completeness, but this is really not necessary here.
}
