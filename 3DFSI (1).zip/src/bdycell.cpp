#include "ripple.h"
#include "comm.h"
#include "testing.h"

/******************************************************************************

This subroutine sets pressure into ghost cells

Subroutine BDYCELL is called by:	IMPLCTP	

Subroutine BDYCELL calls:	BCFOBS

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Added a section to repeat bc application after 	L.Berard	January 17 2013
 xchg of p for cases when obstacle cells near 
 boundaries have insufficient information
-added a function call to bcfobs at the end of this	Ben			May 21 2005
 subroutine to set pressures of obstacle interface
 cells to thier proper values
-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

void bdycell()
{
	int i,j,k;
	/*front and back (no 'edge' ghost cells (im1-1)*(km1-1) cells per side*/
	for (i=1;i<im1;i++)
		for (k=1;k<km1;k++)
		{
			//back
			p[IND(i,0,k)]=p[IND(i,1,k)];
			//front
			p[IND(i,jm1,k)]=p[IND(i,jm1-1,k)];
		}

	/*right and left, including edge ghost cells along top and bottom*/
	for (j=0;j<jmax;j++)
		for (k=1;k<km1;k++)
		{
			//left
			p[IND(0,j,k)]=p[IND(1,j,k)];
			//right
			p[IND(im1,j,k)]=p[IND(im1-1,j,k)];
		}

	/*under and over, including all edge ghost cells*/
	for (i=0;i<imax;i++)
		for (j=0;j<jmax;j++)
		{
			//under
			p[IND(i,j,0)]=p[IND(i,j,1)];
			//over
			p[IND(i,j,km1)]=p[IND(i,j,km1-1)];
		}
		
		//if (mpi.Neighbors[4] == -1)
		//{
			//for (i=0;i<imax;i++)
				//for (j=0;j<jmax;j++)
				//{
					////under
					//p[IND(i,j,0)] = 0.0;
				//}
		//}
		
	/*bdycellobs sets pressures of obst. interface cells correctly
	  just like this subroutine does for ghost cells*/
#ifndef no_obs
	xchg<double> (p);
#endif
	if( mpi.obst_flag )
	{
		bdycellobs();
	}
	
	/*exhange p accross virtual boundaries*/
	xchg<double> (p);
	//none else needed after this ... check with LRB
	/*Everything after this comment was added by LRB*/
	//if( mpi.obst_flag )
		//bdycellobs();

	/*front and back (no 'edge' ghost cells (im1-1)*(km1-1) cells per side*/
	//for (i=1;i<im1;i++)
		//for (k=1;k<km1;k++)
		//{
			////back
			//p[IND(i,0,k)]=p[IND(i,1,k)];
			////front
			//p[IND(i,jm1,k)]=p[IND(i,jm1-1,k)];
		//}

	/*right and left, including edge ghost cells along top and bottom*/
	//for (j=0;j<jmax;j++)
		//for (k=1;k<km1;k++)
		//{
			////left
			//p[IND(0,j,k)]=p[IND(1,j,k)];
			////right
			//p[IND(im1,j,k)]=p[IND(im1-1,j,k)];
		//}

	/*under and over, including all edge ghost cells*/
	//for (i=0;i<imax;i++)
		//for (j=0;j<jmax;j++)
		//{
			////under
			//p[IND(i,j,0)]=p[IND(i,j,1)];
			////over
			//p[IND(i,j,km1)]=p[IND(i,j,km1-1)];
		//}
	
	/*bdycellobs sets pressures of obst. interface cells correctly
	  //just like this subroutine does for ghost cells*/
	//if( mpi.obst_flag )
		//bdycellobs();
	
	/*exhange p accross virtual boundaries*/
	//xchg<double> (p); 
}
