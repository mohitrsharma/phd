#include "ripple.h"
#include "comm.h"
#include "testing.h"

/******************************************************************************
This subroutine MOLLIFYTOBS	sets tens_ correctly in all obstacle cell sfc. cells.  it is
only called by those processors which have obstacle cell sfc. cells.

Subroutine MOLLIFYTOBS is called by:	MOLLIFYT

Subroutine MOLLIFYTOBS calls:

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

void mollifytobs(double *tensx, double *tensy, double *tensz)
{
	int i,j,k;

	for(k = 1; k < km1; k++)
		for(j = 1; j < jm1; j++)
			for(i = 1; i < im1; i++)
			{
				if (isobstsfc(IJK))
				{
					if (obst[IJK].flag_r)          /*if obstacle cell is on the RIGHT of fluid*/
					{
						tensx[IJK] = tensx[IMJK];
						tensy[IJK] = tensy[IMJK];
						tensz[IJK] = tensz[IMJK];
					}

					if (obst[IJK].flag_l)          /*if obstacle cell is on the LEFT of fluid*/
					{
						tensx[IJK] = tensx[IPJK];
						tensy[IJK] = tensy[IPJK];
						tensz[IJK] = tensz[IPJK];
					}

					if (obst[IJK].flag_f)          /*if obstacle cell is in of the FRONT of fluid*/
					{
						tensx[IJK] = tensx[IJMK];
						tensy[IJK] = tensy[IJMK];
						tensz[IJK] = tensz[IJMK];
					}

					if (obst[IJK].flag_b)           /*if obstacle cell is on the BACK of fluid*/
					{
						tensx[IJK] = tensx[IJPK];
						tensy[IJK] = tensy[IJPK];
						tensz[IJK] = tensz[IJPK];
					}

					if (obst[IJK].flag_o)           /*if obstacle cell is OVER the fluid*/
					{
						tensx[IJK] = tensx[IJKM];
						tensy[IJK] = tensy[IJKM];
						tensz[IJK] = tensz[IJKM];
					}

					if (obst[IJK].flag_u)           /*if obstacle cell is UNDER the fluid*/
					{
						tensx[IJK] = tensx[IJKP];
						tensy[IJK] = tensy[IJKP];
						tensz[IJK] = tensz[IJKP];
					}
				}
			}
}
