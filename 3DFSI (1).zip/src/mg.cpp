#include "ripple.h"
#include <math.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>	//memset.
								 
#define INDO(I,J,K) ((I)+((J)+(K)*ny)*nx)
#define INDN(I,J,K) ((I)+((J)+(K)*nny)*nnx)
#define MAXMGLEV 32//should satisfy grids up to 2^MAXMGLEV cells per side in size.
#define BIGA 1e+50

/******************************************************************************


Subroutine MG is called by:	IMPLCTP

Subroutine MG calls:			

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

inline void resize (double **a, int *asize, int size);

//Debugging:
bool issymmetric (double *a, double *bl, double *br, double *bb, double *bf, 
					double *bu, double *bo, int nx, int ny, int nz)
{
//	returns true if matrix is symmetric.
	int i,j,k;
	for (k=2;k<nz-1;k++)
		for (j=2;j<ny-1;j++)
			for (i=2;i<nx-1;i++)
			{  
				int ijk=INDO(i,j,k);
				int imjk = INDO(i-1,j,k);
				int ijmk = INDO(i,j-1,k);
				int ijkm = INDO(i,j,k-1);
				if (a[ijk] > 1e25) continue;

				if (i>0) if (fabs(bl[ijk]-br[imjk])>em6*fabs(bl[ijk])+em6) return false;
				if (j>0) if (fabs(bb[ijk]-bf[ijmk])>em6*fabs(bb[ijk])+em6) return false;
				if (k>0) if (fabs(bu[ijk]-bo[ijkm])>em6*fabs(bu[ijk])+em6) return false;
			}
	return true;
}
bool isdominant (double *a, double *bl, double *br, double *bb, double *bf, 
					double *bu, double *bo, int nx, int ny, int nz)
{
// returns true if for every row |a| >= |bl| + |br| + |bb| + |bf| + |bu| + |bo|.
	int i,j,k;
	for (k=1;k<nz-1;k++)
		for (j=1;j<ny-1;j++)
			for (i=1;i<nx-1;i++)
			{		
				int ijk=INDO(i,j,k);
				if (fabs(a[ijk])*1.000001+fabs(a[ijk])*0.000001< fabs(bl[ijk])
									+fabs(br[ijk])
									+fabs(bb[ijk])
									+fabs(bf[ijk])
									+fabs(bu[ijk])
									+fabs(bo[ijk]))
									return false;
			}
	return true;
}
void stat(const char* n,double *a, int nx, int ny, int nz)
{
	if (nx==0 || ny==0 || nz==0) return;  
	if (a==0) return;
	double sum=0,max,min;
	min=max=a[INDO(1,1,1)];
	int c=0;
	for (int k=1;k<nz-1;k++)
		for (int j=1;j<ny-1;j++)
			for (int i=1;i<nx-1;i++)
			{
				if (a[INDO(i,j,k)] > max) max = a[INDO(i,j,k)];
				if (a[INDO(i,j,k)] < min) min = a[INDO(i,j,k)];
				sum += a[INDO(i,j,k)];
				c++;
			}

	printf ("%s: Max=%.4e, Min=%.4e, Avg=%.4e, c=%d, (%d %d %d)\n", n, max,min,sum/c,c,nx,ny,nz);	
}


struct _ginfo
{
	double *a;
	double *rhs;
	double *bl,*br,*bb,*bf,*bu,*bo;
	double *p;
	double *res;

	int nx,ny,nz;	//size of the grid for this level.
	int fx,fy,fz;

	//sizes of the arrays above.
	int asize;
	int rhssize;
	int blsize, brsize, bbsize, bfsize, busize, bosize;
	int psize;		
	int ressize;	 

	//neighbors
	int neigh[6];
	int o[3];	//coordinate of (0,0,0) for current processor on current grid.

} static ginfo[MAXMGLEV] = {0};

inline void resize (double **a, int *asize, int size)
{
	//ensures a is large enough.
	if (*asize < size)
	{
		*a = (double*)realloc(*a, size);
		*asize = size;
	}
}
	
double normres (double *res, double *rhs, double *a, int nx, int ny, int nz)
{
	//Returns a relative norm of the residual: |residual| / |rhs|.
	double sum=0.0;
	double sumrhs = 0.0;
	for (int k=2;k<nz-2;k++)
		for (int j=2;j<ny-2;j++)
			for (int i=2;i<nx-2;i++)
				if (fabs(a[INDO(i,j,k)]) < 5e+24)
				{
					sum += SQUARE(res[INDO(i,j,k)]);
					sumrhs += SQUARE (rhs[INDO(i,j,k)]);
				}
	double tempsum,tempsumrhs;
	dallreduce (&sum, &tempsum, 1, OP_SUM);
	dallreduce (&sumrhs, &tempsumrhs, 1, OP_SUM);
	if (tempsumrhs != 0.0)
		return sqrt(tempsum/tempsumrhs);
	else return 0.0;
}

bool restrict(int level, double **anew, double *a, int *sizeofanew, int nx, int ny, int nz)
{
	//restrictcoef must be called at least once for a level before restrict can be used.
	//(ginfo[level].o is used here, but only defined in restrictcoef)

	//if successful, returns true and increments level.
	//a is restricted and placed in anew.
	//otherwise, nothing is done, and return value is false.
	//don't do load balancing within MG routines =p

	//sizeofanew in bytes.
	//if anew isn't large enough to hold data, it will be realloced and
	//sizeofanew set to the new size of anew (bytes)

	//nx,ny,nz are dimensions of a.
	if (level >= MAXMGLEV-1) return false;
	if (level < 0) return false;

	if (nx < 7 || ny < 7 || nz < 7) return false;	//not enough points to restrict.

	int nnx = ((nx-1) >> 1) + 2;
	int nny = ((ny-1) >> 1) + 2;
	int nnz = ((nz-1) >> 1) + 2;

	//determine whether OProc is odd, or whether nx is odd, etc.
	int ioffset=0,joffset=0,koffset=0;
	if (ginfo[level].o[0]&1)
	{
		ioffset = 1;
		if (nx&1) nnx--;
	}
	if (ginfo[level].o[1]&1)
	{
		joffset = 1;
		if (ny&1) nny--;
	}
	if (ginfo[level].o[2]&1)
	{
		koffset = 1;
		if (nz&1) nnz--;
	}

	ginfo[level].nx = nx;
	ginfo[level].ny = ny;
	ginfo[level].nz = nz;
	ginfo[level+1].nx = nnx;
	ginfo[level+1].ny = nny;
	ginfo[level+1].nz = nnz;

	
	int newasize = nnx*nny*nnz*sizeof(double);
	resize (anew, sizeofanew, newasize);

	int i,j,k;
	for (k=1;k<nnz-1;k++)
		for (j=1;j<nny-1;j++)
			for (i=1;i<nnx-1;i++)
			{
				(*anew)[INDN(i,j,k)] = 0.125*
								( a[INDO(i*2-1+ioffset, j*2-1+joffset, k*2-1+koffset)]
								 +a[INDO(i*2+ioffset, j*2-1+joffset, k*2-1+koffset)] 
								 +a[INDO(i*2-1+ioffset, j*2+joffset, k*2-1+koffset)] 
								 +a[INDO(i*2-1+ioffset, j*2-1+joffset, k*2+koffset)] 
								 +a[INDO(i*2+ioffset, j*2+joffset, k*2-1+koffset)] 
								 +a[INDO(i*2+ioffset, j*2-1+joffset, k*2+koffset)] 
								 +a[INDO(i*2-1+ioffset, j*2+joffset, k*2+koffset)] 
								 +a[INDO(i*2+ioffset, j*2+joffset, k*2+koffset)] ); 
			}
	for (k=1;k<nnz-1;k++)
		for (j=1;j<nny-1;j++)
		{
			(*anew)[INDN(0,j,k)] = 0.25 *
				( a[INDO(0, 2*j-1+joffset, 2*k-1+koffset)]
				 +a[INDO(0, 2*j+joffset,   2*k-1+koffset)]
				 +a[INDO(0, 2*j-1+joffset, 2*k+koffset)]
				 +a[INDO(0, 2*j+joffset,   2*k+koffset)]
				);
			(*anew)[INDN(nnx-1,j,k)] = 0.25 *
				( a[INDO(nx-1, 2*j-1+joffset, 2*k-1+koffset)]
				 +a[INDO(nx-1, 2*j+joffset,   2*k-1+koffset)]
				 +a[INDO(nx-1, 2*j-1+joffset, 2*k+koffset)]
				 +a[INDO(nx-1, 2*j+joffset,   2*k+koffset)]
				);
		}

	for (k=1;k<nnz-1;k++)
		for (i=1;i<nnx-1;i++)
		{
			(*anew)[INDN(i,0,k)] = 0.25 *
				( a[INDO(2*i-1+ioffset, 0, 2*k-1+koffset)]
				 +a[INDO(2*i+ioffset,   0, 2*k-1+koffset)]
				 +a[INDO(2*i-1+ioffset, 0, 2*k+koffset)]
				 +a[INDO(2*i+ioffset,   0, 2*k+koffset)]
				);
			(*anew)[INDN(i,nny-1,k)] = 0.25 *
				( a[INDO(2*i-1+ioffset, ny-1, 2*k-1+koffset)]
				 +a[INDO(2*i+ioffset,   ny-1, 2*k-1+koffset)]
				 +a[INDO(2*i-1+ioffset, ny-1, 2*k+koffset)]
				 +a[INDO(2*i+ioffset,   ny-1, 2*k+koffset)]
				);
		}

	for (j=1;j<nny-1;j++)
		for (i=1;i<nnx-1;i++)
		{
			(*anew)[INDN(i,j,0)] = 0.25 *
				( a[INDO(2*i-1+ioffset, 2*j-1+joffset, 0)]
				 +a[INDO(2*i+ioffset,   2*j-1+joffset, 0)]
				 +a[INDO(2*i-1+ioffset, 2*j+joffset,   0)]
				 +a[INDO(2*i+ioffset,   2*j+joffset,   0)]
				);
			(*anew)[INDN(i,j,nnz-1)] = 0.25 *
				( a[INDO(2*i-1+ioffset, 2*j-1+joffset, nz-1)]
				 +a[INDO(2*i+ioffset,   2*j-1+joffset, nz-1)]
				 +a[INDO(2*i-1+ioffset, 2*j+joffset,   nz-1)]
				 +a[INDO(2*i+ioffset,   2*j+joffset,   nz-1)]
				);
		}
	for (i=1;i<nnx-1;i++)
	{
		(*anew)[INDN(i,0,0)] = 0.5 * ( a[INDO(2*i-1+ioffset, 0, 0)] + a[INDO(2*i+ioffset, 0, 0)] );
		(*anew)[INDN(i,nny-1,0)] = 0.5 * ( a[INDO(2*i-1+ioffset, ny-1, 0)] + a[INDO(2*i+ioffset, ny-1, 0)] );
		(*anew)[INDN(i,0,nnz-1)] = 0.5 * ( a[INDO(2*i-1+ioffset, 0, nz-1)] + a[INDO(2*i+ioffset, 0, nz-1)] );
		(*anew)[INDN(i,nny-1,nnz-1)] = 0.5 * ( a[INDO(2*i-1+ioffset, ny-1, nz-1)] + a[INDO(2*i+ioffset, ny-1, nz-1)] );
	}
	for (j=1;j<nny-1;j++)
	{
		(*anew)[INDN(0, j, 0)] = 0.5 * ( a[INDO(0, j*2-1+joffset, 0)] + a[INDO(0, 2*j-1+joffset, 0)] );
		(*anew)[INDN(nnx-1, j, 0)] = 0.5 * ( a[INDO(nx-1, j*2-1+joffset, 0)] + a[INDO(nx-1, 2*j-1+joffset, 0)] );
		(*anew)[INDN(0, j, nnz-1)] = 0.5 * ( a[INDO(0, j*2-1+joffset, nz-1)] + a[INDO(0, 2*j-1+joffset, nz-1)] );
		(*anew)[INDN(nnx-1, j, nnz-1)] = 0.5 * ( a[INDO(nx-1, j*2-1+joffset, nz-1)] + a[INDO(nx-1, 2*j-1+joffset, nz-1)] );
	}
	for (k=1;k<nnz-1;k++)
	{
		(*anew)[INDN(0, 0, k)] = 0.5 * ( a[INDO(0, 0, 2*k-1+koffset)] + a[INDO(0, 0, 2*k+koffset)] );
		(*anew)[INDN(nnx-1,0 ,k)] = 0.5 * ( a[INDO(nx-1, 0, 2*k-1+koffset)] + a[INDO(nx-1, 0, 2*k+koffset)] );
		(*anew)[INDN(0, nny-1, k)] = 0.5 * ( a[INDO(0, ny-1, 2*k-1+koffset)] + a[INDO(0, ny-1, 2*k+koffset)] );
		(*anew)[INDN(nnx-1,nny-1,k)] = 0.5 * ( a[INDO(nx-1, ny-1, 2*k-1+koffset)] + a[INDO(nx-1, ny-1, 2*k+koffset)] );
	}

	(*anew)[INDN(0,		0,		0)]		= a[INDO(0,		0,		0)];
	(*anew)[INDN(nnx-1,	0,		0)]		= a[INDO(nx-1,	0,		0)];
	(*anew)[INDN(0,		nny-1,	0)]		= a[INDO(0,		ny-1,	0)];
	(*anew)[INDN(nnx-1,	nny-1,	0)]		= a[INDO(nx-1,	ny-1,	0)];
	(*anew)[INDN(0,		0,		nnz-1)]	= a[INDO(0,		0,		nz-1)];
	(*anew)[INDN(nnx-1,	0,		nnz-1)]	= a[INDO(nx-1,	0,		nz-1)];
	(*anew)[INDN(0,		nny-1,	nnz-1)]	= a[INDO(0,		ny-1,	nz-1)];
	(*anew)[INDN(nnx-1,	nny-1,	nnz-1)] = a[INDO(nx-1,	ny-1,	nz-1)];

	//assume boundary values are zero.
	if (ginfo[level].neigh[1]==-1)
		if (ginfo[level].fx & 1)	//if fine grid had odd number of cells
			for (k=0;k<nnz;k++)
				for (j=0;j<nny;j++)
					(*anew)[INDN(nnx-2,j,k)] *=2.0;
	if (ginfo[level].neigh[3]==-1)
		if (ginfo[level].fy & 1)
			for (k=0;k<nnz;k++)
				for (i=0;i<nnx;i++)
					(*anew)[INDN(i,nny-2,k)] *=2.0;
	if (ginfo[level].neigh[5]==-1)
		if (ginfo[level].fz & 1)
			for (j=0;j<nny;j++)
				for (i=0;i<nnx;i++)
					(*anew)[INDN(i,j,nnz-2)] *=2.0;


	arecvplanen<double> (*anew, 2, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (*anew, 1, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (*anew, 1, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (*anew, 2, ginfo[level].neigh, nnx, nny, nnz);
	arecvspacewait();
	
	arecvplanen<double> (*anew, 4, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (*anew, 3, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (*anew, 3, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (*anew, 4, ginfo[level].neigh, nnx, nny, nnz);
	arecvspacewait();

	arecvplanen<double> (*anew, 6, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (*anew, 5, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (*anew, 5, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (*anew, 6, ginfo[level].neigh, nnx, nny, nnz);
	arecvspacewait();

	return true;

}

bool restrictcoef(int level, int nx, int ny, int nz)
{
	if (level >= MAXMGLEV-1) return false;
	if (level < 0) return false;
	if (nx < 7 || ny < 7 || nz < 7) return false;	//not enough points to restrict.

	//lazy MP MG
	double restrictok= (nx < 7 || ny < 7 || nz < 7)?0.0: 1.0;
	double rrestrictok = 0;
	dallreduce (&restrictok, &rrestrictok, 1, OP_MIN);
	if (rrestrictok==0.0) return false;		//if remote can't restrict, don't restrict here either.

	//assume restrictcoef will be called starting with level 0 and incrementing,
	//all done at the beginning of the solve.
	static double odd[MAXMGLEV][3];	//2^count of how many restrictions involved odd number of 
							//cells in each of three directions.
	static double twon[MAXMGLEV];	//2^#levels restricted.
	if (level==0)
	{
		odd[0][0]=odd[0][1]=odd[0][2]=1.0;
		//twon[0]=6;	//..trial and error?..Disabled
		ginfo[0].fx=dim.fx;
		ginfo[0].fy=dim.fy;
		ginfo[0].fz=dim.fz;
	}
	else //if (level>0)
	{
		memcpy(odd[level],odd[level-1],3*sizeof(double));
		twon[level]=twon[level-1]*2.0;
		ginfo[level].fx = ((ginfo[level-1].fx-1)>>1)+2;
		ginfo[level].fy = ((ginfo[level-1].fy-1)>>1)+2;
		ginfo[level].fz = ((ginfo[level-1].fz-1)>>1)+2;
	}

	//figure out neighbors (future implementation).
	memcpy (ginfo[level].neigh, mpi.Neighbors, 6*sizeof(int));
	memcpy (ginfo[level+1].neigh, mpi.Neighbors, 6*sizeof(int));

	int nnx = ((nx-1) >> 1) + 2;
	int nny = ((ny-1) >> 1) + 2;
	int nnz = ((nz-1) >> 1) + 2;

	//calculate o
	if (level==0)
	{
		ginfo[level].o[0] = mpi.OProc[0];
		ginfo[level].o[1] = mpi.OProc[1];
		ginfo[level].o[2] = mpi.OProc[2];
	}
	else
	{
		ginfo[level].o[0] = (ginfo[level-1].o[0]+1)/2;
		ginfo[level].o[1] = (ginfo[level-1].o[1]+1)/2;
		ginfo[level].o[2] = (ginfo[level-1].o[2]+1)/2;
	}
	
	//determine whether OProc is odd, or whether nx is odd, etc.
	int ioffset=0,joffset=0,koffset=0;
	if (ginfo[level].o[0]&1)
	{
		ioffset = 1;
		if (nx&1) nnx--;
	}
	if (ginfo[level].o[1]&1)
	{
		joffset = 1;
		if (ny&1) nny--;
	}
	if (ginfo[level].o[2]&1)
	{
		koffset = 1;
		if (nz&1) nnz--;
	}
	
	ginfo[level].nx = nx;		//should be the same as with standard restrict, so it's ok to overwrite them.
	ginfo[level].ny = ny;
	ginfo[level].nz = nz;
	ginfo[level+1].nx = nnx;
	ginfo[level+1].ny = nny;
	ginfo[level+1].nz = nnz;

	//ensure arrays are large enough.
	int newsize = nnx*nny*nnz*sizeof(double);
	resize (&ginfo[level+1].a, &ginfo[level+1].asize, newsize);
	resize (&ginfo[level+1].bl, &ginfo[level+1].blsize, newsize);
	resize (&ginfo[level+1].br, &ginfo[level+1].brsize, newsize);
	resize (&ginfo[level+1].bb, &ginfo[level+1].bbsize, newsize);
	resize (&ginfo[level+1].bf, &ginfo[level+1].bfsize, newsize);
	resize (&ginfo[level+1].bu, &ginfo[level+1].busize, newsize);
	resize (&ginfo[level+1].bo, &ginfo[level+1].bosize, newsize);

	memset (ginfo[level+1].a, 0, nnx*nny*nnz*sizeof(double));
	memset (ginfo[level+1].bl, 0, nnx*nny*nnz*sizeof(double));
	memset (ginfo[level+1].br, 0, nnx*nny*nnz*sizeof(double));
	memset (ginfo[level+1].bb, 0, nnx*nny*nnz*sizeof(double));
	memset (ginfo[level+1].bf, 0, nnx*nny*nnz*sizeof(double));
	memset (ginfo[level+1].bu, 0, nnx*nny*nnz*sizeof(double));
	memset (ginfo[level+1].bo, 0, nnx*nny*nnz*sizeof(double));

	//Harmonic mean apparently works better than arithemetic mean . . .
	//Oleg P. Iliev, On second-order-accurate discretization of 3D interface problems and its fast solution
	//with a pointwise multigrid solver.
	//IMA Journal of Numerical Analysis (2002) 22, 392.	 (Issue 3, July 2002)

	int i,j,k; 
	for (k=1;k<nnz-1;k++)
		for (j=1;j<nny-1;j++)
			for (i=1;i<nnx-1;i++)
			{
 
				ginfo[level+1].bl[INDN(i, j, k)] = -.25*sqrt(.25*
					( SQUARE(ginfo[level].bl[INDO(2*i-1+ioffset, 2*j-1+joffset, 2*k-1+koffset)])
					 +SQUARE(ginfo[level].bl[INDO(2*i-1+ioffset, 2*j+joffset,   2*k-1+koffset)])
					 +SQUARE(ginfo[level].bl[INDO(2*i-1+ioffset, 2*j-1+joffset, 2*k+koffset)])
					 +SQUARE(ginfo[level].bl[INDO(2*i-1+ioffset, 2*j+joffset,   2*k+koffset)])
					));
				ginfo[level+1].br[INDN(i, j, k)] = -.25*sqrt(.25*
					( SQUARE(ginfo[level].br[INDO(2*i+ioffset, 2*j-1+joffset, 2*k-1+koffset)])
					 +SQUARE(ginfo[level].br[INDO(2*i+ioffset, 2*j+joffset,   2*k-1+koffset)])
					 +SQUARE(ginfo[level].br[INDO(2*i+ioffset, 2*j-1+joffset, 2*k+koffset)])	 
					 +SQUARE(ginfo[level].br[INDO(2*i+ioffset, 2*j+joffset,   2*k+koffset)])
					));
				ginfo[level+1].bb[INDN(i, j, k)] = -.25*sqrt(.25*
					( SQUARE(ginfo[level].bb[INDO(2*i-1+ioffset, 2*j-1+joffset, 2*k-1+koffset)])
					 +SQUARE(ginfo[level].bb[INDO(2*i+ioffset,   2*j-1+joffset, 2*k-1+koffset)])
					 +SQUARE(ginfo[level].bb[INDO(2*i-1+ioffset, 2*j-1+joffset, 2*k+koffset)])  
					 +SQUARE(ginfo[level].bb[INDO(2*i+ioffset,   2*j-1+joffset, 2*k+koffset)])
					));
				ginfo[level+1].bf[INDN(i, j, k)] = -.25*sqrt(.25*
					( SQUARE(ginfo[level].bf[INDO(2*i-1+ioffset, 2*j+joffset, 2*k-1+koffset)])
					 +SQUARE(ginfo[level].bf[INDO(2*i+ioffset,   2*j+joffset, 2*k-1+koffset)])
					 +SQUARE(ginfo[level].bf[INDO(2*i-1+ioffset, 2*j+joffset, 2*k+koffset)])
					 +SQUARE(ginfo[level].bf[INDO(2*i+ioffset,   2*j+joffset, 2*k+koffset)])
					));
				ginfo[level+1].bu[INDN(i, j, k)] = -.25*sqrt(.25*
					( SQUARE(ginfo[level].bu[INDO(2*i-1+ioffset, 2*j-1+joffset, 2*k-1+koffset)])
					 +SQUARE(ginfo[level].bu[INDO(2*i+ioffset,   2*j-1+joffset, 2*k-1+koffset)])
					 +SQUARE(ginfo[level].bu[INDO(2*i-1+ioffset, 2*j+joffset,   2*k-1+koffset)])
					 +SQUARE(ginfo[level].bu[INDO(2*i+ioffset,   2*j+joffset,   2*k-1+koffset)])
					));
				ginfo[level+1].bo[INDN(i, j, k)] = -.25*sqrt(.25*
					( SQUARE(ginfo[level].bo[INDO(2*i-1+ioffset, 2*j-1+joffset, 2*k+koffset)])
					 +SQUARE(ginfo[level].bo[INDO(2*i+ioffset,   2*j-1+joffset, 2*k+koffset)])
					 +SQUARE(ginfo[level].bo[INDO(2*i-1+ioffset, 2*j+joffset,   2*k+koffset)])
					 +SQUARE(ginfo[level].bo[INDO(2*i+ioffset,   2*j+joffset,   2*k+koffset)])
					));
				/*
				if (ginfo[level].neigh[0]==-1) if (i==1) ginfo[level+1].bl[INDN(i,j,k)] *= SQUARE(1.0 + 1/(twon[level]+1));
				if (ginfo[level].neigh[1]==-1) if (i==nnx-2) ginfo[level+1].br[INDN(i,j,k)] *= SQUARE(1.0 + 1/(twon[level]+1));
				if (ginfo[level].neigh[2]==-1) if (j==1) ginfo[level+1].bb[INDN(i,j,k)] *= SQUARE(1.0 + 1/(twon[level]+1));
				if (ginfo[level].neigh[3]==-1) if (j==nny-2) ginfo[level+1].bf[INDN(i,j,k)] *= SQUARE(1.0 + 1/(twon[level]+1));
				if (ginfo[level].neigh[4]==-1) if (k==1) ginfo[level+1].bu[INDN(i,j,k)] *= SQUARE(1.0 + 1/(twon[level]+1));
				if (ginfo[level].neigh[5]==-1) if (k==nnz-2) ginfo[level+1].bo[INDN(i,j,k)] *= SQUARE(1.0 + 1/(twon[level]+1));
				*/				
				ginfo[level+1].a[INDN(i,j,k)] = -ginfo[level+1].bl[INDN(i,j,k)]
												-ginfo[level+1].br[INDN(i,j,k)]
												-ginfo[level+1].bb[INDN(i,j,k)]
												-ginfo[level+1].bf[INDN(i,j,k)]
												-ginfo[level+1].bu[INDN(i,j,k)]
												-ginfo[level+1].bo[INDN(i,j,k)];

			}
	 
	if (ginfo[level].fx&1)	//if odd number of cells
		odd[level][0] *= 4.0;
	if (ginfo[level].fy&1)
		odd[level][1] *= 4.0;
	if (ginfo[level].fz&1)
		odd[level][2] *= 4.0;
	 
	if (ginfo[level].neigh[1]==-1)
		if (odd[level][0]>1.0)
			for (k=0;k<nnz;k++)
				for (j=0;j<nny;j++)
					ginfo[level+1].a[INDN(nnx-2,j,k)] -= (odd[level][0]-1)*ginfo[level+1].bl[INDN(nnx-2,j,k)];
	if (ginfo[level].neigh[3]==-1)
		if (odd[level][1]>1.0)	
			for (k=0;k<nnz;k++)
				for (i=0;i<nnx;i++)
					ginfo[level+1].a[INDN(i,nny-2,k)] -= (odd[level][1]-1)*ginfo[level+1].bb[INDN(i,nny-2,k)];
	if (ginfo[level].neigh[5]==-1)
		if (odd[level][2]>1.0)	
			for (j=0;j<nny;j++)
				for (i=0;i<nnx;i++)
					ginfo[level+1].a[INDN(i,j,nnz-2)] -= (odd[level][2]-1)*ginfo[level+1].bu[INDN(i,j,nnz-2)];

	if (ginfo[level].neigh[0]==-1)
	for (k=1;k<nnz-1;k++)
		for (j=1;j<nny-1;j++)
		{
			ginfo[level+1].bl[INDN(0,j,k)]		= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].bl[INDO(0, 2*j-1+joffset, 2*k-1+koffset)])    + SQUARE(ginfo[level].bl[INDO(0, 2*j+joffset,   2*k-1+koffset)])    + SQUARE(ginfo[level].bl[INDO(0, 2*j-1+joffset, 2*k+koffset)])     + SQUARE(ginfo[level].bl[INDO(0, 2*j+joffset,   2*k+koffset)])));
			ginfo[level+1].br[INDN(0,j,k)]		= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].br[INDO(0, 2*j-1+joffset, 2*k-1+koffset)])    + SQUARE(ginfo[level].br[INDO(0, 2*j+joffset,   2*k-1+koffset)])    + SQUARE(ginfo[level].br[INDO(0, 2*j-1+joffset, 2*k+koffset)])     + SQUARE(ginfo[level].br[INDO(0, 2*j+joffset,   2*k+koffset)])));
			ginfo[level+1].bb[INDN(0,j,k)]		= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].bb[INDO(0, 2*j-1+joffset, 2*k-1+koffset)])    + SQUARE(ginfo[level].bb[INDO(0, 2*j+joffset,   2*k-1+koffset)])    + SQUARE(ginfo[level].bb[INDO(0, 2*j-1+joffset, 2*k+koffset)])     + SQUARE(ginfo[level].bb[INDO(0, 2*j+joffset,   2*k+koffset)])));
			ginfo[level+1].bf[INDN(0,j,k)]		= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].bf[INDO(0, 2*j-1+joffset, 2*k-1+koffset)])    + SQUARE(ginfo[level].bf[INDO(0, 2*j+joffset,   2*k-1+koffset)])    + SQUARE(ginfo[level].bf[INDO(0, 2*j-1+joffset, 2*k+koffset)])     + SQUARE(ginfo[level].bf[INDO(0, 2*j+joffset,   2*k+koffset)])));
			ginfo[level+1].bu[INDN(0,j,k)]		= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].bu[INDO(0, 2*j-1+joffset, 2*k-1+koffset)])    + SQUARE(ginfo[level].bu[INDO(0, 2*j+joffset,   2*k-1+koffset)])    + SQUARE(ginfo[level].bu[INDO(0, 2*j-1+joffset, 2*k+koffset)])     + SQUARE(ginfo[level].bu[INDO(0, 2*j+joffset,   2*k+koffset)])));
			ginfo[level+1].bo[INDN(0,j,k)]		= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].bo[INDO(0, 2*j-1+joffset, 2*k-1+koffset)])    + SQUARE(ginfo[level].bo[INDO(0, 2*j+joffset,   2*k-1+koffset)])    + SQUARE(ginfo[level].bo[INDO(0, 2*j-1+joffset, 2*k+koffset)])     + SQUARE(ginfo[level].bo[INDO(0, 2*j+joffset,   2*k+koffset)])));
			ginfo[level+1].a[INDN(0,j,k)]		= -ginfo[level+1].bl[INDN(0,j,k)] 
												  -ginfo[level+1].br[INDN(0,j,k)] 
												  -ginfo[level+1].bb[INDN(0,j,k)] 
												  -ginfo[level+1].bf[INDN(0,j,k)]
												  -ginfo[level+1].bu[INDN(0,j,k)]
												  -ginfo[level+1].bo[INDN(0,j,k)];
		}
	if (ginfo[level].neigh[1]==-1)
	for (k=1;k<nnz-1;k++)
		for (j=1;j<nny-1;j++)
		{
			ginfo[level+1].bl[INDN(nnx-1,j,k)]	= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].bl[INDO(nx-1, 2*j-1+joffset, 2*k-1+koffset)]) + SQUARE(ginfo[level].bl[INDO(nx-1, 2*j+joffset,   2*k-1+koffset)]) + SQUARE(ginfo[level].bl[INDO(nx-1+ioffset, 2*j-1+joffset, 2*k+koffset)])	+ SQUARE(ginfo[level].bl[INDO(nx-1+ioffset, 2*j+joffset,   2*k+koffset)])));
			ginfo[level+1].br[INDN(nnx-1,j,k)]	= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].br[INDO(nx-1, 2*j-1+joffset, 2*k-1+koffset)]) + SQUARE(ginfo[level].br[INDO(nx-1, 2*j+joffset,   2*k-1+koffset)]) + SQUARE(ginfo[level].br[INDO(nx-1+ioffset, 2*j-1+joffset, 2*k+koffset)])	+ SQUARE(ginfo[level].br[INDO(nx-1+ioffset, 2*j+joffset,   2*k+koffset)])));
			ginfo[level+1].bb[INDN(nnx-1,j,k)]	= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].bb[INDO(nx-1, 2*j-1+joffset, 2*k-1+koffset)]) + SQUARE(ginfo[level].bb[INDO(nx-1, 2*j+joffset,   2*k-1+koffset)]) + SQUARE(ginfo[level].bb[INDO(nx-1+ioffset, 2*j-1+joffset, 2*k+koffset)])	+ SQUARE(ginfo[level].bb[INDO(nx-1+ioffset, 2*j+joffset,   2*k+koffset)])));
			ginfo[level+1].bf[INDN(nnx-1,j,k)]	= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].bf[INDO(nx-1, 2*j-1+joffset, 2*k-1+koffset)]) + SQUARE(ginfo[level].bf[INDO(nx-1, 2*j+joffset,   2*k-1+koffset)]) + SQUARE(ginfo[level].bf[INDO(nx-1+ioffset, 2*j-1+joffset, 2*k+koffset)])	+ SQUARE(ginfo[level].bf[INDO(nx-1+ioffset, 2*j+joffset,   2*k+koffset)])));
			ginfo[level+1].bu[INDN(nnx-1,j,k)]	= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].bu[INDO(nx-1, 2*j-1+joffset, 2*k-1+koffset)]) + SQUARE(ginfo[level].bu[INDO(nx-1, 2*j+joffset,   2*k-1+koffset)]) + SQUARE(ginfo[level].bu[INDO(nx-1+ioffset, 2*j-1+joffset, 2*k+koffset)])	+ SQUARE(ginfo[level].bu[INDO(nx-1+ioffset, 2*j+joffset,   2*k+koffset)])));
			ginfo[level+1].bo[INDN(nnx-1,j,k)]	= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].bo[INDO(nx-1, 2*j-1+joffset, 2*k-1+koffset)]) + SQUARE(ginfo[level].bo[INDO(nx-1, 2*j+joffset,   2*k-1+koffset)]) + SQUARE(ginfo[level].bo[INDO(nx-1+ioffset, 2*j-1+joffset, 2*k+koffset)])	+ SQUARE(ginfo[level].bo[INDO(nx-1+ioffset, 2*j+joffset,   2*k+koffset)])));
			ginfo[level+1].a[INDN(nnx-1,j,k)]	= -ginfo[level+1].bl[INDN(nnx-1,j,k)]
												  -ginfo[level+1].br[INDN(nnx-1,j,k)]
												  -ginfo[level+1].bb[INDN(nnx-1,j,k)]
												  -ginfo[level+1].bf[INDN(nnx-1,j,k)]
												  -ginfo[level+1].bu[INDN(nnx-1,j,k)]
												  -ginfo[level+1].bo[INDN(nnx-1,j,k)];
		}
	if (ginfo[level].neigh[2]==-1)
	for (k=1;k<nnz-1;k++)
		for (i=1;i<nnx-1;i++)
		{
			ginfo[level+1].bl[INDN(i,0,k)]		= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].bl[INDO(2*i-1+ioffset, 0, 2*k-1+koffset)])    + SQUARE(ginfo[level].bl[INDO(2*i+ioffset,   0, 2*k-1+koffset)])    + SQUARE(ginfo[level].bl[INDO(2*i-1+ioffset, 0, 2*k+koffset)])    + SQUARE(ginfo[level].bl[INDO(2*i+ioffset,   0, 2*k+koffset)])));
			ginfo[level+1].br[INDN(i,0,k)]		= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].br[INDO(2*i-1+ioffset, 0, 2*k-1+koffset)])    + SQUARE(ginfo[level].br[INDO(2*i+ioffset,   0, 2*k-1+koffset)])    + SQUARE(ginfo[level].br[INDO(2*i-1+ioffset, 0, 2*k+koffset)])    + SQUARE(ginfo[level].br[INDO(2*i+ioffset,   0, 2*k+koffset)])));
			ginfo[level+1].bb[INDN(i,0,k)]		= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].bb[INDO(2*i-1+ioffset, 0, 2*k-1+koffset)])    + SQUARE(ginfo[level].bb[INDO(2*i+ioffset,   0, 2*k-1+koffset)])    + SQUARE(ginfo[level].bb[INDO(2*i-1+ioffset, 0, 2*k+koffset)])    + SQUARE(ginfo[level].bb[INDO(2*i+ioffset,   0, 2*k+koffset)])));
			ginfo[level+1].bf[INDN(i,0,k)]		= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].bf[INDO(2*i-1+ioffset, 0, 2*k-1+koffset)])    + SQUARE(ginfo[level].bf[INDO(2*i+ioffset,   0, 2*k-1+koffset)])    + SQUARE(ginfo[level].bf[INDO(2*i-1+ioffset, 0, 2*k+koffset)])    + SQUARE(ginfo[level].bf[INDO(2*i+ioffset,   0, 2*k+koffset)])));
			ginfo[level+1].bu[INDN(i,0,k)]		= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].bu[INDO(2*i-1+ioffset, 0, 2*k-1+koffset)])    + SQUARE(ginfo[level].bu[INDO(2*i+ioffset,   0, 2*k-1+koffset)])    + SQUARE(ginfo[level].bu[INDO(2*i-1+ioffset, 0, 2*k+koffset)])    + SQUARE(ginfo[level].bu[INDO(2*i+ioffset,   0, 2*k+koffset)])));
			ginfo[level+1].bo[INDN(i,0,k)]		= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].bo[INDO(2*i-1+ioffset, 0, 2*k-1+koffset)])    + SQUARE(ginfo[level].bo[INDO(2*i+ioffset,   0, 2*k-1+koffset)])    + SQUARE(ginfo[level].bo[INDO(2*i-1+ioffset, 0, 2*k+koffset)])    + SQUARE(ginfo[level].bo[INDO(2*i+ioffset,   0, 2*k+koffset)])));
			ginfo[level+1].a[INDN(i,0,k)]		= -ginfo[level+1].bl[INDN(i,0,k)]
  												  -ginfo[level+1].br[INDN(i,0,k)]
												  -ginfo[level+1].bb[INDN(i,0,k)]
												  -ginfo[level+1].bf[INDN(i,0,k)]
												  -ginfo[level+1].bu[INDN(i,0,k)]
												  -ginfo[level+1].bo[INDN(i,0,k)];
		}
	if (ginfo[level].neigh[3]==-1)
	for (k=1;k<nnz-1;k++)
		for (i=1;i<nnx-1;i++)
		{
			ginfo[level+1].bl[INDN(i,nny-1,k)]	= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].bl[INDO(2*i-1+ioffset, ny-1, 2*k-1+koffset)]) + SQUARE(ginfo[level].bl[INDO(2*i+ioffset,   ny-1, 2*k-1+koffset)]) + SQUARE(ginfo[level].bl[INDO(2*i-1+ioffset, ny-1, 2*k+koffset)]) + SQUARE(ginfo[level].bl[INDO(2*i+ioffset,   ny-1, 2*k+koffset)])));
			ginfo[level+1].br[INDN(i,nny-1,k)]	= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].br[INDO(2*i-1+ioffset, ny-1, 2*k-1+koffset)]) + SQUARE(ginfo[level].br[INDO(2*i+ioffset,   ny-1, 2*k-1+koffset)]) + SQUARE(ginfo[level].br[INDO(2*i-1+ioffset, ny-1, 2*k+koffset)]) + SQUARE(ginfo[level].br[INDO(2*i+ioffset,   ny-1, 2*k+koffset)])));
			ginfo[level+1].bb[INDN(i,nny-1,k)]	= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].bb[INDO(2*i-1+ioffset, ny-1, 2*k-1+koffset)]) + SQUARE(ginfo[level].bb[INDO(2*i+ioffset,   ny-1, 2*k-1+koffset)]) + SQUARE(ginfo[level].bb[INDO(2*i-1+ioffset, ny-1, 2*k+koffset)]) + SQUARE(ginfo[level].bb[INDO(2*i+ioffset,   ny-1, 2*k+koffset)])));
			ginfo[level+1].bf[INDN(i,nny-1,k)]	= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].bf[INDO(2*i-1+ioffset, ny-1, 2*k-1+koffset)]) + SQUARE(ginfo[level].bf[INDO(2*i+ioffset,   ny-1, 2*k-1+koffset)]) + SQUARE(ginfo[level].bf[INDO(2*i-1+ioffset, ny-1, 2*k+koffset)]) + SQUARE(ginfo[level].bf[INDO(2*i+ioffset,   ny-1, 2*k+koffset)])));
			ginfo[level+1].bu[INDN(i,nny-1,k)]	= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].bu[INDO(2*i-1+ioffset, ny-1, 2*k-1+koffset)]) + SQUARE(ginfo[level].bu[INDO(2*i+ioffset,   ny-1, 2*k-1+koffset)]) + SQUARE(ginfo[level].bu[INDO(2*i-1+ioffset, ny-1, 2*k+koffset)]) + SQUARE(ginfo[level].bu[INDO(2*i+ioffset,   ny-1, 2*k+koffset)])));
			ginfo[level+1].bo[INDN(i,nny-1,k)]	= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].bo[INDO(2*i-1+ioffset, ny-1, 2*k-1+koffset)]) + SQUARE(ginfo[level].bo[INDO(2*i+ioffset,   ny-1, 2*k-1+koffset)]) + SQUARE(ginfo[level].bo[INDO(2*i-1+ioffset, ny-1, 2*k+koffset)]) + SQUARE(ginfo[level].bo[INDO(2*i+ioffset,   ny-1, 2*k+koffset)])));
			ginfo[level+1].a[INDN(i,nny-1,k)]	= -ginfo[level+1].bl[INDN(i,nny-1,k)]
												  -ginfo[level+1].br[INDN(i,nny-1,k)]
												  -ginfo[level+1].bb[INDN(i,nny-1,k)]
												  -ginfo[level+1].bf[INDN(i,nny-1,k)]
												  -ginfo[level+1].bu[INDN(i,nny-1,k)]
												  -ginfo[level+1].bo[INDN(i,nny-1,k)];
		}
	if (ginfo[level].neigh[4]==-1)
	for (j=1;j<nny-1;j++)
		for (i=1;i<nnx-1;i++)
		{
			ginfo[level+1].bl[INDN(i,j,0)]		= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].bl[INDO(2*i-1+ioffset, 2*j-1+joffset, 0)])    + SQUARE(ginfo[level].bl[INDO(2*i+ioffset,   2*j-1+joffset, 0)])    + SQUARE(ginfo[level].bl[INDO(2*i-1+ioffset, 2*j+joffset,   0)])    + SQUARE(ginfo[level].bl[INDO(2*i+ioffset,   2*j+joffset,   0)])));
			ginfo[level+1].br[INDN(i,j,0)]		= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].br[INDO(2*i-1+ioffset, 2*j-1+joffset, 0)])    + SQUARE(ginfo[level].br[INDO(2*i+ioffset,   2*j-1+joffset, 0)])    + SQUARE(ginfo[level].br[INDO(2*i-1+ioffset, 2*j+joffset,   0)])    + SQUARE(ginfo[level].br[INDO(2*i+ioffset,   2*j+joffset,   0)])));
			ginfo[level+1].bb[INDN(i,j,0)]		= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].bb[INDO(2*i-1+ioffset, 2*j-1+joffset, 0)])    + SQUARE(ginfo[level].bb[INDO(2*i+ioffset,   2*j-1+joffset, 0)])    + SQUARE(ginfo[level].bb[INDO(2*i-1+ioffset, 2*j+joffset,   0)])    + SQUARE(ginfo[level].bb[INDO(2*i+ioffset,   2*j+joffset,   0)])));
			ginfo[level+1].bf[INDN(i,j,0)]		= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].bf[INDO(2*i-1+ioffset, 2*j-1+joffset, 0)])    + SQUARE(ginfo[level].bf[INDO(2*i+ioffset,   2*j-1+joffset, 0)])    + SQUARE(ginfo[level].bf[INDO(2*i-1+ioffset, 2*j+joffset,   0)])    + SQUARE(ginfo[level].bf[INDO(2*i+ioffset,   2*j+joffset,   0)])));
			ginfo[level+1].bu[INDN(i,j,0)]		= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].bu[INDO(2*i-1+ioffset, 2*j-1+joffset, 0)])    + SQUARE(ginfo[level].bu[INDO(2*i+ioffset,   2*j-1+joffset, 0)])    + SQUARE(ginfo[level].bu[INDO(2*i-1+ioffset, 2*j+joffset,   0)])    + SQUARE(ginfo[level].bu[INDO(2*i+ioffset,   2*j+joffset,   0)])));
			ginfo[level+1].bo[INDN(i,j,0)]		= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].bo[INDO(2*i-1+ioffset, 2*j-1+joffset, 0)])    + SQUARE(ginfo[level].bo[INDO(2*i+ioffset,   2*j-1+joffset, 0)])    + SQUARE(ginfo[level].bo[INDO(2*i-1+ioffset, 2*j+joffset,   0)])    + SQUARE(ginfo[level].bo[INDO(2*i+ioffset,   2*j+joffset,   0)])));
			ginfo[level+1].a[INDN(i,j,0)]		= -ginfo[level+1].bl[INDN(i,j,0)]
												  -ginfo[level+1].br[INDN(i,j,0)]
												  -ginfo[level+1].bb[INDN(i,j,0)]
												  -ginfo[level+1].bf[INDN(i,j,0)]
												  -ginfo[level+1].bu[INDN(i,j,0)]
												  -ginfo[level+1].bo[INDN(i,j,0)];
		}
	if (ginfo[level].neigh[5]==-1)
	for (j=1;j<nny-1;j++)
		for (i=1;i<nnx-1;i++)
		{
			ginfo[level+1].bl[INDN(i,j,nnz-1)]	= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].bl[INDO(2*i-1+ioffset, 2*j-1+joffset, nz-1)]) + SQUARE(ginfo[level].bl[INDO(2*i+ioffset,   2*j-1+joffset, nz-1)]) + SQUARE(ginfo[level].bl[INDO(2*i-1+ioffset, 2*j+joffset,   nz-1)]) + SQUARE(ginfo[level].bl[INDO(2*i+ioffset,   2*j+joffset,   nz-1)])));			
			ginfo[level+1].br[INDN(i,j,nnz-1)]	= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].br[INDO(2*i-1+ioffset, 2*j-1+joffset, nz-1)]) + SQUARE(ginfo[level].br[INDO(2*i+ioffset,   2*j-1+joffset, nz-1)]) + SQUARE(ginfo[level].br[INDO(2*i-1+ioffset, 2*j+joffset,   nz-1)]) + SQUARE(ginfo[level].br[INDO(2*i+ioffset,   2*j+joffset,   nz-1)])));			
			ginfo[level+1].bb[INDN(i,j,nnz-1)]	= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].bb[INDO(2*i-1+ioffset, 2*j-1+joffset, nz-1)]) + SQUARE(ginfo[level].bb[INDO(2*i+ioffset,   2*j-1+joffset, nz-1)]) + SQUARE(ginfo[level].bb[INDO(2*i-1+ioffset, 2*j+joffset,   nz-1)]) + SQUARE(ginfo[level].bb[INDO(2*i+ioffset,   2*j+joffset,   nz-1)])));			
			ginfo[level+1].bf[INDN(i,j,nnz-1)]	= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].bf[INDO(2*i-1+ioffset, 2*j-1+joffset, nz-1)]) + SQUARE(ginfo[level].bf[INDO(2*i+ioffset,   2*j-1+joffset, nz-1)]) + SQUARE(ginfo[level].bf[INDO(2*i-1+ioffset, 2*j+joffset,   nz-1)]) + SQUARE(ginfo[level].bf[INDO(2*i+ioffset,   2*j+joffset,   nz-1)])));			
			ginfo[level+1].bu[INDN(i,j,nnz-1)]	= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].bu[INDO(2*i-1+ioffset, 2*j-1+joffset, nz-1)]) + SQUARE(ginfo[level].bu[INDO(2*i+ioffset,   2*j-1+joffset, nz-1)]) + SQUARE(ginfo[level].bu[INDO(2*i-1+ioffset, 2*j+joffset,   nz-1)]) + SQUARE(ginfo[level].bu[INDO(2*i+ioffset,   2*j+joffset,   nz-1)])));			
			ginfo[level+1].bo[INDN(i,j,nnz-1)]	= -.25*sqrt(0.25 * ( SQUARE(ginfo[level].bo[INDO(2*i-1+ioffset, 2*j-1+joffset, nz-1)]) + SQUARE(ginfo[level].bo[INDO(2*i+ioffset,   2*j-1+joffset, nz-1)]) + SQUARE(ginfo[level].bo[INDO(2*i-1+ioffset, 2*j+joffset,   nz-1)]) + SQUARE(ginfo[level].bo[INDO(2*i+ioffset,   2*j+joffset,   nz-1)])));			
			ginfo[level+1].a[INDN(i,j,nnz-1)]	= -ginfo[level+1].bl[INDN(i,j,nnz-1)]
												  -ginfo[level+1].br[INDN(i,j,nnz-1)]
												  -ginfo[level+1].bb[INDN(i,j,nnz-1)]
												  -ginfo[level+1].bf[INDN(i,j,nnz-1)]
												  -ginfo[level+1].bu[INDN(i,j,nnz-1)]
												  -ginfo[level+1].bo[INDN(i,j,nnz-1)];
		}
	for (i=1;i<nnx-1;i++)
	{
		ginfo[level+1].bl[INDN(i,	0,		0)]		= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bl[INDO(2*i-1+ioffset,	0,		0)])	+ SQUARE(ginfo[level].bl[INDO(2*i+ioffset,	0,		0)]) ));
		ginfo[level+1].bl[INDN(i,	nny-1,	0)]		= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bl[INDO(2*i-1+ioffset,	ny-1,	0)])	+ SQUARE(ginfo[level].bl[INDO(2*i+ioffset,	ny-1,	0)]) ));
		ginfo[level+1].bl[INDN(i,	0,		nnz-1)]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bl[INDO(2*i-1+ioffset,	0,		nz-1)])	+ SQUARE(ginfo[level].bl[INDO(2*i+ioffset,	0,		nz-1)]) ));
		ginfo[level+1].bl[INDN(i,	nny-1,	nnz-1)]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bl[INDO(2*i-1+ioffset,	ny-1,	nz-1)])	+ SQUARE(ginfo[level].bl[INDO(2*i+ioffset,	ny-1,	nz-1)]) ));
		ginfo[level+1].br[INDN(i,	0,		0)]		= -.25*sqrt(0.5 * (SQUARE(ginfo[level].br[INDO(2*i-1+ioffset,	0,		0)])	+ SQUARE(ginfo[level].br[INDO(2*i+ioffset,	0,		0)]) ));
		ginfo[level+1].br[INDN(i,	nny-1,	0)]		= -.25*sqrt(0.5 * (SQUARE(ginfo[level].br[INDO(2*i-1+ioffset,	ny-1,	0)])	+ SQUARE(ginfo[level].br[INDO(2*i+ioffset,	ny-1,	0)]) ));
		ginfo[level+1].br[INDN(i,	0,		nnz-1)]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].br[INDO(2*i-1+ioffset,	0,		nz-1)])	+ SQUARE(ginfo[level].br[INDO(2*i+ioffset,	0,		nz-1)]) ));
		ginfo[level+1].br[INDN(i,	nny-1,	nnz-1)]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].br[INDO(2*i-1+ioffset,	ny-1,	nz-1)])	+ SQUARE(ginfo[level].br[INDO(2*i+ioffset,	ny-1,	nz-1)]) ));
		ginfo[level+1].bb[INDN(i,	0,		0)]		= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bb[INDO(2*i-1+ioffset,	0,		0)])	+ SQUARE(ginfo[level].bb[INDO(2*i+ioffset,	0,		0)]) ));
		ginfo[level+1].bb[INDN(i,	nny-1,	0)]		= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bb[INDO(2*i-1+ioffset,	ny-1,	0)])	+ SQUARE(ginfo[level].bb[INDO(2*i+ioffset,	ny-1,	0)]) ));
		ginfo[level+1].bb[INDN(i,	0,		nnz-1)]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bb[INDO(2*i-1+ioffset,	0,		nz-1)])	+ SQUARE(ginfo[level].bb[INDO(2*i+ioffset,	0,		nz-1)]) ));
		ginfo[level+1].bb[INDN(i,	nny-1,	nnz-1)]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bb[INDO(2*i-1+ioffset,	ny-1,	nz-1)])	+ SQUARE(ginfo[level].bb[INDO(2*i+ioffset,	ny-1,	nz-1)]) ));
		ginfo[level+1].bf[INDN(i,	0,		0)]		= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bf[INDO(2*i-1+ioffset,	0,		0)])	+ SQUARE(ginfo[level].bf[INDO(2*i+ioffset,	0,		0)]) ));
		ginfo[level+1].bf[INDN(i,	nny-1,	0)]		= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bf[INDO(2*i-1+ioffset,	ny-1,	0)])	+ SQUARE(ginfo[level].bf[INDO(2*i+ioffset,	ny-1,	0)]) ));
		ginfo[level+1].bf[INDN(i,	0,		nnz-1)]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bf[INDO(2*i-1+ioffset,	0,		nz-1)])	+ SQUARE(ginfo[level].bf[INDO(2*i+ioffset,	0,		nz-1)]) ));
		ginfo[level+1].bf[INDN(i,	nny-1,	nnz-1)]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bf[INDO(2*i-1+ioffset,	ny-1,	nz-1)])	+ SQUARE(ginfo[level].bf[INDO(2*i+ioffset,	ny-1,	nz-1)]) ));
		ginfo[level+1].bu[INDN(i,	0,		0)]		= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bu[INDO(2*i-1+ioffset,	0,		0)])	+ SQUARE(ginfo[level].bu[INDO(2*i+ioffset,	0,		0)]) ));
		ginfo[level+1].bu[INDN(i,	nny-1,	0)]		= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bu[INDO(2*i-1+ioffset,	ny-1,	0)])	+ SQUARE(ginfo[level].bu[INDO(2*i+ioffset,	ny-1,	0)]) ));
		ginfo[level+1].bu[INDN(i,	0,		nnz-1)]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bu[INDO(2*i-1+ioffset,	0,		nz-1)])	+ SQUARE(ginfo[level].bu[INDO(2*i+ioffset,	0,		nz-1)]) ));
		ginfo[level+1].bu[INDN(i,	nny-1,	nnz-1)]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bu[INDO(2*i-1+ioffset,	ny-1,	nz-1)])	+ SQUARE(ginfo[level].bu[INDO(2*i+ioffset,	ny-1,	nz-1)]) ));
		ginfo[level+1].bo[INDN(i,	0,		0)]		= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bo[INDO(2*i-1+ioffset,	0,		0)])	+ SQUARE(ginfo[level].bo[INDO(2*i+ioffset,	0,		0)]) ));
		ginfo[level+1].bo[INDN(i,	nny-1,	0)]		= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bo[INDO(2*i-1+ioffset,	ny-1,	0)])	+ SQUARE(ginfo[level].bo[INDO(2*i+ioffset,	ny-1,	0)]) ));
		ginfo[level+1].bo[INDN(i,	0,		nnz-1)]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bo[INDO(2*i-1+ioffset,	0,		nz-1)])	+ SQUARE(ginfo[level].bo[INDO(2*i+ioffset,	0,		nz-1)]) ));
		ginfo[level+1].bo[INDN(i,	nny-1,	nnz-1)]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bo[INDO(2*i-1+ioffset,	ny-1,	nz-1)])	+ SQUARE(ginfo[level].bo[INDO(2*i+ioffset,	ny-1,	nz-1)]) ));

		ginfo[level+1].a[INDN(i,0,0)]		= BIGA;
		ginfo[level+1].a[INDN(i,nny-1,0)]		= BIGA;
		ginfo[level+1].a[INDN(i,0,nnz-1)]		= BIGA;
		ginfo[level+1].a[INDN(i,nny-1,nnz-1)]		= BIGA;
	}
	for (j=1;j<nny-1;j++)
	{
		ginfo[level+1].bl[INDN(0    , j    ,0    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bl[INDO(0    , 2*j-1+joffset, 0   )])	+ SQUARE(ginfo[level].bl[INDO(0    , 2*j+joffset  , 0   )])));
		ginfo[level+1].bl[INDN(nnx-1, j    ,0    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bl[INDO(nx-1 , 2*j-1+joffset, 0   )])	+ SQUARE(ginfo[level].bl[INDO(nx-1 , 2*j+joffset  , 0   )])));
		ginfo[level+1].bl[INDN(0    , j    ,nnz-1)]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bl[INDO(0    , 2*j-1+joffset, nz-1)])	+ SQUARE(ginfo[level].bl[INDO(0    , 2*j+joffset  , nz-1)])));
		ginfo[level+1].bl[INDN(nnx-1, j    ,nnz-1)]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bl[INDO(nx-1 , 2*j-1+joffset, nz-1)])	+ SQUARE(ginfo[level].bl[INDO(nx-1 , 2*j+joffset  , nz-1)])));
		ginfo[level+1].br[INDN(0    , j    ,0    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].br[INDO(0    , 2*j-1+joffset, 0   )])	+ SQUARE(ginfo[level].br[INDO(0    , 2*j+joffset  , 0   )])));
		ginfo[level+1].br[INDN(nnx-1, j    ,0    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].br[INDO(nx-1 , 2*j-1+joffset, 0   )])	+ SQUARE(ginfo[level].br[INDO(nx-1 , 2*j+joffset  , 0   )])));
		ginfo[level+1].br[INDN(0    , j    ,nnz-1)]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].br[INDO(0    , 2*j-1+joffset, nz-1)])	+ SQUARE(ginfo[level].br[INDO(0    , 2*j+joffset  , nz-1)])));
		ginfo[level+1].br[INDN(nnx-1, j    ,nnz-1)]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].br[INDO(nx-1 , 2*j-1+joffset, nz-1)])	+ SQUARE(ginfo[level].br[INDO(nx-1 , 2*j+joffset  , nz-1)])));
		ginfo[level+1].bb[INDN(0    , j    ,0    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bb[INDO(0    , 2*j-1+joffset, 0   )])	+ SQUARE(ginfo[level].bb[INDO(0    , 2*j+joffset  , 0   )])));
		ginfo[level+1].bb[INDN(nnx-1, j    ,0    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bb[INDO(nx-1 , 2*j-1+joffset, 0   )])	+ SQUARE(ginfo[level].bb[INDO(nx-1 , 2*j+joffset  , 0   )])));
		ginfo[level+1].bb[INDN(0    , j    ,nnz-1)]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bb[INDO(0    , 2*j-1+joffset, nz-1)])	+ SQUARE(ginfo[level].bb[INDO(0    , 2*j+joffset  , nz-1)])));
		ginfo[level+1].bb[INDN(nnx-1, j    ,nnz-1)]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bb[INDO(nx-1 , 2*j-1+joffset, nz-1)])	+ SQUARE(ginfo[level].bb[INDO(nx-1 , 2*j+joffset  , nz-1)])));
		ginfo[level+1].bf[INDN(0    , j    ,0    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bf[INDO(0    , 2*j-1+joffset, 0   )])	+ SQUARE(ginfo[level].bf[INDO(0    , 2*j+joffset  , 0   )])));
		ginfo[level+1].bf[INDN(nnx-1, j    ,0    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bf[INDO(nx-1 , 2*j-1+joffset, 0   )])	+ SQUARE(ginfo[level].bf[INDO(nx-1 , 2*j+joffset  , 0   )])));
		ginfo[level+1].bf[INDN(0    , j    ,nnz-1)]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bf[INDO(0    , 2*j-1+joffset, nz-1)])	+ SQUARE(ginfo[level].bf[INDO(0    , 2*j+joffset  , nz-1)])));
		ginfo[level+1].bf[INDN(nnx-1, j    ,nnz-1)]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bf[INDO(nx-1 , 2*j-1+joffset, nz-1)])	+ SQUARE(ginfo[level].bf[INDO(nx-1 , 2*j+joffset  , nz-1)])));
		ginfo[level+1].bu[INDN(0    , j    ,0    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bu[INDO(0    , 2*j-1+joffset, 0   )])	+ SQUARE(ginfo[level].bu[INDO(0    , 2*j+joffset  , 0   )])));
		ginfo[level+1].bu[INDN(nnx-1, j    ,0    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bu[INDO(nx-1 , 2*j-1+joffset, 0   )])	+ SQUARE(ginfo[level].bu[INDO(nx-1 , 2*j+joffset  , 0   )])));
		ginfo[level+1].bu[INDN(0    , j    ,nnz-1)]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bu[INDO(0    , 2*j-1+joffset, nz-1)])	+ SQUARE(ginfo[level].bu[INDO(0    , 2*j+joffset  , nz-1)])));
		ginfo[level+1].bu[INDN(nnx-1, j    ,nnz-1)]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bu[INDO(nx-1 , 2*j-1+joffset, nz-1)])	+ SQUARE(ginfo[level].bu[INDO(nx-1 , 2*j+joffset  , nz-1)])));
		ginfo[level+1].bo[INDN(0    , j    ,0    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bo[INDO(0    , 2*j-1+joffset, 0   )])	+ SQUARE(ginfo[level].bo[INDO(0    , 2*j+joffset  , 0   )])));
		ginfo[level+1].bo[INDN(nnx-1, j    ,0    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bo[INDO(nx-1 , 2*j-1+joffset, 0   )])	+ SQUARE(ginfo[level].bo[INDO(nx-1 , 2*j+joffset  , 0   )])));
		ginfo[level+1].bo[INDN(0    , j    ,nnz-1)]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bo[INDO(0    , 2*j-1+joffset, nz-1)])	+ SQUARE(ginfo[level].bo[INDO(0    , 2*j+joffset  , nz-1)])));
		ginfo[level+1].bo[INDN(nnx-1, j    ,nnz-1)]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bo[INDO(nx-1 , 2*j-1+joffset, nz-1)])	+ SQUARE(ginfo[level].bo[INDO(nx-1 , 2*j+joffset  , nz-1)])));
													  
		ginfo[level+1].a[INDN(0,j,0)]		= BIGA;
		ginfo[level+1].a[INDN(nnx-1,j,0)]		= BIGA;
		ginfo[level+1].a[INDN(0,j,nnz-1)]		= BIGA;
		ginfo[level+1].a[INDN(nnx-1,j,nnz-1)]		= BIGA;

	}
	for (k=1;k<nnz-1;k++)
	{
		ginfo[level+1].bl[INDN(0    , 0    ,k    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bl[INDO(0    , 0    , 2*k-1+koffset)])	+ SQUARE(ginfo[level].bl[INDO(0    , 0    , 2*k+koffset )])));
		ginfo[level+1].bl[INDN(nnx-1, 0    ,k    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bl[INDO(nx-1 , 0    , 2*k-1+koffset)])	+ SQUARE(ginfo[level].bl[INDO(nx-1 , 0    , 2*k+koffset )])));
		ginfo[level+1].bl[INDN(0    , nny-1,k    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bl[INDO(0    , ny-1 , 2*k-1+koffset)])	+ SQUARE(ginfo[level].bl[INDO(0    , ny-1 , 2*k+koffset )])));
		ginfo[level+1].bl[INDN(nnx-1, nny-1,k    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bl[INDO(nx-1 , ny-1 , 2*k-1+koffset)])	+ SQUARE(ginfo[level].bl[INDO(nx-1 , ny-1 , 2*k+koffset )])));
		ginfo[level+1].br[INDN(0    , 0    ,k    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].br[INDO(0    , 0    , 2*k-1+koffset)])	+ SQUARE(ginfo[level].br[INDO(0    , 0    , 2*k+koffset )])));
		ginfo[level+1].br[INDN(nnx-1, 0    ,k    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].br[INDO(nx-1 , 0    , 2*k-1+koffset)])	+ SQUARE(ginfo[level].br[INDO(nx-1 , 0    , 2*k+koffset )])));
		ginfo[level+1].br[INDN(0    , nny-1,k    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].br[INDO(0    , ny-1 , 2*k-1+koffset)])	+ SQUARE(ginfo[level].br[INDO(0    , ny-1 , 2*k+koffset )])));
		ginfo[level+1].br[INDN(nnx-1, nny-1,k    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].br[INDO(nx-1 , ny-1 , 2*k-1+koffset)])	+ SQUARE(ginfo[level].br[INDO(nx-1 , ny-1 , 2*k+koffset )])));
		ginfo[level+1].bb[INDN(0    , 0    ,k    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bb[INDO(0    , 0    , 2*k-1+koffset)])	+ SQUARE(ginfo[level].bb[INDO(0    , 0    , 2*k+koffset )])));
		ginfo[level+1].bb[INDN(nnx-1, 0    ,k    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bb[INDO(nx-1 , 0    , 2*k-1+koffset)])	+ SQUARE(ginfo[level].bb[INDO(nx-1 , 0    , 2*k+koffset )])));
		ginfo[level+1].bb[INDN(0    , nny-1,k    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bb[INDO(0    , ny-1 , 2*k-1+koffset)])	+ SQUARE(ginfo[level].bb[INDO(0    , ny-1 , 2*k+koffset )])));
		ginfo[level+1].bb[INDN(nnx-1, nny-1,k    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bb[INDO(nx-1 , ny-1 , 2*k-1+koffset)])	+ SQUARE(ginfo[level].bb[INDO(nx-1 , ny-1 , 2*k+koffset )])));
		ginfo[level+1].bf[INDN(0    , 0    ,k    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bf[INDO(0    , 0    , 2*k-1+koffset)])	+ SQUARE(ginfo[level].bf[INDO(0    , 0    , 2*k+koffset )])));
		ginfo[level+1].bf[INDN(nnx-1, 0    ,k    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bf[INDO(nx-1 , 0    , 2*k-1+koffset)])	+ SQUARE(ginfo[level].bf[INDO(nx-1 , 0    , 2*k+koffset )])));
		ginfo[level+1].bf[INDN(0    , nny-1,k    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bf[INDO(0    , ny-1 , 2*k-1+koffset)])	+ SQUARE(ginfo[level].bf[INDO(0    , ny-1 , 2*k+koffset )])));
		ginfo[level+1].bf[INDN(nnx-1, nny-1,k    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bf[INDO(nx-1 , ny-1 , 2*k-1+koffset)])	+ SQUARE(ginfo[level].bf[INDO(nx-1 , ny-1 , 2*k+koffset )])));
		ginfo[level+1].bu[INDN(0    , 0    ,k    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bu[INDO(0    , 0    , 2*k-1+koffset)])	+ SQUARE(ginfo[level].bu[INDO(0    , 0    , 2*k+koffset )])));
		ginfo[level+1].bu[INDN(nnx-1, 0    ,k    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bu[INDO(nx-1 , 0    , 2*k-1+koffset)])	+ SQUARE(ginfo[level].bu[INDO(nx-1 , 0    , 2*k+koffset )])));
		ginfo[level+1].bu[INDN(0    , nny-1,k    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bu[INDO(0    , ny-1 , 2*k-1+koffset)])	+ SQUARE(ginfo[level].bu[INDO(0    , ny-1 , 2*k+koffset )])));
		ginfo[level+1].bu[INDN(nnx-1, nny-1,k    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bu[INDO(nx-1 , ny-1 , 2*k-1+koffset)])	+ SQUARE(ginfo[level].bu[INDO(nx-1 , ny-1 , 2*k+koffset )])));
		ginfo[level+1].bo[INDN(0    , 0    ,k    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bo[INDO(0    , 0    , 2*k-1+koffset)])	+ SQUARE(ginfo[level].bo[INDO(0    , 0    , 2*k+koffset )])));
		ginfo[level+1].bo[INDN(nnx-1, 0    ,k    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bo[INDO(nx-1 , 0    , 2*k-1+koffset)])	+ SQUARE(ginfo[level].bo[INDO(nx-1 , 0    , 2*k+koffset )])));
		ginfo[level+1].bo[INDN(0    , nny-1,k    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bo[INDO(0    , ny-1 , 2*k-1+koffset)])	+ SQUARE(ginfo[level].bo[INDO(0    , ny-1 , 2*k+koffset )])));
		ginfo[level+1].bo[INDN(nnx-1, nny-1,k    )]	= -.25*sqrt(0.5 * (SQUARE(ginfo[level].bo[INDO(nx-1 , ny-1 , 2*k-1+koffset)])	+ SQUARE(ginfo[level].bo[INDO(nx-1 , ny-1 , 2*k+koffset )])));

		ginfo[level+1].a[INDN(0,0,k)]		= BIGA;
		ginfo[level+1].a[INDN(nnx-1,0,k)]		= BIGA;
		ginfo[level+1].a[INDN(0,nny-1,k)]		= BIGA;
		ginfo[level+1].a[INDN(nnx-1,nny-1,k)]		= BIGA;

	}

	ginfo[level+1].a[INDN(0    , 0    ,	0    )] = .25*ginfo[level].a[INDO(0   ,	0   ,	0   )];
	ginfo[level+1].a[INDN(nnx-1, 0    ,	0    )] = .25*ginfo[level].a[INDO(nx-1,	0   ,	0   )];
	ginfo[level+1].a[INDN(0    , nny-1,	0    )] = .25*ginfo[level].a[INDO(0   ,	ny-1,	0   )];
	ginfo[level+1].a[INDN(nnx-1, nny-1,	0    )] = .25*ginfo[level].a[INDO(nx-1,	ny-1,	0   )];
	ginfo[level+1].a[INDN(0    , 0    ,	nnz-1)] = .25*ginfo[level].a[INDO(0   ,	0   ,	nz-1)];
	ginfo[level+1].a[INDN(nnx-1, 0    ,	nnz-1)] = .25*ginfo[level].a[INDO(nx-1,	0   ,	nz-1)];
	ginfo[level+1].a[INDN(0    , nny-1,	nnz-1)] = .25*ginfo[level].a[INDO(0   ,	ny-1,	nz-1)];
	ginfo[level+1].a[INDN(nnx-1, nny-1,	nnz-1)] = .25*ginfo[level].a[INDO(nx-1,	ny-1,	nz-1)];

	ginfo[level+1].bl[INDN(0    , 0    ,	0    )] = .25*ginfo[level].bl[INDO(0   ,	0   ,	0   )];
	ginfo[level+1].bl[INDN(nnx-1, 0    ,	0    )] = .25*ginfo[level].bl[INDO(nx-1,	0   ,	0   )];
	ginfo[level+1].bl[INDN(0    , nny-1,	0    )] = .25*ginfo[level].bl[INDO(0   ,	ny-1,	0   )];
	ginfo[level+1].bl[INDN(nnx-1, nny-1,	0    )] = .25*ginfo[level].bl[INDO(nx-1,	ny-1,	0   )];
	ginfo[level+1].bl[INDN(0    , 0    ,	nnz-1)] = .25*ginfo[level].bl[INDO(0   ,	0   ,	nz-1)];
	ginfo[level+1].bl[INDN(nnx-1, 0    ,	nnz-1)] = .25*ginfo[level].bl[INDO(nx-1,	0   ,	nz-1)];
	ginfo[level+1].bl[INDN(0    , nny-1,	nnz-1)] = .25*ginfo[level].bl[INDO(0   ,	ny-1,	nz-1)];
	ginfo[level+1].bl[INDN(nnx-1, nny-1,	nnz-1)] = .25*ginfo[level].bl[INDO(nx-1,	ny-1,	nz-1)];

	ginfo[level+1].br[INDN(0    , 0    ,	0    )] = .25*ginfo[level].br[INDO(0   ,	0   ,	0   )];
	ginfo[level+1].br[INDN(nnx-1, 0    ,	0    )] = .25*ginfo[level].br[INDO(nx-1,	0   ,	0   )];
	ginfo[level+1].br[INDN(0    , nny-1,	0    )] = .25*ginfo[level].br[INDO(0   ,	ny-1,	0   )];
	ginfo[level+1].br[INDN(nnx-1, nny-1,	0    )] = .25*ginfo[level].br[INDO(nx-1,	ny-1,	0   )];
	ginfo[level+1].br[INDN(0    , 0    ,	nnz-1)] = .25*ginfo[level].br[INDO(0   ,	0   ,	nz-1)];
	ginfo[level+1].br[INDN(nnx-1, 0    ,	nnz-1)] = .25*ginfo[level].br[INDO(nx-1,	0   ,	nz-1)];
	ginfo[level+1].br[INDN(0    , nny-1,	nnz-1)] = .25*ginfo[level].br[INDO(0   ,	ny-1,	nz-1)];
	ginfo[level+1].br[INDN(nnx-1, nny-1,	nnz-1)] = .25*ginfo[level].br[INDO(nx-1,	ny-1,	nz-1)];

	ginfo[level+1].bb[INDN(0    , 0    ,	0    )] = .25*ginfo[level].bb[INDO(0   ,	0   ,	0   )];
	ginfo[level+1].bb[INDN(nnx-1, 0    ,	0    )] = .25*ginfo[level].bb[INDO(nx-1,	0   ,	0   )];
	ginfo[level+1].bb[INDN(0    , nny-1,	0    )] = .25*ginfo[level].bb[INDO(0   ,	ny-1,	0   )];
	ginfo[level+1].bb[INDN(nnx-1, nny-1,	0    )] = .25*ginfo[level].bb[INDO(nx-1,	ny-1,	0   )];
	ginfo[level+1].bb[INDN(0    , 0    ,	nnz-1)] = .25*ginfo[level].bb[INDO(0   ,	0   ,	nz-1)];
	ginfo[level+1].bb[INDN(nnx-1, 0    ,	nnz-1)] = .25*ginfo[level].bb[INDO(nx-1,	0   ,	nz-1)];
	ginfo[level+1].bb[INDN(0    , nny-1,	nnz-1)] = .25*ginfo[level].bb[INDO(0   ,	ny-1,	nz-1)];
	ginfo[level+1].bb[INDN(nnx-1, nny-1,	nnz-1)] = .25*ginfo[level].bb[INDO(nx-1,	ny-1,	nz-1)];

	ginfo[level+1].bf[INDN(0    , 0    ,	0    )] = .25*ginfo[level].bf[INDO(0   ,	0   ,	0   )];
	ginfo[level+1].bf[INDN(nnx-1, 0    ,	0    )] = .25*ginfo[level].bf[INDO(nx-1,	0   ,	0   )];
	ginfo[level+1].bf[INDN(0    , nny-1,	0    )] = .25*ginfo[level].bf[INDO(0   ,	ny-1,	0   )];
	ginfo[level+1].bf[INDN(nnx-1, nny-1,	0    )] = .25*ginfo[level].bf[INDO(nx-1,	ny-1,	0   )];
	ginfo[level+1].bf[INDN(0    , 0    ,	nnz-1)] = .25*ginfo[level].bf[INDO(0   ,	0   ,	nz-1)];
	ginfo[level+1].bf[INDN(nnx-1, 0    ,	nnz-1)] = .25*ginfo[level].bf[INDO(nx-1,	0   ,	nz-1)];
	ginfo[level+1].bf[INDN(0    , nny-1,	nnz-1)] = .25*ginfo[level].bf[INDO(0   ,	ny-1,	nz-1)];
	ginfo[level+1].bf[INDN(nnx-1, nny-1,	nnz-1)] = .25*ginfo[level].bf[INDO(nx-1,	ny-1,	nz-1)];

	ginfo[level+1].bu[INDN(0    , 0    ,	0    )] = .25*ginfo[level].bu[INDO(0   ,	0   ,	0   )];
	ginfo[level+1].bu[INDN(nnx-1, 0    ,	0    )] = .25*ginfo[level].bu[INDO(nx-1,	0   ,	0   )];
	ginfo[level+1].bu[INDN(0    , nny-1,	0    )] = .25*ginfo[level].bu[INDO(0   ,	ny-1,	0   )];
	ginfo[level+1].bu[INDN(nnx-1, nny-1,	0    )] = .25*ginfo[level].bu[INDO(nx-1,	ny-1,	0   )];
	ginfo[level+1].bu[INDN(0    , 0    ,	nnz-1)] = .25*ginfo[level].bu[INDO(0   ,	0   ,	nz-1)];
	ginfo[level+1].bu[INDN(nnx-1, 0    ,	nnz-1)] = .25*ginfo[level].bu[INDO(nx-1,	0   ,	nz-1)];
	ginfo[level+1].bu[INDN(0    , nny-1,	nnz-1)] = .25*ginfo[level].bu[INDO(0   ,	ny-1,	nz-1)];
	ginfo[level+1].bu[INDN(nnx-1, nny-1,	nnz-1)] = .25*ginfo[level].bu[INDO(nx-1,	ny-1,	nz-1)];

	ginfo[level+1].bo[INDN(0    , 0    ,	0    )] = .25*ginfo[level].bo[INDO(0   ,	0   ,	0   )];
	ginfo[level+1].bo[INDN(nnx-1, 0    ,	0    )] = .25*ginfo[level].bo[INDO(nx-1,	0   ,	0   )];
	ginfo[level+1].bo[INDN(0    , nny-1,	0    )] = .25*ginfo[level].bo[INDO(0   ,	ny-1,	0   )];
	ginfo[level+1].bo[INDN(nnx-1, nny-1,	0    )] = .25*ginfo[level].bo[INDO(nx-1,	ny-1,	0   )];
	ginfo[level+1].bo[INDN(0    , 0    ,	nnz-1)] = .25*ginfo[level].bo[INDO(0   ,	0   ,	nz-1)];
	ginfo[level+1].bo[INDN(nnx-1, 0    ,	nnz-1)] = .25*ginfo[level].bo[INDO(nx-1,	0   ,	nz-1)];
	ginfo[level+1].bo[INDN(0    , nny-1,	nnz-1)] = .25*ginfo[level].bo[INDO(0   ,	ny-1,	nz-1)];
	ginfo[level+1].bo[INDN(nnx-1, nny-1,	nnz-1)] = .25*ginfo[level].bo[INDO(nx-1,	ny-1,	nz-1)];

	//exchange coefficients after restrict...
	arecvplanen<double> (ginfo[level+1].a, 2, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].a, 1, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].bl, 2, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].bl, 1, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].br, 2, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].br, 1, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].bb, 2, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].bb, 1, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].bf, 2, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].bf, 1, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].bu, 2, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].bu, 1, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].bo, 2, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].bo, 1, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].a, 1, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].a, 2, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].bl, 1, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].bl, 2, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].br, 1, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].br, 2, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].bb, 1, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].bb, 2, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].bf, 1, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].bf, 2, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].bu, 1, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].bu, 2, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].bo, 1, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].bo, 2, ginfo[level].neigh, nnx, nny, nnz);
	arecvspacewait();

	arecvplanen<double> (ginfo[level+1].a, 4, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].a, 3, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].bl, 4, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].bl, 3, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].br, 4, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].br, 3, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].bb, 4, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].bb, 3, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].bf, 4, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].bf, 3, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].bu, 4, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].bu, 3, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].bo, 4, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].bo, 3, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].a, 3, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].a, 4, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].bl, 3, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].bl, 4, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].br, 3, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].br, 4, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].bb, 3, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].bb, 4, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].bf, 3, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].bf, 4, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].bu, 3, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].bu, 4, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].bo, 3, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].bo, 4, ginfo[level].neigh, nnx, nny, nnz);
	arecvspacewait();

	arecvplanen<double> (ginfo[level+1].a, 6, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].a, 5, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].bl, 6, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].bl, 5, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].br, 6, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].br, 5, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].bb, 6, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].bb, 5, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].bf, 6, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].bf, 5, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].bu, 6, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].bu, 5, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].bo, 6, ginfo[level].neigh, nnx, nny, nnz);
	arecvplanen<double> (ginfo[level+1].bo, 5, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].a, 5, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].a, 6, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].bl, 5, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].bl, 6, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].br, 5, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].br, 6, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].bb, 5, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].bb, 6, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].bf, 5, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].bf, 6, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].bu, 5, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].bu, 6, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].bo, 5, ginfo[level].neigh, nnx, nny, nnz);
	sendplanen<double> (ginfo[level+1].bo, 6, ginfo[level].neigh, nnx, nny, nnz);
	arecvspacewait();

	return true;
}

bool interpolate(int level, double**anew, double *a, int *sizeofanew, int nx, int ny, int nz)
{
	//if successful, returns true and decrements level.
	//a is interpolated onto anew.
	//otherwise, nothing is done, and return value is false.

	//sizeofanew in bytes.
	//if anew isn't large enough to hold data, it will be realloced and
	//sizeofanew set to the new size of anew (bytes)

	//nx, ny, nz are dimensions of a.

	//Calls to interpolate must be paired with a previous call to restrict..
	//e.g. if calling interpolate 3 times, the last three calls to restrict
	//must be for a field variable of the same size.
	//However, calls to restrict need not be paired with calls to interpolate.

	if (level >= MAXMGLEV) return false;
	if (level < 1) return false;	//can't interpolate past level 0!
	int nnx = ginfo[level-1].nx;
	int nny = ginfo[level-1].ny;
	int nnz = ginfo[level-1].nz;

	int newasize = nnx*nny*nnz*sizeof(double);
	//ensure anew is allocated and large enough.
	resize (anew, sizeofanew, newasize);
	memset (*anew, 0, nnx*nny*nnz*sizeof(double));

	//calculate i,j,k-offsets if ginfo[level].o is odd.
	int ioffset=0,joffset=0,koffset=0;
	if (ginfo[level-1].o[0] &1) ioffset = 1;
	if (ginfo[level-1].o[1] &1) joffset = 1;
	if (ginfo[level-1].o[2] &1) koffset = 1;
	
	int i,j,k;
	for (k=1;k<nnz-1;k++)
		for (j=1;j<nny-1;j++)
			for (i=1;i<nnx-1;i++)
			{
				(*anew)[INDN(i,j,k)] = a[INDO((i+1-ioffset)>>1, (j+1-joffset)>>1, (k+1-koffset)>>1)];
			}

	arecvplanen<double> (*anew, 2, ginfo[level-1].neigh, nnx, nny, nnz);
	arecvplanen<double> (*anew, 1, ginfo[level-1].neigh, nnx, nny, nnz);
	sendplanen<double> (*anew, 1, ginfo[level-1].neigh, nnx, nny, nnz);
	sendplanen<double> (*anew, 2, ginfo[level-1].neigh, nnx, nny, nnz);
	arecvspacewait();

	arecvplanen<double> (*anew, 4, ginfo[level-1].neigh, nnx, nny, nnz);
	arecvplanen<double> (*anew, 3, ginfo[level-1].neigh, nnx, nny, nnz);
	sendplanen<double> (*anew, 3, ginfo[level-1].neigh, nnx, nny, nnz);
	sendplanen<double> (*anew, 4, ginfo[level-1].neigh, nnx, nny, nnz);
	arecvspacewait();

	arecvplanen<double> (*anew, 6, ginfo[level-1].neigh, nnx, nny, nnz);
	arecvplanen<double> (*anew, 5, ginfo[level-1].neigh, nnx, nny, nnz);
	sendplanen<double> (*anew, 5, ginfo[level-1].neigh, nnx, nny, nnz);
	sendplanen<double> (*anew, 6, ginfo[level-1].neigh, nnx, nny, nnz);
	arecvspacewait();

	return true;

}

void gs(double *p, double *rhs, double *a, double *bl, double *br, double *bb, double *bf, double *bu, double *bo, int nx, int ny, int nz, struct _ginfo &info)
{
	//See Numerical Recipes, 19.5 Relaxation Methods for Boundary Value Problems on Chebyshev acceleration.
	//(no, Chebyshev acceleration isn't used here because spectral radius is not available...or at least 
	//I don't know how to calculate it =)

	//neigh[6] specifies which processors are this one's neighbors (for future use).

	//make sure boundary conditions are applied before calling gs

	//red-black gauss-seidel
	int i,j,k;
	double maxp=0.0;
	for (int it=0;it<2;it++)
	{
		maxp=0.0;
		for (k=1; k<nz-1;k++)
			for (j=1;j<ny-1;j++)
				for (i=1+((info.o[0]+info.o[1]+info.o[2]+it+j+k)&1);i<nx-1;i+=2)
				{
					const int ijk=i+(j+k*ny)*nx;
					const int imjk=ijk-1;
					const int ijmk=ijk-nx;
					const int ijkm=ijk-nx*ny;
					const int ipjk=ijk+1;
					const int ijpk=ijk+nx;
					const int ijkp=ijk+nx*ny;

					if (fabs(a[ijk]) >= 5e+24 || fabs(a[ijk])<=1e-75) //a is set to large number if out of bounds.
						p[ijk]=0.0;
					else
					{
						p[ijk]=(rhs[ijk]
								 -bl[ijk]*p[imjk]
								 -br[ijk]*p[ipjk]
								 -bb[ijk]*p[ijmk]
								 -bf[ijk]*p[ijpk]
								 -bu[ijk]*p[ijkm]
								 -bo[ijk]*p[ijkp] 
								 )
								 /
								 (a[ijk])*omega + p[ijk]*(1.0-omega);
						if (fabs(p[ijk])>1e20)
						{
							if (nx==dim.nx)
								printf ("%d: %d %d %d: p too big: %.3e %.3e %.3e %.3e %.3e %.3e %.3e %.3e %.3e %.3e\n", mpi.MyRank, i,j,k,p[ijk], a[ijk], bl[ijk],  br[ijk],bb[ijk],bf[ijk],bu[ijk],bo[ijk],rhs[ijk],f[ijk]);
							p[ijk]=0.0;
						}
					}
				}
		arecvplanen<double>(p, 2, info.neigh, nx,ny,nz);
		arecvplanen<double>(p, 1, info.neigh, nx,ny,nz);
		sendplanen<double>(p, 1, info.neigh, nx,ny,nz);
		sendplanen<double>(p, 2, info.neigh, nx,ny,nz);
		arecvspacewait();
		arecvplanen<double>(p, 4, info.neigh, nx,ny,nz);
		arecvplanen<double>(p, 3, info.neigh, nx,ny,nz);
		sendplanen<double>(p, 3, info.neigh, nx,ny,nz);
		sendplanen<double>(p, 4, info.neigh, nx,ny,nz);
		arecvspacewait();
		arecvplanen<double>(p, 6, info.neigh, nx,ny,nz);
		arecvplanen<double>(p, 5, info.neigh, nx,ny,nz);
		sendplanen<double>(p, 5, info.neigh, nx,ny,nz);
		sendplanen<double>(p, 6, info.neigh, nx,ny,nz);
		arecvspacewait();
	}
}

void residue (double**res, int *sizeofres, double *p, double *a, double *rhs, double *bl, double *br, double *bb, double *bf, double *bu, double *bo, int nx, int ny, int nz)
{
	if (*sizeofres < nx*ny*nz*(int)sizeof(double))
	{
		*res = (double*) realloc (*res, nx*ny*nz*sizeof(double));
		*sizeofres = nx*ny*nz*sizeof(double);
	}
	//calculate residue.
	memset (*res, 0, nx*ny*nz*sizeof(double));

	int i,j,k;
	for (k=1;k<nz-1;k++)
		for (j=1;j<ny-1;j++)
			for (i=1;i<nx-1;i++)
			{
				const int ijk=INDO(i,j,k);
				const int imjk=ijk-1;
				const int ipjk=ijk+1;
				const int ijmk=ijk-nx;
				const int ijpk=ijk+nx;
				const int ijkm=ijk-nx*ny;
				const int ijkp=ijk+nx*ny;
				if (a[ijk] > 0.8/tiny) 
					(*res)[ijk]=0.0; 
				else
					(*res)[ijk]=rhs[ijk]
							 -bl[ijk]*p[imjk]
							 -br[ijk]*p[ipjk]
							 -bb[ijk]*p[ijmk]
							 -bf[ijk]*p[ijpk]
							 -bu[ijk]*p[ijkm]
							 -bo[ijk]*p[ijkp] 
							 -a[ijk]*p[ijk];
				
			}

}

void mgv(double *p, double *rhs, double *a, double *bl, double *br, double *bb, double *bf, double *bu, double *bo )
{
	//Multigrid V-cycles using initial guess.
	//solve matrix equation 
	// div (grad p / rho) = rhs.
	//a,bl,br,bb,bf,bu,bo are coefficents.
	//solve for p.

	//p is an initial guess.

	//calculate coefficients for all levels...
	int level=0;
	int it;

	bool aret=true, oret;
	//Set level 0 (fine grid) storage to be externally-provided memory.
	ginfo[0].a  = a;
	ginfo[0].bl = bl;
	ginfo[0].br = br;
	ginfo[0].bb = bb;
	ginfo[0].bf = bf;
	ginfo[0].bu = bu;
	ginfo[0].bo = bo;
	ginfo[0].rhs = rhs;
	ginfo[0].p = p;
	ginfo[0].nx = NX;
	ginfo[0].ny = NY;
	ginfo[0].nz = NZ;
	ginfo[0].asize = NX*NY*NZ*sizeof(double);	//assume supplied buffers are ok.
	ginfo[0].blsize = NX*NY*NZ*sizeof(double);
	ginfo[0].brsize = NX*NY*NZ*sizeof(double);
	ginfo[0].bbsize = NX*NY*NZ*sizeof(double);
	ginfo[0].bfsize = NX*NY*NZ*sizeof(double);
	ginfo[0].busize = NX*NY*NZ*sizeof(double);
	ginfo[0].bosize = NX*NY*NZ*sizeof(double);
	ginfo[0].rhssize = NX*NY*NZ*sizeof(double);
	ginfo[0].psize = NX*NY*NZ*sizeof(double);
				  
	//get coefficients and rhs for all coarse grids.
	while (aret)
	{
		aret=true; oret=false;
		bool r = restrictcoef (level, ginfo[level].nx, ginfo[level].ny, ginfo[level].nz);
		aret &= r;
		oret |= r;
		r = restrict (level, &ginfo[level+1].rhs, ginfo[level].rhs, &ginfo[level+1].rhssize, ginfo[level].nx, ginfo[level].ny, ginfo[level].nz);
		aret &= r;
		oret |= r;
		if (oret != aret)
		{
			//if some restrictions are ok, but some aren't, something's wrong.
			printf ("mg restrict coef/rhs error\n");
			exit(1);
		}  
		if (aret)
			level++;
	}

	int toplv=level;
	for (int itcycle=0; itcycle<mgcycles; itcycle++)
	{
		int lv;
		//down the V cycle.
		for (lv=1; lv <= toplv; lv++)
		{
			for (it=0;it<npre;it++)
				gs (ginfo[lv-1].p, ginfo[lv-1].rhs, ginfo[lv-1].a, ginfo[lv-1].bl, ginfo[lv-1].br, ginfo[lv-1].bb, ginfo[lv-1].bf, ginfo[lv-1].bu, ginfo[lv-1].bo, ginfo[lv-1].nx, ginfo[lv-1].ny, ginfo[lv-1].nz, ginfo[lv-1]);
			residue(&ginfo[lv-1].res, &ginfo[lv-1].ressize, ginfo[lv-1].p, ginfo[lv-1].a, ginfo[lv-1].rhs, ginfo[lv-1].bl, ginfo[lv-1].br, ginfo[lv-1].bb, ginfo[lv-1].bf, ginfo[lv-1].bu, ginfo[lv-1].bo, ginfo[lv-1].nx, ginfo[lv-1].ny, ginfo[lv-1].nz);
			restrict (lv-1, &ginfo[lv].rhs, ginfo[lv-1].res, &ginfo[lv].rhssize, ginfo[lv-1].nx, ginfo[lv-1].ny, ginfo[lv-1].nz);
			resize (&ginfo[lv].p, &ginfo[lv].psize, ginfo[lv].nx*ginfo[lv].ny*ginfo[lv].nz*sizeof(double));
			memset (ginfo[lv].p, 0, ginfo[lv].nx*ginfo[lv].ny*ginfo[lv].nz*sizeof(double));
		}

		//coarsest grid. Solve.
		double topnrm=0.0, oldtopnrm=0.0;
		int toprep=0;	//limit the number of iterations.
		do
		{
			oldtopnrm = topnrm;
			for (it=0;it<ntop;it++)
				gs (ginfo[toplv].p, ginfo[toplv].rhs, ginfo[toplv].a, ginfo[toplv].bl, ginfo[toplv].br, ginfo[toplv].bb, ginfo[toplv].bf, ginfo[toplv].bu, ginfo[toplv].bo, ginfo[toplv].nx, ginfo[toplv].ny, ginfo[toplv].nz, ginfo[toplv]);
			residue (&ginfo[toplv].res, &ginfo[toplv].ressize, ginfo[toplv].p, ginfo[toplv].a, ginfo[toplv].rhs, ginfo[toplv].bl, ginfo[toplv].br, ginfo[toplv].bb, ginfo[toplv].bf, ginfo[toplv].bu, ginfo[toplv].bo, ginfo[toplv].nx, ginfo[toplv].ny, ginfo[toplv].nz);
			topnrm = normres (ginfo[toplv].res, ginfo[toplv].rhs, ginfo[toplv].a, ginfo[toplv].nx, ginfo[toplv].ny, ginfo[toplv].nz);
		}while (fabs(oldtopnrm-topnrm)*2 >= maxres && toprep++ < 7);

		
		//up the V cycle
		for (lv=toplv-1; lv>=0; lv--)
		{
			interpolate (lv+1, &ginfo[lv].res, ginfo[lv+1].p, &ginfo[lv].ressize, ginfo[lv+1].nx, ginfo[lv+1].ny, ginfo[lv+1].nz);
			for (int i=0;i<ginfo[lv].nx*ginfo[lv].ny*ginfo[lv].nz; i++)
				ginfo[lv].p[i] += ginfo[lv].res[i];
			for (it=0;it<npost;it++)
				gs (ginfo[lv].p, ginfo[lv].rhs, ginfo[lv].a, ginfo[lv].bl, ginfo[lv].br, ginfo[lv].bb, ginfo[lv].bf, ginfo[lv].bu, ginfo[lv].bo, ginfo[lv].nx, ginfo[lv].ny, ginfo[lv].nz, ginfo[lv]);	
		}
	}

}

void mg(double *p, double *rhs, double *a, double *bl, double *br, double *bb, double *bf, double *bu, double *bo )
{
	//solve matrix equation 
	// div (grad p / rho) = rhs.
	//a,bl,br,bb,bf,bu,bo are coefficents.
	//solve for p.

	//p is ignored. it is *not* an initial guess.

	//calculate coefficients for all levels...
	int level=0;
	int it;

	//Set level 0 (fine grid) storage to be externally-provided memory.
	ginfo[0].a  = a;
	ginfo[0].bl = bl;
	ginfo[0].br = br;
	ginfo[0].bb = bb;
	ginfo[0].bf = bf;
	ginfo[0].bu = bu;
	ginfo[0].bo = bo;
	ginfo[0].rhs = rhs;
	ginfo[0].p = p;
	ginfo[0].nx = NX;
	ginfo[0].ny = NY;
	ginfo[0].nz = NZ;
	ginfo[0].asize = NX*NY*NZ*sizeof(double);	//assume supplied buffers are ok.
	ginfo[0].blsize = NX*NY*NZ*sizeof(double);
	ginfo[0].brsize = NX*NY*NZ*sizeof(double);
	ginfo[0].bbsize = NX*NY*NZ*sizeof(double);
	ginfo[0].bfsize = NX*NY*NZ*sizeof(double);
	ginfo[0].busize = NX*NY*NZ*sizeof(double);
	ginfo[0].bosize = NX*NY*NZ*sizeof(double);
	ginfo[0].rhssize = NX*NY*NZ*sizeof(double);
	ginfo[0].psize = NX*NY*NZ*sizeof(double);

	//get coefficients and rhs for all coarse grids.
	bool r=true;
	while (r)
	{
		r=restrictcoef (level, ginfo[level].nx, ginfo[level].ny, ginfo[level].nz);
		restrict (level, &ginfo[level+1].rhs, ginfo[level].rhs, &ginfo[level+1].rhssize, ginfo[level].nx, ginfo[level].ny, ginfo[level].nz);
		if (r) level++;
	}
	//make sure p(coarsest) is allocated and big enough.
	resize (&ginfo[level].p, &ginfo[level].psize, ginfo[level].nx*ginfo[level].ny*ginfo[level].nz*sizeof(double));
	memset (ginfo[level].p, 0, ginfo[level].nx*ginfo[level].ny*ginfo[level].nz*sizeof(double));
	//level is set to the index of the top level.
	int toplv = level;
	for (it=0;it<ntop;it++)
		gs(ginfo[toplv].p, ginfo[toplv].rhs, ginfo[toplv].a, ginfo[toplv].bl, ginfo[toplv].br, ginfo[toplv].bb, ginfo[toplv].bf, ginfo[toplv].bu, ginfo[toplv].bo, ginfo[toplv].nx, ginfo[toplv].ny, ginfo[toplv].nz, ginfo[toplv]);

	for (int lv = toplv-1; lv >= 0; lv--)
	{
		//Interpolate coarse grid solution to current grid.
		interpolate (lv+1, &ginfo[lv].p, ginfo[lv+1].p, &ginfo[lv].psize, ginfo[lv+1].nx, ginfo[lv+1].ny, ginfo[lv+1].nz);

		//relax interpolated solution
		for (it=0;it<npost;it++)
			gs(ginfo[lv].p, ginfo[lv].rhs, ginfo[lv].a, ginfo[lv].bl, ginfo[lv].br, ginfo[lv].bb, ginfo[lv].bf, ginfo[lv].bu, ginfo[lv].bo, ginfo[lv].nx, ginfo[lv].ny, ginfo[lv].nz, ginfo[lv]);

		//V cycles within fixed V level.
		for (int itcycle = 0; itcycle < mgcycles; itcycle++)
		{
			//down the V cycle.
			int lv2;
			for (lv2=lv; lv2<toplv; lv2++)
			{
				//relax first
				for (it=0;it<npre;it++)
					gs(ginfo[lv2].p, ginfo[lv2].rhs, ginfo[lv2].a, ginfo[lv2].bl, ginfo[lv2].br, ginfo[lv2].bb, ginfo[lv2].bf, ginfo[lv2].bu, ginfo[lv2].bo, ginfo[lv2].nx, ginfo[lv2].ny, ginfo[lv2].nz, ginfo[lv2]);

				//take the residue...
				residue (&ginfo[lv2].res, &ginfo[lv2].ressize, ginfo[lv2].p, ginfo[lv2].a, ginfo[lv2].rhs, ginfo[lv2].bl, ginfo[lv2].br, ginfo[lv2].bb, ginfo[lv2].bf, ginfo[lv2].bu, ginfo[lv2].bo, ginfo[lv2].nx,ginfo[lv2].ny, ginfo[lv2].nz);

				//restrict the residue and place it as the rhs of the coarse grid.
				restrict (lv2, &ginfo[lv2+1].rhs, ginfo[lv2].res, &ginfo[lv2+1].rhssize, ginfo[lv2].nx, ginfo[lv2].ny, ginfo[lv2].nz);

				//set initial guess for coarse grid to be 0.
				memset (ginfo[lv2+1].p, 0, ginfo[lv2+1].nx*ginfo[lv2+1].ny*ginfo[lv2+1].nz*sizeof(double));
			}

			//at coarsest grid. Solve. (i.e. GS-solve until change in residue small enough.)
			double topnrm=0.0, oldtopnrm=0.0;
			int toprep=0;	//limit the number of iterations.
			do
			{
				oldtopnrm = topnrm;
				for (it=0;it<ntop;it++)
					gs(ginfo[toplv].p, ginfo[toplv].rhs, ginfo[toplv].a, ginfo[toplv].bl, ginfo[toplv].br, ginfo[toplv].bb, ginfo[toplv].bf, ginfo[toplv].bu, ginfo[toplv].bo, ginfo[toplv].nx, ginfo[toplv].ny, ginfo[toplv].nz, ginfo[toplv]);
				residue (&ginfo[toplv].res, &ginfo[toplv].ressize, ginfo[toplv].p, ginfo[toplv].a, ginfo[toplv].rhs, ginfo[toplv].bl, ginfo[toplv].br, ginfo[toplv].bb, ginfo[toplv].bf, ginfo[toplv].bu, ginfo[toplv].bo, ginfo[toplv].nx, ginfo[toplv].ny, ginfo[toplv].nz);
				topnrm = normres (ginfo[toplv].res, ginfo[toplv].rhs, ginfo[toplv].a, ginfo[toplv].nx, ginfo[toplv].ny, ginfo[toplv].nz);
			}while (fabs(oldtopnrm-topnrm)*2 >= maxres && toprep++ < 7);

			//up the V cycle.
			for (lv2=toplv-1; lv2>=lv; lv2--)
			{
				//use residue as temporary. Add solution on coarse grid to the solution of the next finer grid.
				interpolate (lv2+1, &ginfo[lv2].res, ginfo[lv2+1].p, &ginfo[lv2].ressize, ginfo[lv2+1].nx, ginfo[lv2+1].ny, ginfo[lv2+1].nz);

				for (int i=0;i<ginfo[lv2].nx*ginfo[lv2].ny*ginfo[lv2].nz; i++)
					ginfo[lv2].p[i] += ginfo[lv2].res[i];

				//relax the finer grid after interpolated solution-to-residue is added.
				for (it=0;it<npost;it++)
					gs(ginfo[lv2].p, ginfo[lv2].rhs, ginfo[lv2].a, ginfo[lv2].bl, ginfo[lv2].br, ginfo[lv2].bb, ginfo[lv2].bf, ginfo[lv2].bu, ginfo[lv2].bo, ginfo[lv2].nx, ginfo[lv2].ny, ginfo[lv2].nz, ginfo[lv2]);
			}
		}
	}
}
