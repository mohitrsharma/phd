#include "ripple.h"
#include <math.h>
#include "testing.h"
#include <stdlib.h>

/******************************************************************************
This subroutine DIFFUSION solves for the diffusion part of the energy equation

Subroutine DIFFUSION is called by:	RIPPLE
	
Subroutine DIFFUSION calls:   ENTHTMP, BCE

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

- Created this subroutine							Babak		May 15 2009


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

void diffusion()
{
	double disl, disr, disb, dist, disu, diso;
	double aml, amr, amb, amt, amu, amo, ap;
	int i,j,k;

	for (i=1;i<im1;i++)
		for (j=1;j<jm1;j++)
			for (k=1;k<km1;k++)
			{

				//Distance to the neighboring cell centers

				disl = fabs(xi[i]-xi[i-1]);		//Left
				disr = fabs(xi[i]-xi[i+1]);		//Right
				disb = fabs(yj[j]-yj[j-1]);		//Bottom
				dist = fabs(yj[j]-yj[j+1]);		//Top
				disu = fabs(zk[k]-zk[k-1]);		//Under
				diso = fabs(zk[k]-zk[k+1]);		//Over

				//Calculating the diffusion coefficients of the energy equation

				aml = kface(IJK,IMJK)*dely[j]*delz[k]/disl;
				amr = kface(IJK,IPJK)*dely[j]*delz[k]/disr;
				amb = kface(IJK,IJMK)*delx[i]*delz[k]/disb;
				amt = kface(IJK,IJPK)*delx[i]*delz[k]/dist;
				amu = kface(IJK,IJKM)*delx[i]*dely[j]/disu;
				amo = kface(IJK,IJKP)*delx[i]*dely[j]/diso;
					
				ap = delt/(rho[IJK]*delx[i]*dely[j]*delz[k]);

				//Updating the enthalpy field

				h[IJK] = hn[IJK]+ap*(aml*(hn[IMJK]/cp[IMJK]-hn[IJK]/cp[IJK])+
						amr*(hn[IPJK]/cp[IPJK]-hn[IJK]/cp[IJK])+
						amb*(hn[IJMK]/cp[IJMK]-hn[IJK]/cp[IJK])+
						amt*(hn[IJPK]/cp[IJPK]-hn[IJK]/cp[IJK])+
						amu*(hn[IJKM]/cp[IJKM]-hn[IJK]/cp[IJK])+
						amo*(hn[IJKP]/cp[IJKP]-hn[IJK]/cp[IJK]));
			}

	enthtmp();
	bce();

}
