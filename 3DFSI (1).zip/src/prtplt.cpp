#include "ripple.h"

/******************************************************************************
This subroutine writes cycle data to an out file for tracking

Subroutine PRTPLT is called by:	NEWCYC

Subroutine PRTPLT calls:			

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

-Created this template for tracking changes			Ben			April 21 2005


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

void prtplt(int n)
{
	//prtplt(1) - write time step, cycle information
	if (n==1)
	{
		fprintf (files.out, "cycle=%5d, time=%11.5e, dt %2s(%3d,%3d,%3d)=%11.5e, iter=%4d,\n", ncyc, t, idt, itc, jtc, ktc, delt, iter);
		fprintf (files.out, "fluid vol=%11.5e, vchgt=%12.5e,\n  xmom=%12.5e, ymom=%12.5e, zmom=%12.5e, total ke=%12.5e\n",fvol, vchgt, xmv, ymv, zmv, tke);
		return;
	}
	else if (n==2)

	//prtplt(2) - write field variables
	{
		//fprintf (files.out,"  dim.nx = %3d  dim.ny = %3d\n", dim.nx, dim.ny);

/*		fprintf (files.out,"  tauxz        tauyz\n");
		
		for ( int i = 0; i < imax; i++ )
		{
			for ( int j = 0; j < jmax; j++ )
			{
				for ( int k = 0; k < 2; k++ )
				{
					if ( f[IJK] > em6 )
					{
						fprintf( files.out, "%12.4e  %12.4e\n", tauxz[IJK], tauyz[IJK] );
					}
				}
				fprintf(files.out, "\n");
			}
			fprintf(files.out, "\n");
		}
*/	



		fprintf (files.out,"  I   J   K	  U            V            W            F            AC            P\n");
		
		for (int i = 0; i < imax; i++)
		{	
			for (int j = 0; j < jmax; j++)
			{
				for(int k = 0; k < kmax ; k++)
				{
					fprintf(files.out, "%3d %3d %3d %12.4e %12.4e %12.4e %12.4e %12.4e %12.4e\n", i, j, k, u[IJK], v[IJK], w[IJK],
							f[IJK], ac[IJK], p[IJK]);
				}
				fprintf(files.out, "\n");	
			}
			fprintf(files.out, "\n");
		}
	}
}	

/*		for (int j = 0; j < 12; j++)
		{
			for (int k = 0; k < 7; k++)
			{
				for (int i = 0; i < 3; i++)
				{
					fprintf(files.out, "%3d %3d %3d %12.4e %12.4e %12.4e %12.4e		YZ PLANE\n", i, j, k, u[IJK], v[IJK], w[IJK], f[IJK]);
				}
				fprintf(files.out, "\n");
			}
			fprintf(files.out, "\n");
		}
*/	

/*		int i,j,k;
		for (k=1;k<km1;k++)
			for (i=1;i<im1;i++)
				for (j=1;j<jm1;j++)
				{
					if (f[IJK] < em6 || ac[IJK] < em6) continue;
					double div=(rdx[i]*(ar[IJK]*u[IJK]-ar[IMJK]*u[IMJK])
						+rdy[j]*(at[IJK]*v[IJK]-at[IJMK]*v[IJMK])
						+rdz[k]*(ao[IJK]*w[IJK]-ao[IJKM]*w[IJKM]))/ac[IJK];
					
					fprintf (files.out, "%3d %4i %4i %4i %12.4e %12.4e %12.4e %12.4e %12.4e %12.4e\n", i,j,k, nf[IJK], u[IJK], v[IJK], w[IJK], p[IJK], f[IJK], div);
				}
		fprintf (files.out, "\n");
		return;
*/
	

