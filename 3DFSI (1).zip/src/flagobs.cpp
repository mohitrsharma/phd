#include <stdio.h>
#include "ripple.h"
#include "testing.h"

void flagobs()
{
    /*
	 * This subroutine flags obstacle surface cells as being on the left, right, back etc.,
     * side of the fluid cell. There is currently no conflict resolution in case flid is on
     * two sides of the obstacle cell.
     */
	int i,j,k;

	/*Initialize all flags of struct obst to false*/
	for (i = 0; i < NX*NY*NZ; i++)
	{
		obst[i].flag_r = false;
		obst[i].flag_l = false;
		obst[i].flag_f = false;
		obst[i].flag_b = false;
		obst[i].flag_o = false;
		obst[i].flag_u = false;
	}

	/*identify each obstacle sufrace cell and its orientation to the fluid*/
	for (k = 1; k < km1; k++)
		for (j = 1; j < jm1; j++)
			for (i = 1; i < im1; i++)
			{
				if (isobstsfc(IJK))      /*check if cell IJK is obstacle surface cell*/
				{
					if (ac[IMJK] == 1)              /*If obstacle cell is to the right*/
						obst[IJK].flag_r = true;

                    if (ac[IPJK] == 1)              /*If obstacle cell is to the left*/
						obst[IJK].flag_l = true;

                    if (ac[IJMK] == 1)              /*If obstacle cell is to the front*/
						obst[IJK].flag_f = true;

                    if (ac[IJPK] == 1)              /*If obstacle cell is to the back*/
						obst[IJK].flag_b = true;

                    if (ac[IJKM] == 1)              /*If obstacle cell is over fluid cell*/
						obst[IJK].flag_o = true;

                    if (ac[IJKP] == 1)              /*If obstacle cell is under fluid cell*/
						obst[IJK].flag_u = true;
				}
			}
}
