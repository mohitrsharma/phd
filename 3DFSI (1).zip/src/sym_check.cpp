#include "ripple.h"
#include "math.h"

void sym_check(void)
{
	/*this subroutine checks the symmetry of various variables in a domain across
	XZ and XY planes


	*/
    
	double usym, vsym, wsym, fsym, psym;
	int ijusym, ijvsym, ijwsym, ijfsym, ijpsym, iju, ijv, ijw, ijf, ijp;
    int i, j, k, ijsym;
	
	usym = vsym = wsym = fsym = psym = 0.0;

	/*XZ plane symmetry check*/
	for(k = 1; k < km1; k++)
		for(j = 1; j < jmax / 2; j++)
			for(i = 1; i < im1; i++)
			{
               ijsym = IND(i, jm1 - j, k);

			   psym = MAX(psym, fabs(p[IJK] - p[ijsym]));
			   if(psym == fabs(p[IJK] - p[ijsym]))
			   {
				   ijpsym = ijsym;
				   ijp = IJK;
			   }
			   fsym = MAX(fsym, fabs(f[IJK] - f[ijsym]));
			   if(fsym == fabs(f[IJK] - f[ijsym]))
			   {
				   ijfsym = ijsym;
				   ijf = IJK;
			   }
			   usym = MAX(usym, fabs(u[IJK] - u[ijsym]));
			   if(usym == fabs(u[IJK] - u[ijsym]))
			   {
				   ijusym = ijsym;
				   iju = IJK;
			   }
			   vsym = MAX(vsym, fabs(v[IJK] - v[ijsym - imax]));
			   if(vsym == fabs(v[IJK] - v[ijsym - imax]))
			   {
				   ijvsym = ijsym - imax;
				   ijv = IJK;
			   }
			   wsym = MAX(wsym, fabs(w[IJK] - w[ijsym]));
			   if(wsym == fabs(w[IJK] - w[ijsym]))
			   {
				   ijwsym = ijsym;
				   ijw = IJK;
			   }
			}
	printf("\t\t\tXZ PLANE OF SYMETRY IN X-DIR\n");
    printf("ncyc = %8d \n", ncyc);
	printf("psym = %10.2e, ijp = %4d <-> %4d\n", psym, ijp, ijpsym);
	printf("fsym = %10.2e, ijf = %4d <-> %4d\n", fsym, ijf, ijfsym);
	printf("usym = %10.2e, iju = %4d <-> %4d\n", usym, iju, ijusym);
	printf("vsym = %10.2e, ijv = %4d <-> %4d\n", vsym, ijv, ijvsym);
	printf("wsym = %10.2e, ijw = %4d <-> %4d\n", wsym, ijw, ijwsym);

	/*XY plane symmetry check*/
	/*usym = vsym = wsym = fsym = psym = 0.0;

	for(k = 1; k < kmax / 2; k++)
		for(j = 1; j < jm1; j++)
			for(i = 1; i < im1; i++)
			{
               ijsym = IND(i, j, km1 -k);

			   psym = MAX(psym, fabs(p[IJK] - p[ijsym]));
			   if(psym == fabs(p[IJK] - p[ijsym]))
			   {
				   ijpsym = ijsym;
				   ijp = IJK;
			   }
			   fsym = MAX(fsym, fabs(f[IJK] - f[ijsym]));
			   if(fsym == fabs(f[IJK] - f[ijsym]))
			   {
				   ijfsym = ijsym;
				   ijf = IJK;
			   }
			   usym = MAX(usym, fabs(u[IJK] - u[ijsym]));
			   if(usym == fabs(u[IJK] - u[ijsym]))
			   {
				   ijusym = ijsym;
				   iju = IJK;
			   }
			   vsym = MAX(vsym, fabs(v[IJK] - v[ijsym]));
			   if(vsym == fabs(v[IJK] - v[ijsym]))
			   {
				   ijvsym = ijsym;
				   ijv = IJK;
			   }
			   wsym = MAX(wsym, fabs(w[IJK] - w[ijsym - ijmax]));
			   if(wsym == fabs(w[IJK] - w[ijsym - ijmax]))
			   {
				   ijwsym = ijsym -ijmax;
				   ijw = IJK;
			   }
			}
	printf("\t\t\tXY PLANE OF SYMETRY IN X-DIR\n");
    	printf("ncyc = %8d \n", ncyc);
	printf("psym = %10.2e, ijp = %4d <-> %4d\n", psym, ijp, ijpsym);
	printf("fsym = %10.2e, ijf = %4d <-> %4d\n", fsym, ijf, ijfsym);
	printf("usym = %10.2e, iju = %4d <-> %4d\n", usym, iju, ijusym);
	printf("vsym = %10.2e, ijv = %4d <-> %4d\n", vsym, ijv, ijvsym);
	printf("wsym = %10.2e, ijw = %4d <-> %4d\n", wsym, ijw, ijwsym);*/
	
}
