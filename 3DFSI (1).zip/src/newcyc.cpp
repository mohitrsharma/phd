#include "ripple.h"
#include "comm.h"
#include <string.h>
#include "testing.h"
#include <stdlib.h>//system

/******************************************************************************


Subroutine NEWCYC is called by:	RIPPLE

Subroutine NEWCYC calls:	DELDTADJ, DUMP, GLOBAL, PRTPLT, TECPF, TECPO

____________________________NOTES ON CNAGES____________________________________

Whoever edits this file please write a short description of the change bellow.
KEEP MOST RECENT CHANGES AT THE TOP OF THE LIST.  Also please put comments
at places in the code where changesa are made


DESCRIPTION											NAME		DATE

- Turned off VOF function convection limit			S.Codyer	April 10 2012

- Enthalpy and temperature arrays are added to		Babak		May 15 2009
  the store list.
  
- A new method implemented to compress dump and     Babak       October 23 2008
  RBD files into a single file.


_________________________________TO DO LIST____________________________________

DESCRIPTION											NAME		DATE


*******************************************************************************/

bool newcyc()
{

	//If VOF function convection limit exceeded, decrease the timestep and try again.
	if (flgc <= 0.5)
	{

		//Generating graphics
		if (t >= twplt - delt/4.0)
		{
			twplt += pltdt;
#ifdef fine_plt
			p_flg = 1;
#endif
#ifndef fine_plt
			tecpf();						//Store results in RBD files

            //Zip RBD files after calling tecpf()
			if(mpi.MyRank == 0)				
			{	
				//FILE *fplot;
				//fplot=fopen("list_iplot","a+");
				//fprintf(fplot,"f%03d-*-%04d.rbd\n",mpi.NProc,iplot-1);
				//fclose(fplot);
				
				printf("Compressing stnd grid RBD files...\n");
				char command[50];
				//sprintf(command, "zip -qm -1 F%03d-%04d.gz f%03d-*-%04d.rbd &", mpi.NProc, iplot, mpi.NProc, iplot);
				sprintf(command, "gzip f%03d-*-%04d.rbd &", mpi.NProc,iplot);
				system(command);
			}
#endif

		}
		static bool once = false;
		//Writing dump files 
		if (t >= twdmp - delt/2.0)
		{
			twdmp += dmpdt;
			dump();						//Dump data to a dump file								
			//Zip dump files after calling dump()
			if(mpi.MyRank == 0)				
			{
				//FILE *fplot;
				//fplot=fopen("list_idump","a+");
				//fprintf(fplot,"dump-*-%03d\n",idump-1);
				//fclose(fplot);
				printf("Compressing dump files...\n");
				char command[50];
				//sprintf(command, "zip -qm -1 Dump-%03d.gz dump-*-%03d &", idump, idump);
				sprintf(command, "gzip dump-*-%03d &", idump);
				system(command);
			}
		}
		else if (wtime() >= 169200000 && once == false)
		{
			once = true;
			twdmp += dmpdt;
			dump();						//Dump data to a dump file								
			//Zip dump files after calling dump()
			if(mpi.MyRank == 0)				
			{
				//FILE *fplot;
				//fplot=fopen("list_idump","a+");
				//fprintf(fplot,"dump-*-%03d\n",idump-1);
				//fclose(fplot);
				printf("Compressing dump files...\n");
				char command[50];
				//sprintf(command, "zip -qm -1 Dump-%03d.gz dump-*-%03d &", idump, idump);
				sprintf(command, "gzip dump-*-%03d &", idump);
				system(command);
			}
		}

		//Check to see if problem finish time surpassed
		if (t >= twfin)
		{
			//Normal termination (t > twfin)
			fprintf (files.summary, "* * * * Normal Termination * * * *\n");
			if (mpi.MyRank == 0)
				printf("* * * * Normal Termination * * * * twfin=%e\n",twfin);
			return true;
		}

		//Set advance time arrays into the time-n arrays
		memcpy (un, u, NX*NY*NZ*sizeof(double));
		memcpy (vn, v, NX*NY*NZ*sizeof(double));
		memcpy (wn, w, NX*NY*NZ*sizeof(double));
		memcpy (pn, p, NX*NY*NZ*sizeof(double));
#ifndef rudman_fine
		memcpy (FN, f, NX*NY*NZ*sizeof(double));
		memcpy (fn, f, NX*NY*NZ*sizeof(double));
#endif

#ifdef rudman_fine
		memcpy (FN_f, f_f, NX_f*NY_f*NZ_f*sizeof(double));
		memcpy (fn_f, f_f, NX_f*NY_f*NZ_f*sizeof(double));
#ifdef __solid
		memcpy (PSIN_f, psi_f, NX_f*NY_f*NZ_f*sizeof(double));
		memcpy (psin_f, psi_f, NX_f*NY_f*NZ_f*sizeof(double));
		int i;
		for(i=1;i<=NBODY;i++) equate_pt(&Omegan[i],&Omega[i]);
		for(i=1;i<=NBODY;i++) memcpy(rig_Un[i],rig_U[i],4*sizeof(double));
#endif
#endif	
		
		if (ENERGY)
		{
			memcpy (hn, h, NX*NY*NZ*sizeof(double));
			memcpy (tmpn, tmp, NX*NY*NZ*sizeof(double));
		}

	}/* if (flgc <= 0.5) */

#ifndef pres_v
	if(DELTADJ || flgc > 0.5) deltadj();	/* Adjust and advance the time step.  Restores previous  
	                                  			 * Values if VOF convection limit exceeded (flgc > 0.5) */
#endif

	t += delt;
	double t_temp = t;
	bcastdata(&t_temp, sizeof(double));
	if (t != t_temp)
	{
		fprintf (files.summary, "Time out of sync between processors. Time at root=%14.6e, Local time=%14.6e\n",t_temp, t);
	}

	//Check for VOF function convection limit: terminate if it has been exceeded.
	/*
	if (nflgc >= 100)
	{
		//Exit froom newcyc and terminate
		fprintf (files.summary, "too many vofadv failures   ncyc=%7d, t=%14.6e\n", ncyc, t);
		return true;
	}
	*/

	//Check for pressure convergence failure, terminate if number of failed cycles (nocon) is nonzero
	if (nocon >= 0.5)
	{
		//Exit from newcyc and terminate
		fprintf (files.summary, "too many pressit failures   ncyc=%7d, t=%14.6e\n", ncyc, t);
		return true;
	}

	//Everything ok, advance cycle
	ncyc++;

	if (delt <= dtend && deltold <= 0)
	{
		fprintf (files.summary, "delt less than dtend on cycle %6d, t=%12.5e\n", ncyc, t);
		twfin=t*0.999;	//Force quit next iteration.
	}

	iter = 0;
	//bar();
	//if(mpi.MyRank==0) {
		//printf("exiting after initialization\n");
		//exit(1);
	//}
	//bar();
	return false;
}
