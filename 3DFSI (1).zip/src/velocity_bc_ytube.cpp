#include "ripple.h"
#include <math.h>
#include <string.h>
#include <stdlib.h> //exit
#include "testing.h"

void ytube_bc()
{

/////////////////////////////////////////////////////////////////////////////////////////////////
//Velocity BOundary Condition for ytube simulation
	
	int i,j,k;
	
	double right_face = floor((( 21.e-3)/delx[1]));
	double left_face = floor((( 14.e-3)/delx[1]));
	double over_face = floor(((25.e-3)/delx[1]));
	double under_face = floor(((20.e-3)/delx[1]));
	double top_face = floor(((8.e-3)/delx[1]));
	double bottom_face = floor(((3.e-3)/delx[1]));
	
	int r_f = ((int)right_face) +1;
	int o_f = ((int)over_face) +1;
	int under_f = ((int)under_face) +1;
	int l_f = ((int)left_face) +1;
	int t_f = ((int)top_face) +1;
	int b_f = ((int)bottom_face) +1;

///////////////////////////////////////////////////////////////////////////////////////////
//for Ytube
				for(k=under_f;k<o_f;k++)
					for(j=b_f;j<t_f;j++)
						for(i=l_f;i<r_f;i++) 
						{
							w[IJK]=-0.02;
							wn[IJK]=-0.02;
						}
////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////

}

void ytube_bc2()
{
	
	int i,j,k, m;
	double tx, ty, tz, txm, tym, tzm; //temporary x,y,z of ijk
	double xcent, ycent, zcent;

	double *fmz = temp[17];
#ifdef __solid
	double *psimz = temp[23];
#endif
	
	double r2 = (parent_radius)*(parent_radius); // Cylinder Radius
	double rl = (parent_radius - 0.2625e-3)*(parent_radius - 0.2625e-3); // Radius of Film
	
	double velocity = -0.02;
	
	xcent = x_carina;
	ycent = ye/2;
	zcent = z_upper_bound; // Upper Bound on Y_tube - z3 + h3

	m = (zcent/delz[1]);

	//loop that initialized the f field of a droplet
	for (k=1; k<=km1; k++)
		for (j=1; j<jm1; j++)
			for (i=1; i<im1; i++)
			{
				//cell is empty?
				tx = x[i];
				ty = y[j];
				tz = z[k];
				txm = x[i-1];
				tym = y[j-1];					
				tzm = z[k-1];
				
				if ( MIN(SQUARE(txm-xcent), SQUARE(tx-xcent)) + MIN(SQUARE(tym-ycent), SQUARE(ty-ycent)) <= r2 && psimz[IJK] < em6 && fabs(tz-zcent) <= 5*delz[1] && tz<=zcent ) // Do not give velocity in solid momentum C.V.
				{
					u[IJK] = 0;
					v[IJK] = 0;
					w[IJK] = velocity;	// How many layers of this boundary do I want?
				}
			}
		
	// Need Boundary Condition for fluid now
//	for(int i=1; i<im1_f; i++)                                 
//		for(int j=1; j<jm1_f; j++)
//			for(int k=1; k<km1_f; k++)
//			{
//				if(ytubef_field[IJK_f] > em6)
//				{
//					f_f[IJK_f] = ytubef_field[IJK_f]; 
//				}
//			}
//	fine2stnd();
}

void ytube_bc3()
{
	int i,j,k, m, l;
	double tx, ty, tz, txm, tym, tzm; //temporary x,y,z of ijk
	double xcent, ycent, zcent;

	double *fmz = temp[17];
#ifdef __solid
	double *psimx = temp[21];
	double *psimy = temp[22];
	double *psimz = temp[23];
#endif
	
	double r2 = (parent_radius)*(parent_radius); // Cylinder Radius
	double rl = (parent_radius - film_thickness)*(parent_radius - film_thickness); // Radius of Film
	
	double w_avg = -0.16;
	
	xcent = x_carina;
	ycent = ye/2;
	zcent = z_upper_bound + delx[1]; // Upper Bound on Y_tube - z3 + h3
	
	l = km1 - 5;
	
	for (k=l;k<km1;k++)
		for (j=1;j<jm1;j++)
			for (i=1;i<im1;i++)
			{	
				tx = (i+mpi.OProc[0])*delx[1] - 0.5*delx[1]; //global coordinates in coarse-grid
				ty = (j+mpi.OProc[1])*dely[1] - 0.5*dely[1];
				tz = (k+mpi.OProc[2])*delz[1];
				
				if ( SQUARE(tx-xcent) + SQUARE(ty-ycent) <= r2 && psimz[IJK] < em6 && fabs(tz-zcent) <= (3)*delz[1] && tz<=zcent && (1 - f[IJK]) > 0.5)
				{
					u[IJK] = 0.0;
					v[IJK] = 0.0;
					w[IJK] = 2*w_avg*(1 - ( SQUARE(tx-xcent) + SQUARE(ty-ycent) ) / r2 );
				}
				else if (SQUARE(tx-xcent+delx[1]) + SQUARE(ty-ycent+delx[1]) <= r2 && fabs(tz-zcent) <= (3)*delz[1] && tz<=zcent)
				{
					u[IJK] = 0.0;
					v[IJK] = 0.0;
				}
			}
}
