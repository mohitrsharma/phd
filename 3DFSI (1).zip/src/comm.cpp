//All interprocessor communications are done using calls to routines in this function.
//It should be possible to replace MPI with another message passing library by reimplementing
//comm.cpp, but it may be difficult to emulate MPI behaviour.
#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <math.h>
#include <string.h>
#include "comm.h"
#include "ripple.h"
#include "vector.h"
#include "size_defs.h"		/* Contains MPI size params read in from
							* input file by setup.py */

//MAXSBUF controls how many 'in-flight' send opreations
//are allowed. Excess sends are blocked until older sends have completed.
//This may cause communications to deadlock when sending data out of order.
#define MAXSBUF (32)

static unsigned long sbufsize[MAXSBUF]={0};
static char* sbuffer[MAXSBUF]={0};
static MPI_Request smpirq[MAXSBUF];	//send MPI_Request array to save status of in-flight sends.
static long sbufp=0;	//pointer to current location in buffer arrays.
//Buffer for recvspace (synchronous)
static unsigned long bufsize;
static char* buffer;


//instantiate template functions
//  if the linker complains of unresolved external for a template function defined above, make sure there is an instance of it.
template void sendplane (double*, const int&);
template void sendplane (int*, const int&);
template void sendplane (Vector*, const int&);
template void arecvplane (double*, const int&);
template void arecvplane (int*, const int&);
template void arecvplane (Vector*, const int&);
template int arecvspace (double*, const int&, const int&, const int&, const int&, const int&, const int&, const int&, const int&, const int&, const int&, const int&);
template int arecvspace (int*, const int&, const int&, const int&, const int&, const int&, const int&, const int&, const int&, const int&, const int&, const int&);
template int arecvspace (Vector*, const int&, const int&, const int&, const int&, const int&, const int&, const int&, const int&, const int&, const int&, const int&);
template void sendplanen (double*, const int&, int[], const int&, const int&, const int&);
template void sendplanen (Vector*, const int&, int[], const int&, const int&, const int&);
template void arecvplanen (double*, const int&, int[], const int&, const int&, const int&);
template void arecvplanen (Vector*, const int&, int[], const int&, const int&, const int&);
template void sendspace (double*, const int&, const int&, const int&, const int&, const int&, const int&, const int&, const int&, const int&, const int&, const int&);
template void sendspace (int*, const int&, const int&, const int&, const int&, const int&, const int&, const int&, const int&, const int&, const int&, const int&);
template void sendspace (Vector*, const int&, const int&, const int&, const int&, const int&, const int&, const int&, const int&, const int&, const int&, const int&);
template void recvspace (int*, const int&, const int&, const int&, const int&, const int&, const int&, const int&, const int&, const int&, const int&, const int&);

#ifdef rudman_fine
	template void sendplane_f (double*, const int&);
	template void sendplane_f (int*, const int&);
	template void sendplane_f (Vector*, const int&);
	template void arecvplane_f (double*, const int&);
	template void arecvplane_f (int*, const int&);
	template void arecvplane_f (Vector*, const int&);
	template void sendplane2 (double*,double*,double*, const int&);
	template void sendplane2 (int*,int*,int*, const int&);
	template void sendplane2 (Vector*,Vector*,Vector*, const int&);
	template void arecvplane2 (double*, const int&);
	template void arecvplane2 (int*, const int&);
	template void arecvplane2 (Vector*, const int&);
//#ifdef __solid
	template void sendplane2_f (double*,double*,double*, const int&);
	template void sendplane2_f (int*,int*,int*, const int&);
	template void sendplane2_f (Vector*,Vector*,Vector*, const int&);
	template void arecvplane2_f (double*, const int&);
	template void arecvplane2_f (int*, const int&);
	template void arecvplane2_f (Vector*, const int&);
//#endif
#endif

#ifdef bl_mg
template void sendplane_lev(const int&, double*, const int&);
template void sendplane_lev(const int&, int*, const int&);
template void sendplane_lev(const int&, Vector*, const int&);
template void arecvplane_lev(const int&, double*, const int&);
template void arecvplane_lev(const int&, int*, const int&);
template void arecvplane_lev(const int&, Vector*, const int&);
#endif

void bar () 
{
	MPI_Barrier(MPI_COMM_WORLD);
}


void initmpi (int argc, char *argv[])
{
	//Must be called before any MPI routines are called.
	MPI_Init((int*)&argc, (char***)&argv);

	//Allocate buffer for message passing
	MPI_Buffer_attach ( malloc (16777216), 16777216);
	MPI_Comm_size (MPI_COMM_WORLD, &mpi.NProc);
	MPI_Comm_rank (MPI_COMM_WORLD, &mpi.MyRank);

	//Create Cartesian topology.
	creatempitopology();
}
void cleanupmpi()
{
	//must be called before program ends. No more MPI calls can be made after
	//this routine is called.
	MPI_Finalize();
}
void adjustdims ()
{
	//given dim.fx/fy/fz, calculate initial dim.nx/ny/nz

	int dims[3],p[3],c[3];
	MPI_Cart_get ((MPI_Comm)mpi.COMM_CART, 3, dims, p, c);

	dim.nx = (dim.fx)/dims[0];
	dim.ny = (dim.fy)/dims[1];
	dim.nz = (dim.fz)/dims[2];

/*	//Restrict individual processor grid dimensions to be powers of two;
	//Find value for nx/ny/nz to the nearest power of two.
	dim.nx = 1 << (int)floor(log(dim.nx)/log(2)+0.5);
	dim.ny = 1 << (int)floor(log(dim.ny)/log(2)+0.5);
	dim.nz = 1 << (int)floor(log(dim.nz)/log(2)+0.5);

	//change fx/fy/fz to match adjusted nx/ny/nz.
	dim.fx = (dim.nx)*dims[0] +2;
	dim.fy = (dim.ny)*dims[1] +2;
	dim.fz = (dim.nz)*dims[2] +2;
*/
	dim.nx += 2;
	dim.ny += 2;
	dim.nz += 2;

	mpi.OProc[0] = c[0]*(dim.nx-2);
	mpi.OProc[1] = c[1]*(dim.ny-2);
	mpi.OProc[2] = c[2]*(dim.nz-2);
	if (mpi.MyRank ==0)
	{
		printf ("Global dimensions: %d, %d, %d\n", dim.fx + 2, dim.fy + 2, dim.fz +
		2);
		printf ("%d: Local dimensions: %d, %d, %d\n", mpi.MyRank, dim.nx, dim.ny, dim.nz);
	}
}
void creatempitopology()
{
	//Create an MPI cartesian topology.

	int period[3];
	bool reorder;
	int dims[3];
	int temp;

	//number of partitions in a direction: 0=auto
	dims[0]=NP_X;
	dims[1]=NP_Y;
	dims[2]=NP_Z;

	//periodicity
	period[0]=false;
	period[1]=false;
	period[2]=false;

	//no reorder
	reorder=false;

	//create topology
	MPI_Dims_create (mpi.NProc, 3, dims);
	MPI_Cart_create (MPI_COMM_WORLD, 3, dims, period, reorder, (MPI_Comm*)(&mpi.COMM_CART));

	//Update rank to be current with the new topology.
	MPI_Comm_rank ((MPI_Comm)mpi.COMM_CART, &temp);
	mpi.MyRank = temp;

	//Figure out neighbors
	MPI_Cart_shift ((MPI_Comm)mpi.COMM_CART, 0, 1, &mpi.Neighbors[0], &mpi.Neighbors[1]);
	MPI_Cart_shift ((MPI_Comm)mpi.COMM_CART, 1, 1, &mpi.Neighbors[2], &mpi.Neighbors[3]);
	MPI_Cart_shift ((MPI_Comm)mpi.COMM_CART, 2, 1, &mpi.Neighbors[4], &mpi.Neighbors[5]);

}

void cartsize (int *x, int *y, int *z)
{
	//Gets size of the cartesian communicator.
	int per[3], dims[3], coords[3];
	MPI_Cart_get ((MPI_Comm)mpi.COMM_CART, 3, dims, per, coords);
	*x = dims[0];
	*y = dims[1];
	*z = dims[2];
	return;
}
int rankat (const int &x, const int &y, const int &z)
{
	//Gets the processor rank in the processor array, at position (x,y,z)
	//(processor coordinates)

	int per[3];
	int dims[3];
	int coords[3];
	int rank;
	MPI_Cart_get ((MPI_Comm)mpi.COMM_CART, 3, dims, per, coords);
	coords[0] = x;
	coords[1] = y;
	coords[2] = z;

	if ( ((x>=0&&x<dims[0])||(per[0])) && ((y>=0&&y<dims[1])||(per[1])) && ((z>=0&&z<dims[2])||(per[2])) )
		MPI_Cart_rank((MPI_Comm)mpi.COMM_CART, coords, &rank);
	else
		rank = -1;
	return rank;
}
void coordat (const int &rank, int *x, int *y, int *z)
{
	//Gets the coordinates for processor with rank rank. Output to x,y,z.
	int coords[3];
	if (rank >=0 && rank <mpi.NProc)
		MPI_Cart_coords ((MPI_Comm)mpi.COMM_CART, rank, 3, coords);
	else
		memset (coords, 255, 3*sizeof(int));
	*x = coords[0];
	*y = coords[1];
	*z = coords[2];
}
void bcastdata(void *data, const int &size)
{
	//Wrapper for MPI_Bcast
	MPI_Bcast (data, size, MPI_BYTE, 0, (MPI_Comm)mpi.COMM_CART);
}

/*
void sync()
{
	MPI_Barrier((MPI_Comm)mpi.COMM_CART);
}
*/
void dreduceloc (double *sendbuf, double *recvbuf, int &x, int &y, int &z, const int &op)
{
	//perform an operation on all processors and return one result in processor with rank=0.
	MPI_Op mpi_op;
	switch (op)
	{
		case OP_MAX:
			mpi_op = MPI_MAXLOC;
			break;
		case OP_MIN:
			mpi_op = MPI_MINLOC;
			break;
		default:
			return;
	}
	struct doubleuint snd, rcv;

	snd.value = *sendbuf;
	snd.loc = x + ((dim.fx+1)*y) + ((dim.fy+1)*(dim.fx+1)*z);
	MPI_Reduce (&snd, &rcv, 1, MPI_DOUBLE_INT, mpi_op, 0, (MPI_Comm)mpi.COMM_CART);
	x = rcv.loc % (dim.fx+1);
	rcv.loc /= (dim.fx+1);
	y = rcv.loc % (dim.fy+1);
	rcv.loc /= (dim.fy+1);
	z = rcv.loc;

	*recvbuf = rcv.value;
}
void dallreduceloc (double *sendbuf, double *recvbuf, int &x, int &y, int &z, const int &op)
{
	//perform an operation on all processors and return one result in all processors.
	MPI_Op mpi_op;
	switch (op)
	{
		case OP_MAX:
			mpi_op = MPI_MAXLOC;
			break;
		case OP_MIN:
			mpi_op = MPI_MINLOC;
			break;
		default:
			return;
	}
	struct doubleuint snd, rcv;

	snd.value = *sendbuf;
	snd.loc = x + ((dim.fx+1)*y) + ((dim.fy+1)*(dim.fx+1)*z);
	MPI_Allreduce (&snd, &rcv, 1, MPI_DOUBLE_INT, mpi_op, (MPI_Comm)mpi.COMM_CART);
	x = rcv.loc % (dim.fx+1);
	rcv.loc /= (dim.fx+1);
	y = rcv.loc % (dim.fy+1);
	rcv.loc /= (dim.fy+1);
	z = rcv.loc;

	*recvbuf = rcv.value;
}
void dreduce (double *sendbuf, double *recvbuf, const int &count, const int &op)
{
	//perform OP on all processors.
	MPI_Op mpi_op;
	switch (op)
	{
		case OP_SUM:
			mpi_op = MPI_SUM;
			break;
		case OP_MAX:
			mpi_op = MPI_MAX;
			break;
		case OP_MIN:
			mpi_op = MPI_MIN;
			break;
	}
	MPI_Reduce (sendbuf, recvbuf, count, MPI_DOUBLE, mpi_op, 0, (MPI_Comm)mpi.COMM_CART);
}
void dallreduce (double *sendbuf, double *recvbuf, const int &count, const int &op)
{
	//perform OP on all processors. Returns result to all processors.
	MPI_Op mpi_op;
	switch (op)
	{
		case OP_SUM:
			mpi_op = MPI_SUM;
			break;
		case OP_MAX:
			mpi_op = MPI_MAX;
			break;
		case OP_MIN:
			mpi_op = MPI_MIN;
			break;
		default:
			printf ("Error: Invalid reduce Op, %d\n", op);
			exit(1);
			return;
	}
	MPI_Allreduce (sendbuf, recvbuf, count, MPI_DOUBLE, mpi_op, (MPI_Comm)mpi.COMM_CART);
}

void mpigroup (MPI_Group group_name, MPI_Comm group_comm, int n_ranks, int *rank_list)
{
	//Check if group already exists
	for(int i=0; i<n_ranks; ++i)
	{
		
		
	}
	
	//Create a World_Group
	MPI_Group World_Group;
	MPI_Comm_group ((MPI_Comm)(mpi.COMM_CART), &World_Group);
	
		
	MPI_Group_incl(World_Group, n_ranks, rank_list, &group_name); // Creates a new group
	
	MPI_Comm_create_group(MPI_COMM_WORLD, group_name, 0, &group_comm); // Creates a communicator for the new group
	
	int group_rank, group_size; // Here we obtain the new group size and ranks
	MPI_Comm_rank(group_comm, &group_rank);
	MPI_Comm_size(group_comm, &group_size);
	
}

void senddata (void *array, const unsigned long &size, const int &destrank, const int &tag)
{
	if (destrank < 0) return;

	//Send count bytes in array to destrank.
	MPI_Status mpis;
	if (sbufsize[sbufp])	//non-zero means allocated and used.
		MPI_Wait (&smpirq[sbufp], &mpis);

	//Check for adequate buffer space.
	if (size > sbufsize[sbufp])
	{
		sbuffer[sbufp] = (char*)realloc (sbuffer[sbufp], size);
		sbufsize[sbufp] = size;
	}
	memcpy (sbuffer[sbufp], array, size);
	MPI_Isend (sbuffer[sbufp], size, MPI_BYTE, destrank, tag, (MPI_Comm)mpi.COMM_CART, &smpirq[sbufp]);
	sbufp = (sbufp+1)%MAXSBUF;
}
template <class T> void sendspace (T *array, const int &nx, const int &ny, const int &nz, const int &x1, const int &y1, const int &z1, const int &x2, const int &y2, const int &z2, const int &destrank, const int &tag)
{
	//Treat array as a 3 dimensional array of size nx*ny*nz.
	//Sends a rectangular portion of the 3D array bounded by (x1,y1,z1)-(x2,y2,z2), x1<=x2, y1<=y2, z1<=z2, inclusive.
	//Parameters are one-based indices.
	if (destrank < 0) return;

	MPI_Status mpis;
	if (sbufsize[sbufp])	//non-zero means allocated and used.
	{
		MPI_Wait (&smpirq[sbufp], &mpis);
	}
	//Use fortran convention for array indices. (1-based)

	if (x2 < x1) return;
	if (y2 < y1) return;
	if (z2 < z1) return;

	int sx = ((x2)-(x1)+1);
	int sy = ((y2)-(y1)+1);
	int sz = ((z2)-(z1)+1);
	unsigned long size = sx*sy*sz*sizeof(T)+sizeof(long);

	if (size > sbufsize[sbufp])
	{
		sbuffer[sbufp] = (char*)realloc(sbuffer[sbufp], size );
		sbufsize[sbufp] = size;
	}
	((long*)sbuffer[sbufp])[0] = size;
	T *pbuffer = (T*)(((char*)sbuffer[sbufp]) + sizeof(long));
	int i,j,k,i2,j2,k2;
	for (k=(z1)-1, k2=0; k<z2;k++, k2++)
		for (j=(y1)-1, j2=0; j<y2; j++, j2++)
			for (i=(x1)-1, i2=0; i<x2; i++, i2++)
				pbuffer [ i2 + j2*(sx) + k2*(sx)*(sy) ] = array [ i + j*(nx) + k*(nx)*(ny) ];
	MPI_Isend (sbuffer[sbufp], size, MPI_BYTE, destrank, SendTag(tag, destrank), (MPI_Comm)mpi.COMM_CART, &smpirq[sbufp]);
	sbufp = (sbufp+1)%MAXSBUF;
}
void sendwait()
{
	//waits for completion of non-blocking sends.
	MPI_Status mpis;
	for (int i=0;i<MAXSBUF;i++)
		if (sbufsize[i])
			MPI_Wait (&smpirq[i], &mpis);
}
void recvdata (void *array, const unsigned long &size, const int &srcrank, const int &tag)
{
	//Receive data into array.
	int lsrcrank = srcrank;
	int ltag = tag;

	if (srcrank == ANY_SOURCE) lsrcrank = MPI_ANY_SOURCE;
	if (srcrank == -1) return;
	if (tag == ANY_TAG) ltag = MPI_ANY_TAG;

	MPI_Status status;
	MPI_Recv (array, size, MPI_BYTE, lsrcrank, ltag, (MPI_Comm)mpi.COMM_CART, &status);
}

template <class T> void recvspace (T *array, const int &nx, const int &ny, const int &nz, const int &x1, const int &y1, const int &z1, const int &x2, const int &y2, const int &z2, const int &srcrank, const int &tag)
{
	//Receive a rectangular section of an array of the same size as to a corresponding call to sendspace.
	//Writes the received data into a section of the 3D array bounded by (x1,y1,z1)-(x2,y2,z2), x1<=x2, y1<=y2, z1<=z2, inclusive.
	//1-based indices!
	if (srcrank < 0) return;

	if (x2 < x1) return;
	if (y2 < y1) return;
	if (z2 < z1) return;

	int sx = ((x2)-(x1)+1);
	int sy = ((y2)-(y1)+1);
	int sz = ((z2)-(z1)+1);
	unsigned long size = sx*sy*sz*sizeof(T)+sizeof(long);

	if (size > bufsize)
	{
		buffer = (char*) realloc (buffer, size);
		bufsize = size;
	}

	MPI_Status status;
	MPI_Recv (buffer, size, MPI_BYTE, srcrank, RecvTag(tag,srcrank), (MPI_Comm)mpi.COMM_CART, &status);
	if (((unsigned long*)buffer)[0] != size)
	{
		printf ("ERROR: Requested receive message size incorrect\n");
		exit (-1);
	}
	T* pbuffer = (T*)(((char*)buffer)+sizeof(long));
	int i,j,k,i2,j2,k2;
	for (k=(z1)-1, k2=0; k<z2;k++, k2++)
		for (j=(y1)-1, j2=0; j<y2; j++, j2++)
			for (i=(x1)-1, i2=0; i<x2; i++, i2++)
				array [ i + j*(nx) + k*(nx)*(ny) ] = pbuffer [ i2 + j2*(sx) + k2*(sx)*(sy) ] ;
}
template <class T> void sendplanen(T *array, const int &direction, int Neighbors[6], const int &rnx, const int &rny, const int &rnz)
{
	//sends a plane to a neighbor. (the plane nearest to the neighbor that is "owned" by the current processor)

	//Directions:  1-6 as with Neighbors. (See input.h for Neigbors(1-6))

	int x1,y1,z1,  x2,y2,z2, tag;
	int nx=rnx, ny=rny, nz=rnz;
	tag = ((direction-1)+1)+10;
	switch (direction)
	{
		case 1:
			x1=2,  y1=1,  z1=1;
			x2=2,  y2=ny, z2=nz;
			break;
		case 2:
			x1=nx-1,  y1=1,  z1=1;
			x2=nx-1,  y2=ny, z2=nz;
			break;
		case 3:
			x1=1,  y1=2,  z1=1;
			x2=nx,  y2=2, z2=nz;
			break;
		case 4:
			x1=1,  y1=ny-1,  z1=1;
			x2=nx,  y2=ny-1, z2=nz;
			break;
		case 5:
			x1=1,  y1=1,  z1=2;
			x2=nx,  y2=ny, z2=2;
			break;
		case 6:
			x1=1,  y1=1,  z1=nz-1;
			x2=nx,  y2=ny, z2=nz-1;
			break;
	}
	sendspace<T> (array, nx, ny, nz, x1,y1,z1, x2,y2,z2, Neighbors[(direction)-1], tag);
}
template <class T> void sendplaneex (T *array, const int &direction, const int &rnx, const int &rny, const int &rnz)
{
	sendplanen<T> (array, direction, mpi.Neighbors, rnx,rny,rnz);
}
template <class T> void sendplane (T *array, const int &direction)
{
	sendplanen<T> (array, direction, mpi.Neighbors, dim.nx, dim.ny, dim.nz);
}
template <class T> void recvplane (T *array, const int &direction)
{
	recvplanen<T> (array, direction, mpi.Neighbors, dim.nx, dim.ny, dim.nz);
}
template <class T> void recvplanen (T *array, const int &direction, int Neighbors[6], const int &rnx, const int &rny, const int &rnz)
{
	int x1,y1,z1,  x2,y2,z2,  tag;
	int nx=rnx, ny=rny, nz=rnz;
	tag = ((direction-1)^1)+1+10;
	switch (direction)
	{
		case 1:
			x1=1,  y1=1,  z1=1;
			x2=1,  y2=ny, z2=nz;
			break;
		case 2:
			x1=nx,  y1=1,  z1=1;
			x2=nx,  y2=ny, z2=nz;
			break;
		case 3:
			x1=1,  y1=1,  z1=1;
			x2=nx,  y2=1, z2=nz;
			break;
		case 4:
			x1=1,  y1=ny,  z1=1;
			x2=nx,  y2=ny, z2=nz;
			break;
		case 5:
			x1=1,  y1=1,  z1=1;
			x2=nx,  y2=ny, z2=1;
			break;
		case 6:
			x1=1,  y1=1,  z1=nz;
			x2=nx,  y2=ny, z2=nz;
			break;
	}
	recvspace<T> (array, nx, ny, nz, x1,y1,z1, x2,y2,z2, Neighbors[(direction)-1], tag);
}
template <class T> void recvplaneex (T *array, const int &direction, const int &rnx, const int &rny, const int &rnz)
{
	recvplanen (array, direction, mpi.Neighbors, rnx, rny, rnz);
}

unsigned int wtime ()
{
	//Millisecond timer. Accuracy dependent on MPI_Wtime().
	static unsigned int st=(unsigned int)(MPI_Wtime()*1000+0.5);
	return (unsigned int)(MPI_Wtime()*1000-st+0.5);
}







//Asynchronous (non-blocking) receive routines:

//arecv--- functions instruct MPI to receive data. These functions are non-blocking and return before
//         the receive operation has completed.
//Use a call to arecvspacewait or arecvwait to wait for all pending receive operations to complete.
//arecv*wait functions return only after all outstanding receive operations have completed.
//If data was sent via sendplane/sendspace, then arecvspacewait should be used. arecvwait is intended
//to be used when matching a senddata, or when used by arecvspacewait.

#define MAXRECV 32					//Maximum number of 'in-flight' receive operations.
static bool abufinuse[MAXRECV]={0};
static unsigned long abufsize[MAXRECV]={0};
static char* abuffer[MAXRECV]={0};
static MPI_Request ampireq[MAXRECV];
struct ainf
{
	int nx, ny, nz;
	int x1,x2,y1,y2,z1,z2;
	int sx, sy, sz;
	void *dest;
	void *parecvspace2;	//pointer to template function to unpack spaces/planes.
}ainfo[MAXRECV];


template <class T> void arecvplane (T *array, const int &direction)
{
	arecvplanen<T> (array, direction, mpi.Neighbors, dim.nx, dim.ny, dim.nz);
}
template <class T> void arecvplanen (T *array, const int &direction, int Neighbors[6], const int &rnx, const int &rny, const int &rnz)
{
	int x1,y1,z1,  x2,y2,z2,  tag;
	int nx=rnx, ny=rny, nz=rnz;
	tag = ((direction-1)^1)+1+10;
	switch (direction)
	{
		case 1:
			x1=1,  y1=1,  z1=1;
			x2=1,  y2=ny, z2=nz;
			break;
		case 2:
			x1=nx,  y1=1,  z1=1;
			x2=nx,  y2=ny, z2=nz;
			break;
		case 3:
			x1=1,  y1=1,  z1=1;
			x2=nx,  y2=1, z2=nz;
			break;
		case 4:
			x1=1,  y1=ny,  z1=1;
			x2=nx,  y2=ny, z2=nz;
			break;
		case 5:
			x1=1,  y1=1,  z1=1;
			x2=nx,  y2=ny, z2=1;
			break;
		case 6:
			x1=1,  y1=1,  z1=nz;
			x2=nx,  y2=ny, z2=nz;
			break;
	}
	arecvspace<T> (array, nx, ny, nz, x1,y1,z1, x2,y2,z2, Neighbors[(direction)-1], tag);

}
template <class T> void arecvplaneex (T *array, const int &direction, const int &rnx, const int &rny, const int &rnz)
{
	arecvplanen<T> (array, direction, mpi.Neighbors, rnx, rny, rnz);
}
template <class T> int arecvspace (T *array, const int &nx, const int &ny, const int &nz, const int &x1, const int &y1, const int &z1, const int &x2, const int &y2, const int &z2, const int &srcrank, const int &tag)
{
	if (srcrank < 0) return -1;

	if (x2 < x1) return -1;
	if (y2 < y1) return -1;
	if (z2 < z1) return -1;

	int sx = ((x2)-(x1)+1);
	int sy = ((y2)-(y1)+1);
	int sz = ((z2)-(z1)+1);
	unsigned long size = sx*sy*sz*sizeof(T)+sizeof(long);

	int bufi;
	for (bufi=0;bufi<MAXRECV;bufi++)
		if (!abufinuse[bufi]) break;
	if (bufi >= MAXRECV)
	{
		printf ("Too many non-blocking receives\n");
		exit (1);
	}
	abufinuse[bufi] = true;

	if (size > abufsize[bufi])
	{
		abuffer[bufi] = (char*) realloc (abuffer[bufi], size);
		abufsize[bufi] = size;
	}

	MPI_Irecv (abuffer[bufi], size, MPI_BYTE, srcrank, RecvTag(tag,srcrank), (MPI_Comm)mpi.COMM_CART, &ampireq[bufi]);

	ainfo[bufi].nx = nx;
	ainfo[bufi].ny = ny;
	ainfo[bufi].nz = nz;
	ainfo[bufi].sx = sx;
	ainfo[bufi].sy = sy;
	ainfo[bufi].sz = sz;
	ainfo[bufi].x1 = x1;
	ainfo[bufi].x2 = x2;
	ainfo[bufi].y1 = y1;
	ainfo[bufi].y2 = y2;
	ainfo[bufi].z1 = z1;
	ainfo[bufi].z2 = z2;
	ainfo[bufi].dest = (void*)array;
	ainfo[bufi].parecvspace2 = (void*)((void (*)(const int&, T*))tarecvspace2<T>);
	return bufi;
}
void arecvspace2 (const int &Handle)
{
	if (Handle < 0) return;
	if (!abufinuse[Handle]) return;
	void (*pfunc)(const int &, void*) = (void (*)(const int&, void*))ainfo[Handle].parecvspace2;
	pfunc(Handle, 0);
}
template <class T> void tarecvspace2 (const int &Handle, T* dummy)
{
	//Complete the RecvSpace operation by copying the received data into the array.
	if (Handle < 0) return;

	if (!abufinuse[Handle]) return;
	int nx = ainfo[Handle].nx;
	int ny = ainfo[Handle].ny;
	int nz = ainfo[Handle].nz;
	int sx = ainfo[Handle].sx;
	int sy = ainfo[Handle].sy;
	int sz = ainfo[Handle].sz;
	int x1 = ainfo[Handle].x1;
	int x2 = ainfo[Handle].x2;
	int y1 = ainfo[Handle].y1;
	int y2 = ainfo[Handle].y2;
	int z1 = ainfo[Handle].z1;
	int z2 = ainfo[Handle].z2;
	T *array = (T*)ainfo[Handle].dest;
	T *buffer = (T*)(((char*)abuffer[Handle])+sizeof(long));

	if (((long*)abuffer[Handle])[0] != (long)(sx*sy*sz*sizeof(T)+sizeof(long)))
	{
		printf ("ERROR: Requested receive message size incorrect\n");
		printf ("ERROR: Requested %d, Received %d bytes\n", (long)(sx*sy*sz*sizeof(T)+sizeof(long)), ((long*)abuffer[Handle])[0]);
		exit (-1);
	}
	int i,j,k,i2,j2,k2;
	for (k=(z1)-1, k2=0; k<z2;k++, k2++)
		for (j=(y1)-1, j2=0; j<y2; j++, j2++)
			for (i=(x1)-1, i2=0; i<x2; i++, i2++)
				array [ i + j*(nx) + k*(nx)*(ny) ] = buffer [ i2 + j2*(sx) + k2*(sx)*(sy) ] ;
	abufinuse[Handle] = false;
}

void arecvspacewait()
{
	//Wait until all receive operations have completed.
	//Will also do arecvspace2 on any recvspace operations.

	//abufinuse[] is used only for arecvspace operations.
	arecvwait();
	for (int i=0;i<MAXRECV;i++)
		if (abufinuse[i])		//assume that if there is an outstanding arecvspace, then
			arecvspace2(i);     //arecvwait will have ensured data for it is received.
}

void arecvwait()
{
	//Wait for all pending receive operations to complete.
	MPI_Status ms;
	for (int i=0;i<MAXRECV;i++)
		if (abufinuse[i])
		{
			MPI_Wait (&ampireq[i], &ms);
		}
}



//Modify tags to try to make every message have almost unique tags. Non-blocking
//messages sometimes arrive out of order if the tags are the same.
//Tags repeat every 16384 mesages to target processor.
int SendTag(int Tag, int rank)
{
	static short *tags=0;
	if (!tags)
	{
		tags = new short[mpi.NProc];
		memset (tags, 0, mpi.NProc*sizeof(short));
	}
	return (Tag&0xFFFF)|(((int)tags[rank])<<16);
	tags[rank] = (tags[rank]+1)&0x3FFF;	//try to avoid interference with special values of tag.
}
int RecvTag(int Tag, int rank)
{
	static short *tags=0;
	if (!tags)
	{
		tags = new short[mpi.NProc];
		memset (tags, 0, mpi.NProc*sizeof(short));
	}
	return (Tag&0xFFFF)|(((int)tags[rank])<<16);
	tags[rank] = (tags[rank]+1)&0x3FFF;
}

#ifdef rudman_fine
	//receive routine
	template <class T> void arecvplane_f (T *array, const int &direction)
	{
		arecvplanen<T> (array, direction, mpi.Neighbors, 2*dim.nx-2, 2*dim.ny-2, 2*dim.nz-2);
	}

	//send routine
	template <class T> void sendplane_f (T *array, const int &direction)
	{
		sendplanen<T> (array, direction, mpi.Neighbors, 2*dim.nx-2, 2*dim.ny-2, 2*dim.nz-2);
	}

//#ifdef __solid
//receive routines for 2nd layer of ghost cells
template <class T> void arecvplane2_f(T *array, const int &direction)
{
	int indx = MAX(0,MIN(direction-1,2))*(2*dim.ny)*(2*dim.nz)
		   + MAX(0,MIN(direction-3,2))*(2*dim.nx)*(2*dim.nz)
		   + MAX(0,MIN(direction-5,2))*(2*dim.nx)*(2*dim.ny);
	
	arecvplanen2 <T> (&(array[indx]),direction,mpi.Neighbors,2*dim.nx, 2*dim.ny, 2*dim.nz);
}

template <class T> void arecvplanen2(T *array, const int &direction, int Neighbors[6], const int &rnx, const int &rny, const int &rnz)
{
	int x1,y1,z1, x2,y2,z2,tag;
	int nx=rnx, ny=rny, nz=rnz; //nx is already 2*dim.nx here
	int gx, gy, gz;
	
	tag = ((direction-1)^1)+1+10;
	
	switch (direction)
	{
		case 1:
			x1=1, y1=1, z1=1;
			x2=1, y2=ny, z2=nz;
			break;
		case 2:
			x1=1, y1=1, z1=1;
			x2=1, y2=ny, z2=nz;
			break;
		case 3: 
			x1=1, y1=1, z1=1;
			x2=nx, y2=1, z2=nz;
			break;
		case 4:
			x1=1, y1=1, z1=1;
			x2=nx, y2=1, z2=nz;
			break;
		case 5:
			x1=1, y1=1, z1=1;
			x2=nx, y2=ny, z2=1;
			break;
		case 6:
			x1=1, y1=1, z1=1;
			x2=nx, y2=ny, z2=1;
			break;
	}
	
	gx=x2-x1+1, gy=y2-y1+1, gz=z2-z1+1;
	arecvspace <T> (array,gx,gy,gz,x1,y1,z1,x2,y2,z2,Neighbors[(direction)-1],tag);
}

//send routines for 2nd layer of ghost cells
template <class T> void sendplane2_f(T *array, T *gArray, T *pArray, const int &direction)
{
	sendplanen2<T> (array, gArray, pArray, direction, mpi.Neighbors, 2*dim.nx-2, 2*dim.ny-2, 2*dim.nz-2);
}

template <class T> void sendplanen2(T *array, T *gArray, T *pArray, const int &direction, int Neighbors[6], const int &rnx, const int &rny, const int &rnz)
{
	//array: physical array in cartesian 3D topology,
	//gArray: 2nd layer ghost cells 
	//pArray: decorated array to be sent  
	
	int x1,y1,z1,  x2,y2,z2, x3,y3,z3, x4,y4,z4,tag;
	int px,py,pz, gx,gy,gz; //dimensions of planArray and gArray
	int indx,indx1,indx2,indx3,indx4;
	
	int nx=rnx, ny=rny, nz=rnz;
	tag = ((direction-1)+1)+10;
	switch (direction)
	{
		case 1:
			x1=3,  y1=1,  z1=1;
			x2=3,  y2=ny, z2=nz;
			break;
		case 2:
			x1=nx-2,  y1=1,  z1=1;
			x2=nx-2,  y2=ny, z2=nz;
			break;
		case 3:
			x1=1,  y1=3,  z1=1;
			x2=nx,  y2=3, z2=nz;
			break;
		case 4:
			x1=1,  y1=ny-2,  z1=1;
			x2=nx,  y2=ny-2, z2=nz;
			break;
		case 5:
			x1=1,  y1=1,  z1=3;
			x2=nx,  y2=ny, z2=3;
			break;
		case 6:
			x1=1,  y1=1,  z1=nz-2;
			x2=nx,  y2=ny, z2=nz-2;
			break;
	}
	//bounds for planArray
	x3=1, y3=1, z3=1;
	x4=1+(x2-x1)*(nx+1)/(nx-1); y4=1+(y2-y1)*(ny+1)/(ny-1); z4=1+(z2-z1)*(nz+1)/(nz-1);
	//dimensions of planArray
	px=x4-x3+1, py=y4-y3+1, pz=z4-z3+1;
	
	//starting indx of pArray
	indx = MAX(0,MIN(1,(direction-1)/2))*(ny+2)*(nz+2)
	     + MAX(0,MIN(1,(direction-3)/2))*(nx+2)*(nz+2)
	     + MAX(0,MIN(1,(direction-5)/2))*(nx+2)*(ny+2);
	
	T *planArray = &(pArray[indx]);
	
	//first copy from physical cell
	int i,j,k, i2,j2,k2;
	
	for(k=z1-1,k2=(z2-z1)/(nz-1); k<z2; k++,k2++)
	 for(j=y1-1,j2=(y2-y1)/(ny-1); j<y2; j++,j2++)
	  for(i=x1-1,i2=(x2-x1)/(nx-1); i<x2; i++,i2++)
	  {
		  planArray[i2 + j2*(px) + k2*(px)*(py)]
			= array[i + j*(nx) + k*(nx)*(ny)];
	  }
	
	//decoration of planArray with ghost cell values
	switch (direction) {
		//i2,j2,k2: indices for planArray
		//i,j,k: indices for gArray
		
		case 1: case 2:
		//do nothing 
		break;
		
		case 3: case 4:
		indx1=0, indx2=(ny+2)*(nz+2); //indices of gArray
		gx=1, gy=ny+2, gz=nz+2; //dimensions of gArray
		
		i=0,i2=0, j=y1,j2=0;
		for(k=1,k2=1; k<nz+1; k++,k2++)
			planArray[i2 + j2*(px) +k2*(px)*(py)]
				= gArray[indx1 + i + j*(gx) + k*(gx)*(gy)];
		
		i2=nx+1;		
		for(k=1,k2=1; k<nz+1; k++,k2++)
			planArray[i2 + j2*(px) +k2*(px)*(py)]
				= gArray[indx2 + i + j*(gx) + k*(gx)*(gy)];
				
		break;
		
		case 5: case 6:
		//ghost cells in y-z plane
		indx1=0, indx2=(ny+2)*(nz+2);
		indx3=2*(ny+2)*(nz+2), indx4=2*(ny+2)*(nz+2)+(nx+2)*(nz+2);
		gx=1, gy=ny+2, gz=nz+2;
		
		i=0,i2=0, k=z1,k2=0;
		for(j=1,j2=1; j<ny+1; j++,j2++)
			planArray[i2 + j2*(px) +k2*(px)*(py)]
				= gArray[indx1 + i + j*(gx) + k*(gx)*(gy)];
				
		i2=nx+1;
		for(j=1,j2=1; j<ny+1; j++,j2++)
			planArray[i2 + j2*(px) +k2*(px)*(py)]
				= gArray[indx2 + i + j*(gx) + k*(gx)*(gy)];
				
		//2nd copying from ghost cells in x-z plane
		gx=nx+2, gy=1, gz=nz+2;
		j=0,j2=0, k=z1,k2=0;
		for(i=0,i2=0; i<nx+2; i++,i2++)
			planArray[i2 + j2*(px) +k2*(px)*(py)]
				= gArray[indx3 + i + j*(gx) + k*(gx)*(gy)];
		
		j2=ny+1;
		for(i=0,i2=0; i<nx+2; i++,i2++)
			planArray[i2 + j2*(px) +k2*(px)*(py)]
				= gArray[indx4 + i + j*(gx) + k*(gx)*(gy)];
				
		break;
	}//end switch
		    
	sendspace<T> (planArray, px, py, pz, x3,y3,z3, x4,y4,z4, Neighbors[(direction)-1], tag);
}

//for exchanges on standard grid
template <class T> void arecvplane2(T *array, const int &direction)
{
	int indx = MAX(0,MIN(direction-1,2))*(dim.ny+2)*(dim.nz+2)
		   + MAX(0,MIN(direction-3,2))*(dim.nx+2)*(dim.nz+2)
		   + MAX(0,MIN(direction-5,2))*(dim.nx+2)*(dim.ny+2);
	
	arecvplanen2 <T> (&(array[indx]),direction,mpi.Neighbors,dim.nx+2,dim.ny+2,dim.nz+2);
}

template <class T> void sendplane2 (T *array, T *gArray, T *pArray, const int &direction)
{
	sendplanen2<T> (array, gArray, pArray, direction, mpi.Neighbors, dim.nx, dim.ny, dim.nz);
}
//#endif	
#endif

#ifdef bl_mg
template <class T> void arecvplane_lev(const int &lev, T *array, const int &direction)
{
	arecvplanen<T>(array,direction,mpi.Neighbors,mg_bnd[lev][1],mg_bnd[lev][2],mg_bnd[lev][3]);
}

template <class T> void sendplane_lev (const int &lev, T *array, const int &direction)
{	
	sendplanen <T>(array,direction,mpi.Neighbors,mg_bnd[lev][1],mg_bnd[lev][2],mg_bnd[lev][3]);
}
#endif
